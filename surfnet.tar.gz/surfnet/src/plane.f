C**************************************************************************
C
C  PLANE.F  -  Program to generate a density array for a user-defined
C              plane
C
C**************************************************************************
C
C               R A Laskowski, University College, London, 1993
C
C----------------------------------------------------------------------+--- 
C
C Program description
C -------------------
C
C Program accepts equation of a plane and boundaries of a grid-box within
C which the plane is to be generated. Outputs a density map in one of
C several formats which, when displayed, produces the desired plane on the
C graphics.
C
C--------------------------------------------------------------------------
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.0     Original release version.                   4 May 1995 (RAL)
C v.1.3     Addition of option on type of map to be output.
C           Addition of Insight and Sybyl output maps.
C                                                       5 Dec 1995 (RAL)
C v.1.3.2   Bug-fix for CCP4 output: MAPRMS not defined, and routines to
C           calculate it added to GRHIST.
C                                                       6 Feb 1996 (RAL)
C
C v.1.4     Amendments to group map-generating routines together in
C           surfmaps.f.
C                                                      17 Jun 1996 (RAL)
C           Changes to make all filenames 120 characters long.
C                                                       5 Sep 1996 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Files
C -----
C
C 10  plane.den  - Output CCP4 density map
C 10  plane.grd  - Output InsightII grid file
C 10  plane.mbk  - Output Quanta brick file
C 10  plane.srf  - Output .srf file holding the arrays of density values
C ??  plane.cnt  - Output Sybyl contour file
C
C--------------------------------------------------------------------------
C
C
C Compilation and linking (on unix)
C -----------------------
C
C f77 -u -c plane.f
C f77 -u -c surfmaps.f
C f77 -o plane plane.o surfmaps.o
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines in surfmaps.f and use surfsyb.scr to link to the Sybyl
C library routines.
C
C If CCP4 density maps are to be generated, uncomment all the CCP4
C lines in surfmaps.f and use surfccp4.scr to link to the CCP4
C library routines.
C
C Subroutine calling tree
C -----------------------
C
C MAIN  --> PARAMS  --> FINKEY
C                   --> GETOUT  --> FINKEY
C                   --> READCH
C                   --> OPNERR
C
C           Read in coordinates and calculate grid bounds
C
C       --> INITS
C       --> GBOUND
C
C           Form the grid and write out denisty and brick map files
C
C       --> MAKEGR  --> GRIDUP
C       --> GRSCAL
C       --> WRIMAP  --> LIMTAR
C                   --> ADJARR
C                   --> GRHIST  --> SHSORT
C                   --> WRISRF
C                   --> COMPRS
C                   --> ASCDEN  --> CCP4 routines to write out density file
C                   --> MBRICK  --> CCP4 routines to read in density files
C                                   and write out brick files (for FRODO)
C                                   [This routine is no longer used]
C                   --> INSIGH
C                   --> QUANTA  --> GETHED
C                               --> MBRWRH
C                               --> MRDSE8
C                   --> SYBYL   --> XCCreate
C                               --> XCWrite
C                               --> XCClose
C
C
C----------------------------------------------------------------------+--- 


      PROGRAM SRFNET

CVAX      IMPLICIT NONE

      INCLUDE 'plane.inc'

CHANGE v.1.4-->
C      INTEGER       IMAP
C      REAL          ARRAY(MAXARR)
      INTEGER       IMAP, IUNIT
      LOGICAL       RAWDAT
      REAL          ARRAY(MAXARR), MAPTOT, MFACTR
CHANGE v.1.4<--
CHANGE v.1.4-->
CHANGE v.1.3-->
CC-Sybyl-->
CCSYBYL      REAL*8        SHEET(MXSHEE)
CC-Sybyl<--
CHANGE v.1.4<--

C---- Set flags indicating which routines will be linked in during 
C     compilation
CHANGE v.1.4-->
C      FROLNK = .FALSE.
CC---- CCP4-->
CCCP4      FROLNK = .TRUE.
CC---- CCP4<--
C      SYBLNK = .FALSE.
CC-Sybyl-->
CCSYBYL      SYBLNK = .TRUE.
CC-Sybyl<--
CCHANGE v.1.3<--
      CALL INTMAP(FROLNK,SYBLNK)
CHANGE v.1.4<--

C---- Read in the run parameters
      CALL PARAMS
CHANGE v.1.4-->
C      IF (IFAIL.NE.0) GO TO 999
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--

C---- Initialise run variables
      IMAP = 1
CHANGE v.1.3<--
      FILCNT = 'plane.cnt'
      FILDEN = 'plane.den'
      FILGRD = 'plane.grd'
CHANGE v.1.3<--
      FILMBK = 'plane.mbk'
      FILSRF = 'plane.srf'
      CALL INITS

C---- Calculate grid-box boundaries
      CALL GBOUND
CHANGE v.1.4-->
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--

C---- Form the grid-map of density values
CHANGE v.1.4-->
C      CALL MAKEGR(ARRAY,IMAP)
      CALL MAKEGR(ARRAY)
CHANGE v.1.4<--

CHANGE v.1.4-->
C---- Apply scaling factor to all map-points
      CALL GRSCAL(ARRAY,NPOINT(1)*NPOINT(2)*NPOINT(3),'S',.FALSE.,200.0,
     -    MAPTOT)
CHANGE v.1.4<--

C---- Calculate maximum and minimum values in map
CHANGE v.1.4-->
C      CALL GRHIST(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
C
CC---- Check that density file has points to be plotted
C      IF (NOPNT) THEN
C          PRINT*, '+*** Density file empty! Not written out'
C
CC---- Write out density and brick files
C      ELSE
C
CC----     Write the array to disk as a surface density file
C          PRINT*, 'Writing surface density file ...   ', IMAP
C          CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C
CCHANGE v.1.3-->
CC----     If the  density and brick files are actually required,
CC         then call the appropriate  routines and write them out
C          IF (FROMAP) THEN
C
CC----         Write the array to disk as a CCP4 density file
CC---- CCP4-->
CCCP4              PRINT*, 'Writing CCP4 density file ...   '
CCCP4              CALL ASCDEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCCP4     -            FILDEN,TITLE,LIM,IUVW,VALMAX,
CCCP4     -            VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)
CC---- CCP4<--
C
CC----         Write the array to disk as a FRODO brick file [Not used. Use 
CC             routines to convert  format to FRODO format]
CCFRODO          PRINT*, 'Writing brick file ...     ', IMAP
CCFRODO          CALL MBRICK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C          ENDIF
C
CC----     If InsightII grid files are required, then write these out
C          IF (INSMAP) THEN
C
CC----         Write the array to disk as a standard formatted
CC             InsightII grid file
C              PRINT*, 'Writing InsightII grid file ...   ', IMAP
C              CALL INSIGH(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -            IMAP,FILGRD,GRDSEP,VALMIN,VALMAX)
C          ENDIF
CCHANGE v.1.3<--
C
CC----     Write the array to disk as a Quanta density file
CCHANGE v.1.3-->
C          IF (QUAMAP) THEN
CCHANGE v.1.3<--
C              PRINT*, 'Writing brick file ...   ', IMAP
C              CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -            IMAP,FILMBK,GRDSEP,MAPAV,MAPMIN,
C     -            MAPMAX,VALMIN,VALMAX)
CCHANGE v.1.3-->
C          ENDIF
C
CC----     If Sybyl contour files are required, then write these out
C          IF (SYBMAP) THEN
C
CC----         Check that the sheet-size not larger than
CC             allowed in the parameters
C              IF (MXSHEE.GE.NPOINT(1) * NPOINT(2)) THEN
C
CC----             Write the array to disk as a Sybyl contour file
C                  PRINT*, 'Writing Sybyl contour file ...     ', IMAP
CC-Sybyl-->
CCSYBYL                  CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
CCSYBYL     -                NPOINT(3),IMAP,FILCNT,GRDSEP,MAPAV,
CCSYBYL     -                MAPMIN,MAPMAX,VALMIN,VALMAX,SHEET,TITLE,
CCSYBYL     -                IFAIL)
CC-Sybyl<--
C
CC----         If array not large enough, display error message
C              ELSE
C                  PRINT*, '*** ERROR. Array variable MXSHEE ',
C     -                'not large enough for sheets to be'
C                  PRINT*, '*          written out to Sybyl ',
C     -                'contour file', MXSHEE, NPOINT(1) * NPOINT(2)
C              ENDIF
C          ENDIF
CCHANGE v.1.3<--
C      ENDIF

C---- Write out the array in whichever output format is required
      IFRAG = 0
      IATYPE = 0
      ICOUNT = 0
      FRGFRQ = 0.0
      IUNIT = 10
      MFACTR = 1.0
      RAWDAT = .TRUE.
      FILTYP = 'S'
      CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,FILTYP,IMAP,IFRAG,
     -    IATYPE,ICOUNT,FRGFRQ,FILCNT,FILDEN,FILGRD,FILMBK,FILSRF,
     -    IUNIT,FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,
     -    RAWDAT,MFACTR,.FALSE.,.FALSE.,NOPNT,IFAIL)
CHANGE v.1.4<--

999   CONTINUE
CHANGE v.1.4-->
C      IF (IFAIL.EQ.0) THEN
      IF (.NOT.IFAIL) THEN
CHANGE v.1.4<--
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PARAMS  -  Read in the run parameters for the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PARAMS

CVAX      IMPLICIT NONE

      INCLUDE 'plane.inc'

CHANGE v.1.3-->
      CHARACTER*1   YESNO
CHANGE v.1.3<--
      INTEGER        I
      REAL           A, B, C, CX, CY, CZ, D, NMAG, WX, WY, WZ

C---- Accept input parameters
CHANGE v.1.4-->
      IFAIL = .FALSE.
CHANGE v.1.4<--
      PRINT*, 'Enter parameters defining plane: a, b, c, d'
      PRINT*, '   where eqtn of plane is  ax + by + cz = d'
      READ*, A, B, C, D

C---- Calculate unit vector perpendicular to this plane
      NMAG = SQRT(A * A + B * B + C * C)
      IF (NMAG.EQ.0.0) GO TO 900
      NORMX = A / NMAG
      NORMY = B / NMAG
      NORMZ = C / NMAG

C---- Find a point on the plane
      IF (C.NE.0.0) THEN
          QPOINT(1) = 0.0
          QPOINT(2) = 0.0
          QPOINT(3) = D / C
      ELSE
          QPOINT(1) = 0.0
          QPOINT(2) = D / B
          QPOINT(3) = 0.0
      ENDIF

C---- Print details
      PRINT*
      PRINT*, '    Unit vector normal to plane:', NORMX, NORMY, NORMZ
      PRINT*, '    Arbitrary point in plane:   ', (QPOINT(I), I = 1, 3)

C---- Accept coordinates of box-centre
      PRINT*
      PRINT*, 'Enter coordinates of centre of box'
      READ*, CX, CY, CZ

C---- Accept size of box
      PRINT*
      PRINT*, 'Enter size of box in each direction'
      READ*, WX, WY, WZ

C---- Find minimum and maximum coordinates
      VALMIN(1) = CX - WX / 2.0
      VALMIN(2) = CY - WY / 2.0
      VALMIN(3) = CZ - WZ / 2.0
      VALMAX(1) = CX + WX / 2.0
      VALMAX(2) = CY + WY / 2.0
      VALMAX(3) = CZ + WZ / 2.0

C---- Accept grid-separation
      PRINT*
      PRINT*, 'Enter grid separation'
      READ*, GRDSEP

CHANGE v.1.3-->
C---- Accept which output map format is required
      FROMAP = .FALSE.
      INSMAP = .FALSE.
      QUAMAP = .FALSE.
      SYBMAP = .FALSE.
      PRINT*, 'Enter map-format required: (Q)uanta, (C)CP4, (S)ybyl',
     -    ', (I)nsightII or (N)one'
      READ(*,110) YESNO
 110  FORMAT(A)
      IF (YESNO.EQ.'Q' .OR. YESNO.EQ.'q') THEN
          QUAMAP = .TRUE.
      ELSE IF (YESNO.EQ.'I' .OR. YESNO.EQ.'i') THEN
          INSMAP = .TRUE.
      ELSE IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          IF (FROLNK) THEN
              FROMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to  librar',
     -            'ies'
              PRINT*, '***          No  density maps will be produ',
     -            'ced'
          ENDIF
      ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
          IF (SYBLNK) THEN
              SYBMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to Sybyl libra',
     -            'ries'
              PRINT*, '***          No Sybyl contour maps will be prod',
     -            'uced'
          ENDIF
      ELSE IF (YESNO.EQ.'N' .OR. YESNO.EQ.'n') THEN
          PRINT*, '*** No map files required'
      ELSE
          PRINT*, '*** INVALID map format requested: [', YESNO, ']'
          PRINT*, '*** No map files will be written out.'
      ENDIF
CHANGE v.1.3<--

      GO TO 999

C---- Fatal errors
 900  CONTINUE
      PRINT*, '*** ERROR. Invalid plane. A,B,C,D =', A, B, C, D
      GO TO 990

 990  CONTINUE
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'plane.inc'

C---- Initialise variables
      RADIUS = GRDSEP
      KVALUE = - LOG (0.5) / (RADIUS * RADIUS)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GBOUND  -   Calculate boundaries for grid box
C
C--------------------------------------------------------------------------

      SUBROUTINE GBOUND

CVAX      IMPLICIT NONE

      INCLUDE 'plane.inc'
          
      INTEGER       ARSIZE, ICOORD, LOWER, UPPER
CHANGE v.1.4-->
C      LOGICAL       FIRST
CHANGE v.1.4<--
      REAL          RESD(3)

CHANGE v.1.4-->
C      DATA  FIRST / .TRUE./
CHANGE v.1.4<--

C---- Print boundaries entered by user
      PRINT 620, 'Min coords:         ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
      PRINT 620, 'Max coords:         ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      ARSIZE = 1

C---- Calculate the array size for the grid
      DO 600, ICOORD = 1, 3
          LOWER = 2 * ICOORD - 1
          UPPER = LOWER + 1

C----     Calculate lowest grid value for this coordinate
          LIM(LOWER) = INT(VALMIN(ICOORD) / GRDSEP)
          IF (VALMIN(ICOORD).GT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) + 1
          ELSE IF (VALMIN(ICOORD).LT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF
          IF (GAPMAP) LIM(LOWER) = LIM(LOWER) - IRANGE

C----     Calculate upper grid value for this coordinate
          LIM(UPPER) = INT(VALMAX(ICOORD) / GRDSEP)
          IF (VALMAX(ICOORD).GT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) + 1
          ELSE IF (VALMAX(ICOORD).LT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) - 1
          ENDIF
          IF (GAPMAP) LIM(UPPER) = LIM(UPPER) + IRANGE
      
C----     Calculate number of grid points required for this coordinate
          NPOINT(ICOORD) = LIM(UPPER) - LIM(LOWER) + 1
          ARSIZE = ARSIZE * NPOINT(ICOORD)
      
C----     Adjust the minimum and maximum values to correspond to the
C         grid limits
          VALMIN(ICOORD) = LIM(LOWER) * GRDSEP
          VALMAX(ICOORD) = LIM(UPPER) * GRDSEP
          RESD(ICOORD) = VALMAX(ICOORD) - VALMIN(ICOORD)
600   CONTINUE

C---- Check that array is not too large
      IF (ARSIZE.GT.MAXARR) THEN
          PRINT*, '*** Array required:', ARSIZE, '   is larger',
     -            ' than that allowed:', MAXARR
          PRINT*, '     Grid points:', (NPOINT(ICOORD), ICOORD = 1, 3)
          GO TO 990
      ENDIF
      VOLBOX = RESD(1) * RESD(2) * RESD(3)
      PRINT 620, 'Adjusted min:       ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
 620  FORMAT(1X,A,3F12.4)
      PRINT 620, 'Adjusted max:       ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      PRINT*
      PRINT 640, 'Grid separation:    ', GRDSEP
 640  FORMAT(1X,A,F12.4)
      PRINT*
      PRINT 660, 'Length:             ',
     -    (RESD(ICOORD), ICOORD = 1, 3), 'Volume:         ',
     -     VOLBOX
 660  FORMAT(1X,A,3F12.4,/,1X,A,F16.2)
      PRINT 680, NPOINT(1), NPOINT(2), NPOINT(3), ARSIZE
 680  FORMAT(/,1X,'Array size: ',I8,'  x',I8,'  x',I8,'  = ',I8,
     -    ' points',/) 
      GO TO 999

C---- Error conditions
CHANGE v.1.4-->
C 900  CONTINUE
C      PRINT*, '*** No atoms found to define grid boundary. Range ',
C     -    'given:', BOUNAT(1), '    to', BOUNAT(2)
C      GO TO 990
CHANGE v.1.4<--

990   CONTINUE
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MAKEGR  -  Form the grid of values
C
C--------------------------------------------------------------------------

CHANGE v.1.4-->
C      SUBROUTINE MAKEGR(ARRAY,IMAP)
      SUBROUTINE MAKEGR(ARRAY)
CHANGE v.1.4<--

CVAX      IMPLICIT NONE

      INCLUDE 'plane.inc'

CHANGE v.1.4-->
C      INTEGER       I, IMAP
      INTEGER       I
CHANGE v.1.4<--
      REAL          ARRAY(MAXARR)
          
C---- Initialise grid array
      DO 10, I = 1, MAXARR
          ARRAY(I) = 0.0
10    CONTINUE
      GRPTS = 0
      PRINT*
      PRINT*, 'Calculating density map ...'

C---- Loop through all the grid-points updating each one according to
C     distance from the plane
CHANGE v.1.4-->
C      CALL GRID(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
      CALL GRIDUP(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
CHANGE v.1.4<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GRIDUP  -  Update the grid-points according to
C                        distance from the plane
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      SUBROUTINE GRID(ARRAY,N1,N2,N3)
      SUBROUTINE GRIDUP(ARRAY,N1,N2,N3)
CHANGE v.1.4<--

CVAX      IMPLICIT NONE

      INCLUDE 'plane.inc'
          
      INTEGER       I, J, K, N1, N2, N3
      REAL          ADJUST, ARRAY(N1,N2,N3), CONST, DIST, PQ(3), R, RAD,
     -              X, Y, Z

C---- Initialise variables
      CONST = - KVALUE
      RAD = RADIUS

C---- Loop through the points in the z-direction
      DO 380, K = 1, N3
          Z = VALMIN(3) + (K - 1) * GRDSEP
          PQ(3) = QPOINT(3) - Z

C----     Loop in y-direction
          DO 360, J = 1, N2
              Y = VALMIN(2) + (J - 1) * GRDSEP
              PQ(2) = QPOINT(2) - Y

C----         Loop in x-direction
              DO 340, I = 1, N1
                  X = VALMIN(1) + (I - 1) * GRDSEP

C----             Calculate distance of point from plane

C----             Calculate vector PQ
                  PQ(1) = QPOINT(1) - X

C----             Calculate dot product PQ.n
                  DIST = PQ(1) * NORMX + PQ(2) * NORMY
     -                + PQ(3) * NORMZ

C----             If distance less than minus "width", set to high
                  R = DIST + RADIUS
                  IF (R.LE.0.0) THEN
                      ADJUST = 1.0
                  ELSE IF (R.GT.5.0 * RADIUS) THEN
                      ADJUST = 0.0
                  ELSE
                      ADJUST = EXP (CONST * R * R)
                  ENDIF

C----             Update grid point
                  ARRAY(I,J,K) = ADJUST
340           CONTINUE
360       CONTINUE
380   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutines WRISRF & GRHIST amended and moves to surfmaps.f
C Subroutine WRIMSK removed as not used
CHANGE v.1.4<--
CHANGE v.1.3-->
CHANGE v.1.4-->
C Subroutine INSIGH moved to surfmaps.f
CHANGE v.1.4<--
CHANGE v.1.3<--
