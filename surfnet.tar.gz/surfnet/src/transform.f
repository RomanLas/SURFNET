C*****************************************************************************
C*****************************************************************************
C********                                                           **********
C********     T   R   A   N   S   F   O   R   M   .   F   O   R     **********
C********                                                           **********
C*****************************************************************************
C*****************************************************************************
C
C                      R A Laskowski, University College London
C
C                                  September 1993
C
C---------------------------------------------------------------------------
C
C Program description
C -------------------
C
C Program to perform transform a supplied PDB file using a rotation matrix
C and translation vector stored in file transform.in.
C
C Files assigned prior to running the program are:
C
C 1 transform.in   - Input file containing the transformation that will
C                    line up the principal axes with the x-, y- and z-axes.
C 2 <infile.pdb>   - Input .pdb file holding the x-, y-, and z-coordinates
C                    of the molecule to be processed.
C 7 <outfile.pdb>  - Output file containing the transformed molecule(s)
C
C---------------------------------------------------------------------------
C
C Amendments
C ----------
C Amendments subsequent to v.1.3 are labelled by CHANGE v.m.n--> and
C CHANGE v.m.n<-- where m.n is the version number corresponding to the
C change
C
C v.1.3     Original release as part of version 1.3 of the SURFNET suite
C           of programs.                               12 Dec 1995 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Subroutine calling tree
C -----------------------
C
C MAIN
C
C--------------------------------------------------------------------------

      PROGRAM TRANSF

CVAX      IMPLICIT NONE

      CHARACTER*1  YESNO
      CHARACTER*24 COORDS
      CHARACTER*80 INFIL, IREC, OUTFIL
      INTEGER      I, ICOORD, J, LINE, NATOMS
      LOGICAL      BACKON, NORMAL
      REAL         BACKTR(3,3), CENTRE(3), COORD(3), EIGVEC(3,3),
     -             TCOORD(3), X, XMAX, XMIN, Y, YMAX, YMIN, Z, ZMAX,
     -             ZMIN

      DATA BACKTR / -0.707107, -0.353553,  0.612372,
     -               0.707107, -0.353553,  0.612372,
     -               0.0,       0.866025,  0.5       /

C---- Initialise variables
      NATOMS = 0
      NORMAL = .TRUE.

C---- Open input transformation file
      OPEN(UNIT=1, FILE='transform.in', STATUS='OLD',
CVAX     -     CARRIAGECONTROL='LIST',READONLY,
     -     ACCESS='SEQUENTIAL', FORM='FORMATTED', ERR=900)

C---- Read in the transformation
      LINE = 0
      DO 100, J = 1, 3
          LINE = LINE + 1
          READ(1,*) (EIGVEC(I,J), I = 1, 3)
 100  CONTINUE
      LINE = LINE + 1
      READ(1,*) (CENTRE(I), I = 1, 3)
      CLOSE(1)

C---- Accept name of input PDB file
      PRINT*, 'Enter name of .pdb file to be transformed'
      READ(*,110) INFIL
 110  FORMAT(A)

C---- Open input PDB file
      OPEN(UNIT=2, FILE=INFIL, STATUS='OLD', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL='LIST',READONLY,
     -     FORM='FORMATTED', ERR=904)

C---- Accept name of output PDB file
      PRINT*, 'Enter name of output file'
      READ(*,110) OUTFIL

C---- Open output PDB file
      OPEN(UNIT=7, FILE=OUTFIL, STATUS='UNKNOWN', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL='LIST',
     -     FORM='FORMATTED', ERR=906)

C---- Ask whether coordinates to be back-transformed as well
      PRINT*
      PRINT*, 'Back-transform coordinates for SURFPLOT - (Y/N/D)?'
      READ(*,110) YESNO
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
          BACKON = .TRUE.
      ELSE IF (YESNO.EQ.'D' .OR. YESNO.EQ.'d') THEN
          NORMAL = .FALSE.
      ELSE
          BACKON = .FALSE.
      ENDIF

C---- Loop through the coordinates in the input file
      LINE = 0
 200  CONTINUE
          READ(2,110,ERR=908,END=800) IREC
          LINE = LINE + 1
          IF (IREC(1:4).EQ.'ATOM' .OR. IREC(1:6).EQ.'HETATM') THEN
              NATOMS = NATOMS + 1
              READ(IREC,210,ERR=910) X, Y, Z
 210          FORMAT(30X,3F8.3)

C----         Tranform the coordinates to the new axes
              IF (NORMAL) THEN
                  COORD(1) = X - CENTRE(1)
                  COORD(2) = Y - CENTRE(2)
                  COORD(3) = Z - CENTRE(3)

C----             Apply rotation
                  DO 400, ICOORD = 1, 3
                      TCOORD(ICOORD)
     -                    = COORD(1) * EIGVEC(1,ICOORD)
     -                    + COORD(2) * EIGVEC(2,ICOORD)
     -                    + COORD(3) * EIGVEC(3,ICOORD)
400               CONTINUE

C----             If back-transformation required, then apply it
                  IF (BACKON) THEN
                      COORD(1) = TCOORD(1)
                      COORD(2) = TCOORD(2)
                      COORD(3) = TCOORD(3)
                      DO 500, ICOORD = 1, 3
                          TCOORD(ICOORD)
     -                        = COORD(1) * BACKTR(1,ICOORD)
     -                        + COORD(2) * BACKTR(2,ICOORD)
     -                        + COORD(3) * BACKTR(3,ICOORD)
500                   CONTINUE
                  ENDIF

C----         Transform using matrix from distrib.f
              ELSE
                  COORD(1) = X
                  COORD(2) = Y
                  COORD(3) = Z
                  DO 600, ICOORD = 1, 3
                      TCOORD(ICOORD)
     -                    = COORD(1) * EIGVEC(1,ICOORD)
     -                    + COORD(2) * EIGVEC(2,ICOORD)
     -                    + COORD(3) * EIGVEC(3,ICOORD)
     -                    + CENTRE(ICOORD)
 600              CONTINUE
              ENDIF

C----         Save the transformed coordinates
              X = TCOORD(1)
              Y = TCOORD(2)
              Z = TCOORD(3)

C----         Determine maximum and minimum coords
              IF (NATOMS.EQ.1) THEN
                  XMAX = X
                  YMAX = Y
                  ZMAX = Z
                  XMIN = X
                  YMIN = Y
                  ZMIN = Z
              ELSE
                  XMAX = MAX(X,XMAX)
                  YMAX = MAX(Y,YMAX)
                  ZMAX = MAX(Z,ZMAX)
                  XMIN = MIN(X,XMIN)
                  YMIN = MIN(Y,YMIN)
                  ZMIN = MIN(Z,ZMIN)
              ENDIF

C----         Write the transformed coordinates out to file
              WRITE(COORDS,720) (TCOORD(ICOORD), ICOORD = 1, 3)
 720          FORMAT(3F8.3)
              IREC(31:54) = COORDS
          ENDIF

C----     Write the record to the output file
          WRITE(7,110) IREC

C---- Loop back for next record
      GO TO 200

C---- Close the output file
 800  CONTINUE
      CLOSE(7)

C---- Print statistics
      IF (LINE.EQ.0) THEN
          PRINT*, '*** Input PDB file empty!'
          GO TO 999
      ENDIF
      IF (NATOMS.EQ.0) THEN
          PRINT*, '*** Input PDB has no ATOM or HETATM records!'
          GO TO 999
      ENDIF
      PRINT*, 'Number of lines read in:    ', LINE
      PRINT*, 'Number of atoms transformed:', NATOMS
      PRINT*
      PRINT*, 'Minimum coordinates:', XMIN, YMIN, ZMIN
      PRINT*, 'Maximum coordinates:', XMAX, YMAX, ZMAX

      GO TO 999

C---- Error messages
900   CONTINUE
      PRINT*, '*** Transformation file, transform.in, not found. ',
     -    'Program aborted.'
      GO TO 999

CHANGE v.1.4-->
C 902  CONTINUE
C      PRINT*, '*** Error reading transform.in at line ', LINE
C      GO TO 999
CHANGE v.1.4<--

 904  CONTINUE
      PRINT*, '*** Input PDB file not found. Program aborted.'
      GO TO 999

 906  CONTINUE
      PRINT*, '*** Unable to open output file', OUTFIL
      GO TO 999

 908  CONTINUE
      PRINT*, '*** Error reading PDB file at line ', LINE
      GO TO 999

 910  CONTINUE
      PRINT*, '*** Error in coordinates at line ', LINE
      GO TO 999

999   CONTINUE
      END

C---------------------------------------------------------------------------
