C**************************************************************************
C
C  SUBROUTINE ASCDEN  -   Write data out to direct-access binary density
C                         file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE ASCDEN(ARRAY,N1,N2,N3,FNAME,TITLE,LIM,IUVW,VALMAX,
     -    VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)

      IMPLICIT NONE

      CHARACTER*(*) FNAME, TITLE
CHANGE v.1.4-->
C      INTEGER       I, IMAP, IUVW(3), IW, LIM(6), N, N1, N2, N3, NW,
      INTEGER       IUVW(3), IW, LIM(6), N, N1, N2, N3, NW,
CHANGE v.1.4<--
     -              NSG, NXYZ(3), MODE
      REAL          ARRAY(N1,N2,N3), CC(6), MAPAV, MAPMAX, MAPMIN,
     -              MAPRMS, RHRMS, RL, RM, RU, SC, VALMAX(3), VALMIN(3)
            

C---- Calculate the number of points in each section
      N = (LIM(2) - LIM(1) + 1) * (LIM(4) - LIM(3) + 1)

C---- Set up header information
C---- Title, number of sections and fast, medium and slow axes
      NW = LIM(6) - LIM(5) + 1
      IUVW(1) = 1
      IUVW(2) = 2
      IUVW(3) = 3
      
C---- Number of x-, y-, and z-points, NSG, MODE and scale factor
      NXYZ(1) = N1 - 1
      NXYZ(2) = N2 - 1
      NXYZ(3) = N3 - 1
      NSG = 1
      MODE = 2
      SC = 1.0
  
C---- Cell coordinates
      CC(1) = VALMAX(1) - VALMIN(1)
      CC(2) = VALMAX(2) - VALMIN(2)
      CC(3) = VALMAX(3) - VALMIN(3)
      CC(4) = 90.0
      CC(5) = 90.0
      CC(6) = 90.0
  
C---- Lowest, highest, and mean values in map
      RHRMS = MAPRMS
      RL = MAPMIN
      RU = MAPMAX
      RM = MAPAV
  
C---- Write out header information
      CALL MWRHDL(2,FNAME,TITLE,NW,IUVW,NXYZ,LIM(5),LIM(1),
     -    LIM(2),LIM(3),LIM(4),CC,NSG,MODE)

C---- Loop for all sections
      DO 200, IW = 1, N3

C----     Write current section to disk
          CALL MSPEW(2,ARRAY(1,1,IW))
200   CONTINUE

C---- Close the density file. For O, if this is a surface or a gap map,
C     want to fix the mean at the desired van der Waals level (100.0),
C     with an apparent RMS deviation of 1.0
      CALL MCLOSC(2,RL,RU,RM,RHRMS)

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
