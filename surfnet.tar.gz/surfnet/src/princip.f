C*****************************************************************************
C*****************************************************************************
C************                                                   **************
C************     P   R   I   N   C   I   P   .   F   O   R     **************
C************                                                   **************
C*****************************************************************************
C*****************************************************************************
C
C             R A Laskowski, Birkbeck College, University of London
C
C                                  February 1990
C
C----------------------------------------------------------------------+---
C
C Program description
C -------------------
C
C Program to perform a principal components analysis on data supplied in
C input file (which should be a PDB format file). The output gives the
C eigenvalues and eigen vectors of the product moment matrix, and the
C equation of a best-fit plane to the atoms. Program plane.f can be run
C to generate a brick file giving the plane for display on Quanta, O, etc.
C
C The program also output the transformation (translation and rotation)
C that will line the principal axes of the molecule with the x- y- and
C z-axes. This transformation can be applied to any PDB file by running
C program transform.f.
C
C The program firstly calculates the centre of mass of the data points
C and then rescales the coordinates accordingly.
C
C It then forms the scalar products matrix, as defined below:
C
C             SUM(X * X)    SUM(X * Y)    SUM(X * Z)
C             SUM(Y * X)    SUM(Y * Y)    SUM(Y * Z)
C             SUM(Z * X)    SUM(Z * Y)    SUM(Z * Z)
C
C It then calculates the eigen values and eigen vectors for this matrix using
C the Numerical Recipes routine JACOBI. The eigen vectors give the direction
C cosines of the principal components.
C
C Files assigned prior to running the program are:
C
C 1 <filename.pdb> - Input .pdb file holding the x-, y-, and z-coordinates
C                    of the molecule to be processed.
C 7 plane.in       - Output file containing the equation of the best-fit
C                    plane in the format required by plane.f.
C 8 transform.in   - Output file containing the transformation that will
C                    line up the principal axes with the x-, y- and z-axes.
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments subsequent to v.1.3 are labelled by CHANGE v.m.n--> and
C CHANGE v.m.n<-- where m.n is the version number corresponding to the
C change
C
C v.1.3.4   Original release as part of version 1.3 of the SURFNET suite
C           of programs.                               12 Dec 1995 (RAL)
C           Output of "Q" to plane.in file as default file type for plane.f.
C                                                       5 Sep 1996 (RAL)
C v.1.4     Addition of RMSLIN to calculate rmsd of transformed coords
C           to x-axis.
C                                                      20 Sep 2007 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Compiling under g77:-
C
C f77 -Wimplicit -fbounds-check -o princip princip.f
C
C Subroutine calling tree
C -----------------------
C
C MAIN    --> GETPDB
C         --> PLANE    --> GETCOM
C                      --> SCPMAT
C                      --> JACOBI
C                      --> EIGSRT
C                      --> ORIEN3  --> VECPRD
C                                  --> DOT3
C         --> WRIPLN
C         --> WRITRN
C         --> GETRMS
C         --> RMSLIN
C
C--------------------------------------------------------------------------


      PROGRAM PRININ

CVAX      IMPLICIT NONE

      INTEGER    MAXPT
      PARAMETER (
     -           MAXPT  = 50000
     -          )

      INTEGER       NPOINT, ORDVEC(3)
      LOGICAL       IFAIL
      REAL          CENTRE(3), COORD(3,MAXPT), D, EIGVEC(3,3),
     -              EIGVAL(3), NORMAL(3), RMSDIF, XMAX, XMIN, YMAX,
     -              YMIN, ZMAX, ZMIN

C---- Initialise variables
      IFAIL = .FALSE.

C---- Read in data from PDB file
      CALL GETPDB(COORD,MAXPT,NPOINT,XMAX,XMIN,YMAX,YMIN,ZMAX,
     -    ZMIN,IFAIL)
      IF (IFAIL) GO TO 999

C---- Calculate the best-fit plane
      CALL PLANE(COORD,NPOINT,CENTRE,NORMAL,D,EIGVEC,EIGVAL,ORDVEC,
     -    IFAIL)
      IF (IFAIL) GO TO 999

C---- Write out best-fit plane parameters to file plane.in
      CALL WRIPLN(CENTRE,NORMAL,D,XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,
     -    IFAIL)
      IF (IFAIL) GO TO 999

C---- Write out transformation matrix to file transform.in
      CALL WRITRN(CENTRE,EIGVEC,EIGVAL,ORDVEC,IFAIL)
      IF (IFAIL) GO TO 999

C---- Calculate RMS distance of all points from best-fit plane
      CALL GETRMS(COORD,NPOINT,NORMAL,RMSDIF)
      PRINT*
      PRINT*, 'RMS difference from best-fit plane: ', RMSDIF

CHANGE v.1.4-->
C---- Calculate RMS distance of all points to the best fit line
      CALL RMSLIN(COORD,NPOINT,EIGVEC,ORDVEC,CENTRE,RMSDIF)
      PRINT*
      PRINT*, 'RMS difference from best-fit line: ', RMSDIF

CHANGE <--v.1.4

999   CONTINUE
      IF (IFAIL) THEN
          PRINT*, '***    Program terminated with error'
      ELSE
          PRINT*
          PRINT*, 'Program completed'
      ENDIF
      END


C**************************************************************************
C
C  SUBROUTINE GETPDB  -  Accept name of PDB file and read in all the
C                        atom coordinates
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETPDB(COORD,MAXPT,NPOINT,XMAX,XMIN,YMAX,YMIN,ZMAX,
     -    ZMIN,IFAIL)

      CHARACTER*80  FNAME, IREC
      INTEGER       LINE, MAXPT, NPOINT
      LOGICAL       IFAIL
      REAL          COORD(3,MAXPT), X, XMAX, XMIN, Y, YMAX, YMIN, Z,
     -              ZMAX, ZMIN

C---- Accept name of input PDB file
      PRINT*, 'Enter name of .pdb file'
      READ(*,10) FNAME
 10   FORMAT(A)

C---- Open data files
      OPEN(UNIT=1, FILE=FNAME, STATUS='OLD', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL='LIST',READONLY,
     -     FORM='FORMATTED', ERR=900)

C---- Read in coordinates
      LINE = 0
      NPOINT = 0
100   CONTINUE
          READ(1,10,ERR=904,END=200) IREC
          LINE = LINE + 1
          IF (IREC(1:4).EQ.'ATOM' .OR. IREC(1:6).EQ.'HETATM') THEN
              READ(IREC,110,ERR=904) X, Y, Z
 110          FORMAT(30X,3F8.3)
              NPOINT = NPOINT + 1
              IF (NPOINT.GT.MAXPT) GO TO 908
              COORD(1,NPOINT) = X
              COORD(2,NPOINT) = Y
              COORD(3,NPOINT) = Z
              IF (NPOINT.EQ.1) THEN
                  XMAX = X
                  YMAX = Y
                  ZMAX = Z
                  XMIN = X
                  YMIN = Y
                  ZMIN = Z
              ELSE
                  XMAX = MAX(X,XMAX)
                  YMAX = MAX(Y,YMAX)
                  ZMAX = MAX(Z,ZMAX)
                  XMIN = MIN(X,XMIN)
                  YMIN = MIN(Y,YMIN)
                  ZMIN = MIN(Z,ZMIN)
              ENDIF
          ENDIF
      GO TO 100

C---- All coordinates read in. Close datafile
200   CONTINUE
      CLOSE(1)
      IF (NPOINT.EQ.0) GO TO 910
      PRINT*, 'Number of points read in: ', NPOINT
       
      GO TO 999

C---- Error messages
900   CONTINUE
      PRINT*, '*** Input PDB file not found. Program aborted.'
      GO TO 990

904   CONTINUE
      PRINT*, '*** Error reading PDB file at line ', LINE + 1
      GO TO 990

CHANGE v.1.4-->
C 906  CONTINUE
C      PRINT*, '*** Error opening output file transform.in not found. ',
C     -        'Program aborted.'
C      GO TO 990
CHANGE v.1.4<--

 908  CONTINUE
      PRINT*, 'Number of data points exceeds allowed value:', MAXPT
      GO TO 990

 910  CONTINUE
      PRINT*, '*** No data points in PDB file'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PLANE  -  Calculate a best-fit plane through the supplied
C                       data points
C
C----------------------------------------------------------------------+---

      SUBROUTINE PLANE(COORD,NPOINT,CENTRE,NORMAL,D,EIGVEC,EIGVAL,
     -    ORDVEC,IFAIL)

      INTEGER       IORDER, NPOINT, NROT, ORIEN3, ORDVEC(3)
      LOGICAL       IFAIL
      REAL          CENTRE(3), COORD(3,NPOINT), D, EIGVEC(3,3),
     -              EIGVAL(3), MATRIX(3,3), NORMAL(3)

C---- Calculate centre of mass of points and adjust coords such that
C     CofM is at the origin
      CALL GETCOM(COORD,NPOINT,CENTRE)

C---- Calculate scalar products matrix
      CALL SCPMAT(COORD,NPOINT,MATRIX)

C---- Calculate eigen values and eigenvectors of matrix
      CALL JACOBI(MATRIX,3,3,EIGVAL,EIGVEC,IFAIL,NROT)
      IF (IFAIL) GO TO 900

C---- Sort the eigen vectors into descending order of eigen value
      CALL EIGSRT(EIGVAL,ORDVEC)

C---- Check whether the sorted eigenvectors make a right-handed set
      IORDER = ORIEN3(
     -    EIGVEC(1,ORDVEC(1)),EIGVEC(2,ORDVEC(1)),EIGVEC(3,ORDVEC(1)),
     -    0.0,0.0,0.0,
     -    EIGVEC(1,ORDVEC(2)),EIGVEC(2,ORDVEC(2)),EIGVEC(3,ORDVEC(2)),
     -    EIGVEC(1,ORDVEC(3)),EIGVEC(2,ORDVEC(3)),EIGVEC(3,ORDVEC(3)))

C---- If the sorted vectors don't make a right-handed set, then reverse the
C     signs on the third vector
      IF (IORDER.EQ.1) THEN
          EIGVEC(1,ORDVEC(3)) = - EIGVEC(1,ORDVEC(3))
          EIGVEC(2,ORDVEC(3)) = - EIGVEC(2,ORDVEC(3))
          EIGVEC(3,ORDVEC(3)) = - EIGVEC(3,ORDVEC(3))
      ENDIF

C---- Compute parameters of best-fit line
      NORMAL(1) = EIGVEC(1,ORDVEC(3))
      NORMAL(2) = EIGVEC(2,ORDVEC(3))
      NORMAL(3) = EIGVEC(3,ORDVEC(3))
      D = NORMAL(1) * CENTRE(1) + NORMAL(2) * CENTRE(2)
     -    + NORMAL(3) * CENTRE(3)

      GO TO 999

C---- Error messages
 900  CONTINUE
      PRINT*, '**** Error. Failed to find eigenvalues of matrix'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETCOM  -  Calculate centre of mass of supplied data points
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETCOM(COORD,NPOINT,CENTRE)

      INTEGER       IPT, NPOINT
      REAL          CENTRE(3), COORD(3,NPOINT), XSUM, YSUM, ZSUM

C---- Initialise values
      XSUM = 0.0
      YSUM = 0.0
      ZSUM = 0.0

C---- Loop through the data points
      DO 300, IPT = 1, NPOINT
          XSUM = XSUM + COORD(1,IPT)
          YSUM = YSUM + COORD(2,IPT)
          ZSUM = ZSUM + COORD(3,IPT)
300   CONTINUE

C---- Calculate centre of mass and adjust all coordinates accordingly
      CENTRE(1) = XSUM / REAL (NPOINT)
      CENTRE(2) = YSUM / REAL (NPOINT)
      CENTRE(3) = ZSUM / REAL (NPOINT)
      DO 400, IPT = 1, NPOINT
          COORD(1,IPT) = COORD(1,IPT) - CENTRE(1)
          COORD(2,IPT) = COORD(2,IPT) - CENTRE(2)
          COORD(3,IPT) = COORD(3,IPT) - CENTRE(3)
400   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SCPMAT  -  Calculate scalar products matrix from supplied
C                        coordinates
C
C----------------------------------------------------------------------+---

      SUBROUTINE SCPMAT(COORD,NPOINT,MATRIX)

      INTEGER       IPT, NPOINT
      REAL          COORD(3,NPOINT), MATRIX(3,3), XXSUM, XYSUM, XZSUM,
     -              YYSUM, YZSUM, ZZSUM


C---- Initialise values
      XXSUM = 0.0
      XYSUM = 0.0
      XZSUM = 0.0
      YYSUM = 0.0
      YZSUM = 0.0
      ZZSUM = 0.0

C---- Loop through all the data points
      DO 500, IPT = 1, NPOINT
          XXSUM = XXSUM + COORD(1,IPT) * COORD(1,IPT)
          XYSUM = XYSUM + COORD(1,IPT) * COORD(2,IPT)
          XZSUM = XZSUM + COORD(1,IPT) * COORD(3,IPT)
          YYSUM = YYSUM + COORD(2,IPT) * COORD(2,IPT)
          YZSUM = YZSUM + COORD(2,IPT) * COORD(3,IPT)
          ZZSUM = ZZSUM + COORD(3,IPT) * COORD(3,IPT)
500   CONTINUE

C---- Form the scalar products matrix
      MATRIX(1,1) = XXSUM
      MATRIX(1,2) = XYSUM
      MATRIX(1,3) = XZSUM
      MATRIX(2,1) = XYSUM
      MATRIX(2,2) = YYSUM
      MATRIX(2,3) = YZSUM
      MATRIX(3,1) = XZSUM
      MATRIX(3,2) = YZSUM
      MATRIX(3,3) = ZZSUM

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE EIGSRT  -  Sort the eigen vectors into descending order
C                        of eigen value
C
C----------------------------------------------------------------------+---

      SUBROUTINE EIGSRT(EIGVAL,ORDVEC)

      INTEGER       ORDVEC(3), I, ISWAP, J, K
      REAL          EIGVAL(3)

C---- Bubble sort the eigenvalues
      ORDVEC(1) = 1
      ORDVEC(2) = 2
      ORDVEC(3) = 3

C---- Repeate the sort twice
      DO 580, K = 1, 2
          DO 560, J = 1, 2
              DO 540, I = J + 1, 3
                  IF (EIGVAL(ORDVEC(I)).GT.EIGVAL(ORDVEC(J))) THEN
                      ISWAP = ORDVEC(I)
                      ORDVEC(I) = ORDVEC(J)
                      ORDVEC(J) = ISWAP
                  ENDIF
 540          CONTINUE
 560      CONTINUE
 580  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C     ******************************************************************
      SUBROUTINE JACOBI(A,N,NP,D,V,IFAIL,NROT)
C     ******************************************************************
C
C     THIS SUBROUTINE COMPUTES ALL EIGENVALUES AND VECTORS OF A REAL
C     SYMMETRIC MATRIX A USING THE JACOBI METHOD (Taken from Numerical
C     Recipes - Press et al.)
C
C     PARAMETERS:
C
C     A     = REAL SYMMETRIC MATRIX, WHICH IS OF SIZE N BY N, STORED IN
C             A PHYSICAL NP BY NP ARRAY. ON EXIT, ELEMENTS OF A ABOVE
C             THE DIAGONAL ARE DESTROYED.
C     N     = ON ENTRY, ORDER OF MATRIX A FOR WHICH COMPUTATIONS ARE
C             DONE. UNCHANGED ON EXIT.
C     NP    = PHYSICAL ARRAY SUBSCRIPTS OF MATRIX A. UNCHANGED ON EXIT.
C     D     = REAL ARRAY OF PHYSICAL DIMENSION NP WHICH, ON EXIT,
C             CONTAINS EIGENVALUES OF A IN ITS FIRST N ELEMENTS.
C     V     = REAL MATRIX WITH THE SAME LOGICAL AND PHYSICAL DIMENSIONS
C             AS A WHOSE COLUMNS CONTAIN, ON EXIT, THE NORMALIZED
C             EIGENVECTORS OF A.
C     IFAIL = FAILURE INDICATOR. THIS IS SET TO 0 FOR NORMAL RETURN, AND
C             TO 1 WHEN MORE THAN 50 * N(N-1)/2 ROTATIONS ARE NEEDED.
C     NROT  = COUNTER WHICH, ON EXIT, CONTAINS THE NUMBER OF ROTATIONS.
C
C     DURING COMPUTATION:
C
C     Z    = VECTOR WHICH ACCUMULATES TERMS OF FORM TA(PQ)
C     B    = VECTOR WHICH CONTAINS CURRENT EIGENVALUES OF A
C
C     OPERATION COUNT:
C
C     TYPICAL MATRICES REQUIRE 6 TO 10 SWEEPS OF N*(N-1)/2 JACOBI
C     ROTATIONS TO ACHIEVE CONVERGENCE, OR 3*N**2 TO 5*N**2
C     ROTATIONS. EACH ROTATION REQUIRES OF ORDER 6*N OPERATIONS, SO
C     THE TOTAL LABOR IS OF THE ORDER 18*N**3 TO 30*N**3.
C
C
      REAL              EMIN
      PARAMETER        (EMIN=1.0E-8)

      INTEGER          NMAX
      PARAMETER        (NMAX=100)

      INTEGER          I, IP, IQ, J, N, NP, NROT
      LOGICAL          IFAIL
      REAL             A(NP,NP), B(NMAX), C, D(NP), G, H, V(NP,NP), S,
     -                 SM, T, TAU, THETA, TRESH, Z(NMAX)

      IFAIL=.FALSE.

C
C   JACOBI METHOD NOT MOST EFFICIENT METHOD FOR MATRICES OF ORDER
C   GREATER THAN 10 ; MAXIMUM ALLOWED PRESET BY NMAX
C
      IF (N.GT.NMAX) THEN
          WRITE(6,10)
10        FORMAT(/' *** MAXIMUM NUMBER OF ELEMENTS EXCEEDED IN ',
     -    'SUBROUTINE JACOBI; CHANGE NMAX - RUN TERMINATED')
          STOP
      ENDIF
C
C   INITIALISE V TO THE IDENTITY MATRIX
C
      DO 12 IP=1,N
          DO 11 IQ=1,N
              V(IP,IQ)=0.0
11        CONTINUE
          V(IP,IP)=1.0
12    CONTINUE
C
C   INITIALISE B AND D TO THE DIAGONAL OF A AND Z TO 0.0
C
      DO 13 IP=1,N
          B(IP)=A(IP,IP)
          D(IP)=B(IP)
          Z(IP)=0.0
13    CONTINUE
C
C   START OF SWEEPS
C
      NROT=0
      DO 24 I=1,50
C
C---SUM OFF-DIAGONAL ELEMENTS OF MATRIX A
C
          SM=0.0
          DO 15 IP=1,N-1
              DO 14 IQ=IP+1,N
                  SM=SM+ABS(A(IP,IQ))
 14           CONTINUE
 15       CONTINUE
C
C---NORMAL RETURN ON QUADRATIC CONVERGENCE TO MACHINE UNDERFLOW
C
          IF (SM.EQ.0.0) RETURN
C
C---SET TRESHOLD
C
C---ON THE FIRST THREE SWEEPS
          IF (I.LT.4) THEN
              TRESH=0.2*SM/N**2
          ELSE

C---THEREAFTER
              TRESH=0.0
          ENDIF

C---PERFORM PQ ROTATIONS
C
          DO 22 IP=1,N-1
              DO 21 IQ=IP+1,N
                  G=100.0*ABS(A(IP,IQ))

C---AFTER 4 SWEEPS, SKIP ROTATION IF THE OFF-DIAGONAL ELEMENT IS SMALL
                  IF ( (I.GT.4) .AND. (ABS(D(IP))+G.EQ.ABS(D(IP)))
     -                .AND. (ABS(D(IQ))+G.EQ.ABS(D(IQ))) ) THEN
                      A(IP,IQ)=0.0

C---OTHERWISE ROTATE DEPENDENT ON THE TRESHOLD
                  ELSE IF (ABS(A(IP,IQ)).GT.TRESH) THEN
                      H=D(IQ)-D(IP)
                      IF (ABS(H).LT.EMIN) H = 0.0
                      IF (ABS(H)+G.EQ.ABS(H)) THEN

C   T=1/(2THETA)
                          T=A(IP,IQ)/H
                      ELSE

C   T=SIGN(THETA) / (ABS(THETA)+ SQRT(THETA**2 + 1))
                          THETA=0.5*H/A(IP,IQ)
                          T=1.0/(ABS(THETA)+SQRT(1.0+THETA**2))
                          IF (THETA.LT.0.0) T=-T
                      ENDIF
                      C=1.0/SQRT(1+T**2)
                      IF (ABS(C).LT.EMIN) C = 0.0
                      S=T*C
                      IF (ABS(S).LT.EMIN) S = 0.0
                      TAU=S/(1.0+C)
                      IF (ABS(TAU).LT.EMIN) TAU = 0.0
                      H=T*A(IP,IQ)
                      IF (ABS(H).LT.EMIN) H = 0.0
                      Z(IP)=Z(IP)-H
                      IF (ABS(Z(IP)).LT.EMIN) Z(IP) = 0.0
                      Z(IQ)=Z(IQ)+H
                      IF (ABS(Z(IQ)).LT.EMIN) Z(IQ) = 0.0
                      D(IP)=D(IP)-H
                      IF (ABS(D(IP)).LT.EMIN) D(IP) = 0.0
                      D(IQ)=D(IQ)+H
                      IF (ABS(D(IQ)).LT.EMIN) D(IQ) = 0.0
                      A(IP,IQ)=0.0

C   CASE OF ROTATIONS 1.LE.J.LT.P
                      DO 16 J=1,IP-1
                          G=A(J,IP)
                          IF (ABS(G).LT.EMIN) G = 0.0
                          H=A(J,IQ)
                          IF (ABS(H).LT.EMIN) H = 0.0
                          A(J,IP)=G-S*(H+G*TAU)
                          IF (ABS(A(J,IP)).LT.EMIN) A(J,IP) = 0.0
                          A(J,IQ)=H+S*(G-H*TAU)
                          IF (ABS(A(J,IQ)).LT.EMIN) A(J,IQ) = 0.0
16                    CONTINUE

C   CASE OF ROTATIONS P.LT.J.LT.Q
                      DO 17 J=IP+1,IQ-1
                          G=A(IP,J)
                          H=A(J,IQ)
                          A(IP,J)=G-S*(H+G*TAU)
                          IF (ABS(A(IP,J)).LT.EMIN) A(IP,J) = 0.0
                          A(J,IQ)=H+S*(G-H*TAU)
                          IF (ABS(A(J,IQ)).LT.EMIN) A(J,IQ) = 0.0
17                    CONTINUE

C   CASE OF ROTATIONS Q.LT.J.LE.N
                      DO 18 J=IQ+1,N
                          G=A(IP,J)
                          H=A(IQ,J)
                          A(IP,J)=G-S*(H+G*TAU)
                          IF (ABS(A(IP,J)).LT.EMIN) A(IP,J) = 0.0
                          A(IQ,J)=H+S*(G-H*TAU)
                          IF (ABS(A(IQ,J)).LT.EMIN) A(IQ,J) = 0.0
18                    CONTINUE
                      DO 19 J=1,N
                          G=V(J,IP)
                          H=V(J,IQ)
                          V(J,IP)=G-S*(H+G*TAU)
                          IF (ABS(V(J,IP)).LT.EMIN) V(J,IP) = 0.0
                          V(J,IQ)=H+S*(G-H*TAU)
                          IF (ABS(V(J,IQ)).LT.EMIN) V(J,IQ) = 0.0
19                    CONTINUE
                      NROT=NROT+1
                  ENDIF
21            CONTINUE
22        CONTINUE

C---END OF PQ ROTATIONS
C

C---UPDATE D WITH THE SUM OF TA(PQ) AND REINITIALIZE Z TO 0.0
C
          DO 23 IP=1,N
              B(IP)=B(IP)+Z(IP)
              D(IP)=B(IP)
              Z(IP)=0.0
23        CONTINUE
24    CONTINUE

C   END OF SWEEPS
C
C---ABNORMAL RETURN; 50 SWEEPS IN JACOBI SHOULD NEVER HAPPEN
C
      IFAIL=.TRUE.
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION ORIEN3  -  Returns the orientation of the polygon with the
C                      consecutive vertices (x1,y1,z1), (x2,y2,z2), and
C                      (x3,y3,z3) as viewed from (ex,ey,ez).
C
C                      -1  :  clockwise orientation
C                      +1  :  anti-clockwise orientation (desired order)
C                       0  :  degenerate (line or point)
C
C [Taken from Angell I O & Griffith G (1987). High-resolution Computer
C  Graphics using FORTRAN 77. Macmillan Education Ltd, Basingstoke, UK.]
C
C----------------------------------------------------------------------+---

      INTEGER FUNCTION ORIEN3(X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3,EX,EY,EZ)

      REAL          A, B, C, DOT3, DX1, DY1, DZ1, DX2, DY2, DZ2,
     -              EX, EY, EZ, FE, X1, Y1, Z1, X2, Y2, Z2, X3, Y3, Z3

C---- Initialise variables
      DX1 = X2 - X1
      DY1 = Y2 - Y1
      DZ1 = Z2 - Z1
      DX2 = X3 - X2
      DY2 = Y3 - Y2
      DZ2 = Z3 - Z2

C---- Calculate triple scalar product
      CALL VECPRD(DX1,DY1,DZ1,DX2,DY2,DZ2,A,B,C)
      FE = DOT3(A,B,C,EX-X1,EY-Y1,EZ-Z1)
      ORIEN3 = SIGN(1.0,FE)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE VECPRD  -  Calculates the vector product (vx,vy,vz) of
C                        two vectors (px,py,pz) and (qx,qy,qz)
C
C----------------------------------------------------------------------+---

      SUBROUTINE VECPRD(PX,PY,PZ,QX,QY,QZ,VX,VY,VZ)

      REAL          PX, PY, PZ, QX, QY, QZ, VX, VY, VZ

      VX = PY * QZ - PZ * QY
      VY = PZ * QX - PX * QZ
      VZ = PX * QY - PY * QX

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION DOT3  -  Returns the scalar product of the two vectors
C                    (x1,y1,z1) and (x2,y2,z2)
C
C----------------------------------------------------------------------+---

      REAL FUNCTION DOT3(X1,Y1,Z1,X2,Y2,Z2)

      REAL          X1, Y1, Z1, X2, Y2, Z2

      DOT3 = X1 * X2 + Y1 * Y2 + Z1 * Z2

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRIPLN  -  Write out best-fit plane parameters to file
C                        plane.in
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRIPLN(CENTRE,NORMAL,D,XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,
     -    IFAIL)

      INTEGER       I
      LOGICAL       IFAIL
      REAL          CENTRE(3), D, NORMAL(3), XMIN, XMAX, YMIN, YMAX,
     -              ZMIN, ZMAX

C---- Print normal and value of C of G
      PRINT*
      PRINT*, 'Normal to best-fit plane:', (NORMAL(I), I = 1, 3)
      PRINT*, 'Centre of gravity:       ', (CENTRE(I), I = 1, 3)

C---- Print equation of best-fit plane
      PRINT*
      PRINT*, 'Equation of best-fit plane is  ax + by + cz = d'
      PRINT*, '   where  a =', NORMAL(1)
      PRINT*, '          b =', NORMAL(2)
      PRINT*, '          c =', NORMAL(3)
      PRINT*, '          d =', D

C---- Open output file plane.in
      OPEN(UNIT=7, FILE='plane.in', STATUS='UNKNOWN',
     -     ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL='LIST',
     -     FORM='FORMATTED', ERR=900)

C---- Write out the parameters for program plane.f
      WRITE(7,110) (NORMAL(I), I = 1, 3), D, '      <- Eqtn of plane'
 110  FORMAT(4F12.6,A)
      WRITE(7,120) (CENTRE(I), I = 1, 3), '      <- Centre of gravity'
 120  FORMAT(3F12.6,A)
      WRITE(7,120) XMAX - XMIN, YMAX - YMIN, ZMAX - ZMIN,
     -    '      <- Extent of molecule'
      WRITE(7,130) 1.0, '      <- Grid-spacing (mesh size)'
 130  FORMAT(F12.6,A)
CHANGE v.1.3.4-->
      WRITE(7,150)
 150  FORMAT('Q   <- (C)CP4, (I)nsightII, (Q)uanta, (S)ybyl contour fi',
     -    'les, or (N)one')
CHANGE v.1.3.4<--

C---- Close the output file
      CLOSE(7)

      GO TO 999

C---- Error messages
 900  CONTINUE
      PRINT*, '*** Error opening output file plane.in not found. ',
     -        'Program aborted.'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRITRN  -  Write out transformation matrix to file transform.in
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRITRN(CENTRE,EIGVEC,EIGVAL,ORDVEC,IFAIL)

      INTEGER       I, J, ORDVEC(3)
      LOGICAL       IFAIL
      REAL          CENTRE(3), EIGVAL(3), EIGVEC(3,3)

C---- Open output file, transform.in
      OPEN(UNIT=8, FILE='transform.in', STATUS='UNKNOWN',
     -     ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL='LIST',
     -     FORM='FORMATTED', ERR=900)

C---- Print the eigen vectors, giving the transormation matrix for
C     putting the principal axes on the x-, y- and z-axes
      PRINT*
      PRINT*, 'Eigenvectors and eigenvalues:'
      PRINT*, '-----------------------------'
      DO 600, J = 1, 3
           PRINT*, (EIGVEC(I,ORDVEC(J)), I = 1,3), '   |',
     -         EIGVAL(ORDVEC(J))
           WRITE(8,*) (EIGVEC(I,ORDVEC(J)), I = 1,3), 
     -         '      <- Eigen vector', J
600   CONTINUE
      WRITE(8,*) (CENTRE(I), I = 1, 3), '      <- Centre of gravity'

C---- Close the output file
      CLOSE(8)

      GO TO 999

C---- Error messages
 900  CONTINUE
      PRINT*, '*** Error opening output file transform.in not found. ',
     -        'Program aborted.'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETRMS  -  Calculate the RMS distance of the atoms from the
C                        best-fit plane
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETRMS(COORD,NPOINT,NORMAL,RMSDIF)

      INTEGER       IPT, NPOINT
      REAL          COORD(3,NPOINT), DOTPRD, NORMAL(3),
     -              RMSDIF, VECTPQ(3)

C---- Initialise values
      RMSDIF = 0.0

C---- Loop through all the data points
      DO 1500, IPT = 1, NPOINT

C----     Calculate distance of point from plane

C----     Form vector between point and an arbitrary point in the plane
C         (here the CofG - now at the origin - is used as the arbitrary
C         point)
          VECTPQ(1) = COORD(1,IPT)
          VECTPQ(2) = COORD(2,IPT)
          VECTPQ(3) = COORD(3,IPT)

C----     Calculate dot product PQ.n
          DOTPRD = VECTPQ(1) * NORMAL(1) + VECTPQ(2) * NORMAL(2)
     -        + VECTPQ(3) * NORMAL(3)

C----     Add distance squared to RMS-diff summation
          RMSDIF = RMSDIF + DOTPRD * DOTPRD
1500  CONTINUE

C---- Calculate and print RMS difference
      RMSDIF = SQRT(RMSDIF / REAL(NPOINT))

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE RMSLIN  -  Calculate the RMS distance of the atoms from the
C                        best-fit line
C
C----------------------------------------------------------------------+---

      SUBROUTINE RMSLIN(COORD,NPOINT,EIGVEC,ORDVEC,CENTRE,RMSDIF)

      INTEGER       I, ICOORD, IPT, J, NPOINT, ORDVEC(3)
      REAL          CENTRE(3), COORD(3,NPOINT), EIGVEC(3,3),
     -              MATRIX(3,3), RMSDIF, TCOORD(3)

C---- Initialise values
      RMSDIF = 0.0

C---- Form the rotation matrix
      DO 200, J = 1, 3
          DO 100, I = 1, 3
              MATRIX(I,J) = EIGVEC(I,ORDVEC(J))
 100      CONTINUE
 200  CONTINUE

C---- Loop through all the data points
      DO 800, IPT = 1, NPOINT

C----     Apply rotation
          DO 400, ICOORD = 1, 3
              TCOORD(ICOORD)
     -            = COORD(1,IPT) * EIGVEC(1,ICOORD)
     -            + COORD(2,IPT) * EIGVEC(2,ICOORD)
     -            + COORD(3,IPT) * EIGVEC(3,ICOORD)
 400      CONTINUE

C----     Calculate distance of point from x-axis
          RMSDIF
     -         = RMSDIF + TCOORD(2) * TCOORD(2) + TCOORD(3) * TCOORD(3)
 800  CONTINUE

C---- Calculate and print RMS difference
      RMSDIF = SQRT(RMSDIF / REAL(NPOINT))

      RETURN
      END

C--------------------------------------------------------------------------
