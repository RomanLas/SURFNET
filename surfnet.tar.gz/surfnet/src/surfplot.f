C**************************************************************************
C
C  SURFPLOT.FOR  -  Plot of polygons, and other objects, in .grf files
C                   created by the 3D contouring program SURFACE.
C
C                   Output is a colour or black-and-white PostScript file
C                   called sadge.ps.
C
C                   Parameters governing the appearance of the objects
C                   plotted are defined in the file sadge.par
C                   (or, in latest version, surfnet.par).
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.0     Original release version.        Roman Laskowski  4 May 1995
C
C v.1.1     Amendments to Raster3D output. Bonds written out as round-
C           ended cylinders. Back walls written out.
C           Inclusion of file type J in bond-colouring.
C                                            Roman Laskowski  7 May 1995
C
C v.1.1.1   Minor bug-fix to help centre Raster3D pictures when back walls
C           included.
C           Amendment so that cartoon-plot shows outer boundaries of object.
C           Amendment so that bonds can be generated of a single colour by
C           entry of a -ve colour.
C           Bug-fix for Raster3D output to deal with hydrogens, coloured
C           white (COLOUR = 0), to prevent array-bound overflow.
C           Bug-fix for Raster3D output to prevent box-plots going out of
C           the field of view.
C           Bug-fix on background greys when one of the maps has no data.
C           Add wall-slabs to Raster3D output of box plots.
C           Addition of colour 13 for carbon atoms under Raster3D.
C           Amendment to accept type E files.
C           Fix of routines for 4-sided polygons (not previously used)
C           so that work correctly in colour.
C                                Roman Laskowski   10 May - 28 Jul 1995
C
C v.1.3.3   Addition of parameters defining the light position and the size
C           for the required Raster3D picture (in numbers of tiles in x
C           and y)
C           Reinstatement of old scale-calculation for Raster3D output.
C                                                      21 Mar 1996 (RAL)
C
C v.1.4     Removal of unused variables.
C                                                      17 Jun 1996 (RAL)
C           Addition of PDB-format output of vertex points (for use with
C           RASMOL, for example).
C                                                       7 Jul 1996 (RAL)
C           Bug-fix in format statement for light position to Raster3D
C           output file.
C           Write-out of wire-frame cages for Raster3D output.
C                                                       7 Aug 1996 (RAL)
C           Amendments to parameter-file reading routines for output
C           options.
C                                                      15 Aug 1996 (RAL)
C           Options for selecting which back-walls are required.
C           Option for making back-walls infinite planes in Raster3D.
C           Use of "line-width" definition for the atomic radii in file
C           types "A".
C           Rationalisation of line-widths in PostScript output to tie in
C           with bond-thicknesses in Raster3D output.
C           Additional file-type of "a", being the same as "A", but with
C           the atoms coloured according to B-factor (0-80).
C                                                   28-29 Aug 1996 (RAL)
C           Changes to make all filenames 120 characters long.
C                                                       5 Sep 1996 (RAL)
C           Bug-fix on foreground wireframes being plotted as black
C           surfaces when the 'G' option in use. Spotted by Andrew Wallace.
C                                                      22 Sep 1996 (RAL)
C v.1.4.1   Minor bug-fix to use of IFAIL.
C                                                       7 Nov 1996 (RAL)
C           Bug-fix on bond-colours not being picked up when switched off
C           in foreground.
C                                                      18 Nov 1996 (RAL)
C
C v.1.4.2   Minor bug-fix for writing out 4-sided polygons to the Raster3d
C           file (used only to write first triangle).
C                                                      13 Feb 1997 (RAL)
C           Bug-fix for negative line-widths on atom objects.
C                                                       5 Jun 1997 (RAL)
C
C v.1.5     Minor bug-fix to allow program to run if only a single vertex
C           present in the input file.
C                                                      20 Nov 1997 (RAL)
C           Addition of VRML output.
C                                                      25 Nov 1997 (RAL)
C           Amendment to ignore dittos option (used bu SURFNET only) in
C           OUTPUT FILES section of surfnet.par.
C                                                      14 Dec 1997 (RAL)
C v.1.6     Increase of array sizes.
C                                                      17 Jul 2000 (RAL)
C           Addition of extra colours for binding-sites database.
C                                                      27 Jul 2001 (RAL)
C v.1.6.1   Addition of vertex normals for solid surfaces output for
C           Raster3D to give better rendered surfaces.
C                                                      10 Jun 2002 (RAL)
C           Bug-fix. Program crashing when margin round object switched
C           off due to uninitialised variable MNLEN in BORDER.
C                                                      14 Nov 2003 (RAL)
C                                                      
C
C--------------------------------------------------------------------------
C
C Files
C -----
C
C  1   sadge.par       - File holding run parameters for program (ie file
C     (surfnet.par)      names, etc)
C  2  <user-defined>   - .grf files (one for each of the input density files)
C                        holding the polygons that defined the surfaces to be
C                        plotted
C  3  <user-defined>   - Original .pdb file of the protein structure in
C                        question
C 11  sadge.ps         - Output PostScript file (surfnet.ps)
C 12  sadge.r3d        - Output Raster3D file (surfnet.r3d)
C 13  sadge.pdb        - Output Rasmol file (surfnet.pdb)
C 14  sadge.wrl        - Output VRML file (surfnet.wrl)
C
C Compiling under g77:-
C
C f77 -Wimplicit -fbounds-check -o surfplot surfplot.f
C
C--------------------------------------------------------------------------
C
C
C Notes:- 1. If the colour is entered as -999 for the foreground object, the
C            object will not be displayed. Similarly, for the background
C            projections
C         2. For "atom" objects (displayed as spheres), if the colour is set
C            between -1 and -9, a single point will be plotted rather than a
C            sphere.
C         3. For SOLID surfaces, a negative colour will shade all polygons 
C            white, giving a sketched, cartoon appearance to the figure
C         4. For negative line widths, the line plotted is a dashed one. If
C            the object is a solid surface, then a negative line-width
C            makes the away-facing polygons be plotted in black (the usual
C            case is that they are not plotted at all as this keeps the
C            size of the PostScript file down).
C
C--------------------------------------------------------------------------
C
C Subroutine calling tree 
C -----------------------
C
C Simpleplot routines are shown in lower case
C Routines from Angell & Griffith are shown with 1st letter capitalized 
C
C MAIN    --> PARAMS  --> FINKEY
C                     --> GETOUT  --> FINKEY
C                                 --> READCH
C         --> INITS
C         --> PSOPEN
C         --> RASOPE
C         --> WRLOPE
C         --> MOLOPE
C         --> GETGRF  --> WHICHP
C         --> MOLOUT
C         --> APPLYT  --> ROTALL  --> ROTATE
C                     --> TRNALL  --> TRANSF
C         --> TRNMAT
C         --> BORDER  --> TRNALL  --> TRANSF
C                     --> MAXMIN
C                     --> TRANSF
C                     --> SETORG
C                     --> CONVRT
C         --> PLTPOL  --> PSCTXT
C                     --> PSCOMM
C                     --> DRBORD  --> PSLWID
C                                 --> PSHADE
C                                 --> PSCOLB
C                                 --> PSHADB
C                                 --> PSCOLR
C                                 --> PSBBOX
C                                 --> DRTICK  --> TRANSF
C                                             --> PSLINE
C                                 --> Normal
C                     --> TRNALL  --> TRANSF
C                     --> Projec
C                     --> WHSIDE  --> Iorien
C                     --> PRESRT
C                     --> SHELL
C                     --> SHPLOT  --> PSCOLB
C                                 --> PSHADB
C                                 --> NRMPOL  --> Normal
C                                 --> Ishade
C                                 --> PSHADE
C                                 --> TRANSF
C                                 --> GETSPC
C                                 --> PSLWID
C                                 --> PSPHCL
C                                 --> PSPHSC
C                                 --> PSPHSH
C                                 --> PSPHER
C                                 --> PSCSHD
C                                 --> PSCCSC
C                                 --> PSCCOL
C                                 --> PSCIRC
C                                 --> PSUCIR
C                                 --> PSETCL
C                                 --> PSTRI1
C                                 --> PSTRI2
C                                 --> PSTRI3
C                                 --> PSUBOX
C                                 --> PSDASH
C                                 --> PSLINE
C                     --> RASOUT  --> WRINRM  --> NRMPOL
C                     --> WRLOUT  --> GETSPC
C                                 --> WRLINE  --> WRLCOL
C                                 --> WRLSPH  --> WRLCOL
C                                 --> WRLCYL  --> WRLCOL
C                                             --> PRINCP  --> GETCOM
C                                                         --> SCPMAT
C                                                         --> JACOBI
C                                                         --> EIGSRT
C                                                         --> ORIEN3
C                                             --> WRLSPH  --> WRLCOL
C                                 --> OPDASH  --> WRLINE  --> WRLCOL
C                                 --> WRLTRI  --> WRLCOL
C         --> PSCLOS
C         --> CLOWRL
C
C
C--------------------------------------------------------------------------

      PROGRAM SRFPLT

      INCLUDE 'surfplot.inc'

CHANGE v.1.4-->
C      CHARACTER*1   DUMMY
CHANGE v.1.4<--
      INTEGER       IMAP

C---- Read in program parameters
      CALL PARAMS
      IF (IFAIL) GO TO 999

C---- Initialise all global variables
      CALL INITS

C---- Open PostScript file and write out header records
      CALL PSOPEN(PSFIL)
      IF (IFAIL) GO TO 999

C---- If outputting as a raster3d picture, open the file
      IF (RASTER) THEN
          CALL RASOPE(RASFIL)
          IF (IFAIL) GO TO 999
      ENDIF

CHANGE v.1.5-->
C---- If outputting as a VRML file, open the file
      IF (VRML) THEN
          CALL WRLOPE(WRLFIL,TITLE)
          IF (IFAIL) GO TO 999
      ENDIF
CHANGE v.1.5<--

CHANGE v.1.4-->
C---- If outputting as a PDB-format file for Rasmol, open the file
      IF (PDBOUT) THEN
          CALL MOLOPE(MOLFIL)
          IF (IFAIL) GO TO 999
      ENDIF
CHANGE v.1.4<--

C---- Read in each of the .grf files generated by program SURFACE
      DO 500, IMAP = 1, NMAP

C----     Read in all the polygons from the .grf file
          CALL GETGRF(IMAP)

500   CONTINUE

C---- Print the statistics of the polygons read in
      PRINT*, 'Total number of polygons read in:', TPOL
      PRINT*, '    Total lines:', TVERT, '        Total vertices:',
     -    TXTVRT
      PRINT*
      NPOL = TPOL
      NVERT = TVERT
      NXTVRT = TXTVRT
CHANGE v.1.1-->
      NEWVRT = NXTVRT
CHANGE v.1.1<--

C---- If no vertices, then stop here
CHANGE v.1.5-->
C      IF (NVERT.LE.1) THEN
      IF (NVERT.LT.1) THEN
CHANGE v.1.5<--
          PRINT*, 'No contour lines found. Nothing to plot.'
CHANGE v.1.1.1-->
C          PRINT*, 'Press RETURN'
C          READ(*,100) DUMMY
C 100      FORMAT(A)
CHANGE v.1.1.1<--

C---- Otherwise, plot the picture
      ELSE

CHANGE v.1.4-->
C----     If writing out as a PDB-format file for Rasmol, then write
C         out all the vertices as ATOM records
          IF (PDBOUT) CALL MOLOUT
CHANGE v.1.4<--

C----     Apply the user-defined transformations
          CALL APPLYT

C----     Calculate the transformation matrices
          CALL TRNMAT

C----     Find borders of object to be plotted
          CALL BORDER

C----     Plot the polygons
          CALL PLTPOL

C----     Close the PostScript file
          CALL PSCLOS

CHANGE v.1.5-->
C----     Close VRML file, if there is one
          IF (VRML) THEN
              CALL CLOWRL(CURCOL)
          ENDIF
CHANGE v.1.5<--

      ENDIF

 999  CONTINUE
      IF (IFAIL) THEN
          PRINT*, 'Program terminated with error'
      ELSE
          PRINT*, 'Program completed'
      ENDIF
      END

C----------------------------------------------------------------------+--- 
C**************************************************************************
C
C  SUBROUTINE PARAMS  -  Read in the run parameters for the program
C
C--------------------------------------------------------------------------

      SUBROUTINE PARAMS

      INCLUDE 'surfplot.inc'

      CHARACTER*1    YESNO
CHANGE v.1.4-->
C      CHARACTER*40   FNAME
      CHARACTER*3    PROJEC
CHANGE v.1.4<--
CHANGE v.1.3.3-->
C      INTEGER        ICOL, IMAP, LINE
CHANGE v.1.4-->
C      INTEGER        ICOL, IERR, IMAP, LINE
      INTEGER        ICOL, IERR, IMAP, IPOS, LINE
CHANGE v.1.4<--
CHANGE v.1.3.3<--
      REAL           FPARAM(NPARM,MXMAP)

C---- Initialise values
CHANGE v.1.4-->
      ATMRAD = 0.0
      BFLOOR = .FALSE.
      BRIGHT = .FALSE.
      BSITE = .FALSE.
      BLEFT = .FALSE.
      SLABFL = .FALSE.
      SLABRT = .FALSE.
      SLABLF = .FALSE.
CHANGE v.1.4<--
      NEWPAR = .FALSE.
      NMAP = 0
      LINE = 0
      PERSPC = .FALSE.
      PSFIL = 'sadge.ps'
      RASFIL = 'sadge.r3d'
      RASTER = .FALSE.
CHANGE v.1.4-->
      MOLFIL = 'sadge.pdb'
      PDBOUT = .FALSE.
CHANGE v.1.4<--
CHANGE v.1.5-->
      VRML = .FALSE.
      WRLFIL = 'sadge.wrl'
CHANGE v.1.5<--

C---- Open the new-format parameter file, surfnet.par
      OPEN(UNIT=1, FILE='surfnet.par', STATUS='OLD', FORM='FORMATTED',
     -     ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST', READONLY,
     -     ERR=100)
      NEWPAR = .TRUE.
      PSFIL = 'surfnet.ps'
      RASFIL = 'surfnet.r3d'
CHANGE v.1.4-->
      MOLFIL = 'surfnet.pdb'
CHANGE v.1.4<--
CHANGE v.1.5-->
      WRLFIL = 'surfnet.wrl'
CHANGE v.1.5<--

C---- Open the parameter file, sadge.par
 100  CONTINUE
      IF (.NOT.NEWPAR) THEN
          OPEN(UNIT=1, FILE='sadge.par', STATUS='OLD',
     -        FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST', READONLY,
     -     ERR=900)
      ENDIF

C---- Read in the title
      CALL FINKEY('TITLE',5,LINE)
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) TITLE
 110  FORMAT(A)
      PRINT*, 'Title: ', TITLE
      PRINT*

C---- Read in the names of the input files
      CALL GETOUT(FPARAM)

C---- Extract the relevant parameters for the files
      DO 200, IMAP = 1, NMAP
          MAPCOL(IMAP) = FPARAM(4,IMAP)
          MAPBAK(IMAP) = FPARAM(5,IMAP)
          MAPLIN(IMAP) = FPARAM(6,IMAP)
CHANGE v.1.4-->
          IF (FILTYP(IMAP).EQ.'A' .OR. FILTYP(IMAP).EQ.'a') THEN
              ATMRAD = MAX(ATMRAD,MAPLIN(IMAP))
          ENDIF
CHANGE v.1.4<--
 200  CONTINUE

C---- Read in the remaining parameters
CHANGE v.1.6-->
      RASTER = .FALSE.
CHANGE v.1.6<--

C---- Search through the file until find the keyword: SURFPLOT
      CALL FINKEY('SURFPLOT',8,LINE)

C---- Read in whether a colour PostScript file is to be produced
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) YESNO
CHANGE v.1.4-->
C      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
C          INCOLR = .TRUE.
C      ELSE
C          INCOLR = .FALSE.
C      ENDIF
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y' .OR.
     -    YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          INCOLR = .TRUE.
      ELSE
          INCOLR = .FALSE.
      ENDIF
CHANGE v.1.4<--

CHANGE v.1.6-->
C---- Check for special binding-sites definition
      IF (YESNO.EQ.'B' .OR. YESNO.EQ.'b') THEN
          INCOLR = .TRUE.
          BSITE = .TRUE.
      ENDIF
CHANGE v.1.6<--

C---- If special input of R or P, then output is either a Raster3d or
C     a PDB-format file
CHANGE v.1.4-->
C      IF (YESNO.EQ.'R' .OR. YESNO.EQ.'e') THEN
      IF (YESNO.EQ.'R' .OR. YESNO.EQ.'r') THEN
CHANGE v.1.4<--
          RASTER = .TRUE.
CHANGE v.1.6-->
C      ELSE
C          RASTER = .FALSE.
CHANGE v.1.6<--
      ENDIF
CHANGE v.1.4<--
      IF (YESNO.EQ.'P' .OR. YESNO.EQ.'p') THEN
          PDBOUT = .TRUE.
      ELSE
          PDBOUT = .FALSE.
      ENDIF
CHANGE v.1.4<--
CHANGE v.1.5-->
      IF (YESNO.EQ.'V' .OR. YESNO.EQ.'v') THEN
          VRML = .TRUE.
      ELSE
          VRML = .FALSE.
      ENDIF
CHANGE v.1.5<--

C---- Read in the background colour
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) BAKCOL
      IF (BAKCOL.LT.0 .OR. BAKCOL.GT.MXCOLS) BAKCOL = 0

C---- Read in the colour of the "walls" for the back projections
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) WALCOL
      IF (WALCOL.LT.0 .OR. WALCOL.GT.MXCOLS) WALCOL = 0

C---- Read in whether the 3 background orthographic projections are required
      LINE = LINE + 1
CHANGE v.1.4-->
C      READ(1,110,END=902,ERR=904) YESNO
C      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
C          BACKON = .TRUE.
C      ELSE
C          BACKON = .FALSE.
C      ENDIF
      READ(1,110,END=902,ERR=904) PROJEC
      YESNO = PROJEC(1:1)
      BACKON = .FALSE.
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y' .OR. YESNO.EQ.'A' .OR.
     -    YESNO.EQ.'a') THEN
          BFLOOR = .TRUE.
          BRIGHT = .TRUE.
          BLEFT = .TRUE.
          SLABFL = .TRUE.
          SLABRT = .TRUE.
          SLABLF = .TRUE.
      ELSE
          IPOS = INDEX(PROJEC,'F')
          IF (IPOS.GT.0) THEN
              BFLOOR = .TRUE.
              SLABFL = .TRUE.
          ENDIF
          IPOS = INDEX(PROJEC,'f')
          IF (IPOS.GT.0) SLABFL = .TRUE.
          IPOS = INDEX(PROJEC,'R')
          IF (IPOS.GT.0) THEN
              BRIGHT = .TRUE.
              SLABRT = .TRUE.
          ENDIF
          IPOS = INDEX(PROJEC,'r')
          IF (IPOS.GT.0) SLABRT = .TRUE.
          IPOS = INDEX(PROJEC,'L')
          IF (IPOS.GT.0) THEN
              BLEFT = .TRUE.
              SLABLF = .TRUE.
          ENDIF
          IPOS = INDEX(PROJEC,'l')
          IF (IPOS.GT.0) SLABLF = .TRUE.
      ENDIF
      IF (BFLOOR .OR. BRIGHT .OR. BLEFT .OR. SLABFL .OR.
     -    SLABRT .OR. SLABLF) BACKON = .TRUE.
CHANGE v.1.4<--

C---- Read in whether the foreground object is to be plotted
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) YESNO
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
          FRNTON = .TRUE.
      ELSE
          FRNTON = .FALSE.
      ENDIF

C---- Read in whether a border is required around the edges of the object
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) YESNO
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
          BORDON = .TRUE.
      ELSE
          BORDON = .FALSE.
      ENDIF

C---- Read in the standard atom radius for the spheres on the plot
      LINE = LINE + 1
CHANGE v.1.4-->
C      READ(1,*,END=902,ERR=904) ATMRAD
      READ(1,110,END=902,ERR=904) YESNO
CHANGE v.1.4<--

C---- Read in whether atom numbers are required
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) YESNO
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
          NUMBAT = .TRUE.
      ELSE
          NUMBAT = .FALSE.
      ENDIF

C---- Read in whether axes are to be fixed and transformations ignored
C     This option is usually set to Y for atom distributions and N for
C     surfaces and gaps
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) YESNO
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
          NOTRAN = .TRUE.
      ELSE
          NOTRAN = .FALSE.
      ENDIF

C---- Read in rotation required about the x-axis
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) XROT

C---- Read in rotation required about the y-axis
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) YROT

C---- Read in rotation required about the z-axis
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) ZROT

C---- Read in a transformation matrix
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) (TMATRX(ICOL,1,1,1), ICOL = 1, 3)
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) (TMATRX(ICOL,2,1,1), ICOL = 1, 3)
      LINE = LINE + 1
      READ(1,*,END=902,ERR=904) (TMATRX(ICOL,3,1,1), ICOL = 1, 3)

CHANGE v.1.3.3-->
C---- Read in location of the light-source for the picture
      LINE = LINE + 1
      READ(1,*,IOSTAT=IERR) LITEX, LITEY, LITEZ
      IF (IERR.NE.0) THEN
          LITEX = LIGHTX
          LITEY = LIGHTY
          LITEZ = LIGHTZ
      ELSE IF (LITEX.EQ.0.0 .AND. LITEY.EQ.0.0 .AND.
     -    LITEZ.EQ.0.0) THEN
          LITEX = LIGHTX
          LITEY = LIGHTY
          LITEZ = LIGHTZ
      ENDIF

C---- Read in the tile-size for the Raster3D output
      LINE = LINE + 1
      READ(1,*,IOSTAT=IERR) TILEX, TILEY
      IF (IERR.NE.0) THEN
          TILEX = RTILEX
          TILEY = RTILEY
      ELSE IF (TILEX.EQ.0 .AND. TILEY.EQ.0) THEN
          TILEX = RTILEX
          TILEY = RTILEY
      ENDIF
CHANGE v.1.3.3<--

CHANGE v.1.4-->
C---- Read in whether back walls in Raster3D are to be infinite in extent
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) YESNO
      IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
          WALINF = .TRUE.
      ELSE
          WALINF = .FALSE.
      ENDIF
CHANGE v.1.4<--

C---- Close input parameter file
      CLOSE(1)
      GO TO 999


C     E R R O R   C O N D I T I O N S

C---- Unable to open input parameters file
900   CONTINUE
      PRINT*, '**** Error opening parameter file, surfnet.par.'
      GO TO 990

C---- Parameter file incomplete 
902   CONTINUE
      PRINT 903, LINE
903   FORMAT(1X,'**** Premature end of file reached in parameter ',
     -       'file, surfnet.par/sadge.par, at line ', I2)
      GO TO 990

C---- Data format error in parameter file
904   CONTINUE
      PRINT 905, LINE
905   FORMAT(1X,'**** Data format error in parameter file, ',
     -    'surfnet.par/sadge.par, at line ',I2)
      GO TO 990

CHANGE v.1.4-->
CC---- Data format error in parameter file
C906   CONTINUE
C      PRINT 907, FNAME
C907   FORMAT(1X,'**** Improper filename: [',A,']')
C      GO TO 990
CHANGE v.1.4<--

C---- No density files to process
CHANGE v.1.4-->
C908   CONTINUE
C      PRINT 909
C909   FORMAT(1X,'**** No density files to process')
C      GO TO 990
C
CC---- No density files to process
C 910  CONTINUE
C      PRINT 909, MXMAP
C 911  FORMAT(1X,'**** Maximum number of input files exceeded:',I6)
C      GO TO 990
CHANGE v.1.4<--

990   CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE FINKEY  -  Find the required keyword in the parameter file
C
C----------------------------------------------------------------------+---

      SUBROUTINE FINKEY(KEY,LEN,LINE)

      CHARACTER*(*) KEY
      CHARACTER*80  IREC
      INTEGER       LEN, LINE

C---- Search through the file until find the keyword
      REWIND(1)
      LINE = 0
 100  CONTINUE
          LINE = LINE + 1
          READ(1,110,END=900) IREC
 110      FORMAT(A)
      IF (IREC(1:LEN).NE.KEY) GO TO 100

      GO TO 999

C---- Unable to find keyword
 900  CONTINUE
      PRINT*, ' *** ERROR. Unable to find keyword in surfnet.par/',
     -    'sadge.par: ', KEY

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETOUT  -  Get the names of the output files and their
C                        associated parameters
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETOUT(FPARAM)

      INCLUDE 'surfplot.inc'

      CHARACTER*1   INCHAR
      CHARACTER*20  CHNUMB
      CHARACTER*26  LOWER, UPPER
CHANGE v.1.4-->
C      CHARACTER*60  FNAME
C      CHARACTER*120 IREC
       CHARACTER*120 FNAME, IREC
CHANGE v.1.4<--
      INTEGER       ILEN, IMAP, INUM, IPARM, IPOS, ISTATE, LINE, LPOS,
     -              NDECPT, RERROR
      REAL          FPARAM(NPARM,MXMAP), VALUE

      DATA LOWER  / 'abcdefghijklmnopqrstuvwxyz' /
      DATA UPPER  / 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' /

C---- Initialise variables
      DO 80, IMAP = 1, MXMAP
          BGREY(IMAP) = .FALSE.
          DO 60, IPARM = 1, NPARM
              FPARAM(IPARM,IMAP) = 0.0
 60       CONTINUE
 80   CONTINUE
      IMAP = 0

C---- Search for the start of the output file names
      CALL FINKEY('OUTPUT FILES',12,LINE)

C---- Read through the names and store the details
 100  CONTINUE
          LINE = LINE + 1
          READ(1,110,END=500) IREC
 110      FORMAT(A)
          IF (IREC.EQ.' ') GO TO 500
          IPARM = 0
          ISTATE = 0

CHANGE v.1.5-->
C----     Check whether this is not a ditto entry
          IPOS = INDEX(IREC,'"')
          IF (IPOS.GT.0) GO TO 100
CHANGE v.1.5<--

C----     Retrieve the filename and generate the appropriate extensions
CHANGE v.1.4-->
C          FNAME = IREC(1:60)
C          ILEN = INDEX(FNAME,' ')
C          IF (ILEN.GT.0 .AND. ILEN.LT.37) THEN
          FNAME = IREC
          ILEN = INDEX(FNAME,' ') - 1
          IF (ILEN.GT.0 .AND. ILEN.LT.80) THEN
CHANGE v.1.4<--
              IMAP = IMAP + 1
              IF (IMAP.GT.MXMAP) GO TO 900
              WIRSOL(IMAP) = 'W'
CHANGE v.1.4-->
C              FNAME(ILEN:40) = '.grf'
C              FILGRF(IMAP) = FNAME
              FILGRF(IMAP) = FNAME(1:ILEN) // '.grf'
CHANGE v.1.4<--
              ISTATE = 1
          ELSE
              GO TO 908
          ENDIF

C----     Search for file type and other data
          IPOS = ILEN

C----     Loop through the characters in the line until end reached
 200      CONTINUE
              IPOS = IPOS + 1
              INCHAR = IREC(IPOS:IPOS)

C----         State 1 - Search for first non-blank character
              IF (ISTATE.EQ.1) THEN

C----             If this is not a space, check for letters
                  IF (INCHAR.NE.' ') THEN

C----                 If this is a percent-sign, convert to C
                      IF (INCHAR.EQ.'%') INCHAR = 'C'

C----                 If a lower case letter, then convert to upper case
CHANGE v.1.4-->
C                      IF (INCHAR.GE.'a' .AND. INCHAR.LE.'z') THEN
C                          LPOS = INDEX(LOWER,INCHAR)
C                          IF (LPOS.GT.0) INCHAR = UPPER(LPOS:LPOS)
C                      ENDIF
CHANGE v.1.4<--

C----                 If an upper case letter, then interpret
CHANGE v.1.4-->
C                      IF (INCHAR.GE.'A' .AND. INCHAR.LE.'Z') THEN
C                          IF (INCHAR.NE.'A' .AND. INCHAR.NE.'B' .AND.
                      IF ((LGE(INCHAR,'A') .AND. LLE(INCHAR,'Z')) .OR.
     -                    INCHAR.EQ.'a') THEN
                          IF (INCHAR.NE.'A' .AND. INCHAR.NE.'B' .AND.
     -                        INCHAR.NE.'a' .AND.
CHANGE v.1.4<--
     -                        INCHAR.NE.'C' .AND. INCHAR.NE.'J' .AND.
     -                        INCHAR.NE.'P' .AND. INCHAR.NE.'S' .AND.
CHANGE v.1.1.1-->
C     -                        INCHAR.NE.'N' .AND. INCHAR.NE.'G')
     -                        INCHAR.NE.'N' .AND. INCHAR.NE.'G' .AND.
     -                        INCHAR.NE.'E')
CHANGE v.1.1.1<--
     -                            GO TO 904
                          FILTYP(IMAP) = INCHAR
                          ISTATE = 2
                      ENDIF
                  ENDIF

C----         State 2 - Search for first digit of a number
              ELSE IF (ISTATE.EQ.2) THEN

C----             Check for a digit
                  IF (INCHAR.GE.'0' .AND. INCHAR.LE.'9') THEN
                      INUM = 1
                      CHNUMB = INCHAR
                      NDECPT = 0
                      ISTATE = 3

C----             Check for a minus or a plus sign
                  ELSE IF (INCHAR.EQ.'+' .OR. INCHAR.EQ.'-') THEN
                      INUM = 1
                      CHNUMB = INCHAR
                      NDECPT = 0
                      ISTATE = 3

C----             Check for a decimal point
                  ELSE IF (INCHAR.EQ.'.') THEN
                      INUM = 1
                      CHNUMB = INCHAR
                      NDECPT = 1
                      ISTATE = 3

C----             Check for a 'W' or an 'S' to indicate whether a wire-frame
C                 or solid object required here
                  ELSE

C----                 If a lower-case letter, convert to uppercase
                      IF (INCHAR.GE.'a' .AND. INCHAR.LE.'z') THEN
                          LPOS = INDEX(LOWER,INCHAR)
                          IF (LPOS.GT.0) INCHAR = UPPER(LPOS:LPOS)
                      ENDIF

C----                 If an upper case letter, then interpret
                      IF (INCHAR.EQ.'W' .OR. INCHAR.EQ.'S') THEN
                          WIRSOL(IMAP) = INCHAR
                      ELSE IF (INCHAR.EQ.'G') THEN
                          BGREY(IMAP) = .TRUE.
                      ENDIF
                  ENDIF

C----         State 3 - Storing characters making up a number
              ELSE IF (ISTATE.EQ.3) THEN

C----             If character is a number, add it to the number being built up
                  IF (INCHAR.LE.'9' .AND. INCHAR.GE.'0') THEN
                      INUM = INUM + 1
                      IF (INUM.LE.20) CHNUMB(INUM:INUM) = INCHAR

C----             If character is a decimal point, add on
                  ELSE IF (INCHAR.EQ.'.') THEN
                      IF (NDECPT.EQ.0 .AND. INUM.LE.20) THEN
                          INUM = INUM + 1
                          CHNUMB(INUM:INUM) = INCHAR
                          NDECPT = 1
                      ENDIF

C----             Otherwise, assume end of number reached, so convert
                  ELSE
                      IF (INUM.LT.20 .AND. NDECPT.EQ.0) THEN
                          CHNUMB(INUM+1:INUM+1) = '.'
                      ENDIF
                      CALL READCH(CHNUMB,VALUE,RERROR)
                      IF (RERROR.NE.0) GO TO 906
                      IPARM = IPARM + 1
                      IF (IPARM.LE.NPARM) THEN
                          FPARAM(IPARM,IMAP) = VALUE
                      ENDIF
                      ISTATE = 2
                  ENDIF
              ENDIF

C----     Loop back for the next character in this line
          IF (IPOS.LT.120) GO TO 200

C---- Loop back for the next line
      GO TO 100

C---- End of output files reached
 500  CONTINUE

C---- Check whether any output files supplied
      NMAP = IMAP
      IF (NMAP.EQ.0) GO TO 902

      GO TO 999

C---- Unable to find keyword
 900  CONTINUE
      PRINT*, '*** ERROR. Maximum number of maps exceeded:',
     -    MXMAP
      GO TO 990

 902  CONTINUE
      PRINT*, ' *** ERROR. No output filenames supplied'
      GO TO 990

C---- File type is not one of: A, B, C, G, J, N, P, S, or %
 904  CONTINUE
      PRINT*, '*** Error in file type for file', IMAP, '. ',
     -    FILGRF(IMAP)(1:ILEN)
      PRINT*, '*** File type must be one of: A, B, C, G, J, N, P, S' //
     -    ', or %'
      GO TO 990

 906  CONTINUE
      PRINT*, ' *** ERROR in number at line', LINE
      GO TO 990

 908  CONTINUE
      PRINT*, ' *** ERROR in filename at line', LINE
      PRINT*, ' *** Maximum 40 characters allowed. Length:', ILEN
      GO TO 990

 990  CONTINUE
CHECK v.1.4.1-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHECK v.1.4.1<--

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE READCH  -  Routine to convert character string to real number
C
C----------------------------------------------------------------------+---

      SUBROUTINE READCH(NUMB,A,RERROR)

      CHARACTER*4   EXPO
      CHARACTER*20  NUMB
      REAL          A, RPOWER
      INTEGER       EPOS, IPOWER, RERROR

      RERROR = 0
      EPOS = INDEX(NUMB,'E')
      IF (EPOS.GT.0) THEN
          READ(NUMB(1:EPOS - 1),160,ERR=904) A
160       FORMAT(F20.0)
          EXPO = NUMB(EPOS + 1:)
          EPOS = INDEX(EXPO,' ')
          IF (EPOS.GT.0) EXPO(EPOS:EPOS) = '.'
          READ(EXPO,160,ERR=904) RPOWER
          IPOWER = RPOWER
          A = A * 10.0 ** IPOWER
      ELSE
          READ(NUMB,160,ERR=904) A
      ENDIF

      GO TO 999

904   CONTINUE
      RERROR = 1

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

      INCLUDE 'surfplot.inc'
 
CHANGE v.1.4-->
C      INTEGER       ILINE, IPOL, IVERT
CHANGE v.1.6.1-->
C      INTEGER       ILINE, IMAP, IPOL, IVERT
      INTEGER       ICOMV, ILINE, IMAP, IPOL, IVERT
CHANGE v.1.6.1<--
CHANGE v.1.4<--

C---- Initialise variables
      IFAIL = .FALSE.
      DO 100, IPOL = 1, MXPOL
          IPOLYG(IPOL) = 0
CHANGE v.1.1.1-->
          POLCOL(IPOL) = 0
CHANGE v.1.1.1<--
          VISIBL(IPOL) = .FALSE.
 100  CONTINUE
      TPOL = 0
      TVERT = 0
      TXTVRT = 0
      DO 200, IVERT = 1, MXVERT
          VERTEX(1,IVERT) = 0.0
          VERTEX(2,IVERT) = 0.0
          VERTEX(3,IVERT) = 0.0
CHANGE v.1.6.1-->
          DO 150, ICOMV = 1, MXCOMV
              WHCHPL(ICOMV,IVERT) = 0
 150      CONTINUE
CHANGE v.1.6.1<--
 200  CONTINUE
      DO 300, ILINE = 1, MXLINE
          OTHPOL(ILINE) = 0
          VERTNO(ILINE) = 0
 300  CONTINUE
CHANGE v.1.4-->
      DO 400, IMAP = 1, MXMAP
          FSTVRT(IMAP) = 0
 400  CONTINUE
CHANGE v.1.4<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETGRF  -  Read in the polygons making up the surface for
C                        plotting. The polygons should have been generated
C                        by program SURFACE.FOR.
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GETGRF(IMAP)

CHANGE v.1.1.1-->
CHANGE v.1.6-->
C      SAVE
CHANGE v.1.6<--
CHANGE v.1.1.1<--

      INCLUDE 'surfplot.inc'

      CHARACTER*50  EMESS
CHANGE v.1.1.1-->
C      INTEGER       ATTYPE, ICOLR(MXCOLS), ICOORD, IMAP, INMAP, IPOL,
C     -              IVERT, NSTEP, OPOL, OVERT, OXTVRT
      INTEGER       ATTYPE, ICOLR(MXCOLS), ICOORD, IEND, IMAP, INMAP,
CHANGE v.1.4-->
C     -              IPOL, ISTART, IVERT, NCOL, NPOINT, NSTEP, OPOL,
C     -              OVERT, OXTVRT, SETCOL
     -              IPOL, ISTART, IVERT, LENSTR, NCOL, NPOINT, NSTEP,
     -              OPOL, OVERT, OXTVRT, SETCOL
CHANGE v.1.4<--
CHANGE v.1.1.1<--
CHECK v.1.4.1-->
      LOGICAL       SETBAK, SETFOR
CHECK v.1.4.1<--

CHANGE v.1.1.1-->
C      DATA ICOLR  / 0, 10, 8, 5, 1, 9, 7, 6, 3, 3, 3, 3 /
      DATA ICOLR  / 0, 10, 8, 5, 1, 9, 6, 6, 3, 3, 3, 3, 13 /
CHANGE v.1.1.1<--
 
      DATA OPOL, OVERT, OXTVRT / 3*0 /

CHANGE v.1.1.1-->
C---- Initialise map start-point
      MAPFST(IMAP) = TPOL + 1
CHANGE v.1.1.1<--
CHANGE v.1.4-->
      FSTVRT(IMAP) = TXTVRT
CHANGE v.1.4<--

C---- Open the .grf file
      OPEN(UNIT=2, FILE=FILGRF(IMAP), STATUS='OLD',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     READONLY,
     -     ERR=900)

C---- Read in all the polygon data
CHANGE v.1.4-->
C      PRINT*, 'Reading file:', FILGRF(IMAP)
      PRINT*, 'Reading file:', FILGRF(IMAP)(1:LENSTR(FILGRF(IMAP)))
CHANGE v.1.4<--

C---- Number of polygons, line, vertices
CHANGE v.1.1.1-->
C      MAPFST(IMAP) = TPOL + 1
CHANGE v.1.1.1<--
      EMESS = 'first line'
CHANGE v.1.1.1-->
C      READ(2,100,END=902,ERR=906) INMAP, NPOL, NVERT, NXTVRT
C100   FORMAT(5X,I2,7X,I6,10X,I8,11X,I8)
      READ(2,100,END=902,ERR=906) INMAP, NPOL, NVERT, NXTVRT, NCOL
100   FORMAT(5X,I2,7X,I6,10X,I8,11X,I8,8X,I8)
CHANGE v.1.1.1<--
      PRINT*, '  Polygons read in:', NPOL
      PRINT*, '    Lines:', NVERT, '        Vertices:', NXTVRT
      PRINT*

C---- Accumulate total figures
      TPOL = TPOL + NPOL
      TVERT = TVERT + NVERT
      TXTVRT = TXTVRT + NXTVRT

C---- Check that array bounds not exceeded
      IF (TPOL.GT.MXPOL) GO TO 908
      IF (TVERT.GT.MXLINE) GO TO 910
      IF (TXTVRT.GT.MXVERT) GO TO 912

C---- Read in the arrays themselves
      EMESS = 'polygon starts'
      READ(2,*,END=904)
      READ(2,120,END=904,ERR=906) (IPOLYG(IPOL), IPOL = OPOL + 1, TPOL)
120   FORMAT(10I8)
      READ(2,*,END=904)
      EMESS = 'vertex indices'
      READ(2,120,END=904,ERR=906) (VERTNO(IVERT),
     -    IVERT = OVERT + 1, TVERT)
      READ(2,*,END=904)
      EMESS = 'paired polygons'
      READ(2,120,END=904,ERR=906) (OTHPOL(IVERT),
     -    IVERT = OVERT + 1, TVERT)
      READ(2,*,END=904)
      EMESS = 'vertex coordinates'
      READ(2,180,END=904,ERR=906) ((VERTEX(ICOORD,IVERT),
     -    ICOORD = 1, 3), IVERT = OXTVRT + 1, TXTVRT)
180   FORMAT(8F10.3)

CHANGE v.1.1.1-->
C---- If polygon colours are explicitly defined, then read them in
      IF (NCOL.GT.0) THEN
          EMESS = 'polygon colours'
          READ(2,*,END=904)
          READ(2,120,END=904,ERR=906)
     -        (POLCOL(IPOL), IPOL = OPOL + 1, TPOL)
      ENDIF
CHANGE v.1.1.1<--

C---- Close the .grf file
      CLOSE(2)

C---- Adjust the polygon pointers
      IF (IMAP.GT.1) THEN

C----     Adjust polygon starts
          DO 200, IPOL = OPOL + 1, TPOL
              IPOLYG(IPOL) = IPOLYG(IPOL) + OVERT
200       CONTINUE

C----     Adjust vertex pointers, being the line-starts for each polygon
C         edge, and the other polygon in each pair
          DO 300, IVERT = OVERT + 1, TVERT
              VERTNO(IVERT) = VERTNO(IVERT) + OXTVRT
              IF (OTHPOL(IVERT).GT.0) THEN
                  OTHPOL(IVERT) = OTHPOL(IVERT) + OPOL
              ENDIF
300       CONTINUE
      ENDIF

C---- Assign the polygon colours and line-thicknesses
      DO 400, IPOL = OPOL + 1, TPOL

CHANGE v.1.1.1-->
C----     Find start and end points of polygon
          ISTART = IPOLYG(IPOL)
          IF (IPOL.LT.NPOL) THEN
              IEND = IPOLYG(IPOL + 1) - 1
          ELSE
              IEND = NVERT
          ENDIF
          NPOINT = IEND - ISTART + 1
CHANGE v.1.1.1<--

          IF (WIRSOL(IMAP).EQ.'S') THEN
              PLOTWR(IPOL) = .FALSE.
CHANGE v.1.1.1-->
              IF (FILTYP(IMAP).EQ.'S' .AND. NPOINT.EQ.2) THEN
                  PLOTWR(IPOL) = .TRUE.
              ENDIF
CHANGE v.1.1.1<--
          ELSE
              PLOTWR(IPOL) = .TRUE.
          ENDIF
          POLBAK(IPOL) = MAPBAK(IMAP)
CHANGE v.1.1.1-->
C          POLCOL(IPOL) = MAPCOL(IMAP)
          IF (POLCOL(IPOL).EQ.0) THEN
              POLCOL(IPOL) = MAPCOL(IMAP)
          ENDIF
CHANGE v.1.1.1<--
          POLINE(IPOL) = MAPLIN(IMAP)
400   CONTINUE

C---- If this is an atoms or bonds map and user has opted to use atom colours
C     then get the atom-colour from the atom type
CHANGE v.1.1.1-->
C      IF ((FILTYP(IMAP).EQ.'A' .OR. FILTYP(IMAP).EQ.'B' .OR.
CCHANGE v.1.1-->
C     -    FILTYP(IMAP).EQ.'P') .AND. MAPLIN(IMAP).GE.0.0) THEN
C     -     FILTYP(IMAP).EQ.'P' .OR. FILTYP(IMAP).EQ.'J') .AND.
C     -     MAPLIN(IMAP).GE.0.0) THEN
CCHANGE v.1.1<--
CHANGE v.1.4-->
C      IF ((FILTYP(IMAP).EQ.'A' .AND. MAPLIN(IMAP).GE.0.0) .OR.
      IF (((FILTYP(IMAP).EQ.'A' .OR. FILTYP(IMAP).EQ.'a') .AND.
     -    MAPLIN(IMAP).GE.0.0) .OR.
CHANGE v.1.4<--
CHECK v.1.4.1-->
C     -    (MAPCOL(IMAP).GT.0 .AND. (FILTYP(IMAP).EQ.'B' .OR.
C     -     FILTYP(IMAP).EQ.'P' .OR. FILTYP(IMAP).EQ.'J'))) THEN
     -    ((MAPCOL(IMAP).GT.0 .OR. MAPBAK(IMAP).GT.0) .AND.
     -    (FILTYP(IMAP).EQ.'B' .OR.
     -     FILTYP(IMAP).EQ.'P' .OR. FILTYP(IMAP).EQ.'J'))) THEN
CHECK v.1.4.1<--
CHANGE v.1.1.1<--
          IPOL = OPOL
CHANGE v.1.4-->
C          IF (FILTYP(IMAP).EQ.'A') THEN
          IF (FILTYP(IMAP).EQ.'A' .OR. FILTYP(IMAP).EQ.'a') THEN
CHANGE v.1.4<--
              NSTEP = 1
          ELSE
              NSTEP = 2
          ENDIF
          DO 500, IVERT = OVERT + 1, TVERT, NSTEP
              IPOL = IPOL + 1
              ATTYPE = OTHPOL(IVERT) - OPOL

CHECK v.1.4.1-->
C----         For bonds, if the existing colour is negative, then
C             don't want to change it
              SETFOR = .TRUE.
              IF (POLCOL(IPOL).EQ.-999 .OR.
     -            (POLCOL(IPOL).LT.0 .AND.
     -            (FILTYP(IMAP).EQ.'B' .OR.
     -             FILTYP(IMAP).EQ.'P' .OR.
     -             FILTYP(IMAP).EQ.'J'))) THEN
                  SETFOR = .FALSE.
              ENDIF
              SETBAK = .TRUE.
              IF (POLBAK(IPOL).EQ.-999 .OR.
     -            (POLBAK(IPOL).LT.0 .AND.
     -            (FILTYP(IMAP).EQ.'B' .OR.
     -             FILTYP(IMAP).EQ.'P' .OR.
     -             FILTYP(IMAP).EQ.'J'))) THEN
                  SETBAK = .FALSE.
              ENDIF
CHECK v.1.4.1<--

CHANGE v.1.4-->
C              IF (ATTYPE.LT.1 .OR. ATTYPE.GT.MXCOLS) THEN
              IF ((ATTYPE.LT.1 .OR. ATTYPE.GT.MXCOLS) .AND.
     -            FILTYP(IMAP).NE.'a') THEN
CHANGE v.1.4<--
CHECK v.1.4.1-->
C                  IF (POLCOL(IPOL).NE.-999) POLCOL(IPOL) = 3
C                  IF (POLBAK(IPOL).NE.-999) POLBAK(IPOL) = 3
                  IF (SETFOR) POLCOL(IPOL) = 3
                  IF (SETBAK) POLBAK(IPOL) = 3
CHECK v.1.4.1<--
              ELSE
CHECK v.1.4.1-->
C                  IF (NSTEP.EQ.1 .OR. WIRSOL(IMAP).EQ.'W') THEN
                  IF (NSTEP.EQ.1 .OR. WIRSOL(IMAP).EQ.'W' .OR.
     -                FILTYP(IMAP).EQ.'B' .OR. FILTYP(IMAP).EQ.'P' .OR.
     -                FILTYP(IMAP).EQ.'J') THEN
CHECK v.1.4.1<--
CHANGE v.1.1.1-->
C                      IF (POLCOL(IPOL).NE.-999)
C     -                    POLCOL(IPOL)
C     -                        = SIGN(1,POLCOL(IPOL)) * ICOLR(ATTYPE)
C                      IF (POLBAK(IPOL).NE.-999)
C     -                    POLBAK(IPOL)
C     -                        = SIGN(1,POLBAK(IPOL)) * ICOLR(ATTYPE)

C----                 Get the appropriate atom-colour. Set carbons to
C                     colour 13 for Raster3D output
CHANGE v.1.4-->
                      IF (FILTYP(IMAP).EQ.'a') THEN
                          SETCOL = ATTYPE
                      ELSE
CHANGE v.1.4<--
                          SETCOL = ICOLR(ATTYPE)
CHANGE v.1.5-->
C                          IF (RASTER .AND. SETCOL.EQ.10) SETCOL = 13
                          IF ((RASTER .OR. VRML) .AND. SETCOL.EQ.10)
     -                        SETCOL = 13
CHANGE v.1.5<--
CHANGE v.1.4-->
                      ENDIF
CHANGE v.1.4<--

C----                 Set the appropriate colour
CHECK v.1.4.1-->
C                      IF (POLCOL(IPOL).NE.-999)
                      IF (SETFOR)
CHECK v.1.4.1<--
     -                    POLCOL(IPOL)
     -                        = SIGN(1,POLCOL(IPOL)) * SETCOL
CHECK v.1.4.1-->
C                      IF (POLBAK(IPOL).NE.-999)
                      IF (SETBAK)
CHECK v.1.4.1<--
     -                    POLBAK(IPOL)
     -                        = SIGN(1,POLBAK(IPOL)) * SETCOL
CHANGE v.1.1.1<--
                  ENDIF
              ENDIF
              OTHPOL(IVERT) = 0
500       CONTINUE
      ENDIF

CHANGE v.1.6.1-->
C----     If have a surface map for output as a soloid surface in
C         raster3d, calculate which polygons share each vertex
          IF (RASTER .AND. FILTYP(IMAP).EQ.'S' .AND.
     -        WIRSOL(IMAP).EQ.'S') THEN
              CALL WHICHP(OPOL)
          ENDIF
CHANGE v.1.6.1<--

C---- Update the cumulative totals
      OPOL = TPOL
      OVERT = TVERT
      OXTVRT = TXTVRT

      GO TO 999


C     E R R O R   C O N D I T I O N S

900   CONTINUE
CHANGE v.1.4-->
C      PRINT*, '**** Error opening input file: [', FILGRF(IMAP), ']'
      PRINT*, '**** Error opening input file: [',
     -    FILGRF(IMAP)(1:LENSTR(FILGRF(IMAP))), ']'
CHANGE v.1.4<--
      GO TO 990

902   CONTINUE
CHANGE v.1.4-->
C      PRINT*, '**** Error. Input file is empty: [', FILGRF(IMAP), ']'
      PRINT*, '**** Error. Input file is empty: [',
     -    FILGRF(IMAP)(1:LENSTR(FILGRF(IMAP))), ']'
CHANGE v.1.4<--
      GO TO 990

904   CONTINUE
      PRINT*, '**** Error. Premature end-of-file in input file: [',
CHANGE v.1.4-->
C     -    FILGRF(IMAP), ']'
     -    FILGRF(IMAP)(1:LENSTR(FILGRF(IMAP))), ']'
CHANGE v.1.4<--
      PRINT*, '            while reading in ', EMESS
      GO TO 990

906   CONTINUE
CHANGE v.1.4-->
C      PRINT*, '**** Data error in input file: [', FILGRF(IMAP), ']'
      PRINT*, '**** Data error in input file: [',
     -     FILGRF(IMAP)(1:LENSTR(FILGRF(IMAP))), ']'
      PRINT*, '     while reading in ', EMESS
CHANGE v.1.4<--
      GO TO 990

908   CONTINUE
      PRINT*, '**** Error. Maximum number of polygons exceeded: ', MXPOL
      GO TO 990

910   CONTINUE
      PRINT*, '**** Error. Maximum number of polygon edge-lines ',
     -    'exceeded: ', MXLINE
      GO TO 990

912   CONTINUE
      PRINT*, '**** Error. Maximum number of vertices exceeded: ',
     -    MXVERT
      GO TO 990

990   CONTINUE

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6.1-->
C**************************************************************************
C
C  SUBROUTINE WHICHP  -  Determine which polygons each vertex belongs
C                        to
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WHICHP(OPOL)

      INCLUDE 'surfplot.inc'

      INTEGER       ICOMV, IEND, IPOINT, IPOL, ISTART, IVERT, NPOINT,
     -              OPOL

C---- Loop through all the polygons
      DO 500, IPOL = OPOL + 1, TPOL
          ISTART = IPOLYG(IPOL)

C----     Determine start- and end-vertices for this polygon
          IF (IPOL.LT.NPOL) THEN
              IEND = IPOLYG(IPOL + 1) - 1
          ELSE
              IEND = NVERT
          ENDIF
          NPOINT = IEND - ISTART + 1

C----     Process only if a polygon
          IF (NPOINT.GE.3) THEN

C----         Loop over the polygon's vertices
              DO 400, IPOINT = ISTART, IEND

C----             Get this vertex
                  IVERT = VERTNO(IPOINT)

C----             Update array holding the polygons to which this
C                 vertex belongs
                  DO 200, ICOMV = 1, MXCOMV

C----                 If this is a free slot, then update
                      IF (WHCHPL(ICOMV,IVERT).NE.0) THEN
                          WHCHPL(ICOMV,IVERT) = IPOL
                          GO TO 400
                      ENDIF
 200              CONTINUE
 400          CONTINUE
          ENDIF
 500  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6.1<--
C**************************************************************************
C
C  SUBROUTINE APPLYT  -  Apply the user-defined transformations to all
C                        the objects to be plotted
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE APPLYT

      INCLUDE 'surfplot.inc'


C---- Apply appropriate rotations
      IF (NOTRAN) THEN
          CALL ROTALL(XROT,YROT,ZROT)
          CALL ROTALL(90.0,0.0,0.0)
          CALL ROTALL(0.0,-135.0,0.0)
          CALL ROTALL(-30.0,0.0,0.0)
      ELSE
          CALL ROTALL(XROT,YROT,ZROT)
          CALL TRNALL(FORWRD,1)
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE ROTALL  -  Apply the required transformation to the object
C                        before display
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE ROTALL(XANGLE,YANGLE,ZANGLE)

      INCLUDE 'surfplot.inc'
 
      INTEGER       IVERT
      REAL          COSANG, SINANG, PI, RADIAN, XANGLE, YANGLE, ZANGLE

      PARAMETER    (PI = 3.141592654, RADIAN = PI / 180.0)

C---- Rotate about the x-axis
      IF (XANGLE.NE.0.0) THEN

C----     Calculate required sin and cosines
          SINANG = SIN(XANGLE * RADIAN)
          COSANG = COS(XANGLE * RADIAN)

C----     Loop through all the vertices, transforming each one
          DO 100, IVERT = 1, NXTVRT

C----         Perform the rotation
              CALL ROTATE(VERTEX(2,IVERT),VERTEX(3,IVERT),SINANG,
     -            COSANG)
 100      CONTINUE
      ENDIF

C---- Rotate about the y-axis
      IF (YANGLE.NE.0.0) THEN

C----     Calculate required sin and cosines
          SINANG = SIN(YANGLE * RADIAN)
          COSANG = COS(YANGLE * RADIAN)

C----     Loop through all the vertices, transforming each one
          DO 200, IVERT = 1, NXTVRT

C----         Perform the rotation
              CALL ROTATE(VERTEX(1,IVERT),VERTEX(3,IVERT),SINANG,
     -            COSANG)
 200      CONTINUE
      ENDIF

C---- Rotate about the z-axis
      IF (ZANGLE.NE.0.0) THEN

C----     Calculate required sin and cosines
          SINANG = SIN(ZANGLE * RADIAN)
          COSANG = COS(ZANGLE * RADIAN)

C----     Loop through all the vertices, transforming each one
          DO 300, IVERT = 1, NXTVRT

C----         Perform the rotation
              CALL ROTATE(VERTEX(1,IVERT),VERTEX(2,IVERT),SINANG,
     -            COSANG)
 300      CONTINUE
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE ROTATE  -  Rotate the given coordinates through the given
C                        angle
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE ROTATE(POINT1,POINT2,SINANG,COSANG)

CVAX      IMPLICIT NONE
 
      REAL          COSANG, POINT1, POINT2, SINANG, V1, V2


C---- Calculate required sin and cosines
      V1 = POINT1
      V2 = POINT2
      POINT1 =  COSANG * V1 + SINANG * V2
      POINT2 = -SINANG * V1 + COSANG * V2

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE TRNALL  -  Apply the required transformation to all
C                        coordinates
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE TRNALL(DIR,ITRAN)

      INCLUDE 'surfplot.inc'
 
      INTEGER       DIR, ITRAN, IVERT

C---- Loop through all the vertices, transforming each one
      DO 100, IVERT = 1, NXTVRT

C----     Perform the transformation on the current point
          CALL TRANSF(VERTEX(1,IVERT),VERTEX(2,IVERT),VERTEX(3,IVERT),
     -        DIR,ITRAN)
 100  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE TRANSF  -  Perform the appropriate transformation
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE TRANSF(POINT1,POINT2,POINT3,DIR,ITRAN)

      INCLUDE 'surfplot.inc'
 
      INTEGER       DIR, ITRAN
      REAL          P1, P2, P3, POINT1, POINT2, POINT3

C---- Save the coordinates of the point to be transformed
      P1 = POINT1
      P2 = POINT2
      P3 = POINT3

C---- Perform the appropriate transformation
      POINT1 = TMATRX(1,1,DIR,ITRAN) * P1 + TMATRX(2,1,DIR,ITRAN) * P2
     -    + TMATRX(3,1,DIR,ITRAN) * P3
      POINT2 = TMATRX(1,2,DIR,ITRAN) * P1 + TMATRX(2,2,DIR,ITRAN) * P2
     -    + TMATRX(3,2,DIR,ITRAN) * P3
      POINT3 = TMATRX(1,3,DIR,ITRAN) * P1 + TMATRX(2,3,DIR,ITRAN) * P2
     -    + TMATRX(3,3,DIR,ITRAN) * P3

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE TRNMAT  -  Precalculate the three transformation matrices
C                        that give the orthogonal views, and the three
C                        reverse-transformation matrices
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE TRNMAT

      INCLUDE 'surfplot.inc'
 
      INTEGER       ITRAN
      REAL          COSALP, COSBET, COSGAM, SINALP, SINBET, SINGAM, PI,
     -              RADIAN, TANGLE(3,3)

      PARAMETER    (PI = 3.141592654, RADIAN = PI / 180.0)

      DATA TANGLE / 30.0,  45.0,  0.0,
     -              30.0, -45.0,  0.0,
     -             -60.0,   0.0, 45.0  /

C---- Loop through each of the transformations
      DO 500, ITRAN = 1, 3

C----     Calculate all the required cos and sin terms for the current
C         set of angles
          COSALP = COS(TANGLE(1,ITRAN) * RADIAN)
          COSBET = COS(TANGLE(2,ITRAN) * RADIAN)
          COSGAM = COS(TANGLE(3,ITRAN) * RADIAN)
          SINALP = SIN(TANGLE(1,ITRAN) * RADIAN)
          SINBET = SIN(TANGLE(2,ITRAN) * RADIAN)
          SINGAM = SIN(TANGLE(3,ITRAN) * RADIAN)

C----     Calculate each of the 9 terms in the transformation matrix
          TMATRX(1,1,FORWRD,ITRAN) =   COSBET * COSGAM
          TMATRX(2,1,FORWRD,ITRAN) = - SINALP * SINBET * COSGAM
     -                               + COSALP * SINGAM
          TMATRX(3,1,FORWRD,ITRAN) =   COSALP * SINBET * COSGAM
     -                               + SINALP * SINGAM
          TMATRX(1,2,FORWRD,ITRAN) = - COSBET * SINGAM
          TMATRX(2,2,FORWRD,ITRAN) =   SINALP * SINBET * SINGAM
     -                               + COSALP * COSGAM
          TMATRX(3,2,FORWRD,ITRAN) = - COSALP * SINBET * SINGAM
     -                               + SINALP * COSGAM
          TMATRX(1,3,FORWRD,ITRAN) = - SINBET
          TMATRX(2,3,FORWRD,ITRAN) = - SINALP * COSBET
          TMATRX(3,3,FORWRD,ITRAN) =   COSALP * COSBET

C----     Calculate each of the 9 terms in the reverse transformation matrix
          TMATRX(1,1,BACKWD,ITRAN) =   COSBET * COSGAM
          TMATRX(2,1,BACKWD,ITRAN) = - COSBET * SINGAM
          TMATRX(3,1,BACKWD,ITRAN) = - SINBET
          TMATRX(1,2,BACKWD,ITRAN) =   COSALP * SINGAM
     -                               - SINALP * SINBET * COSGAM
          TMATRX(2,2,BACKWD,ITRAN) =   COSALP * COSGAM
     -                               + SINALP * SINBET * SINGAM
          TMATRX(3,2,BACKWD,ITRAN) = - SINALP * COSBET
          TMATRX(1,3,BACKWD,ITRAN) =   SINALP * SINGAM
     -                               + COSALP * SINBET * COSGAM
          TMATRX(2,3,BACKWD,ITRAN) =   SINALP * COSGAM
     -                               - COSALP * SINBET * SINGAM
          TMATRX(3,3,BACKWD,ITRAN) =   COSALP * COSBET

 500  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE BORDER  -  Calculate maximum and minimum coordinate values
C                        and transformations to place object in display
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE BORDER

      INCLUDE 'surfplot.inc'

CHANGE v.1.6-->
C      REAL          PSMARG
C      PARAMETER    (PSMARG = 40.0)
      REAL          PMARG
      PARAMETER    (PMARG = 40.0)
CHANGE v.1.6<--
 
      INTEGER       IVERT
CHANGE v.1.6-->
C      REAL          BORDPC, BSIZE, DIFF, MAXWID, MNLEN, MXLEN,
C     -              POINT(3,2), XWIDTH, YWIDTH
      REAL          BORDPC, BSIZE, DIFF, MAXWID, MNLEN, MXLEN, PSMARG,
     -              POINT(3,2), XWIDTH, YWIDTH
CHANGE v.1.6<--

C---- Initialise variables
      PRINT*
      PRINT*, 'Preparing for plotting ...'
CHANGE v.1.6.1-->
      MNLEN = 0.0
CHANGE v.1.6.1<--
      IF (BORDON) THEN
          BORDPC = BPERC
      ELSE
          BORDPC = 0.0
      ENDIF
CHANGE v.1.6-->
      IF (BSITE) THEN
          PSMARG = 0.0
      ELSE
          PSMARG = PMARG
      ENDIF
CHANGE v.1.6<--

C---- Save the vertex coordinates and calculate maximum and minimum
      DO 200, IVERT = 1, NXTVRT
          SAVERT(1,IVERT) = VERTEX(1,IVERT)
          SAVERT(2,IVERT) = VERTEX(2,IVERT)
          SAVERT(3,IVERT) = VERTEX(3,IVERT)
 200  CONTINUE

C---- If outputting a raster3D or VRML file, calculate maximum and minimum
C     values on the original 3D coordinates
CHANGE v.1.5-->
C      IF (RASTER) THEN
      IF (RASTER .OR. VRML) THEN
CHANGE v.1.5<--
          CALL MAXMIN
          XLENTH = ZMAX - ZMIN
          YLENTH = XMAX - XMIN
          ZLENTH = YMAX - YMIN
          MAXWID = MAX(XLENTH,YLENTH)
          MAXWID = MAX(ZLENTH,MAXWID)
          RASCAL = (1.0 - 2.0 * BPERC) * 1.0 / MAXWID
      ENDIF

C---- If have back-projections then transform objects onto one of them
      IF (BACKON) THEN

C----     Perform one of the orthogonal transformations so that extent of
C         bounding box can be calculated
          CALL TRNALL(FORWRD,1)

C----     Calculate maximum and minimum values on the transformed coordinates
          CALL MAXMIN
          XLENTH = ZMAX - ZMIN
          YLENTH = XMAX - XMIN
          ZLENTH = YMAX - YMIN

C---- Otherwise use x- and y- boundaries
      ELSE
          CALL MAXMIN
          XLENTH = XMAX - XMIN
          YLENTH = YMAX - YMIN
          ZLENTH = MAX(XLENTH,YLENTH)
      ENDIF

      MXLEN = MAX(XLENTH,YLENTH)
      MXLEN = MAX(MXLEN,ZLENTH)
      IF (MXLEN.EQ.0.0) MXLEN = 10.0
      IF (XLENTH.EQ.0.0) XLENTH = MXLEN / 10.0
      IF (YLENTH.EQ.0.0) YLENTH = MXLEN / 10.0
      IF (ZLENTH.EQ.0.0) ZLENTH = MXLEN / 10.0

C---- If allowed border is smaller than atom radius, adjust it
      IF (BORDON) THEN
          MNLEN = MIN(XLENTH,YLENTH)
          MNLEN = MIN(MNLEN,ZLENTH)
          BSIZE = MNLEN * BORDPC
          IF (BSIZE.LT.2.0 * ATMRAD) THEN
              BORDPC = 2.0 * ATMRAD / MNLEN
          ENDIF
      ENDIF

C---- Adjust these parameters to give a slight border to the projections
      XMIN = XMIN - BORDPC * MNLEN 
      YMIN = YMIN - BORDPC * MNLEN 
      ZMIN = ZMIN - BORDPC * MNLEN 
      XLENTH = XLENTH + 2.0 * BORDPC * MNLEN
      YLENTH = YLENTH + 2.0 * BORDPC * MNLEN
      ZLENTH = ZLENTH + 2.0 * BORDPC * MNLEN
      SLBWID = MIN(XLENTH,YLENTH)
      SLBWID = MIN(ZLENTH,SLBWID) / 20.0
      SLBWID = MAX(0.3,SLBWID)

C---- If have back projections, then transform minimum point back into
C     original coordinate reference frame
      IF (BACKON) THEN
          CALL TRANSF(XMIN,YMIN,ZMIN,BACKWD,1)
      ENDIF

C---- Restore the vertex coordinates
      DO 300, IVERT = 1, NXTVRT
          VERTEX(1,IVERT) = SAVERT(1,IVERT)
          VERTEX(2,IVERT) = SAVERT(2,IVERT)
          VERTEX(3,IVERT) = SAVERT(3,IVERT)
 300  CONTINUE

C---- Set the origin at the transformed minimum-point
      CALL SETORG

C---- Save the vertex coordinates
      DO 400, IVERT = 1, NXTVRT
          SAVERT(1,IVERT) = VERTEX(1,IVERT)
          SAVERT(2,IVERT) = VERTEX(2,IVERT)
          SAVERT(3,IVERT) = VERTEX(3,IVERT)
 400  CONTINUE

C---- If have back-projections transform outer corners of projected cube
C     so that can calculate x- and y-extent of final picture for scaling
      IF (BACKON) THEN
          POINT(1,1) = 0.0
          POINT(2,1) = ZLENTH
          POINT(3,1) = 0.0
          POINT(1,2) = YLENTH
          POINT(2,2) = 0.0
          POINT(3,2) = XLENTH
          CALL TRANSF(POINT(1,1),POINT(2,1),POINT(3,1),BACKWD,1)
          CALL TRANSF(POINT(1,2),POINT(2,2),POINT(3,2),BACKWD,1)
          YWIDTH = POINT(2,1) - POINT(2,2)
          YCENT = POINT(2,2)

          POINT(1,1) = YLENTH
          POINT(2,1) = 0.0
          POINT(3,1) = 0.0
          POINT(1,2) = 0.0
          POINT(2,2) = 0.0
          POINT(3,2) = XLENTH
          CALL TRANSF(POINT(1,1),POINT(2,1),POINT(3,1),BACKWD,1)
          CALL TRANSF(POINT(1,2),POINT(2,2),POINT(3,2),BACKWD,1)
          XWIDTH = POINT(1,1) - POINT(1,2)
          XCENT = POINT(1,2)

C---- Otherwise, use known x- and y-extent of picture
      ELSE
          XWIDTH = XLENTH
          XCENT = 0.0
          YWIDTH = YLENTH
          YCENT = 0.0
      ENDIF

C---- Determine whether picture is limited by extent in x-direction or in
C     y-direction
      IF ((XWIDTH / YWIDTH).GT.(PSIZEX / PSIZEY)) THEN
          SCALE = (1.0 - 2.0 * BPERC) * PSIZEX / XWIDTH
          DIFF = (1.0 - 2.0 * BPERC) * PSIZEY - SCALE * YWIDTH
          XSHIFT = BBOXX1 + BPERC * PSIZEX
          YSHIFT = BBOXY1 + BPERC * PSIZEY + DIFF / 2.0
      ELSE
          SCALE = (1.0 - 2.0 * BPERC) * PSIZEY / YWIDTH
          DIFF = (1.0 - 2.0 * BPERC) * PSIZEX - SCALE * XWIDTH
          XSHIFT = BBOXX1 + BPERC * PSIZEX + DIFF / 2.0
          YSHIFT = BBOXY1 + BPERC * PSIZEY
      ENDIF

C---- Write out PostScript picture's limits to PostScript file
      CALL CONVRT(XSHIFT - PSMARG,
     -    XSHIFT + SCALE * XWIDTH + PSMARG,
     -    YSHIFT - TITPOS - PSMARG,
     -    YSHIFT + SCALE * YWIDTH + PSMARG)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MAXMIN  -  Calculate maximum and minimum coordinates of
C                        list of vertices
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE MAXMIN

      INCLUDE 'surfplot.inc'
 
      INTEGER       IVERT

C---- Initialise variables
      XMIN = VERTEX(1,1)
      XMAX = VERTEX(1,1)
      YMIN = VERTEX(2,1)
      YMAX = VERTEX(2,1)
      ZMIN = VERTEX(3,1)
      ZMAX = VERTEX(3,1)

C---- Loop through all the vertices to calculate max or min values
      DO 100, IVERT = 2, NXTVRT
          XMIN = MIN(VERTEX(1,IVERT),XMIN)
          XMAX = MAX(VERTEX(1,IVERT),XMAX)
          YMIN = MIN(VERTEX(2,IVERT),YMIN)
          YMAX = MAX(VERTEX(2,IVERT),YMAX)
          ZMIN = MIN(VERTEX(3,IVERT),ZMIN)
          ZMAX = MAX(VERTEX(3,IVERT),ZMAX)
 100  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SETORG  -  Set the origin at the minimum x, y, and z coords
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE SETORG

      INCLUDE 'surfplot.inc'
 
      INTEGER       IVERT

C---- Loop through all the vertices to shift the object to new coordinate
C     system
      DO 100, IVERT = 1, NXTVRT
          VERTEX(1,IVERT) = VERTEX(1,IVERT) - XMIN
          VERTEX(2,IVERT) = VERTEX(2,IVERT) - YMIN
          VERTEX(3,IVERT) = VERTEX(3,IVERT) - ZMIN
 100  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PLTPOL  -  Plot the polygons, most distant first
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PLTPOL

      INCLUDE 'surfplot.inc'
 
      CHARACTER*6   TEXT
      INTEGER       I, IPLOT, IVERT, TLEN
      REAL          TSIZE, YPMAX

C---- Initialise
      PRINT*
      PRINT*, 'About to start plotting ...'
      TLEN = 0
      YPMAX = 0.0

C---- Set colour for text to black
      IF (INCOLR) THEN
          CALL PSCOLB(10) 
      ELSE
CDEBUG
      PRINT*, ' [1]'
CDEBUG
          CALL PSHADB(0.0)
      ENDIF

C---- Print the graph title
      I = 60
 100  CONTINUE
          IF (TITLE(I:I).NE.' ') TLEN = I
          I = I - 1
      IF (TLEN.EQ.0 .AND. I.GT.0) GO TO 100
      TSIZE = TITSIZ
      IF (TLEN.GT.40) TSIZE = TSIZE * (2.0 - REAL(TLEN) / 40.0)
      IF (TLEN.GT.0) THEN
          CALL PSCTXT(BCENTX,YSHIFT - TITPOS,TSIZE,TITLE(1:TLEN))
      ENDIF

C---- Loop through the 4 plots making up the picture (ie the 3 back-wall
C     orthographic projections, and the picture of the object itself)
      DO 800, IPLOT = 1, 4
          IF (IPLOT.LT.4 .AND. .NOT.BACKON) GO TO 800
          IF (IPLOT.EQ.4 .AND. .NOT.FRNTON) GO TO 800

C----     Print comment line out to PostScript file
          WRITE(TEXT,120) IPLOT
 120      FORMAT('Plot',I2)
          CALL PSCOMM(TEXT)

C----     Draw border round plot
          IF (IPLOT.EQ.1) THEN
              CALL DRBORD(YLENTH,ZLENTH,YPMAX,IPLOT)
          ELSE IF (IPLOT.EQ.2) THEN
              CALL DRBORD(-XLENTH,ZLENTH,YPMAX,IPLOT)
          ELSE IF (IPLOT.EQ.3) THEN
              CALL DRBORD(-XLENTH,-YLENTH,YPMAX,IPLOT)
          ENDIF

C----     Restore the vertex coordinates
          DO 200, IVERT = 1, NXTVRT
              VERTEX(1,IVERT) = SAVERT(1,IVERT)
              VERTEX(2,IVERT) = SAVERT(2,IVERT)
              VERTEX(3,IVERT) = SAVERT(3,IVERT)
 200      CONTINUE

C----     Skip the rest of corresponding projection not required
CHANGE v.1.4-->
          IF (IPLOT.EQ.1 .AND. .NOT.BRIGHT) GO TO 800
          IF (IPLOT.EQ.2 .AND. .NOT.BLEFT) GO TO 800
          IF (IPLOT.EQ.3 .AND. .NOT.BFLOOR) GO TO 800
CHANGE v.1.4<--

C----     Perform the appropriate transformation
          IF (IPLOT.LT.4) THEN
              CALL TRNALL(FORWRD,IPLOT)
          ENDIF

C----     Project all vertices onto the 2-D viewing plane
CHANGE v.1.1-->
C          CALL PROJEC
          CALL PROJEC(IPLOT)
CHANGE v.1.1<--

C----     Establish which side (inside or outside) of each polygon is facing
C         the observer
          CALL WHSIDE

C----     Prepare for z-sort of polygons
          CALL PRESRT

C----     Sort the polygons
          CALL SHELL(NPOL,EDIST,NPOL,POLORD)

C----     Plot the polygons
          CALL SHPLOT(IPLOT)

C----     If outputting as a Raster3D or a VRML file, write all the
C         plot objects out
CHANGE v.1.5-->
C          IF (RASTER .AND. IPLOT.EQ.4) THEN
C              CALL RASOUT
          IF (IPLOT.EQ.4) THEN
              IF (RASTER) THEN
                  CALL RASOUT
              ENDIF
              IF (VRML) THEN
                  CALL WRLOUT
              ENDIF
CHANGE v.1.5<--
          ENDIF
 800  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE DRBORD  -  Draw the border surrounding the current
C                        orthogonal projection
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE DRBORD(XPOINT,YPOINT,YPMAX,ITRAN)

      INCLUDE 'surfplot.inc'
 
      INTEGER       IPOINT, ITRAN
      REAL          LAMBDA, RNK, RNX, RNY, RNZ, SHADE, SLABCL(3), X(7),
     -              XMID, XP(7), XPOINT, Y(7), YMID, YP(7), YPMAX,
     -              YPOINT, Z(7), ZMID

      DATA SLABCL / 1.000, 1.000, 0.700 /

C---- Calculate transformed coords of the four corners of the border
      X(1) = 0.0
      Y(1) = 0.0
      Z(1) = 0.0
      CALL TRANSF(X(1),Y(1),Z(1),BACKWD,ITRAN)
      X(2) = 0.0
      Y(2) = YPOINT
      Z(2) = 0.0
      CALL TRANSF(X(2),Y(2),Z(2),BACKWD,ITRAN)
      X(3) = XPOINT
      Y(3) = YPOINT
      Z(3) = 0.0
      CALL TRANSF(X(3),Y(3),Z(3),BACKWD,ITRAN)
      X(4) = XPOINT
      Y(4) = 0.0
      Z(4) = 0.0
      CALL TRANSF(X(4),Y(4),Z(4),BACKWD,ITRAN)
      X(5) = XPOINT
      Y(5) = 0.0
      Z(5) = - SLBWID
      CALL TRANSF(X(5),Y(5),Z(5),BACKWD,ITRAN)
      X(6) = XPOINT
      Y(6) = YPOINT
      Z(6) = - SLBWID
      CALL TRANSF(X(6),Y(6),Z(6),BACKWD,ITRAN)
      X(7) = 0.0
      Y(7) = YPOINT
      Z(7) = - SLBWID
      CALL TRANSF(X(7),Y(7),Z(7),BACKWD,ITRAN)

CHANGE v.1.1-->
C---- Store the new vertices
CHANGE v.1.1.1-->
C      IF (NEWVRT + 4.LE.MXVERT) THEN
C          DO 80, IPOINT = 1, 4
      IF (NEWVRT + 7.LE.MXVERT) THEN
          DO 80, IPOINT = 1, 7
CHANGE v.1.1.1<--
              NEWVRT = NEWVRT + 1
              VERTEX(1,NEWVRT) = X(IPOINT)
              VERTEX(2,NEWVRT) = Y(IPOINT)
              VERTEX(3,NEWVRT) = Z(IPOINT)
 80       CONTINUE
      ENDIF
CHANGE v.1.1<--

C---- Skip rest of routine if this back-projection is not required
CHANGE v.1.4-->
      IF (ITRAN.EQ.1 .AND. .NOT.SLABRT) GO TO 999
      IF (ITRAN.EQ.2 .AND. .NOT.SLABLF) GO TO 999
      IF (ITRAN.EQ.3 .AND. .NOT.SLABFL) GO TO 999
CHANGE v.1.4<--

C---- Calculate the projected coordinates on the Postscript page
      DO 100, IPOINT = 1, 7
          XP(IPOINT) = XSHIFT + SCALE * (X(IPOINT) - XCENT)
          YP(IPOINT) = YSHIFT + SCALE * (Y(IPOINT) - YCENT)
          YPMAX = MAX(YP(IPOINT),YPMAX)
 100  CONTINUE

C---- Draw the border
      CALL PSLWID(0.2)
      CALL PSDASH(0)
      IF (INCOLR) THEN
          CALL PSCOLB(10)
          IF (WALCOL.EQ.0) THEN
              CALL PSCOLR(1.0,1.0,1.0)
          ELSE
              CALL PSCOLR(RGBCOL(1,WALCOL),RGBCOL(2,WALCOL),
     -            RGBCOL(3,WALCOL))
          ENDIF
      ELSE
CDEBUG
      PRINT*, '[2]'
CDEBUG
          CALL PSHADB(0.0)
          CALL PSHADE(1.0)
      ENDIF
      CALL PSBBOX(XP(1),YP(1),XP(2),YP(2),XP(3),YP(3),XP(4),YP(4))

C---- Draw the ticks along the borders of the slab
      CALL DRTICK(XPOINT,YPOINT,SLBWID / 2.0,ITRAN)

C---- Draw the first of the slab-edges

C---- Calculate normal vector for current polygon and mid-point
      IF (ITRAN.EQ.2) THEN
          CALL NORMAL(RNX,RNY,RNZ,RNK,
     -        X(3),Y(3),Z(3),X(2),Y(2),Z(2),X(7),Y(7),Z(7))
      ELSE
          CALL NORMAL(RNX,RNY,RNZ,RNK,
     -        X(7),Y(7),Z(7),X(2),Y(2),Z(2),X(3),Y(3),Z(3))
      ENDIF
      XMID = (X(3) + X(7)) / 2.0
      YMID = (Y(3) + Y(7)) / 2.0
      ZMID = (Z(3) + Z(7)) / 2.0

C---- Calculate intensity of light according to orientation of
C     polygon relative to the observer's eye and light source
      CALL ISHADE(XMID,YMID,ZMID,RNX,RNY,RNZ,LAMBDA)
      SHADE = MAX(LAMBDA,0.0)
      IF (INCOLR) THEN
          CALL PSETCL(SLABCL,LAMBDA)
      ELSE
          CALL PSHADE(SHADE)
      ENDIF
      CALL PSBBOX(XP(3),YP(3),XP(2),YP(2),XP(7),YP(7),XP(6),YP(6))

C---- Repeat for other slab edge

C---- Calculate normal vector for current polygon and mid-point
      IF (ITRAN.EQ.2) THEN
          CALL NORMAL(RNX,RNY,RNZ,RNK,
     -        X(4),Y(4),Z(4),X(3),Y(3),Z(3),X(6),Y(6),Z(6))
      ELSE
          CALL NORMAL(RNX,RNY,RNZ,RNK,
     -        X(6),Y(6),Z(6),X(3),Y(3),Z(3),X(4),Y(4),Z(4))
      ENDIF
      XMID = (X(4) + X(6)) / 2.0
      YMID = (Y(4) + Y(6)) / 2.0
      ZMID = (Z(4) + Z(6)) / 2.0

C---- Calculate intensity of light according to orientation of
C     polygon relative to the observer's eye and light source
      CALL ISHADE(XMID,YMID,ZMID,RNX,RNY,RNZ,LAMBDA)
      SHADE = MAX(LAMBDA,0.0)
      IF (INCOLR) THEN
          CALL PSETCL(SLABCL,LAMBDA)
      ELSE
          CALL PSHADE(SHADE)
      ENDIF
      CALL PSBBOX(XP(4),YP(4),XP(3),YP(3),XP(6),YP(6),XP(5),YP(5))

CHANGE v.1.4-->
 999  CONTINUE
CHANGE v.1.4<--
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE DRTICK  -  Draw the ticks on the border edges, 1 unit apart
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE DRTICK(XVAL,YVAL,TSIZE,ITRAN)

      INCLUDE 'surfplot.inc'
 
      INTEGER       IEND, IEDGE, ISTART, ITICK, ITRAN, JEDGE, NTICKS
      LOGICAL       FINISH
      REAL          DX, DY, TSIZE, X(4), XB, XMID, XPOINT, XP1, XP2,
     -              XT, XTDIR, XVAL, XWID, Y(4), YB, YMID, YPOINT, YP1,
     -              YP2, YT, YTDIR, YVAL, YWID, Z(4), ZB, ZPOINT, ZT

C---- Initialise values
      ISTART = 1
      IEND = 2
      FINISH = .FALSE.
      X(1) = 0.0
      Y(1) = 0.0
      Z(1) = 0.0
      X(2) = 0.0
      Y(2) = YVAL
      Z(2) = 0.0
      X(3) = XVAL
      Y(3) = YVAL
      Z(3) = 0.0
      X(4) = XVAL
      Y(4) = 0.0
      Z(4) = 0.0

C---- Set colour for lines
      IF (INCOLR) THEN
          CALL PSCOLB(9) 
      ENDIF

C---- Loop through the four edges of the border
      DO 500, IEDGE = 1, 4

C----     Initialise values for this edge
          ISTART = IEDGE
          IEND = ISTART + 1
          IF (IEND.GT.4) IEND = IEND - 4

C----     Determine along which direction the ticks are to run
          IF (ABS(X(IEND) - X(ISTART)).LE.EMIN) THEN
              DX = 0.0
          ELSE IF (X(IEND).LT.X(ISTART)) THEN
              DX = -1.0
          ELSE
              DX = 1.0
          ENDIF
          IF (ABS(Y(IEND) - Y(ISTART)).LE.EMIN) THEN
              DY = 0.0
          ELSE IF (Y(IEND).LT.Y(ISTART)) THEN
              DY = -1.0
          ELSE
              DY = 1.0
          ENDIF

C----     Determine in which direction the ticks are to face
          JEDGE = IEDGE + 2
          IF (JEDGE.GT.4) JEDGE = JEDGE - 4
          IF (DY.EQ.0) THEN
              XTDIR = 0.0
              IF (X(JEDGE).GT.X(ISTART)) THEN
                  YTDIR = -1.0
              ELSE
                  YTDIR = 1.0
              ENDIF

C----     Determine the number of ticks required
              NTICKS = INT(ABS(X(IEND) - X(ISTART))) + 2
          ELSE
              YTDIR = 0.0
              IF (Y(JEDGE).GT.Y(ISTART)) THEN
                  XTDIR = 1.0
              ELSE
                  XTDIR = -1.0
              ENDIF

C----     Determine the number of ticks required
              NTICKS = INT(ABS(Y(IEND) - Y(ISTART))) + 2
          ENDIF

C----     Reverse directions for the second block
          IF (ITRAN.EQ.2) THEN
              XTDIR = -1.0 * XTDIR
              YTDIR = -1.0 * YTDIR
          ENDIF

C----     Initialise the tick-coordinates
          IF (DX.EQ.0.0) THEN
              XPOINT = X(ISTART)
          ELSE
              XPOINT = INT(X(ISTART))
          ENDIF
          IF (DY.EQ.0.0) THEN
              YPOINT = Y(ISTART)
          ELSE
              YPOINT = INT(Y(ISTART))
          ENDIF
          ZPOINT = 0.0

C----     Calculate mid-point and width
          XMID = (X(ISTART) + X(IEND)) / 2.0
          YMID = (Y(ISTART) + Y(IEND)) / 2.0
          XWID = ABS(X(ISTART) - X(IEND)) / 2.0
          YWID = ABS(Y(ISTART) - Y(IEND)) / 2.0
          IF (DX.EQ.0) XWID = 1.0
          IF (DY.EQ.0) YWID = 1.0

C----     Calculate transformed coords of the four corners of the border
          DO 200, ITICK = 1, NTICKS

C----         Store one end of tick
              XB = XPOINT
              YB = YPOINT
              ZB = ZPOINT

C----         Calculate other end of tick
              XT = XPOINT + XTDIR * TSIZE
              YT = YPOINT + YTDIR * TSIZE
              ZT = ZPOINT

C----         Perform transformation on each end of tick
              CALL TRANSF(XB,YB,ZB,BACKWD,ITRAN)
              CALL TRANSF(XT,YT,ZT,BACKWD,ITRAN)

C----         Calculate projection on printed page
              XP1 = XSHIFT + SCALE * (XB - XCENT)
              YP1 = YSHIFT + SCALE * (YB - YCENT)
              XP2 = XSHIFT + SCALE * (XT - XCENT)
              YP2 = YSHIFT + SCALE * (YT - YCENT)

C----         Draw the tick, providing point is not outside the bounds
              IF (ABS(XPOINT - XMID).LT.XWID .AND.
     -            ABS(YPOINT - YMID).LT.YWID) THEN
                  CALL PSLINE(XP1,YP1,XP2,YP2)
              ENDIF

C----         Increment tick position
              XPOINT = XPOINT + DX
              YPOINT = YPOINT + DY
 200      CONTINUE
 500  CONTINUE

C---- Set colour back to black
      IF (INCOLR) THEN
          CALL PSCOLB(10)
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PROJEC  -  Convert 3-D coords of vertices to 2-D coords
C                        in viewing plane - Orthographic projection
C
C [Taken from Angell & Griffith]
C----------------------------------------------------------------------+--- 

CHANGE v.1.1-->
C      SUBROUTINE PROJEC
      SUBROUTINE PROJEC(IPLOT)
CHANGE v.1.1<--

      INCLUDE 'surfplot.inc'
 
CHANGE v.1.1-->
C      INTEGER       IVERT
C      REAL          MAXX, MINX, MAXY, MINY, MAXZ, MINZ, PPD, XMID,
C     -              YMID, ZPOINT
      INTEGER       ICOORD, IPLOT, IVERT, IWALL
CHANGE v.1.4-->
C      REAL          DIFF, MAXWID, MAXX, MINX, MAXY, MINY, MAXZ, MINZ,
      REAL          MAXWID, MAXX, MINX, MAXY, MINY, MAXZ, MINZ,
CHANGE v.1.4<--
CHANGE v.1.1.1-->
C     -              PPD, WCOL(3), XLEN, XMID, YLEN, YMID, ZLEN, ZPOINT
     -              PPD, WCOL(3), XLEN, XMID, YLEN, YMID, ZLEN, ZMID,
     -              ZPOINT
CHANGE v.1.1.1<--
CHANGE v.1.1<--

CHANGE v.1.1-->
C---- Transform point onto viewing plane using perspective or orthographic
C     projection
C      IF (PERSPC .AND. .NOT.BACKON) THEN
CHANGE v.1.1<--

C---- Find the maximum z-value
      MINX = VERTEX(1,1)
      MAXX = VERTEX(1,1)
      MINY = VERTEX(2,1)
      MAXY = VERTEX(2,1)
      MINZ = VERTEX(3,1)
      MAXZ = VERTEX(3,1)
CHANGE v.1.1.1-->
C      DO 50, IVERT = 2, NXTVRT
      DO 50, IVERT = 2, NEWVRT
CHANGE v.1.1.1<--
          MINX = MIN(VERTEX(1,IVERT),MINX)
          MAXX = MAX(VERTEX(1,IVERT),MAXX)
          MINY = MIN(VERTEX(2,IVERT),MINY)
          MAXY = MAX(VERTEX(2,IVERT),MAXY)
          MINZ = MIN(VERTEX(3,IVERT),MINZ)
          MAXZ = MAX(VERTEX(3,IVERT),MAXZ)
 50   CONTINUE
      IF (MINX.EQ.MAXX) MAXX = MINX + 1.0
      IF (MINY.EQ.MAXY) MAXY = MINY + 1.0
      IF (MINZ.EQ.MAXZ) MAXZ = MINZ + 1.0

CHANGE v.1.1-->
C---- Transform point onto viewing plane using perspective or orthographic
C     projection
      IF (PERSPC .AND. .NOT.BACKON) THEN
CHANGE v.1.1<--

          PPD = 2.0 * (MAXZ - MINZ)
          ZPOINT = MAXZ + PPD
          XMID = (MINX + MAXX) / 2.0
          YMID = (MINY + MAXY) / 2.0

C----     Perspective projection
          DO 100, IVERT = 1, NXTVRT

C----         Calculate projected x- and y-coord
              PCOORD(1,IVERT) = XMID - (VERTEX(1,IVERT) - XMID)
     -            * PPD / (VERTEX(3,IVERT) - ZPOINT)
              PCOORD(2,IVERT) = YMID - (VERTEX(2,IVERT) - YMID)
     -            * PPD / (VERTEX(3,IVERT) - ZPOINT)

C----         Calculate the size of an atom, of radius ATMRAD, placed
C             at this vertex position
              PRJRAD(IVERT) = - ATMRAD
     -            * PPD / (VERTEX(3,IVERT) - ZPOINT)
 100      CONTINUE
      ELSE

C----     Orthographic projection
          DO 200, IVERT = 1, NXTVRT
              PCOORD(1,IVERT) = VERTEX(1,IVERT)
              PCOORD(2,IVERT) = VERTEX(2,IVERT)
 200      CONTINUE
      ENDIF

C---- If plotting foreground object, transform into Raster3D and
C     VRML coords
CHANGE v.1.1-->
CHANGE v.1.5-->
C      IF (RASTER .AND. IPLOT.EQ.4) THEN
      IF ((RASTER .OR. VRML) .AND. IPLOT.EQ.4) THEN
CHANGE v.1.5<--

C----     Calculate the scaling factor to get all the converted coordinates
C         lying between -0.5 and 0.5
          XLEN = MAXX - MINX
          YLEN = MAXY - MINY
          ZLEN = MAXZ - MINZ
          MAXWID = MAX(XLEN,YLEN)
          MAXWID = MAX(ZLEN,MAXWID)
CHANGE v.1.1.1-->
C          RASCAL = (1.0 - 2.0 * BPERC) * 1.0 / MAXWID
C          DIFF = 0.4 - BPERC
CHECK v.1.3.3-->
C          RASCAL = 1.0 / MAXWID
          RASCAL = (1.0 - 2.0 * BPERC) * 1.0 / MAXWID
CHECK v.1.3.3<--
          XMID = (MINX + MAXX) / 2.0
          YMID = (MINY + MAXY) / 2.0
          ZMID = (MINZ + MAXZ) / 2.0
CHANGE v.1.1.1<--
CHANGE v.1.1<--

CHANGE v.1.1-->
C          DO 300, IVERT = 1, NXTVRT
C              RCOORD(1,IVERT) = RASCAL * VERTEX(1,IVERT) - 0.5
C              RCOORD(2,IVERT) = RASCAL * VERTEX(2,IVERT) - 0.5
C              RCOORD(3,IVERT) = RASCAL * VERTEX(3,IVERT) - 0.5
C 300      CONTINUE
          DO 300, IVERT = 1, NEWVRT
CHANGE v.1.1.1-->
C              RCOORD(1,IVERT) = RASCAL * (VERTEX(1,IVERT) - MINX) - DIFF
C              RCOORD(2,IVERT) = RASCAL * (VERTEX(2,IVERT) - MINY) - DIFF
C              RCOORD(3,IVERT) = RASCAL * (VERTEX(3,IVERT) - MINZ) - DIFF
              RCOORD(1,IVERT) = RASCAL * (VERTEX(1,IVERT) - XMID)
              RCOORD(2,IVERT) = RASCAL * (VERTEX(2,IVERT) - YMID)
              RCOORD(3,IVERT) = RASCAL * (VERTEX(3,IVERT) - ZMID)
CHANGE v.1.1.1<--
 300      CONTINUE

C----     Write out the back walls, if required
          IF (BACKON .AND. NEWVRT.GT.NXTVRT) THEN

C----         Get the wall colour
              IF (WALCOL.EQ.0) THEN
                  WCOL(1) = 1.0
                  WCOL(2) = 1.0
                  WCOL(3) = 1.0
              ELSE
                  WCOL(1) = RGBCOL(1,WALCOL)
                  WCOL(2) = RGBCOL(2,WALCOL)
                  WCOL(3) = RGBCOL(3,WALCOL)
              ENDIF

C----         Loop over the three back walls
              DO 500, IWALL = 1, 3
CHANGE v.1.4-->
                  IF (IWALL.EQ.1 .AND. .NOT.SLABRT) GO TO 500
                  IF (IWALL.EQ.2 .AND. .NOT.SLABLF) GO TO 500
                  IF (IWALL.EQ.3 .AND. .NOT.SLABFL) GO TO 500
CHANGE v.1.4<--
CHANGE v.1.1.1-->
C                  IVERT = NXTVRT + (IWALL - 1) * 4 
C                  IF (IVERT + 4.LE.NEWVRT) THEN
                  IVERT = NXTVRT + (IWALL - 1) * 7
                  IF (IVERT + 7.LE.NEWVRT) THEN
CHANGE v.1.1.1<--
CHANGE v.1.4<--
                      IF (WALINF) THEN
                          WRITE(12,320) 6,
     -                        (RCOORD(ICOORD,IVERT + 1), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 2), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 3), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
                      ELSE
CHANGE v.1.4-->
                          WRITE(12,320) 1,
     -                        (RCOORD(ICOORD,IVERT + 1), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 2), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 3), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
 320                      FORMAT(I1,/,9F8.4,/,3F7.4)
                          WRITE(12,320) 1,
     -                        (RCOORD(ICOORD,IVERT + 4), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 1), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 3), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
CHANGE v.1.1.1-->
                          WRITE(12,320) 1,
     -                        (RCOORD(ICOORD,IVERT + 3), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 2), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 6), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
                          WRITE(12,320) 1,
     -                        (RCOORD(ICOORD,IVERT + 2), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 7), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 6), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
                          WRITE(12,320) 1,
     -                        (RCOORD(ICOORD,IVERT + 4), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 3), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 5), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
                          WRITE(12,320) 1,
     -                        (RCOORD(ICOORD,IVERT + 3), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 6), ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,IVERT + 5), ICOORD = 1, 3),
     -                        WCOL(1), WCOL(2), WCOL(3)
CHANGE v.1.4-->
                      ENDIF
CHANGE v.1.4<--
CHANGE v.1.1.1<--
                  ENDIF
 500          CONTINUE
          ENDIF
      ENDIF
CHANGE v.1.1<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WHSIDE  -  Determine which side of each polygon is facing
C                        towards the observer
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WHSIDE

      INCLUDE 'surfplot.inc'
 
      INTEGER       IEND, IORIEN, IPOL, ISTART, ITEST
      REAL          X1, X2, X3, Y1, Y2, Y3


C---- Loop through all the polygons
      DO 500, IPOL = 1, NPOL
          ISTART = IPOLYG(IPOL)

C----     Determine start- and end-vertices for this polygon
          IF (IPOL.LT.NPOL) THEN
              IEND = IPOLYG(IPOL + 1) - 1
          ELSE
              IEND = NVERT
          ENDIF

C----     If this polygon only has two edges (ie is just a line), then it
C         is visible by definition
          IF (IEND - ISTART.LT.2) THEN
              VISIBL(IPOL) = .TRUE.

C----     Otherwise, need to check its orientation relative to the viewer
          ELSE

C----         Check whether this facet is visible
              X1 = PCOORD(1,VERTNO(ISTART))
              Y1 = PCOORD(2,VERTNO(ISTART))
              X2 = PCOORD(1,VERTNO(ISTART + 1))
              Y2 = PCOORD(2,VERTNO(ISTART + 1))
              X3 = PCOORD(1,VERTNO(ISTART + 2))
              Y3 = PCOORD(2,VERTNO(ISTART + 2))
              ITEST = IORIEN(X1,Y1,X2,Y2,X3,Y3)
              IF (ITEST.EQ.1) THEN
                  VISIBL(IPOL) = .TRUE.
              ELSE
                  VISIBL(IPOL) = .FALSE.
              ENDIF
          ENDIF
 500  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION IORIEN  -  Returns the orientation of the polygon when
C                      projected into the 2-D coordinate system
C
C                      -1  :  clockwise orientation  
C                      +1  :  anti-clockwise orientation (desired order)
C                       0  :  degenerate (line or point)
C
C [Adapted from Angell & Griffith]
C----------------------------------------------------------------------+--- 

      INTEGER FUNCTION IORIEN(X1,Y1,X2,Y2,X3,Y3)

      REAL          DX1, DY1, DX2, DY2, EMIN, FE, X1, Y1, X2, Y2, X3,
     -              Y3

      PARAMETER    (EMIN = 1.0E-04)

C---- Initialise variables
      DX1 = X2 - X1
      DY1 = Y2 - Y1
      DX2 = X3 - X2
      DY2 = Y3 - Y2

C---- Calculate orientation
      FE = DX1 * DY2 - DX2 * DY1
      IORIEN = SIGN(1.0,FE)

C---- If orientation very close to being degenerate, then set as such
      IF (ABS(FE).LE.EMIN) IORIEN = 0

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PRESRT  -  Prepare for sorting of polygons by their
C                        z-coordinates by finding the average z-coordinate of
C                        each one
C
C--------------------------------------------------------------------------

      SUBROUTINE PRESRT

      INCLUDE 'surfplot.inc'

      INTEGER       IEND, IPOL, ISTART, IVERT
CHANGE v.1.1.1-->
C      REAL          VALX, VALY, VALZ
      REAL          VALX, VALY, VALZ, XNEAR, YNEAR, ZNEAR
CHANGE v.1.1.1<--

C---- Loop through all the polygons
      DO 500, IPOL = 1, NPOL

C----     Initialise order-pointer
          POLORD(IPOL) = IPOL

C----     Find start and end points of polygon
          ISTART = IPOLYG(IPOL)
          IF (IPOL.LT.NPOL) THEN
              IEND = IPOLYG(IPOL + 1) - 1
          ELSE
              IEND = NVERT
          ENDIF

C----     Initialise minimum value
          VALX = 0.0
          VALY = 0.0
          VALZ = 0.0
CHANGE v.1.1.1-->
          XNEAR = VERTEX(1,VERTNO(ISTART))
          YNEAR = VERTEX(2,VERTNO(ISTART))
          ZNEAR = VERTEX(3,VERTNO(ISTART))
CHANGE v.1.1.1<--

C----     Loop through each line-start in the polygon
          DO 100, IVERT = ISTART, IEND
              VALX = VALX + VERTEX(1,VERTNO(IVERT))
              VALY = VALY + VERTEX(2,VERTNO(IVERT))
              VALZ = VALZ + VERTEX(3,VERTNO(IVERT))
CHANGE v.1.1.1-->
              XNEAR = MAX(VERTEX(1,VERTNO(IVERT)),XNEAR)
              YNEAR = MAX(VERTEX(2,VERTNO(IVERT)),YNEAR)
              ZNEAR = MAX(VERTEX(3,VERTNO(IVERT)),ZNEAR)
CHANGE v.1.1.1<--
100       CONTINUE
          IF (IEND.GE.ISTART) THEN
              MIDX(IPOL) = VALX / (IEND - ISTART + 1)
              MIDY(IPOL) = VALY / (IEND - ISTART + 1)
              MIDZ(IPOL) = VALZ / (IEND - ISTART + 1)
C              EDIST(IPOL) = -1.0 * (MIDX(IPOL) * MIDX(IPOL)
C     -            + MIDY(IPOL) * MIDY(IPOL)
C     -            + MIDZ(IPOL) * MIDZ(IPOL))
              EDIST(IPOL) = MIDZ(IPOL)

C----         For lines, use the furthest point
              IF (IEND.EQ.ISTART + 1) THEN
C                  EDIST(IPOL) = MAX(VERTEX(3,VERTNO(ISTART)),
C     -                VERTEX(3,VERTNO(IEND)))
C                  EDIST(IPOL) = MIN(VERTEX(3,VERTNO(ISTART)),
C     -                VERTEX(3,VERTNO(IEND)))
              ENDIF
          ENDIF
500   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SHELL  -  Sort routine using the Shell sort method. Sorts the
C                       real array RARRAY, of size NSIZE, as indexed by the
C                       array INDEX. The latter array has pointers to only
C                       NINDEX of the elements in RARRAY. The routine
C                       returns the indices in INDEX rearranged in ascending
C                       order of the corresponding values in RARRAY.
C
C--------------------------------------------------------------------------

      SUBROUTINE SHELL(NSIZE,RARRAY,NINDEX,INDEX)

CVAX      IMPLICIT NONE

      REAL          ALN2I, TINY
      PARAMETER (ALN2I=1.4426950, TINY=1.E-5)

      INTEGER       NSIZE, NINDEX
      INTEGER       INDEX(NINDEX)

      INTEGER       I, ISWAP, J, K, L, LOGNB2, M, N, NN

      REAL          RARRAY(NSIZE)

      N = NINDEX
      LOGNB2 = INT(ALOG(FLOAT(N)) * ALN2I + TINY)
      M = N
      DO 12, NN = 1, LOGNB2
          M = M / 2
          K = N - M
          DO 11, J = 1, K
              I = J
3             CONTINUE
              L = I + M
              IF (RARRAY(INDEX(L)).LT.RARRAY(INDEX(I))) THEN
                  ISWAP = INDEX(I)
                  INDEX(I) = INDEX(L)
                  INDEX(L) = ISWAP
                  I = I - M
                  IF (I.GE.1) GO TO 3
              ENDIF
11        CONTINUE
12    CONTINUE

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SHPLOT  -  Plot the polygons, shading each one according to
C                        colour and orientation
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE SHPLOT(ITRAN)

      INCLUDE 'surfplot.inc'

      CHARACTER*6   TEXT
      INTEGER       COLOUR, DLINE, I, ICOORD, ICYCLE, IEND, ILINE, IMAP,
     -              INMAP, IPOINT, IPOL, ISTART, ITRAN, IVERT, J, JVERT,
     -              NCYCLE, NPOINT, PTNUMB
CHANGE v.1.4-->
C      LOGICAL       DRAWLN(4), OTHVIS
CHANGE v.1.6-->
C      LOGICAL       DRAWLN(4), OTHVIS, SPCTRM
      LOGICAL       DRAWLN(4), NEGCOL, OTHVIS, SPCTRM
CHANGE v.1.6<--
CHANGE v.1.4<--
      REAL          BWIDTH, COORDS(2,4), CSIZE, DIST2, LAMBDA, LDIFF,
CHANGE v.1.4-->
C     -              LWIDTH, PERC, PCOMP, PLEN, PTARG, RNK, RNX,
C     -              RNY, RNZ, SHADE, SWAP, TEMP, TSIZE, WIDMAX, X, X1,
C     -              XLINE(4,4), Y, Y1, Z, ZDIFF, ZMAXX, ZMINX, ZVALUE
     -              LWIDTH, PERC, PCOMP, PLEN, PTARG, RGBVAL(3), RNK,
     -              RNX, RNY, RNZ, SHADE, SWAP, TEMP, TSIZE, X, X1,
     -              XLINE(4,4), Y, Y1, Z, ZDIFF, ZMAXX, ZMINX, ZVALUE
CHANGE v.1.4<--

      DATA PTARG  / 0.05 /
CHANGE v.1.4-->
C      DATA WIDMAX / 1.0 / 
CHANGE v.1.4<--

C---- Initialise values
      PRINT*
      IF (ITRAN.GT.3) THEN
          PRINT*, 'Plotting foreground object'
      ELSE
          PRINT*, 'Plotting background projection:', ITRAN
      ENDIF
      PCOMP = PTARG

C---- Find the range of z-values for line-widths
      ZMINX = EDIST(POLORD(1))
      ZMAXX = EDIST(POLORD(NPOL))
      ZDIFF = ZMAXX - ZMINX
      IF (ZDIFF.LE.EMIN) ZDIFF = 1.0
      LDIFF = WMAX - WMIN

C---- Loop through all the polygons in ascending value of z-coordinate
      DO 500, IPOINT = 1, NPOL

C----     Report on progress
          PERC = REAL(IPOINT) / REAL(NPOL)
          IF (PERC.GT.PCOMP) THEN
              PRINT 20, 100.0 * PERC, '% done'
 20           FORMAT(F8.2,A)
              PCOMP = PCOMP + PTARG
          ENDIF

C----     Find next polygon
          IPOL = POLORD(IPOINT)
          COLOUR = 0

C----     Determine which map this polygon belongs to
          INMAP = 0
          DO 50, IMAP = 1, NMAP
             IF (IPOL.GE.MAPFST(IMAP)) INMAP = IMAP
 50       CONTINUE
          IMAP = INMAP
          IF (BGREY(IMAP)) COLOUR = 99

C----     If the colour for this polygon is -999, then don't plot it
          IF ((ITRAN.EQ.4 .AND. POLCOL(IPOL).EQ.-999) .OR.
     -        (ITRAN.LT.4 .AND. POLBAK(IPOL).EQ.-999)) GO TO 500

C----     Find start and end points of polygon
          ISTART = IPOLYG(IPOL)
          IF (IPOL.LT.NPOL) THEN
              IEND = IPOLYG(IPOL + 1) - 1
          ELSE
              IEND = NVERT
          ENDIF
          NPOINT = IEND - ISTART + 1

C----     Determine whether current polygon needs to be shaded in
          IF (PLOTWR(IPOL) .AND. ITRAN.EQ.4) THEN
              SHADIN = .FALSE.
          ELSE
              SHADIN = .TRUE.
          ENDIF

C----     Write out the shade for this polygon
          IF (.NOT.SHADIN .OR. VISIBL(IPOL)) THEN

C----         If plotting one of the orthographic projections, set the
C             shade colour to white or grey
              IF (PLOTWR(IPOL) .OR. ITRAN.LT.4) THEN
CHANGE v.1.4-->
C                  IF (BGREY(IMAP)) THEN
                  IF (BGREY(IMAP) .AND. ITRAN.LT.4) THEN
CHANGE v.1.4<--
                      COLOUR = 99
                      LAMBDA = 1.0
                      SHADE = 1.0
                  ELSE
                      COLOUR = ABS(POLBAK(IPOL))
                      LAMBDA = 1.0
                      SHADE = 1.0
                  ENDIF
              ELSE

C----             If the polygon is not a point or a line, calculate its
C                 shade by calculating its orientation
                  IF (NPOINT.GT.2) THEN

C----                 If the polygon colour is negative, shade in as
C                     white
                      IF (POLCOL(IPOL).LT.0) THEN
                          SHADE = 1.0
                      ELSE

C----                     Calculate normal vector for current polygon
                          CALL NRMPOL(IPOL,RNX,RNY,RNZ,RNK)

C----                     Calculate intensity of light according to
C                         orientation of polygon relative to the
C                         observer's eye and light source
                          CALL ISHADE(MIDX(IPOL),MIDY(IPOL),MIDZ(IPOL),
     -                        RNX,RNY,RNZ,LAMBDA)
                          COLOUR = ABS(POLCOL(IPOL))
                          SHADE = (1.0 - POLCOL(IPOL) / 10.0) * LAMBDA
                          SHADE = MAX(SHADE,0.0)
                      ENDIF
                  ENDIF
              ENDIF

C----     If this is a shaded polygon and is facing the other way, colour
C         it black if line-width is -ve, else don't plot it at all
          ELSE
              IF (POLINE(IPOL).LT.0.0) THEN
                  SHADE = 0.0
              ELSE
                  GO TO 500
              ENDIF
          ENDIF

C----     Initialise line for polygon
          ILINE = 0
          DLINE = 0
          DRAWLN(1) = .FALSE.
          DRAWLN(2) = .FALSE.
          DRAWLN(3) = .FALSE.
          DRAWLN(4) = .FALSE.

C----     Loop through all the lines in the polygon and store the projected
C         coordinates
          DO 100, IVERT = ISTART, IEND
              ILINE = ILINE + 1
              IF (ILINE.LE.4) THEN
                  X = PCOORD(1,VERTNO(IVERT))
                  Y = PCOORD(2,VERTNO(IVERT))
                  Z = 0.0

C----             If this is one of the orthogonal projections, project back
C                 into original reference frame
                  IF (ITRAN.LT.4) CALL TRANSF(X,Y,Z,BACKWD,ITRAN)
                  COORDS(1,ILINE) = XSHIFT + SCALE * (X - XCENT)
                  COORDS(2,ILINE) = YSHIFT + SCALE * (Y - YCENT)

C----             If this is a sphere calculate the projected radius
                  IF (ISTART.EQ.IEND) THEN
CHANGE v.1.4-->
C                      X = PCOORD(1,VERTNO(IVERT)) + ATMRAD
                      X = PCOORD(1,VERTNO(IVERT)) + ABS(POLINE(IPOL))
CHANGE v.1.4<--
                      Y = PCOORD(2,VERTNO(IVERT))
                      Z = 0.0
                      IF (ITRAN.LT.4) CALL TRANSF(X,Y,Z,BACKWD,ITRAN)
                      X = XSHIFT + SCALE * (X - XCENT)
                      Y = YSHIFT + SCALE * (Y - YCENT)
                      TEMP = (X - COORDS(1,ILINE))
     -                    * (X - COORDS(1,ILINE))
     -                    + (Y - COORDS(2,ILINE))
     -                    * (Y - COORDS(2,ILINE))
                      CSIZE = SQRT(TEMP)

C----                 If this is a perspective projection, use the
C                     sphere size already calculated
                      IF (PERSPC .AND. .NOT.BACKON) THEN
                          CSIZE = SCALE * PRJRAD(VERTNO(IVERT))
                      ENDIF
                  ENDIF
              ENDIF

C----         If this line is on the edge of the object, then draw it in
C             as an outline
CHANGE v.1.1.1-->
C              IF (.NOT.PLOTWR(IPOL) .AND. OTHPOL(IVERT).EQ.0) GO TO 100
CHANGE v.1.1.1<--
              IF (OTHPOL(IVERT).EQ.0) THEN
                  OTHVIS = .TRUE.
CHANGE v.1.1.1-->
                   IF (.NOT.PLOTWR(IPOL)) OTHVIS = .FALSE.
CHANGE v.1.1.1<--
              ELSE
                  OTHVIS = VISIBL(OTHPOL(IVERT))
              ENDIF
              IF (VISIBL(IPOL) .AND. .NOT.OTHVIS) THEN
                  JVERT = IVERT + 1
                  IF (JVERT.GT.IEND) JVERT = ISTART
                  DLINE = DLINE + 1
                  IF (DLINE.LE.4) THEN
                      DRAWLN(ILINE) = .TRUE.

C----                 If this is one of the orthogonal projections,
C                     project back into original reference frame
                      X = PCOORD(1,VERTNO(IVERT))
                      Y = PCOORD(2,VERTNO(IVERT))
                      Z = 0.0
                      IF (ITRAN.LT.4) CALL TRANSF(X,Y,Z,BACKWD,ITRAN)
                      XLINE(1,DLINE) = XSHIFT + SCALE * (X - XCENT)
                      XLINE(2,DLINE) = YSHIFT + SCALE * (Y - YCENT)
                      X = PCOORD(1,VERTNO(JVERT))
                      Y = PCOORD(2,VERTNO(JVERT))
                      Z = 0.0
                      IF (ITRAN.LT.4) CALL TRANSF(X,Y,Z,BACKWD,ITRAN)
                      XLINE(3,DLINE) = XSHIFT + SCALE * (X - XCENT)
                      XLINE(4,DLINE) = YSHIFT + SCALE * (Y - YCENT)
                  ENDIF
              ENDIF
 100      CONTINUE

C----     Calculate line-width for polygon borders
          ZVALUE = EDIST(IPOL)
          LWIDTH = WMIN + LDIFF * (ZVALUE - ZMINX) / ZDIFF
CHANGE v.1.4-->
C          LWIDTH = ABS(LWIDTH)
          LWIDTH = SCALE * ABS(LWIDTH)
CHANGE v.1.4<--
          IF (PLOTWR(IPOL)) THEN
CHANGE v.1.4-->
C              LWIDTH = WIDMAX * ABS(POLINE(IPOL) / 10.0)
              LWIDTH = SCALE * ABS(POLINE(IPOL)) / 10.0
CHANGE v.1.4<--
          ENDIF
CHANGE v.1.4-->
C          IF (LWIDTH.GT.1.0) LWIDTH = 1.0
          IF (LWIDTH.GT.99.9) LWIDTH = 99.9
CHANGE v.1.4<--

C----     Plot the polygon

C----     Polygon is a single point (ie a single atom)
          IF (ILINE.EQ.1) THEN

C----         Get the appropriate colour/shade
              IF (ITRAN.GT.3) THEN
                  COLOUR = POLCOL(IPOL)
              ELSE
                  COLOUR = POLBAK(IPOL)
              ENDIF
CHANGE v.1.4-->
              IF (FILTYP(IMAP).EQ.'a') THEN

C----             Colouring/shading atoms by their B-value
                  CALL GETSPC(ABS(COLOUR),SHADE,RGBVAL)
                  SPCTRM = .TRUE.
              ELSE
                  SPCTRM = .FALSE.
CHANGE v.1.4<--
                  SHADE = (10.0 - REAL(ABS(COLOUR))) / 10.0
CHANGE v.1.4-->
                  IF (SHADE.LT.0.0) SHADE = 0.0
              ENDIF
CHANGE v.1.4<--
              CALL PSLWID(0.2)
              CALL PSDASH(0)

C----         If colour is positive, then draw a sphere of the appropriate
C             colour
              IF (COLOUR.GE.0) THEN

C----             For foreground object, or background object with the SOLID
C                 option defined, plot a full sphere
                  IF (ITRAN.GT.3 .OR. .NOT.PLOTWR(IPOL)) THEN
                      IF (INCOLR) THEN
                          CALL PSCOLB(10)
CHANGE v.1.4-->
C                          CALL PSPHCL(COLOUR)
                          IF (SPCTRM) THEN
                              CALL PSPHSC(RGBVAL)
                          ELSE
                              CALL PSPHCL(COLOUR)
                          ENDIF
CHANGE v.1.4<--
                      ELSE
CDEBUG
      PRINT*, '[3]'
CDEBUG
                          CALL PSHADB(0.0)
                          CALL PSPHSH(SHADE)
                      ENDIF
                      CALL PSPHER(COORDS(1,1),COORDS(2,1),CSIZE)

C----             For a back projection, just plot a shaded circle
                  ELSE
                      IF (INCOLR) THEN
CHANGE v.1.4-->
C                          IF (BGREY(IMAP)) COLOUR = 99
C                          CALL PSCCOL(COLOUR)
                          IF (BGREY(IMAP)) THEN
                              COLOUR = 99
                              SPCTRM = .FALSE.
                          ENDIF
                          IF (SPCTRM) THEN
                              CALL PSCCSC(RGBVAL)
                          ELSE
                              CALL PSCCOL(COLOUR)
                          ENDIF
CHANGE v.1.4<--
                          CALL PSUCIR(COORDS(1,1),COORDS(2,1),CSIZE)
                      ELSE
                          CALL PSCSHD(0.8)
                          CALL PSUCIR(COORDS(1,1),COORDS(2,1),CSIZE)
                      ENDIF
                  ENDIF

C----         Otherwise, just print a point of the appropriate colour
              ELSE IF (COLOUR.GE.-10) THEN
                  CALL PSLWID(2.0)
                  IF (INCOLR) THEN
CHANGE v.1.4-->
C                      IF (BGREY(IMAP)) COLOUR = 99
C                      CALL PSCOLB(ABS(COLOUR))
                      IF (BGREY(IMAP)) THEN
                              COLOUR = 99
                              SPCTRM = .FALSE.
                          ENDIF
                      IF (SPCTRM) THEN
                          CALL PSCOLB(ABS(COLOUR))
                      ELSE
                          CALL PSCOLB(ABS(COLOUR))
                      ENDIF
CHANGE v.1.4<--
                  ELSE
CDEBUG
      PRINT*, '[4]'
CDEBUG
                      CALL PSHADB(SHADE)
                  ENDIF
                  CALL PSLINE(COORDS(1,1),COORDS(2,1),COORDS(1,1),
     -                COORDS(2,1))
              ENDIF

C----         If the atoms are to be numbered on the foreground object,
C             print a sequential number above this atom
              IF (NUMBAT .AND. ITRAN.GT.3) THEN

C----             Print the sequential number of this polygon (ie atom)
C                 in this map
                  IF (IMAP.GT.0) THEN
                      PTNUMB = IPOL - MAPFST(IMAP) + 1
                      WRITE(TEXT,120) PTNUMB
 120                  FORMAT(I6)
                      J = 1
                      DO 130, I = 1, 5
                          IF (TEXT(I:I).EQ.' ') J = I + 1
 130                  CONTINUE
                      TSIZE = 3.0 * CSIZE / 2.0
                      TSIZE = MIN(40.0,TSIZE)
                      CALL PSCTXT(COORDS(1,1),COORDS(2,1)
     -                     + CSIZE + TSIZE / 2.0,TSIZE,TEXT(J:6))
                  ENDIF
              ENDIF

C----     Polygon is just a straight line (ie bond between 2 fragment atoms)
          ELSE IF (ILINE.EQ.2) THEN

C----         Calculate line width
CHANGE v.1.4-->
C              BWIDTH = 2.0 * POLINE(IPOL)
CHANGE v.1.4.2-->
C              BWIDTH = 2.0 * SCALE * POLINE(IPOL)
              BWIDTH = 2.0 * SCALE * ABS(POLINE(IPOL))
CHANGE v.1.4.2<--
              IF (BWIDTH.GT.99.9) BWIDTH = 99.9
CHANGE v.1.4<--

C----         Get the appropriate colour/shade and set line-width
CHANGE v.1.6-->
              NEGCOL = .FALSE.
CHANGE v.1.6<--
              IF (ITRAN.GT.3) THEN
                  CALL PSLWID(BWIDTH)
                  COLOUR = ABS(POLCOL(IPOL))
CHANGE v.1.6-->
                  IF (POLCOL(IPOL).LT.0) NEGCOL = .TRUE.
CHANGE v.1.6<--
              ELSE
                  CALL PSLWID(BWIDTH / 2.0)
                  COLOUR = ABS(POLBAK(IPOL))
                  IF (INCOLR .AND. BGREY(IMAP)) COLOUR = 99
CHANGE v.1.6-->
                  IF (POLBAK(IPOL).LT.0) NEGCOL = .TRUE.
CHANGE v.1.6<--
              ENDIF
              SHADE = (10.0 - REAL(COLOUR)) / 10.0

C----         Set colour and dash
              IF (INCOLR) THEN
CHANGE v.1.6-->
                  IF (BSITE .AND. NEGCOL .AND. COLOUR.NE.99) THEN
                      COLOUR = COLOUR + 20
                  ENDIF
CHANGE v.1.6<--
                  CALL PSCOLB(COLOUR)
              ELSE
CDEBUG
      PRINT*, '[5]'
CDEBUG
                  CALL PSHADB(SHADE)
              ENDIF
              IF (POLINE(IPOL).LT.0.0) THEN
                  CALL PSDASH(2)
              ELSE
                  CALL PSDASH(0)
              ENDIF

C----         If the bond-line is to be truncated at one end by an
C             atom's radius, then apply the truncation
              IF (.NOT.PLOTWR(IPOL)) THEN

C----             Calculate projected radius of a sphere
                  X = PCOORD(1,VERTNO(ISTART)) + ATMRAD
                  Y = PCOORD(2,VERTNO(ISTART))
                  Z = 0.0
                  IF (ITRAN.LT.4) CALL TRANSF(X,Y,Z,BACKWD,ITRAN)
                  X = XSHIFT + SCALE * (X - XCENT)
                  Y = YSHIFT + SCALE * (Y - YCENT)
                  TEMP = (X - COORDS(1,1)) * (X - COORDS(1,1))
     -                + (Y - COORDS(2,1)) * (Y - COORDS(2,1))
                  CSIZE = TEMP

C----             If this is a perspective projection, use the
C                 sphere size already calculated
                  IF (PERSPC .AND. .NOT.BACKON) THEN
                      CSIZE = SCALE * PRJRAD(VERTNO(IVERT))
                      CSIZE = CSIZE * CSIZE
                  ENDIF

C----             Calculate projected length of line
                  X = COORDS(1,1)
                  Y = COORDS(2,1)
                  X1 = COORDS(1,2)
                  Y1 = COORDS(2,2)
                  DIST2 = (X - X1) *  (X - X1)
     -                  + (Y - Y1) *  (Y - Y1)

C----             If length of greater than an atomic radius, then
C                 calculate fraction to be lopped off one end
C                  IF (DIST2.GT.4.0 * CSIZE) THEN
                  IF (DIST2.GT.CSIZE) THEN
                      PLEN = SQRT(CSIZE / DIST2)
                  ELSE
                      PLEN = 1.0
                  ENDIF

C----             Calculate amount by which to truncate each end of line
                  X = PLEN * (COORDS(1,2) - COORDS(1,1))
                  Y = PLEN * (COORDS(2,2) - COORDS(2,1))

C----             Apply the truncation
                  COORDS(1,1) = COORDS(1,1) + X
C                  COORDS(1,2) = COORDS(1,2) - X
                  COORDS(2,1) = COORDS(2,1) + Y
C                  COORDS(2,2) = COORDS(2,2) - Y
              ELSE
                  PLEN = 0.0
              ENDIF
              IF (PLEN.LT.1.0) THEN
                  CALL PSLINE(COORDS(1,1),COORDS(2,1),COORDS(1,2),
     -                COORDS(2,2))
              ENDIF

C----     Polygon is a triangle
          ELSE IF (ILINE.EQ.3) THEN

C----         If have a wire-frame triangle then will plot it straight
              IF (.NOT.SHADIN) DLINE = 3

C----         If plotting the back-projections of a wire-frame diagram,
C             plot only the border lines
              IF (PLOTWR(IPOL) .AND. ITRAN.LT.4) THEN
                  IF (DLINE.GT.0) THEN
                      CALL PSLWID(LWIDTH)
CDEBUG
      PRINT*, '[6]'
CDEBUG
                      CALL PSHADB(0.0)
                      COLOUR = ABS(POLBAK(IPOL))
                      SHADE = (10.0 - REAL(COLOUR)) / 10.0

C----                 Set colour and dash
                      IF (INCOLR) THEN
                          IF (BGREY(IMAP)) COLOUR = 99
                          CALL PSCOLB(COLOUR)
                      ELSE
CDEBUG
      PRINT*, '[7]'
CDEBUG
                          CALL PSHADB(SHADE)
                      ENDIF
                      IF (POLINE(IPOL).LT.0.0) THEN
                          CALL PSDASH(1)
                      ELSE
                          CALL PSDASH(0)
                      ENDIF
                  ENDIF
                  DO 140, ILINE = 1, DLINE
                      CALL PSLINE(XLINE(1,ILINE),XLINE(2,ILINE),
     -                    XLINE(3,ILINE),XLINE(4,ILINE))
 140              CONTINUE

C----         Otherwise, plot the appropriate type of triangle
              ELSE

C----             Initialise colours and line-widths
                  IF (DLINE.EQ.0) THEN
                      CALL PSLWID(0.0)
                  ELSE
CHANGE v.1.4-->
                      LWIDTH = SCALE * ABS(POLINE(IPOL)) / 10.0
                      IF (LWIDTH.GT.10.0) LWIDTH = 10.0
CHANGE v.1.4<--
                      CALL PSLWID(LWIDTH)
CDEBUG
      PRINT*, '[8]'
CDEBUG
                      CALL PSHADB(0.0)
                      CALL PSCOLB(10)
                      CALL PSDASH(0)
                  ENDIF
                  IF (SHADIN) THEN
CHANGE v.1.4-->
C                      IF (INCOLR) THEN
                      IF (BGREY(IMAP) .AND. ITRAN.LT.4) THEN
                          SHADE = 0.8
                          CALL PSHADE(SHADE)
                          DLINE = 0
                          CALL PSLWID(0.0)
                      ELSE IF (INCOLR) THEN
CHANGE v.1.4<--
                          IF (COLOUR.LE.0 .OR. COLOUR.GT.MXCOLS) THEN
                              CALL PSHADE(SHADE)
                          ELSE
                              CALL PSETCL(RGBCOL(1,COLOUR),LAMBDA)
                          ENDIF
                      ELSE
                          CALL PSHADE(SHADE)
                      ENDIF
                  ENDIF

C----             Plot a triangle with 0, 1, 2 or 3 border lines, as reqrd

C----             No border lines
CHANGE v.1.4-->
C                  IF (DLINE.EQ.0 .OR.
C     -                (ITRAN.GT.3 .AND. BGREY(IMAP))) THEN
                  IF (DLINE.EQ.0) THEN
CHANGE v.1.4<--
                      CALL PSTRIA(COORDS(1,1),COORDS(2,1),COORDS(1,2),
     -                    COORDS(2,2),COORDS(1,3),COORDS(2,3))

C----             One border-line: adjust vertex order and plot
                  ELSE IF (DLINE.EQ.1) THEN
                      NCYCLE = 0
                      IF (DRAWLN(2)) NCYCLE = 1
                      IF (DRAWLN(3)) NCYCLE = 2
                      DO 200, ICYCLE = 1, NCYCLE
                          DO 150, ICOORD = 1, 2
                              SWAP = COORDS(ICOORD,1)
                              COORDS(ICOORD,1) = COORDS(ICOORD,2)
                              COORDS(ICOORD,2) = COORDS(ICOORD,3)
                              COORDS(ICOORD,3) = SWAP
 150                      CONTINUE
 200                  CONTINUE
                      CALL PSTRI1(COORDS(1,1),COORDS(2,1),COORDS(1,2),
     -                    COORDS(2,2),COORDS(1,3),COORDS(2,3))

C----             Two border-lines: adjust vertex order and plot
                  ELSE IF (DLINE.EQ.2) THEN
                      NCYCLE = 0
                      IF (.NOT.DRAWLN(1)) NCYCLE = 1
                      IF (.NOT.DRAWLN(2)) NCYCLE = 2
                      DO 300, ICYCLE = 1, NCYCLE
                          DO 250, ICOORD = 1, 2
                              SWAP = COORDS(ICOORD,1)
                              COORDS(ICOORD,1) = COORDS(ICOORD,2)
                              COORDS(ICOORD,2) = COORDS(ICOORD,3)
                              COORDS(ICOORD,3) = SWAP
 250                      CONTINUE
 300                  CONTINUE
                      CALL PSTRI2(COORDS(1,1),COORDS(2,1),COORDS(1,2),
     -                    COORDS(2,2),COORDS(1,3),COORDS(2,3))

C----             All three borders are to be drawn: plot it straight
                  ELSE IF (DLINE.EQ.3) THEN

C----                 If plotting as a wire-frame, draw solid lines if
C                     polygon visible, and dashed lines if it is not
                      IF (.NOT.SHADIN) THEN
                          IF (ITRAN.GT.3) THEN
                              COLOUR = ABS(POLCOL(IPOL))
                          ELSE
                              COLOUR = ABS(POLBAK(IPOL))
                          ENDIF
                          SHADE = (10.0 - REAL(COLOUR)) / 10.0

C----                     Set colour
                          IF (INCOLR) THEN
                              CALL PSCOLB(COLOUR)
                          ELSE
CDEBUG
      PRINT*, '[9]'
CDEBUG
                              CALL PSHADB(SHADE)
                          ENDIF

C----                     Set dashed line if required
                          IF (POLINE(IPOL).LT.0.0) THEN
                              IF (.NOT.VISIBL(IPOL)) THEN
                                  CALL PSDASH(1)
                              ELSE
                                  CALL PSDASH(2)
                              ENDIF
                          ELSE
                              IF (.NOT.VISIBL(IPOL)) THEN
                                  CALL PSDASH(3)
                              ELSE
                                  CALL PSDASH(0)
                              ENDIF
                          ENDIF

C----                     Plot the three lines making up the triangle
                          CALL PSLINE(COORDS(1,1),COORDS(2,1),
     -                        COORDS(1,2),COORDS(2,2))
                          CALL PSLINE(COORDS(1,2),COORDS(2,2),
     -                        COORDS(1,3),COORDS(2,3))
                          CALL PSLINE(COORDS(1,3),COORDS(2,3),
     -                        COORDS(1,1),COORDS(2,1))

C----                 For a solid object, plot triangular polygon
                      ELSE
                          CALL PSTRI3(COORDS(1,1),COORDS(2,1),
     -                        COORDS(1,2),COORDS(2,2),COORDS(1,3),
     -                        COORDS(2,3))
                      ENDIF
                  ENDIF
              ENDIF

C----     Polygon has 4 sides
          ELSE IF (ILINE.EQ.4) THEN
              CALL PSLWID(0.0)
              CALL PSDASH(0)
CDEBUG
      PRINT*, '[10]'
CDEBUG
              CALL PSHADB(0.0)
CHANGE v.1.1.1-->
C              CALL PSHADE(SHADE)
              CALL PSCOLB(10)
              CALL PSDASH(0)
              IF (INCOLR) THEN
                  IF (COLOUR.LE.0 .OR. COLOUR.GT.MXCOLS) THEN
                      CALL PSHADE(SHADE)
                  ELSE
                      CALL PSETCL(RGBCOL(1,COLOUR),LAMBDA)
                  ENDIF
              ELSE
                  CALL PSHADE(SHADE)
              ENDIF
CHANGE v.1.1.1<--
              CALL PSUBOX(COORDS(1,1),COORDS(2,1),COORDS(1,2),
     -            COORDS(2,2),COORDS(1,3),COORDS(2,3),COORDS(1,4),
     -            COORDS(2,4))

C----         Draw any of the boundary lines
              IF (DLINE.GT.0) CALL PSLWID(LWIDTH)
              DO 400, ILINE = 1, DLINE
                  CALL PSLINE(XLINE(1,ILINE),XLINE(2,ILINE),
     -                XLINE(3,ILINE),XLINE(4,ILINE))
 400          CONTINUE
          ENDIF
 500  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETSPC  -  Convert the colour-number (0-80) into an RGB colour
C                        ranging from Blue for 0 to Red for 80.
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GETSPC(COLOUR,SHADE,RGBVAL)

      INTEGER       COLOUR
      REAL          RGBVAL(3), SHADE

C---- Initialise colour to red, and shade to black
      RGBVAL(1) = 1.0
      RGBVAL(2) = 0.0
      RGBVAL(3) = 0.0
      SHADE = 0.0

C---- Compute the RGB components for the given colour
      IF (COLOUR.GE.0 .AND. COLOUR.LE.20) THEN
          RGBVAL(1) = 0.0
          RGBVAL(2) = COLOUR / 20.0
          RGBVAL(3) = 1.0
      ELSE IF (COLOUR.GE.20 .AND. COLOUR.LE.40) THEN
          RGBVAL(1) = 0.0
          RGBVAL(2) = 1.0
          RGBVAL(3) = (40 - COLOUR) / 20.0
      ELSE IF (COLOUR.GE.40 .AND. COLOUR.LE.60) THEN
          RGBVAL(1) = (COLOUR - 40) / 20.0
          RGBVAL(2) = 1.0
          RGBVAL(3) = 0.0
      ELSE IF (COLOUR.GE.60 .AND. COLOUR.LE.80) THEN
          RGBVAL(1) = 1.0
          RGBVAL(2) = (80 - COLOUR) / 20.0
          RGBVAL(3) = 0.0
      ENDIF

C---- Compute the shade
      SHADE = (80 - COLOUR) / 80.0
      IF (SHADE.LT.0.0) SHADE = 0.0
      IF (SHADE.GT.1.0) SHADE = 1.0

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE NRMPOL  -  Extracts polygon's 1st three coordinates for
C                        calculating the normal to the plane of the
C                        polygon
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE NRMPOL(IPOL,RNX,RNY,RNZ,RNK)

      INCLUDE 'surfplot.inc'
 
      INTEGER       IPOL, ISTART, KV1, KV2, KV3
      REAL          RNK, RNX, RNY, RNZ

C---- Retrieve the first three vertices of current polygon
      ISTART = IPOLYG(IPOL)
      KV1 = ISTART
      KV2 = KV1 + 1
      KV3 = KV1 + 2

C---- Calculate the normal to the plane
      CALL NORMAL(RNX,RNY,RNZ,RNK,
     -    VERTEX(1,VERTNO(KV1)),VERTEX(2,VERTNO(KV1)),
     -        VERTEX(3,VERTNO(KV1)),
     -    VERTEX(1,VERTNO(KV2)),VERTEX(2,VERTNO(KV2)),
     -        VERTEX(3,VERTNO(KV2)),
     -    VERTEX(1,VERTNO(KV3)),VERTEX(2,VERTNO(KV3)),
     -        VERTEX(3,VERTNO(KV3)))

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE NORMAL  -  Finds the plane RNX.x + RNY.y + RNZ.z = RNK for
C                        current polygon
C
C [Adapted from Angell & Griffith]
C----------------------------------------------------------------------+--- 

      SUBROUTINE NORMAL(RNX,RNY,RNZ,RNK,X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3)

      INCLUDE 'surfplot.inc'
 
      REAL          DX1, DX2, DY1, DY2, DZ1, DZ2, RNK, RNX, RNY, RNZ,
     -              X1, Y1, Z1, X2, Y2, Z2, X3, Y3, Z3

C---- Form two vectors, (dx1,dy1,dz1) and (dx2,dy2,dz2), that lie in the
C     plane of the polygon
      DX1 = X2 - X1
      DY1 = Y2 - Y1
      DZ1 = Z2 - Z1
      DX2 = X3 - X2
      DY2 = Y3 - Y2
      DZ2 = Z3 - Z2

C---- Equation of the plane is RNX.x + RNY.y + RNZ.z = RNK
      RNX = DY1 * DZ2 - DY2 * DZ1
      RNY = DZ1 * DX2 - DZ2 * DX1
      RNZ = DX1 * DY2 - DX2 * DY1
      RNK = RNX * X1 + RNY * Y1 + RNZ * Z1

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE ISHADE  -  Finds the shade of the supplied point on the
C                        polygon due to a point source
C
C [Adapted from Angell & Griffith]
C----------------------------------------------------------------------+--- 

      SUBROUTINE ISHADE(PX,PY,PZ,XN,YN,ZN,LAMBDA)

      INCLUDE 'surfplot.inc'
 
      REAL          AMB, COSVAL, DOT, LAMBDA, PX, PY, PZ, SL, SN, SXP,
     -              SYP, SZP, XN, YN, ZN


C---- Calculate direction of light ray from source to (px,py,pz)
CHANGE v.1.3.3-->
C      SXP = PX - (XMIN - LIGHTX)
C      SYP = PY - (YMIN - LIGHTY)
C      SZP = LIGHTZ - PZ
      SXP = PX - (XMIN - LITEX)
      SYP = PY - (YMIN - LITEY)
      SZP = LITEZ - PZ
CHANGE v.1.3.3<--

C---- Calculate the dot product
      DOT = XN * SXP + YN * SYP + ZN * SZP
      SN = SQRT(XN * XN + YN * YN + ZN * ZN)
      SL = SQRT(SXP * SXP + SYP * SYP + SZP * SZP)
      IF (SN * SL.GT.EMIN) THEN
          COSVAL = DOT / (SN * SL)
      ELSE
          COSVAL = 0.0
      ENDIF
      IF (COSVAL.LT.0.0) COSVAL = 0.0

C---- Set ambient level
CHANGE v.1.4-->
C      AMB = 0.5
      AMB = 0.3
CHANGE v.1.4<--

C---- LAMBDA is the intensity returned
      LAMBDA = ((1 - AMB) * COSVAL + AMB)

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.5-->
C**************************************************************************
C
C  SUBROUTINE CLOWRL  -  Close off the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE CLOWRL(CURCOL)

      INTEGER       CURCOL

C---- If have written one or more colour objects, then close off the
C     last separator
      IF (CURCOL.NE.-1) THEN
          WRITE(14,20) 
 20       FORMAT(' }')
      ENDIF

C---- Write the closing records to the VRML file
      WRITE(14,120) 
 120  FORMAT('}')

C---- Close the file
      CLOSE(14)

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.5<--
C**************************************************************************
C
C  SUBROUTINE PSOPEN  -  Open PostScript file and write out header records
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSOPEN(FNAME)

      INCLUDE 'surfplot.inc'

      CHARACTER*(*)  FNAME
      CHARACTER*2    COLNO
      INTEGER        I, ICOL
      LOGICAL        BORDER
CHANGE v.1.6-->
C      REAL           GCOLOR(3), RGB(3,MXCOLS)
      REAL           GCOLOR(3), RGB(3,MXCOLS), RGB2(3,14)
CHANGE v.1.6<--

      DATA GCOLOR  / 0.8000, 0.8000, 0.8500 /

      DATA RGB     / 1.0000, 1.0000, 0.0000,
     -               0.7000, 0.8000, 0.7000,
     -               0.5000, 1.0000, 0.0000,
     -               0.0000, 1.0000, 0.0000,
CHANGE v.1.1.1-->
C     -               0.2000, 0.8000, 1.0000,
     -               0.0000, 0.0000, 0.8000,
CHANGE v.1.1.1<--
     -               1.0000, 0.5000, 1.0000,
     -               0.8000, 0.5000, 0.0000,
     -               1.0000, 0.0000, 0.0000,
     -               0.5000, 0.0000, 1.0000,
     -               0.0000, 0.0000, 0.0000,
     -               0.3000, 0.8000, 1.0000,
CHANGE v.1.1.1-->
C     -               1.0000, 1.0000, 0.7000 /
     -               1.0000, 1.0000, 0.7000,
     -               0.5000, 1.0000, 0.3000 /
CHANGE v.1.1.1<--
CHANGE v.1.6-->
      DATA RGB2    / 1.0000, 0.0000, 0.0000,
     -               0.6000, 0.0000, 1.0000,
     -               1.0000, 0.8431, 0.0000,
     -               0.0000, 0.0000, 1.0000,
     -               0.0000, 1.0000, 0.0000,
     -               0.5451, 0.2706, 0.0745,
     -               1.0000, 0.4118, 0.7059,
     -               0.2000, 0.6000, 0.4000,
     -               1.0000, 0.0000, 1.0000,
     -               0.0000, 1.0000, 1.0000,
     -               1.0000, 0.4000, 0.0000,
     -               0.9333, 0.5098, 0.9333,
     -               1.0000, 0.6000, 0.0000,
     -               1.0000, 1.0000, 1.0000 /
CHANGE v.1.6<--

C---- Initialise variables
      BORDER = .FALSE.
      DO 100, ICOL = 1, MXCOLS
          RGBCOL(1,ICOL) = RGB(1,ICOL)
          RGBCOL(2,ICOL) = RGB(2,ICOL)
          RGBCOL(3,ICOL) = RGB(3,ICOL)
 100  CONTINUE

C---- Open output file
      OPEN(UNIT=11, FILE=FNAME, STATUS='UNKNOWN',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write header records out to PostScript file
      WRITE(11,120)
 120  FORMAT(
     -    '%!PS-Adobe-3.0',/,
     -    '%%Creator: Surfplot',/,
     -    '%%DocumentNeededResources: font Times-Roman Symbol',/,
     -    '%%BoundingBox: (atend)',/,
     -    '%%Pages: 1',/,
     -    '%%EndComments',/,
     -    '%%BeginProlog')
      WRITE(11,130)
 130  FORMAT(
     -    '/Print { /Times-Roman findfont exch scalefont setfont show',
     -    ' } bind def',/,
     -    '/Center {',/,
     -    '  dup /Times-Roman findfont exch scalefont setfont',/,
     -    '  exch stringwidth pop -2 div exch -3 div rmoveto',/,
     -    ' } bind def',/,
     -    '/C { setrgbcolor } bind def',/,
     -    '/D { setdash } bind def',/,
     -    '/G { setgray } bind def',/,
     -    '/L { moveto lineto stroke } bind def',/,
     -    '/S { gsave } bind def',/,
     -    '/W { setlinewidth } bind def'
     -    )

C---- Loop to define the colours
      COLNO = '00'
      WRITE(11,160) COLNO, 1.0, 1.0, 1.0
      DO 200, ICOL = 1, MXCOLS
          WRITE(COLNO,140) ICOL
 140      FORMAT(I2.0)
          IF (COLNO(1:1).EQ.' ') COLNO(1:1) = '0'
          WRITE(11,160) COLNO, (RGB(I,ICOL), I = 1, 3)
 160      FORMAT('/Col',A2,' {',3F8.4,' setrgbcolor } def')
 200  CONTINUE

CHANGE v.1.6-->
C---- Define the extra colours for binding sites
      IF (BSITE) THEN
          COLNO = '20'
          DO 500, ICOL = 1, MXCOLS
              WRITE(COLNO,140) ICOL + 20
              WRITE(11,160) COLNO, (RGB2(I,ICOL), I = 1, 3)
 500      CONTINUE
      ENDIF
CHANGE v.1.6<--

C---- Write out the background-grey colour
      WRITE(11,210) (GCOLOR(I), I = 1, 3)
 210  FORMAT('/Col99 {',3F8.4,' setrgbcolor } def')

C---- Remainder of set-up definitions
      WRITE(11,220)
 220  FORMAT(
     -    '/Noline { 0.00 setlinewidth } bind def',/,
     -    '/Plane3 { moveto lineto lineto fill grestore } bind def',/,
     -    '/Plane4 { moveto lineto lineto lineto fill grestore } bind',
     -    ' def')
      WRITE(11,230)
 230  FORMAT(
     -    '/Pline4 { 8 copy Plane4 moveto lineto lineto lineto closep',
     -    'ath stroke } bind def',/,
     -    '/Pl3 { 6 copy Plane3 moveto moveto moveto closepath stroke',
     -    ' } bind def',/,
     -    '/Pl31 { 6 copy Plane3 moveto moveto lineto closepath strok',
     -    'e } bind def',/,
     -    '/Pl32 { 6 copy Plane3 moveto lineto lineto strok',
     -    'e } bind def',/,
     -    '/Pl4 { 8 copy Plane4 moveto moveto moveto moveto closepath',
     -    ' stroke } bind def')
      WRITE(11,240)
 240  FORMAT(
     -    '/Sphcol { 1 setgray } def',/,
     -    '/Sphere {',
     -    '  newpath 3 copy 0 360 arc gsave Sphcol fill 0 setgray 0.5',
     -    ' setlinewidth',/,
     -    '  3 copy 0.94 mul 260 350 arc stroke 3 copy 0.87 mul 275 3',
     -    '35 arc stroke',/,
     -    '  3 copy 0.79 mul 295 315 arc stroke 3 copy 0.8 mul 115 13',
     -    '5 arc',/,
     -    '  3 copy 0.6 mul 135 115 arcn closepath gsave 1 setgray fi',
     -    'll grestore stroke',/,
     -    '  3 copy 0.7 mul 115 135 arc stroke 3 copy 0.6 mul 124.9 1',
     -    '25 arc',/,
     -    '  0.8 mul 125 125.1 arc stroke grestore stroke',
     -    ' } bind def')
      WRITE(11,250)
 250  FORMAT(
     -    '/Circol { 1 setgray } def',/,
     -    '/Circle {',
     -    '  newpath 0 360 arc gsave Circol fill grestore stroke',
     -    ' } bind def',/,
     -    '/Ucircle {',
     -    '  newpath 0 360 arc gsave Circol fill grestore newpath',
     -    ' } bind def',/,
     -    '/Arc { newpath arc stroke newpath } bind def')
      WRITE(11,270)
 270  FORMAT(
     -    '%%EndProlog',/,
     -    '%%BeginSetup',/,
     -    '1 setlinecap 1 setlinejoin 1 setlinewidth 0 setgray [ ] 0 ',
     -    'setdash newpath',/,
     -    '%%EndSetup')
      IF (BORDER) THEN
          WRITE(11,280) REAL(BBOXX1), REAL(BBOXY1), REAL(BBOXX2),
     -        REAL(BBOXY1), REAL(BBOXX2), REAL(BBOXY2), REAL(BBOXX1),
     -        REAL(BBOXY2)
      ELSE
          WRITE(11,280) -10.0, -10.0, 800.0, -10.0, 800.0, 900.0,
     -        -10.0, 900.0
      ENDIF
 280  FORMAT(
     -    '%%Page: 1 1',/,
     -    '/SurfplotSave save def',/,
     -    2F6.1,' moveto',/,
     -    3(2F7.1,' lineto'),' closepath gsave')

C---- Set background colour, if required
      IF (INCOLR) THEN
          IF (BAKCOL.EQ.0) THEN
              WRITE(11,320) 1.0, 1.0, 1.0
 320          FORMAT(
     -            'gsave ',3F5.2,' setrgbcolor fill grestore',/,
     -            'clip newpath')
          ELSE
              WRITE(11,320) (RGBCOL(I,BAKCOL), I = 1, 3)
          ENDIF
      ELSE
          WRITE(11,340)
 340      FORMAT(
     -        'gsave 1.0000 setgray fill grestore',/,
     -        'clip newpath')
      ENDIF

      GO TO 999

C---- Errors on parameter file
 900  CONTINUE
      PRINT*, 'WARNING. Unable to open Postscript file'
      GO TO 999
 
 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCLOS  -  Write final lines to PostScript file and close
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCLOS

      INCLUDE 'surfplot.inc'


C---- Write out closing lines to PostScript file
      WRITE(11,100) BBOXX1 - 1, BBOXY1 - 1, BBOXX2 + 1, BBOXY2 + 1
 100  FORMAT(
     -    'grestore stroke',/,
     -    'SurfplotSave restore',/,
     -    'showpage',/,
     -    '%%Trailer',/,
     -    '%%BoundingBox:',4I4,/,
     -    '%%EOF')


C---- Close the file
      CLOSE(11)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSBBOX  -  Write out bounded box to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSBBOX(X1,Y1,X2,Y2,X3,Y3,X4,Y4)

      REAL          X1, X2, Y1, Y2, X3, Y3, X4, Y4

      WRITE(11,100) X1, Y1, X2, Y2, X3, Y3, X4, Y4
 100  FORMAT(8F7.2,' Pline4')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCIRC  -  Write a circle out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCIRC(X,Y,R)

      REAL          R, X, Y

      WRITE(11,100) X, Y, R
 100  FORMAT(3F7.2,' Circle')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCSHD  -  Write a circle out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCSHD(SHADE)

      REAL          SHADE

      WRITE(11,100) SHADE
 100  FORMAT('/Circol { ',F7.2,' setgray} def')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCOLB  -  Write background colour level
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCOLB(ICOL)

      SAVE

      CHARACTER*2   CURCOL, LSTCOL
      INTEGER       ICOL

      DATA LSTCOL / 'XX' /

      WRITE(CURCOL,50) ICOL
 50   FORMAT(I2)
      IF (CURCOL(1:1).EQ.' ') CURCOL(1:1) = '0'
      IF (CURCOL.NE.LSTCOL) THEN
          IF (ICOL.GT.0) THEN
              WRITE(11,100) CURCOL
 100          FORMAT('Col', A2)
          ELSE
              WRITE(11,120)
 120          FORMAT('1.00 G')
          ENDIF
      ENDIF
      LSTCOL = CURCOL

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCCOL  -  Write new circle colour
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCCOL(ICOL)

      SAVE

      CHARACTER*2   CURCOL, LSTCOL
      INTEGER       ICOL

      DATA LSTCOL / 'XX' /

      WRITE(CURCOL,50) ICOL
 50   FORMAT(I2)
      IF (CURCOL(1:1).EQ.' ') CURCOL(1:1) = '0'
      IF (CURCOL.NE.LSTCOL) THEN
          IF (ICOL.GT.0) THEN
              WRITE(11,100) CURCOL
 100          FORMAT('/Circol { Col', A2,' } def')
          ELSE
              WRITE(11,120)
 120          FORMAT('1.00 G')
          ENDIF
      ENDIF
CHANGE v.1.4-->
C      LSTCOL = CURCOL
CHANGE v.1.4<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCCSC  -  Write new circle colour in given RGB value
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCCSC(RGBVAL)

      INTEGER       I
      REAL          RGBVAL(3)

      WRITE(11,100) (RGBVAL(I), I = 1, 3)
 100  FORMAT('/Circol { ',3F8.3,' setrgbcolor } def')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCOLR  -  Write colour level
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCOLR(R,G,B)

      REAL          R, G, B

      WRITE(11,100) R, G, B
 100  FORMAT('S',3F8.4,' C')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCOMM  -  Write out comment line to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCOMM(TEXT)

      CHARACTER*(*) TEXT

      WRITE(11,*)
      WRITE(11,*) '%'
      WRITE(11,200) TEXT
 200  FORMAT('% ',A)
      WRITE(11,*) '%'
      WRITE(11,*)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCTXT  -  Write out centred text to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSCTXT(X,Y,SIZE,TEXT)

      CHARACTER*(*) TEXT
      REAL          SIZE, X, Y

      WRITE(11,100) X, Y
 100  FORMAT(2F7.2,' moveto')
      WRITE(11,200) TEXT, SIZE
 200  FORMAT('(',A,') ',F4.1,' Center')
      WRITE(11,300) TEXT, SIZE
 300  FORMAT('(',A,') ',F4.1,' Print')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSDASH  -  Switch dashed lines on/off
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSDASH(ONOFF)

      SAVE

      INTEGER       LSTVAL, ONOFF

      DATA  LSTVAL / 0 /

      IF (ONOFF.NE.LSTVAL) THEN
          IF (ONOFF.EQ.0) THEN
              WRITE(11,100) 
 100          FORMAT('[] 0 D')
          ELSE
              WRITE(11,120) ONOFF
 120          FORMAT('[ 1',I2,'] 0 D')
          ENDIF
          LSTVAL = ONOFF
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSLINE  -  Write line out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSLINE(X1,Y1,X2,Y2)

      REAL          X1, X2, Y1, Y2

      WRITE(11,100) X1, Y1, X2, Y2
 100  FORMAT(4F7.2,' L')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSPHCL  -  Write sphere colour out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSPHCL(ICOL)

      SAVE

      CHARACTER*2   CURCOL, LSTCOL
      INTEGER       ICOL

      DATA LSTCOL / 'XX' /

      WRITE(CURCOL,50) ICOL
 50   FORMAT(I2)
      IF (CURCOL(1:1).EQ.' ') CURCOL(1:1) = '0'
      IF (CURCOL.NE.LSTCOL) THEN
          IF (ICOL.GT.0) THEN
              WRITE(11,100) CURCOL
 100          FORMAT('/Sphcol { Col', A2,' } def')
          ELSE
              WRITE(11,120)
 120          FORMAT('/Sphcol { 1.00 setgray } def')
          ENDIF
      ENDIF
CHANGE v.1.4-->
C      LSTCOL = CURCOL
CHANGE v.1.4<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSPHSC  -  Write sphere colour using given RGB values
C                        out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSPHSC(RGBVAL)

      INTEGER       I
      REAL          RGBVAL(3)

      WRITE(11,100) (RGBVAL(I), I = 1, 3)
 100  FORMAT('/Sphcol { ',3F8.3,' setrgbcolor } def')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSPHSH  -  Write sphere shade out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSPHSH(SHADE)

      SAVE

      CHARACTER*7   CURCOL, LSTCOL
      REAL          SHADE

      DATA LSTCOL / 'XXXXX' /

      WRITE(CURCOL,50) SHADE
 50   FORMAT(F7.4)
      IF (CURCOL.NE.LSTCOL) THEN
          WRITE(11,100) SHADE
 100      FORMAT('/Sphcol { ', F7.4,' setgray } def')
      ENDIF
      LSTCOL = CURCOL

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSPHER  -  Write a sphere out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSPHER(X,Y,R)

      REAL          R, X, Y

      WRITE(11,100) X, Y, R
 100  FORMAT(3F7.2,' Sphere')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSTRIA  -  Write out unbounded triangle to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSTRIA(X1,Y1,X2,Y2,X3,Y3)

      REAL          X1, X2, Y1, Y2, X3, Y3

      WRITE(11,100) X1, Y1, X2, Y2, X3, Y3
 100  FORMAT(6F7.2,' Pl3')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSTRI1  -  Write out triangle with one edge drawn
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSTRI1(X1,Y1,X2,Y2,X3,Y3)

      REAL          X1, X2, Y1, Y2, X3, Y3

      WRITE(11,100) X1, Y1, X2, Y2, X3, Y3
 100  FORMAT(6F7.2,' Pl31')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSTRI2  -  Write out triangle with two edges drawn
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSTRI2(X1,Y1,X2,Y2,X3,Y3)

      REAL          X1, X2, Y1, Y2, X3, Y3

      WRITE(11,100) X1, Y1, X2, Y2, X3, Y3
 100  FORMAT(6F7.2,' Pl32')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSTRI3  -  Write out triangle with all three edges drawn
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSTRI3(X1,Y1,X2,Y2,X3,Y3)

      REAL          X1, X2, Y1, Y2, X3, Y3

      WRITE(11,100) X1, Y1, X2, Y2, X3, Y3
 100  FORMAT(6F7.2,' Plane3')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSCIRC  -  Write a circle out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSUCIR(X,Y,R)

      REAL          R, X, Y

      WRITE(11,100) X, Y, R
 100  FORMAT(3F7.2,' Ucircle')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSLWID  -  Write line-width out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSLWID(LWIDTH)

      SAVE

      CHARACTER*5   CURRWD, LASTWD
      REAL          LWIDTH

      DATA LASTWD / 'XXXXX' /

      WRITE(CURRWD,50) LWIDTH
 50   FORMAT(F5.2)
      IF (CURRWD.NE.LASTWD) THEN
          IF (LWIDTH.EQ.0.0) THEN
              WRITE(11,100)
 100          FORMAT('Noline')
          ELSE
              WRITE(11,200) LWIDTH
 200          FORMAT(F5.2,' W')
          ENDIF
          LASTWD = CURRWD
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSHADB  -  Write background shading level out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSHADB(SHADE)

      CHARACTER*7   CURRSH, LASTSH
      REAL          SHADE

      DATA LASTSH / 'XXXXXXX' /

CDEBUG
      PRINT*, 'PSHADB ', SHADE
CDEBUG
      WRITE(CURRSH,50) SHADE
 50   FORMAT(F7.4)
      IF (CURRSH.NE.LASTSH) THEN
          WRITE(11,200) SHADE
 200      FORMAT(F7.4,' G')
          LASTSH = CURRSH
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSHADE  -  Write shading level out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSHADE(SHADE)

      REAL          SHADE

CDEBUG
      PRINT*, 'PSHADE ', SHADE
CDEBUG
      WRITE(11,100) SHADE
 100  FORMAT('S',F7.4,' G')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSETCL  -  Write RGB colour out to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSETCL(RGB,LAMBDA)

      CHARACTER*7   COLVAL
      CHARACTER*25  COLINE
      INTEGER       ICOLOR, ILEN, IPOS
      LOGICAL       NONZER
      REAL          LAMBDA, RGB(3)

C---- Initialise colour line
      COLINE = ' '
      IPOS = 0

C---- Loop throught the red, green and blue colours
      DO 100, ICOLOR = 1, 3
          WRITE(COLVAL,20) RGB(ICOLOR) * LAMBDA
 20       FORMAT(F7.4)

C----     Test for trailing zeros so that they can be removed
          NONZER = .FALSE.
          ILEN = 7
 50       CONTINUE
              IF (COLVAL(ILEN:ILEN).NE.'0') THEN
                  NONZER = .TRUE.
              ELSE
                  ILEN = ILEN - 1
              ENDIF
          IF (.NOT.NONZER .AND. ILEN.GE.5) GO TO 50
          COLINE(IPOS+1:IPOS+ILEN) = COLVAL(1:ILEN)
          IPOS = IPOS + ILEN
 100  CONTINUE
      COLINE(IPOS+1:IPOS+2) = ' C'
      IPOS = IPOS + 2

C---- Write out the rgb colour instruction
      WRITE(11,120) 'S', COLINE(1:IPOS)
 120  FORMAT(2A)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PSUBOX  -  Write out unbounded box to PostScript file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PSUBOX(X1,Y1,X2,Y2,X3,Y3,X4,Y4)

      REAL          X1, X2, Y1, Y2, X3, Y3, X4, Y4

      WRITE(11,100) X1, Y1, X2, Y2, X3, Y3, X4, Y4
 100  FORMAT(8F7.2,' Pl4')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE RASOPE  -  Open Raster3D file and write out header records
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE RASOPE(FNAME)

      INCLUDE 'surfplot.inc'

      CHARACTER*(*)  FNAME
CHANGE v.1.1-->
      INTEGER        I
CHANGE v.1.1<--

C---- Open output file
      OPEN(UNIT=12, FILE=FNAME, STATUS='UNKNOWN',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write header records out to Raster3d file
CHANGE v.1.3.3-->
C      WRITE(12,100)
      WRITE(12,100) TILEX, TILEY
CHANGE v.1.3.3<--
 100  FORMAT(
     -    'SURFPLOT output. R A Laskowski (1994).',/,
CHANGE v.1.3.3-->
C     -    '80 64     tiles in x,y',/,
     -    I3,1X,I3,'   tiles in x,y',/,
CHANGE v.1.3.3<--
     -    '24 24     pixels (x,y) per tile',/,
CHANGE v.1.1-->
C     -    '3         3x3 virtual pixels -> 2x2 pixels',/,
C     -    '0 0 0     black background colour',/,
     -    '3         3x3 virtual pixels -> 2x2 pixels')
      IF (BAKCOL.EQ.0) THEN
          WRITE(12,120) 1.0, 1.0, 1.0
 120      FORMAT(3F7.4,'  Background colour')
      ELSE
          WRITE(12,120) (RGBCOL(I,BAKCOL), I = 1, 3)
      ENDIF
      WRITE(12,140)
 140  FORMAT(
CHANGE v.1.1<--
     -    'T         shadows cast',/,
     -    '25        Phong power',/,
     -    '0.15      secondary light contribution',/,
     -    '0.05      ambient light contribution',/,
     -    '0.25      specular reflection component')
CHANGE v.1.3.3-->
C      WRITE(12,200)
C 200  FORMAT(
C     -    '4.0       eye position',/,
C     -    '1 1 1     main light source position',/,
C     -    '1 0 0 0   input coordinate, radius transformation',/,
C     -    '0 1 0 0',/,
C     -    '0 0 1 0',/,
C     -    '0 0 0 1',/,
C     -    '3         mixed objects',/,
C     -    '*',/,
C     -    '*',/,
C     -    '*')
      WRITE(12,200) LITEX, LITEY, LITEZ
 200  FORMAT(
     -    '4.0       eye position',/,
CHANGE v.1.4-->
C     -    3F5.1, '  main light source position',/,
     -    3F10.2, '  main light source position',/,
CHANGE v.1.4<--
     -    '1 0 0 0   input coordinate, radius transformation',/,
     -    '0 1 0 0',/,
     -    '0 0 1 0',/,
     -    '0 0 0 1',/,
     -    '3         mixed objects',/,
     -    '*',/,
     -    '*',/,
     -    '*')
CHANGE v.1.3.3<--

      GO TO 999

C---- Errors on parameter file
 900  CONTINUE
      PRINT*, 'WARNING. Unable to open Raster3D file'
      GO TO 999
 
 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE RASOUT  -  Write out all the objects to the Raster3D file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE RASOUT

      INCLUDE 'surfplot.inc'
 
CHANGE v.1.1.1-->
C      INTEGER       COLOUR, ICOLR, IEND, ICOORD, IPOL, ISTART
CHANGE v.1.4-->
C      INTEGER       COLOUR, ICOLR, IDASH, IEND, ICOORD, IPOL, ISTART,
C     -              NDASH, NINTER
C      LOGICAL       DASHON
      INTEGER       COLOUR, ICOLR, ICOORD, IDASH, IEND, ILINE, IMAP,
     -              INMAP, IPOL, ISTART, JLINE, NDASH, NINTER
      LOGICAL       DASHON, SPCTRM
CHANGE v.1.4<--
CHANGE v.1.1.1<--
CHANGE v.1.1-->
CHANGE v.1.1.1-->
C      REAL          CYLRAD
      REAL          CYLRAD, DLEN, DSTEP(3), END1(3), END2(3), LEND(3),
CHANGE v.1.4-->
C     -              LENGTH, LSTART(3)
     -              LENGTH, LSTART(3), RGBVAL(3), SHADE
CHANGE v.1.4<--
CHANGE v.1.1.1<--
CHANGE v.1.1<--

C---- Loop through all the polygons
      DO 500, IPOL = 1, NPOL

C----     If the polygon's colour is -999, then don't plot it
          IF (POLCOL(IPOL).NE.-999) THEN

C----         Determine which map this polygon belongs to
              INMAP = 0
              DO 50, IMAP = 1, NMAP
                 IF (IPOL.GE.MAPFST(IMAP)) INMAP = IMAP
 50           CONTINUE
              IMAP = INMAP
              SPCTRM = .FALSE.
              IF (IMAP.GT.0) THEN
                  IF (FILTYP(IMAP).EQ.'a') SPCTRM = .TRUE.
              ENDIF

C----         Determine start- and end-vertices for this polygon
              ISTART = IPOLYG(IPOL)
              IF (IPOL.LT.NPOL) THEN
                  IEND = IPOLYG(IPOL + 1) - 1
              ELSE
                  IEND = NVERT
              ENDIF
              COLOUR = ABS(POLCOL(IPOL))
CHANGE v.1.4-->
              IF (SPCTRM) CALL GETSPC(ABS(COLOUR),SHADE,RGBVAL)
CHANGE v.1.4<--

C----         If this polygon only has one edges (ie is a sphere), then
C             write out as a sphere
              IF (IEND - ISTART.EQ.0) THEN
CHANGE v.1.1.1-->
                  IF (COLOUR.NE.0) THEN
CHANGE v.1.1.1<--
CHANGE v.1.4-->
C                      WRITE(12,100) 2,
C     -                    (RCOORD(ICOORD,VERTNO(ISTART)),
C     -                    ICOORD = 1, 3), RASCAL * ATMRAD,
C     -                   (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
                      IF (SPCTRM) THEN
                          WRITE(12,100) 2,
     -                        (RCOORD(ICOORD,VERTNO(ISTART)),
     -                        ICOORD = 1, 3),
     -                        RASCAL * ABS(POLINE(IPOL)),
     -                       (RGBVAL(ICOLR), ICOLR = 1, 3)
                      ELSE
                          WRITE(12,100) 2,
     -                        (RCOORD(ICOORD,VERTNO(ISTART)),
     -                        ICOORD = 1, 3),
     -                        RASCAL * ABS(POLINE(IPOL)),
     -                       (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
                      ENDIF
CHANGE v.1.4<--
 100                  FORMAT(I1,/,9F8.4,/,3F7.4)
CHANGE v.1.1.1-->
                  ELSE
                      WRITE(12,100) 2,
     -                    (RCOORD(ICOORD,VERTNO(ISTART)),
CHANGE v.1.4-->
C     -                    ICOORD = 1, 3), RASCAL * ATMRAD,
     -                    ICOORD = 1, 3), RASCAL * ABS(POLINE(IPOL)),
CHANGE v.1.4<--
     -                    1.0, 1.0, 1.0
                  ENDIF
CHANGE v.1.1.1<--

C----         If this polygon has two edges (ie is a line), then write out
C             as a round-ended cylinder
              ELSE IF (IEND - ISTART.EQ.1) THEN
CHANGE v.1.1-->
C                  WRITE(12,100) 1,
C     -                (RCOORD(ICOORD,VERTNO(ISTART)), ICOORD = 1, 3),
C     -                (RCOORD(ICOORD,VERTNO(ISTART+1)), ICOORD = 1, 3),
C     -                (RCOORD(ICOORD,VERTNO(ISTART)), ICOORD = 1, 3),
C     -                (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
CHANGE v.1.4-->
C                  CYLRAD = RASCAL * ABS(0.1 * POLINE(IPOL))
                  CYLRAD = RASCAL * ABS(POLINE(IPOL))
CHANGE v.1.4<--
CHANGE v.1.1.1-->
C                  WRITE(12,200) 3,
C     -                (RCOORD(ICOORD,VERTNO(ISTART)), ICOORD = 1, 3),
C     -                CYLRAD,
C     -                (RCOORD(ICOORD,VERTNO(ISTART+1)), ICOORD = 1, 3),
C     -                CYLRAD,
C     -                (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
C 200              FORMAT(I1,/,8F8.4,/,3F7.4)

C----             Get the two ends of the line and compute length
                  LENGTH = 0.0
                  DO 200, ICOORD = 1, 3
                      END1(ICOORD) = RCOORD(ICOORD,VERTNO(ISTART))
                      END2(ICOORD) = RCOORD(ICOORD,VERTNO(ISTART + 1))
                      LENGTH = LENGTH + (END1(ICOORD) - END2(ICOORD))
     -                    * (END1(ICOORD) - END2(ICOORD))
 200              CONTINUE

C----             If this is a continuous line, then write out whole line
                  IF (POLINE(IPOL).GE.0.0) THEN
                      IF (COLOUR.NE.0) THEN
                          WRITE(12,240) 3,
     -                        (END1(ICOORD), ICOORD = 1, 3), CYLRAD,
     -                        (END2(ICOORD), ICOORD = 1, 3), CYLRAD,
     -                        (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
 240                      FORMAT(I1,/,8F8.4,/,3F7.4)
                      ELSE
                          WRITE(12,240) 3,
     -                        (END1(ICOORD), ICOORD = 1, 3), CYLRAD,
     -                        (END2(ICOORD), ICOORD = 1, 3), CYLRAD,
     -                        1.0, 1.0, 1.0
                      ENDIF

C----             Otherwise, for a dashed line, write out a series
C                 of short lines
                  ELSE

C----                 Calculate the length of the line
                      LENGTH = SQRT(LENGTH)

C----                 Calculate the number of chunks required
                      DLEN = CYLRAD * 2.0
                      NDASH = LENGTH / DLEN
                      DASHON = .TRUE.

C----                 Make sure that number of dashes is an odd number
                      IF (MOD(NDASH,2).EQ.0) NDASH = NDASH + 1

C----                 Proceed only if there are dashes to write out
                      IF (NDASH.GT.0) THEN

C----                     Calculate step-size in each direction
                          NINTER = (NDASH - 1) / 2 + NDASH
                          DSTEP(1) = (END2(1) - END1(1)) / NINTER
                          DSTEP(2) = (END2(2) - END1(2)) / NINTER
                          DSTEP(3) = (END2(3) - END1(3)) / NINTER

C----                     Initialise the line's start-point
                          LSTART(1) = END1(1)
                          LSTART(2) = END1(2)
                          LSTART(3) = END1(3)

C----                     Loop through the required number of steps
                          DO 300, IDASH = 1, NDASH

C----                         If dash-flag is on, write out the line
                              IF (DASHON) THEN

C----                             Calculate the other end of the line
                                  LEND(1) = LSTART(1) + DSTEP(1)
                                  LEND(2) = LSTART(2) + DSTEP(2)
                                  LEND(3) = LSTART(3) + DSTEP(3)

C----                             Write the line-segment out
                                  IF (COLOUR.NE.0) THEN
                                      WRITE(12,240) 5,
     -                                    (LSTART(ICOORD),
     -                                    ICOORD = 1, 3), CYLRAD,
     -                                    (LEND(ICOORD),
     -                                    ICOORD = 1, 3), CYLRAD,
     -                                    (RGBCOL(ICOLR,COLOUR),
     -                                    ICOLR = 1, 3)
                                  ELSE
                                      WRITE(12,240) 5,
     -                                    (LSTART(ICOORD),
     -                                    ICOORD = 1, 3), CYLRAD,
     -                                    (LEND(ICOORD),
     -                                    ICOORD = 1, 3), CYLRAD,
     -                                    1.0, 1.0, 1.0
                                  ENDIF
                                  DASHON = .FALSE.
                              ELSE
                                  LEND(1) = LSTART(1) + 2.0 * DSTEP(1)
                                  LEND(2) = LSTART(2) + 2.0 * DSTEP(2)
                                  LEND(3) = LSTART(3) + 2.0 * DSTEP(3)
                                  DASHON = .TRUE.
                              ENDIF

C----                         Set the new line-start to the current line-end
                              LSTART(1) = LEND(1)
                              LSTART(2) = LEND(2)
                              LSTART(3) = LEND(3)
 300                      CONTINUE
                      ENDIF
                  ENDIF
CHANGE v.1.1.1<--
CHANGE v.1.1<--

C----         Otherwise, write out the full triangle
              ELSE
CHANGE v.1.1.1-->
C                  WRITE(12,100) 1,
C     -                (RCOORD(ICOORD,VERTNO(ISTART)), ICOORD = 1, 3),
C     -                (RCOORD(ICOORD,VERTNO(ISTART+1)), ICOORD = 1, 3),
C     -                (RCOORD(ICOORD,VERTNO(ISTART+2)), ICOORD = 1, 3),
C     -                (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
C----             For solid surface write out a triangle of the
C                 appropriate colour
CHANGE v.1.4-->
                  IF (.NOT.PLOTWR(IPOL)) THEN
CHANGE v.1.4<--
                      IF (COLOUR.NE.0) THEN
                          WRITE(12,100) 1,
     -                        (RCOORD(ICOORD,VERTNO(ISTART)),
     -                            ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,VERTNO(ISTART+1)),
     -                            ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,VERTNO(ISTART+2)),
     -                            ICOORD = 1, 3),
     -                        (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)

CHANGE v.1.6.1-->
C----                     Calculate and write out the vertex
C                         normals for this triangle
                          CALL WRINRM(12,VERTNO(ISTART),
     -                        VERTNO(ISTART+1),VERTNO(ISTART+2))
CHANGE v.1.6.1<--

CHANGE v.1.4.2-->
C----                     If this this is a 4-sided polygon, then
C                         write out the other triangle
                          IF (IEND - ISTART.EQ.3) THEN
                              WRITE(12,100) 1,
     -                            (RCOORD(ICOORD,VERTNO(ISTART+2)),
     -                                ICOORD = 1, 3),
     -                            (RCOORD(ICOORD,VERTNO(ISTART+3)),
     -                                ICOORD = 1, 3),
     -                            (RCOORD(ICOORD,VERTNO(ISTART)),
     -                                ICOORD = 1, 3),
     -                            (RGBCOL(ICOLR,COLOUR), ICOLR = 1, 3)
CHANGE v.1.6.1-->
C----                         Calculate and write out the vertex
C                             normals for this triangle
                              CALL WRINRM(12,VERTNO(ISTART+2),
     -                            VERTNO(ISTART+3),VERTNO(ISTART))
CHANGE v.1.6.1<--
                          ENDIF
CHANGE v.1.4.2<--
                      ELSE
                          WRITE(12,100) 1,
     -                        (RCOORD(ICOORD,VERTNO(ISTART)),
     -                            ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,VERTNO(ISTART+1)),
     -                            ICOORD = 1, 3),
     -                        (RCOORD(ICOORD,VERTNO(ISTART+2)),
     -                            ICOORD = 1, 3),
     -                        1.0, 1.0, 1.0

CHANGE v.1.4.2-->
C----                     If this this is a 4-sided polygon, then
C                         write out the other triangle
                          IF (IEND - ISTART.EQ.3) THEN
                              WRITE(12,100) 1,
     -                            (RCOORD(ICOORD,VERTNO(ISTART+2)),
     -                                ICOORD = 1, 3),
     -                            (RCOORD(ICOORD,VERTNO(ISTART+3)),
     -                                ICOORD = 1, 3),
     -                            (RCOORD(ICOORD,VERTNO(ISTART)),
     -                                ICOORD = 1, 3),
     -                            1.0, 1.0, 1.0
                          ENDIF
CHANGE v.1.4.2<--
                      ENDIF
CHANGE v.1.4-->
C----             Otherwise, for a wire-cage surface, write out the
C                 wire edges as thin lines
                  ELSE

C----                 Loop over the 3 lines making up this polygon
                      DO 400, ILINE = ISTART, IEND

C----                     If haven't already done this line from an
C                         adjoining polygon, then write out
                          IF (OTHPOL(ILINE).EQ.0 .OR.
     -                        OTHPOL(ILINE).GT.IPOL) THEN

C----                         Get the radius for this cylinder
                              CYLRAD = RASCAL * ABS(0.1 * POLINE(IPOL))

C----                         Get the two ends of the line
                              JLINE = ILINE + 1
                              IF (ILINE.EQ.IEND) JLINE = ISTART
                              DO 350, ICOORD = 1, 3
                                 END1(ICOORD)
     -                               = RCOORD(ICOORD,VERTNO(ILINE))
                                 END2(ICOORD)
     -                               = RCOORD(ICOORD,VERTNO(JLINE))
 350                          CONTINUE

C----                         Write out the line
                              IF (COLOUR.NE.0) THEN
                                  WRITE(12,240) 3,
     -                                (END1(ICOORD), ICOORD = 1, 3),
     -                                CYLRAD,
     -                                (END2(ICOORD), ICOORD = 1, 3),
     -                                CYLRAD,
     -                                (RGBCOL(ICOLR,COLOUR),
     -                                ICOLR = 1, 3)
                              ELSE
                                  WRITE(12,240) 3,
     -                                (END1(ICOORD), ICOORD = 1, 3),
     -                                CYLRAD,
     -                                (END2(ICOORD), ICOORD = 1, 3),
     -                                CYLRAD,
     -                                1.0, 1.0, 1.0
                              ENDIF
                          ENDIF
 400                  CONTINUE
                  ENDIF
CHANGE v.1.4<--
CHANGE v.1.1.1<--
              ENDIF
          ENDIF
 500  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6.1-->
C**************************************************************************
C
C  SUBROUTINE WRINRM  -  Calculate and write out the three vertex
C                        normals
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WRINRM(IUNIT,IVERT1,IVERT2,IVERT3)

      INCLUDE 'surfplot.inc'
 
      INTEGER       I, ICOMV, IPOL, IPOS, ISVERT(3), IUNIT, IVERT,
     -              IVERT1, IVERT2, IVERT3, NCOMV, NPOS
      REAL          DIFF, RNX, RNY, RNZ, RNK, VECMAG, VNORM(3),
     -              TNORM(3,3)

C---- Initialise variables
      DO 100, IPOS = 1, 3
          TNORM(1,IPOS) = 0.0
          TNORM(2,IPOS) = 0.0
          TNORM(3,IPOS) = 0.0
 100  CONTINUE
      NPOS = 0

C---- Store the current vertex numbers
      ISVERT(1) = IVERT1
      ISVERT(2) = IVERT2
      ISVERT(3) = IVERT3

C---- Loop to process each vertex in turn
      DO 800, IPOS = 1, 3

C----     Get current vertex
          IVERT = ISVERT(IPOS)

C----     Initialise variables
          NCOMV = 0
          VNORM(1) = 0.0
          VNORM(2) = 0.0
          VNORM(3) = 0.0

C----     Loop through all the polygons which contain this vertex
          DO 500, ICOMV = 1, MXCOMV

C----         Get this poygon number
              IPOL = WHCHPL(ICOMV,IVERT)

C----         If zero, then have reached the end of this vertex's list
C             of polygons
              IF (IPOL.EQ.0) GO TO 600

C----         Calculate normal to this polygon
              CALL NRMPOL(IPOL,RNX,RNY,RNZ,RNK)

C----         Calculate magnitude of vector
              VECMAG = SQRT(RNX * RNX + RNY * RNY + RNZ * RNZ)

C----         Calculate absolute value
              DIFF = ABS(VECMAG)

C----         If magnitude non-zero, normalise the vector
              IF (DIFF.GT.0.000001) THEN
                  VNORM(1) = RNX / VECMAG
                  VNORM(2) = RNY / VECMAG
                  VNORM(3) = RNZ / VECMAG

C----             Add to accumulated normal vector
                  TNORM(1,IPOS) = TNORM(1,IPOS) + VNORM(1)
                  TNORM(1,IPOS) = TNORM(1,IPOS) + VNORM(1)
                  TNORM(1,IPOS) = TNORM(1,IPOS) + VNORM(1)

C----             Increment count of polygons contriubuting to
C                 the current average
                  NCOMV = NCOMV + 1  
              ENDIF
 500      CONTINUE

C----     If found any polygons, calculate average normal
 600      CONTINUE
          IF (NCOMV.GT.0) THEN

C----         Calculate averages
              TNORM(1,IPOS) = TNORM(1,IPOS) / NCOMV
              TNORM(2,IPOS) = TNORM(2,IPOS) / NCOMV
              TNORM(3,IPOS) = TNORM(3,IPOS) / NCOMV

C----         Increment count of valid normals
              NPOS = NPOS + 1
          ENDIF
 800  CONTINUE

C---- If have 3 valid vertex normals, then write out to file
      IF (NPOS.EQ.3) THEN

C----     Write out the vertex normals
          WRITE(IUNIT,820) 7,
     -        ((TNORM(I,IPOS), I = 1, 3), IPOS = 1, 3)
 820      FORMAT(I1,/,9F8.4)
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6.1<--
C**************************************************************************
C
C  SUBROUTINE WRLOUT  -  Write out all the objects to the VRML file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WRLOUT

      INCLUDE 'surfplot.inc'
 
      INTEGER       MXSTOR

      PARAMETER    (MXSTOR = 100)

      INTEGER       CYLIND, LINE, NONE, POLYG, SPHERE, WIRE

      PARAMETER    (
     -              NONE   =  0,
     -              CYLIND =  1,
     -              LINE   =  2,
     -              POLYG  =  3,
     -              SPHERE =  4,
     -              WIRE   =  5
     -             )

      INTEGER       COLOUR, IEND, ILINE, IMAP, INMAP, IPOL, ISTART,
     -              JLINE, JMAP, OBJCOL, LSTOBJ, NSTORE, OBJECT
      LOGICAL       FLAT, SPCTRM, WANTED
      REAL          BLUE, CYLRAD, GREEN, LENGTH, OBJRGB(3), LWIDTH,
     -              RADIUS, RED, RGBVAL(3), SHADE, X, X1, X2, X3, X4,
     -              XYZ(3,3,MXSTOR), Y, Y1, Y2, Y3, Y4, Z, Z1, Z2, Z3,
     -              Z4

C---- Initialise variables
      CURCOL = -1
      FLAT = .FALSE.
      OBJCOL = 0
      
C---- Loop through the maps, one by one, picking out the polygons
C     belonging to each one
      DO 1000, IMAP = 1, NMAP

C----     Initialise variables for this map
          LSTOBJ = NONE
          OBJECT = NONE
          NSTORE = 0

C----     Loop through all the polygons
          DO 500, IPOL = 1, NPOL

C----         Determine whether polygon is wanted
              WANTED = .TRUE.

C----         If the polygon's colour is -999, then don't want to plot it
              IF (POLCOL(IPOL).EQ.-999) THEN
                  WANTED = .FALSE.

C----         Otherwise, determine whether the polygon belongs to the
C             current map
              ELSE

C----             Get the polygon's map
                  INMAP = 0
                  DO 50, JMAP = 1, NMAP
                      IF (IPOL.GE.MAPFST(JMAP)) INMAP = JMAP
 50               CONTINUE

C----             If this is not the right map, then don't want it
                  IF (INMAP.NE.IMAP) THEN
                      WANTED = .FALSE.
                  ENDIF
              ENDIF

C----         Proceed only if this polygon is wanted
              IF (WANTED) THEN

C----             Store the polygon's colour
                  COLOUR = ABS(POLCOL(IPOL))

C----             Determine whether using spectrum of colours
                  SPCTRM = .FALSE.
                  IF (FILTYP(IMAP).EQ.'a') SPCTRM = .TRUE.

C----             Get this object's colour
                  IF (SPCTRM) THEN
                      RED = RGBVAL(1)
                      GREEN = RGBVAL(2)
                      BLUE = RGBVAL(3)
                      IF (CURCOL.GT.100) CURCOL = 0
                      COLOUR = CURCOL + 1
                  ELSE IF (COLOUR.EQ.0) THEN
                      RED = 1.0
                      GREEN = 1.0
                      BLUE = 1.0
                  ELSE
                      RED = RGBCOL(1,COLOUR)
                      GREEN = RGBCOL(2,COLOUR)
                      BLUE = RGBCOL(3,COLOUR)
                  ENDIF

C----             Determine start- and end-vertices for this polygon
                  ISTART = IPOLYG(IPOL)
                  IF (IPOL.LT.NPOL) THEN
                      IEND = IPOLYG(IPOL + 1) - 1
                  ELSE
                      IEND = NVERT
                  ENDIF
                  COLOUR = ABS(POLCOL(IPOL))
                  IF (SPCTRM) CALL GETSPC(ABS(COLOUR),SHADE,RGBVAL)

C----             Determine the object type

C----             If this polygon only has one edge then is a sphere
                  IF (IEND - ISTART.EQ.0) THEN
                      OBJECT = SPHERE

C----             If this polygon has two edges (ie is a line), then
C                 is either a cylinder or a line
                  ELSE IF (IEND - ISTART.EQ.1) THEN

C----                 Get the radius of the cylinders representing the
C                     lines in the output
                      LWIDTH = ABS(POLINE(IPOL))
                      CYLRAD = RASCAL * ABS(POLINE(IPOL))

C----                 If this is a thin line, then plot as line only
                      IF (ABS(POLINE(IPOL)).LE.0.15) THEN
                          OBJECT = LINE
                          CYLRAD = 0.0

C----                 Otherwise, treat as a cylinder
                      ELSE
                          OBJECT = CYLIND
                      ENDIF

C----             Otherwise must be a polygon (usually a triangle), or
C                 a wire-cage representation
                  ELSE
                      OBJECT = POLYG

C----                 Check whether this is a wire-cage representation
                      IF (PLOTWR(IPOL)) THEN
                          OBJECT = WIRE
                      ENDIF
                  ENDIF

C----             If last object was a line, or set of lines from
C                 a wire-cage map, and we now have either a different
C                 type of object, or the line-colour has changed, then
C                 need to write out the lines we have
                  IF ((LSTOBJ.EQ.LINE .OR. LSTOBJ.EQ.WIRE) .AND.
     -                (OBJECT.NE.LSTOBJ .OR. COLOUR.NE.OBJCOL)) THEN

C----                 Write out the lines stored
                      IF (NSTORE.GT.0) THEN
                          CALL WRLINE(XYZ,MXSTOR,NSTORE,OBJRGB(1),
     -                        OBJRGB(2),OBJRGB(3),OBJCOL,CURCOL)
                      ENDIF
                  ENDIF

C----             If last object was a polygon, or set of polygons from
C                 a surface, and we now have either a different
C                 type of object, or the colour has changed, then
C                 need to write out the traingles we have stored
                  IF (LSTOBJ.EQ.POLYG .AND.
     -                (OBJECT.NE.LSTOBJ .OR. COLOUR.NE.OBJCOL)) THEN

C----                 Write out the lines stored
                      IF (NSTORE.GT.0) THEN
                          CALL WRLTRI(XYZ,MXSTOR,NSTORE,OBJRGB(1),
     -                        OBJRGB(2),OBJRGB(3),OBJCOL,CURCOL)
                      ENDIF
                  ENDIF

C----             Sphere object
                  IF (OBJECT.EQ.SPHERE) THEN

C----                 Get the coordinates of the sphere centre and its radius
                      X = RCOORD(1,VERTNO(ISTART))
                      Y = RCOORD(2,VERTNO(ISTART))
                      Z = RCOORD(3,VERTNO(ISTART))
                      RADIUS = RASCAL * ABS(POLINE(IPOL))

C----                 Write out the sphere
                      CALL WRLSPH(X,Y,Z,RADIUS,RED,GREEN,BLUE,COLOUR,
     -                    CURCOL)

C----             Line or cylinder object
                  ELSE IF (OBJECT.EQ.LINE .OR. OBJECT.EQ.CYLIND) THEN

C----                 Get the end coordinates of the line
                      X1 = RCOORD(1,VERTNO(ISTART))
                      Y1 = RCOORD(2,VERTNO(ISTART))
                      Z1 = RCOORD(3,VERTNO(ISTART))
                      X2 = RCOORD(1,VERTNO(ISTART + 1))
                      Y2 = RCOORD(2,VERTNO(ISTART + 1))
                      Z2 = RCOORD(3,VERTNO(ISTART + 1))

C----                 Get the two ends of the line and compute length
                      LENGTH = (X1 - X2) * (X1 - X2)
     -                    + (Y1 - Y2) * (Y1 - Y2)
     -                    + (Z1 - Z2) * (Z1 - Z2)

C----                 If this is a continuous line, then write out whole
C                     line
                      IF (POLINE(IPOL).GE.0.0) THEN

C----                     If line, then store the line
                          IF (OBJECT.EQ.LINE) THEN

C----                         If have reached maximum number of lines
C                             possible, then write out the ones in store
                              IF (NSTORE.GE.MXSTOR) THEN
                                  CALL WRLINE(XYZ,MXSTOR,NSTORE,
     -                                OBJRGB(1),OBJRGB(2),OBJRGB(3),
     -                                OBJCOL,CURCOL)
                              ENDIF

C----                         Save the line colour
                              OBJCOL = COLOUR
                              OBJRGB(1) = RED
                              OBJRGB(2) = GREEN
                              OBJRGB(3) = BLUE

C----                         Store the current line
                              NSTORE = NSTORE + 1
                              XYZ(1,1,NSTORE) = X1
                              XYZ(2,1,NSTORE) = Y1
                              XYZ(3,1,NSTORE) = Z1
                              XYZ(1,2,NSTORE) = X2
                              XYZ(2,2,NSTORE) = Y2
                              XYZ(3,2,NSTORE) = Z2

C----                     Otherwise, write out as cylinder
                          ELSE

C----                         Write as cylinder
                              CALL WRLCYL(X1,Y1,Z1,X2,Y2,Z2,CYLRAD,FLAT,
     -                            RED,GREEN,BLUE,COLOUR,CURCOL)
                          ENDIF

C----                 Otherwise, for a dashed line, write out a series
C                     of short lines
                      ELSE

C----                     Calculate the length of the line
                          LENGTH = SQRT(LENGTH)

C----                     Generate the dashes making up the line
                          CALL OPDASH(CYLRAD,LENGTH,X1,Y1,Z1,X2,Y2,Z2,
     -                        RED,GREEN,BLUE,COLOUR,CURCOL,XYZ,MXSTOR)
                      ENDIF

C----             Otherwise, write out the full triangle
                  ELSE IF (OBJECT.EQ.POLYG .OR. OBJECT.EQ.WIRE) THEN

C----                 Get the coordinates of the 1st three vertices
                      X1 = RCOORD(1,VERTNO(ISTART))
                      Y1 = RCOORD(2,VERTNO(ISTART))
                      Z1 = RCOORD(3,VERTNO(ISTART))
                      X2 = RCOORD(1,VERTNO(ISTART + 1))
                      Y2 = RCOORD(2,VERTNO(ISTART + 1))
                      Z2 = RCOORD(3,VERTNO(ISTART + 1))
                      X3 = RCOORD(1,VERTNO(ISTART + 2))
                      Y3 = RCOORD(2,VERTNO(ISTART + 2))
                      Z3 = RCOORD(3,VERTNO(ISTART + 2))

C----                 If this this is a 4-sided polygon, get the 4th point
                      IF (IEND - ISTART.EQ.3) THEN
                          X4 = RCOORD(1,VERTNO(ISTART + 3))
                          Y4 = RCOORD(2,VERTNO(ISTART + 3))
                          Z4 = RCOORD(3,VERTNO(ISTART + 3))
                      ENDIF

C----                 Check that not a wire-cage surface
                      IF (OBJECT.EQ.POLYG) THEN

C----                     If have reached maximum number of triangles
C                         possible, then write out the ones in store
                          IF (NSTORE.GE.MXSTOR) THEN
                              CALL WRLTRI(XYZ,MXSTOR,NSTORE,
     -                            OBJRGB(1),OBJRGB(2),OBJRGB(3),
     -                            OBJCOL,CURCOL)
                          ENDIF

C----                     Save the object colour
                          OBJCOL = COLOUR
                          OBJRGB(1) = RED
                          OBJRGB(2) = GREEN
                          OBJRGB(3) = BLUE

C----                     Store the current traingle
                          NSTORE = NSTORE + 1
                          XYZ(1,1,NSTORE) = X1
                          XYZ(2,1,NSTORE) = Y1
                          XYZ(3,1,NSTORE) = Z1
                          XYZ(1,2,NSTORE) = X2
                          XYZ(2,2,NSTORE) = Y2
                          XYZ(3,2,NSTORE) = Z2
                          XYZ(1,3,NSTORE) = X3
                          XYZ(2,3,NSTORE) = Y3
                          XYZ(3,3,NSTORE) = Z3

C----                     If this this is a 4-sided polygon, then
C                         write out the other triangle
                          IF (IEND - ISTART.EQ.3) THEN

C----                         If have reached maximum number of triangles
C                             possible, then write out the ones in store
                              IF (NSTORE.GE.MXSTOR) THEN
                                  CALL WRLTRI(XYZ,MXSTOR,NSTORE,
     -                                OBJRGB(1),OBJRGB(2),OBJRGB(3),
     -                                OBJCOL,CURCOL)
                              ENDIF

C----                         Store the current traingle
                              NSTORE = NSTORE + 1
                              XYZ(1,1,NSTORE) = X3
                              XYZ(2,1,NSTORE) = Y3
                              XYZ(3,1,NSTORE) = Z3
                              XYZ(1,2,NSTORE) = X4
                              XYZ(2,2,NSTORE) = Y4
                              XYZ(3,2,NSTORE) = Z4
                              XYZ(1,3,NSTORE) = X1
                              XYZ(2,3,NSTORE) = Y1
                              XYZ(3,3,NSTORE) = Z1
                          ENDIF

C----                 Otherwise, for a wire-cage surface, store the
C                     wire edges for writing out as thin lines
                      ELSE
C----                     Loop over the lines making up this polygon
                          DO 400, ILINE = ISTART, IEND

C----                         If haven't already done this line from an
C                             adjoining polygon, then write out
                              IF (OTHPOL(ILINE).EQ.0 .OR.
     -                            OTHPOL(ILINE).GT.IPOL) THEN

C----                             Define radius as zero
                                  CYLRAD = 0.0

C----                             Get the two ends of the line
                                  JLINE = ILINE + 1
                                  IF (ILINE.EQ.IEND) JLINE = ISTART
                                  X1 = RCOORD(1,VERTNO(ILINE))
                                  Y1 = RCOORD(2,VERTNO(ILINE))
                                  Z1 = RCOORD(3,VERTNO(ILINE))
                                  X2 = RCOORD(1,VERTNO(JLINE))
                                  Y2 = RCOORD(2,VERTNO(JLINE))
                                  Z2 = RCOORD(3,VERTNO(JLINE))

C----                             If have reached maximum number of
C                                 lines possible, then write out the ones
C                                 in store
                                  IF (NSTORE.GE.MXSTOR) THEN
                                      CALL WRLINE(XYZ,MXSTOR,NSTORE,
     -                                    OBJRGB(1),OBJRGB(2),OBJRGB(3),
     -                                    OBJCOL,CURCOL)
                                  ENDIF

C----                             Save the line colour
                                  OBJCOL = COLOUR
                                  OBJRGB(1) = RED
                                  OBJRGB(2) = GREEN
                                  OBJRGB(3) = BLUE

C----                             Store the current line
                                  NSTORE = NSTORE + 1
                                  XYZ(1,1,NSTORE) = X1
                                  XYZ(2,1,NSTORE) = Y1
                                  XYZ(3,1,NSTORE) = Z1
                                  XYZ(1,2,NSTORE) = X2
                                  XYZ(2,2,NSTORE) = Y2
                                  XYZ(3,2,NSTORE) = Z2
                              ENDIF
 400                      CONTINUE
                      ENDIF
                  ENDIF

C----             Save current object type
                  LSTOBJ = OBJECT
              ENDIF
 500      CONTINUE

C----     If have any lines or triangles to write out, then do so
          IF (NSTORE.GT.0) THEN
              IF (LSTOBJ.EQ.LINE .OR. LSTOBJ.EQ.WIRE) THEN
                  CALL WRLINE(XYZ,MXSTOR,NSTORE,OBJRGB(1),OBJRGB(2),
     -               OBJRGB(3),OBJCOL,CURCOL)
              ELSE IF (LSTOBJ.EQ.POLYG) THEN
                  CALL WRLTRI(XYZ,MXSTOR,NSTORE,OBJRGB(1),OBJRGB(2),
     -               OBJRGB(3),OBJCOL,CURCOL)
              ENDIF
          ENDIF
 1000 CONTINUE
      
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE OPDASH  -  Write out a dashed line to the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE OPDASH(CYLRAD,LENGTH,X1,Y1,Z1,X2,Y2,Z2,RED,GREEN,BLUE,
     -    COLOUR,CURCOL,XYZ,MXSTOR)

      SAVE

      INTEGER       MXSTOR

      INTEGER       COLOUR, CURCOL, IDASH, NDASH, NINTER, NSTORE
      LOGICAL       DASHON, FIRST, FLAT
      REAL          CYLRAD, DLEN, DX, DY, DZ, LENGTH, RED, GREEN, BLUE,
     -              XYZ(3,3,MXSTOR), X1, X2, XL, XR, Y1, Y2, YL, YR,
     -              Z1, Z2, ZL, ZR

      DATA FIRST / .TRUE. /

C---- Initialise variables
      FLAT = .FALSE.
      NSTORE = 0

C---- Calculate the number of chunks required
      IF (CYLRAD.EQ.0.0) THEN
          IF (FIRST) THEN
              DLEN = LENGTH / 10.0
              FIRST = .FALSE.
          ENDIF
      ELSE
          DLEN = CYLRAD * 2.0
      ENDIF
      NDASH = LENGTH / DLEN
      DASHON = .TRUE.

C---- Make sure that number of dashes is an odd number
      IF (MOD(NDASH,2).EQ.0) NDASH = NDASH + 1

C---- Proceed only if there are dashes to write out
      IF (NDASH.GT.0) THEN

C----     Calculate step-size in each direction
          NINTER = (NDASH - 1) / 2 + NDASH
          DX = (X2 - X1) / NINTER
          DY = (Y2 - Y1) / NINTER
          DZ = (Z2 - Z1) / NINTER

C----     Initialise the line's start-point
          XL = X1
          YL = Y1
          ZL = Z1

C----     Loop through the required number of steps
          DO 300, IDASH = 1, NDASH

C----         If dash-flag is on, write out the line
              IF (DASHON) THEN

C----             Calculate the other end of the line
                  XR = XL + DX
                  YR = YL + DY
                  ZR = ZL + DZ

C----             Store the line-segment
                  IF (CYLRAD.EQ.0.0) THEN

C----                 If have reached maximum number of lines
C                     possible, then write out the ones in store
                      IF (NSTORE.GE.MXSTOR) THEN
                          CALL WRLINE(XYZ,MXSTOR,NSTORE,RED,GREEN,BLUE,
     -                        COLOUR,CURCOL)
                      ENDIF

C----                 Store the current line-segment
                      NSTORE = NSTORE + 1
                      XYZ(1,1,NSTORE) = X1
                      XYZ(2,1,NSTORE) = Y1
                      XYZ(3,1,NSTORE) = Z1
                      XYZ(1,2,NSTORE) = X2
                      XYZ(2,2,NSTORE) = Y2
                      XYZ(3,2,NSTORE) = Z2

C----             Or if is has a thickness, write out as a cylinder
                  ELSE
                      CALL WRLCYL(X1,Y1,Z1,X2,Y2,Z2,CYLRAD,FLAT,
     -                    RED,GREEN,BLUE,COLOUR,CURCOL)
                  ENDIF

C----             Switch dash mode off
                  DASHON = .FALSE.

C----         If dash mode is off, shift coords by length of gap
              ELSE
                  XR = XL + 2.0 * DX
                  YR = YL + 2.0 * DY
                  ZR = ZL + 2.0 * DZ

C----             Switch dash mode on
                  DASHON = .TRUE.
              ENDIF

C----         Set the new line-start to the current line-end
              XL = XR
              YL = YR
              ZL = ZR
 300      CONTINUE
      ENDIF

C---- If have any lines to write out, then do so
      IF (NSTORE.GT.0) THEN
          CALL WRLINE(XYZ,MXSTOR,NSTORE,RED,GREEN,BLUE,COLOUR,CURCOL)
      ENDIF
      
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRLOPE  -  Open VRML file and write out header records
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WRLOPE(FNAME,TITLE)

      CHARACTER*(*)  FNAME, TITLE
      INTEGER        LENSTR

C---- Open output file
      OPEN(UNIT=14, FILE=FNAME, STATUS='UNKNOWN',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write header records out to VRML file
      WRITE(14,100) TITLE
 100  FORMAT(
     -    '#VRML V1.0 ascii',/,
     -    '# ',A,/,
     -    '# Generated by program SURFPLOT',/,
     -    '#    - written by Roman A Laskowski, Birkbeck College, Lond',
     -    'on (Nov 1997).',/,
     -    'Separator',/,
     -    '{',/,
     -    ' DirectionalLight',/,
     -    ' {',/,
     -    '  direction 0 0 -1',/,
     -    ' }')

      GO TO 999

C---- Errors on parameter file
 900  CONTINUE
      PRINT*, 'WARNING. Unable to open VRML file: [',
     -    FNAME(1:LENSTR(FNAME)), ']'

      GO TO 999
 
 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRLINE  -  Write out a line to the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRLINE(XYZ,MXSTOR,NSTORE,RED,GREEN,BLUE,COLOUR,CURCOL)

      INTEGER       MXSTOR

      CHARACTER*1   COMMA
      INTEGER       COLOUR, CURCOL, IPOINT, ILINE, JPOINT, NSTORE
      REAL          RED, GREEN, BLUE, XYZ(3,3,MXSTOR), X1, X2, Y1, Y2,
     -              Z1, Z2

C---- Set the line colour
      CALL WRLCOL(COLOUR,RED,GREEN,BLUE,CURCOL)

C---- Start the coordinate list in the VRLM file
      WRITE(14,120)
 120  FORMAT(
     -    '  Separator',/,
     -    '  {',/,
     -    '   Coordinate3',/,
     -    '   {',/,
     -    '    point',/,
     -    '    [')

C---- Loop over the lines, writing out their end-point coordinates
      DO 400, ILINE = 1, NSTORE

C----     Get the coordinates of the two end-points
          X1 = XYZ(1,1,ILINE)
          Y1 = XYZ(2,1,ILINE)
          Z1 = XYZ(3,1,ILINE)
          X2 = XYZ(1,2,ILINE)
          Y2 = XYZ(2,2,ILINE)
          Z2 = XYZ(3,2,ILINE)

C----     Write the coordinates out
          COMMA = ','
          WRITE(14,220) X1, Y1, Z1, COMMA
 220      FORMAT(4X,3F9.3,A)

C----     If have reached last pair of coords, write out without
C         a comma
          IF (ILINE.EQ.NSTORE) COMMA = ' '
          WRITE(14,220) X2, Y2, Z2, COMMA
 400  CONTINUE

C---- Close off the coordinates list and begin the index list
      WRITE(14,420)
 420  FORMAT(
     -    '    ]',/,
     -    '   }',/,
     -    '   IndexedLineSet',/,
     -    '   {',/,
     -    '    coordIndex',/,
     -    '    [')

C---- Initialise link indices
      IPOINT = 0
      JPOINT = -1

C---- Loop over the lines, writing out their end-point coordinates
      DO 600, ILINE = 1, NSTORE

C----     Calculate the indices
          COMMA = ','
          IPOINT = JPOINT + 1
          JPOINT = IPOINT + 1

C----     If have reached last line, then write out without the comma
          IF (ILINE.EQ.NSTORE) COMMA = ' '
          WRITE(14,520) IPOINT, JPOINT, COMMA
 520      FORMAT(4X,2(I4,', '),' -1',A)
 600  CONTINUE

C---- Close off the index list
      WRITE(14,620)
 620  FORMAT(
     -    '    ]',/,
     -    '   }',/,
     -    '  }')

C---- Zero number of lines in the store
      NSTORE = 0

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRLTRI  -  Write out a solid triangle to the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRLTRI(XYZ,MXSTOR,NSTORE,RED,GREEN,BLUE,COLOUR,CURCOL)

      INTEGER       MXSTOR

      CHARACTER*1   COMMA
      INTEGER       COLOUR, CURCOL, IPOINT, IPOLYG, JPOINT, KPOINT,
     -              NSTORE
      REAL          RED, GREEN, BLUE, XYZ(3,3,MXSTOR), X1, X2, X3, Y1,
     -              Y2, Y3, Z1, Z2, Z3

C---- Set the colour of the triangle
      CALL WRLCOL(COLOUR,RED,GREEN,BLUE,CURCOL)

C---- Start the coordinate list in the VRLM file
      WRITE(14,120)
 120  FORMAT(
     -    '  Separator',/,
     -    '  {',/,
     -    '   Coordinate3',/,
     -    '   {',/,
     -    '    point',/,
     -    '    [')

C---- Loop over the lines, writing out their end-point coordinates
      DO 400, IPOLYG = 1, NSTORE

C----     Get the coordinates of the three points
          X1 = XYZ(1,1,IPOLYG)
          Y1 = XYZ(2,1,IPOLYG)
          Z1 = XYZ(3,1,IPOLYG)
          X2 = XYZ(1,2,IPOLYG)
          Y2 = XYZ(2,2,IPOLYG)
          Z2 = XYZ(3,2,IPOLYG)
          X3 = XYZ(1,3,IPOLYG)
          Y3 = XYZ(2,3,IPOLYG)
          Z3 = XYZ(3,3,IPOLYG)

C----     Write the coordinates out
          COMMA = ','
          WRITE(14,220) X1, Y1, Z1, COMMA
 220      FORMAT(4X,3F9.3,A)
          WRITE(14,220) X2, Y2, Z2, COMMA

C----     If have reached last of the coords, write out without
C         a comma
          IF (IPOLYG.EQ.NSTORE) COMMA = ' '
          WRITE(14,220) X3, Y3, Z3, COMMA
 400  CONTINUE

C---- Close off the coordinates list and begin the index list
      WRITE(14,420)
 420  FORMAT(
     -    '    ]',/,
     -    '   }',/,
     -    '   IndexedFaceSet',/,
     -    '   {',/,
     -    '    coordIndex',/,
     -    '    [')

C---- Initialise link indices
      IPOINT = 0
      JPOINT = -1
      KPOINT = -1

C---- Loop over the lines, writing out their end-point coordinates
      DO 600, IPOLYG = 1, NSTORE

C----     Calculate the indices
          COMMA = ','
          IPOINT = KPOINT + 1
          JPOINT = IPOINT + 1
          KPOINT = JPOINT + 1

C----     If have reached last line, then write out without the comma
          IF (IPOLYG.EQ.NSTORE) COMMA = ' '
          WRITE(14,520) IPOINT, JPOINT, KPOINT, COMMA
 520      FORMAT(4X,3(I4,', '),' -1',A)
 600  CONTINUE

C---- Close off the index list
      WRITE(14,620)
 620  FORMAT(
     -    '    ]',/,
     -    '   }',/,
     -    '  }')

C---- Zero number of lines in the store
      NSTORE = 0

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRLCYL  -  Write out a cylinder to the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRLCYL(X1,Y1,Z1,X2,Y2,Z2,RADIUS,FLAT,RED,GREEN,BLUE,
     -    COLOUR,CURCOL)

      INTEGER       COLOUR, CURCOL, I, ICOORD, J, NPOINT
      LOGICAL       FLAT
      REAL          ENDS(3,2), LENGTH, MATFLP(3,3), MATRIX(3,3), RADIUS,
     -              RED, GREEN, BLUE, TRANSL(3), X1, Y1, Z1, X2, Y2, Z2

C---- Set the cylinder colour
      CALL WRLCOL(COLOUR,RED,GREEN,BLUE,CURCOL)

C---- Calculate its length
      LENGTH = (X2 - X1) * (X2 - X1) + (Y2 - Y1) * (Y2 - Y1)
     -    + (Z2 - Z1) * (Z2 - Z1)
      IF (LENGTH.GT.0.0) THEN
          LENGTH = SQRT(LENGTH)
      ELSE
          LENGTH = 0.0
      ENDIF

C---- Calculate the transformation to put the cylinder along the x-axis
      ENDS(1,1) = X1
      ENDS(2,1) = Y1
      ENDS(3,1) = Z1
      ENDS(1,2) = X2
      ENDS(2,2) = Y2
      ENDS(3,2) = Z2
      NPOINT = 2
      CALL PRINCP(ENDS,2,NPOINT,MATRIX,TRANSL)

C---- Adjust the transformation matrix so that it transforms the
C     cylinder along the y- rather than the x-axis
      DO 300, I = 1, 3
          MATFLP(I,1) = MATRIX(I,2)
          MATFLP(I,2) = -MATRIX(I,1)
          MATFLP(I,3) = MATRIX(I,3)
 300  CONTINUE

C---- Write the cylinder out to VRML file
      WRITE(14,620) ((MATFLP(I,J), I = 1, 3), J = 1, 3),
     -    (TRANSL(ICOORD), ICOORD = 1, 3),
     -    RADIUS, LENGTH
 620  FORMAT(
     -    '  Separator',/,
     -    '  {',/,
     -    '   MatrixTransform',/,
     -    '   {',/,
     -    '    matrix ',3F7.3,' 0',/,
     -    '           ',3F7.3,' 0',/,
     -    '           ',3F7.3,' 0',/,
     -    '           ',3F7.3,' 1',/,
     -    '   }',/,
     -    '   Cylinder { radius ',F7.3,' height ',F7.3,' }',/,
     -    '  }')

C---- If want a round-ended cylinder, then write a sphere out coincident
C     with the cylinder's second end
      IF (.NOT.FLAT) THEN
          CALL WRLSPH(X2,Y2,Z2,RADIUS,RED,GREEN,BLUE,COLOUR,CURCOL)
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRLSPH  -  Write out a sphere to the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRLSPH(X,Y,Z,RADIUS,RED,GREEN,BLUE,COLOUR,CURCOL)

      INTEGER       COLOUR, CURCOL
      REAL          RADIUS, RED, GREEN, BLUE, X, Y, Z

C---- Set the sphere colour
      CALL WRLCOL(COLOUR,RED,GREEN,BLUE,CURCOL)

C---- Write the cylinder out to VRML file
      WRITE(14,220) X, Y, Z, RADIUS
 220  FORMAT(
     -    '  Separator',/,
     -    '  {',/,
     -    '   Translation { translation ',3F7.3,' }'/,
     -    '   Sphere { radius ',F7.3,' }',/,
     -    '  }')

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRLCOL  -  Write out the object colour to the VRML file
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRLCOL(COLOUR,RED,GREEN,BLUE,CURCOL)

      REAL          SHINE, SPECL1, SPECL2, SPECL3
      PARAMETER    (SHINE = 0.75, SPECL1 = 0.8, SPECL2 = 0.8,
     -              SPECL3 = 0.8)

      INTEGER       COLOUR, CURCOL
      REAL          RED, GREEN, BLUE

C---- If the colour has changed, then define the new colour
      IF (COLOUR.NE.CURCOL) THEN

C----     Close off previous colour, if there was one
          IF (CURCOL.NE.-1) THEN
              WRITE(14,120)
 120          FORMAT(
     -            ' }')
          ENDIF

C----     Write the new cylinder out to VRML file
          WRITE(14,620) RED, GREEN, BLUE, RED, GREEN, BLUE,
     -        SPECL1, SPECL2, SPECL3, SHINE
 620      FORMAT(
     -        ' Separator',/,
     -        ' {',/,
     -        '  Material',/,
     -        '  {',/,
     -        '   ambientColor ',3F7.3,/,
     -        '   diffuseColor ',3F7.3,/,
     -        '   specularColor',3F7.3,/,
     -        '   shininess      ',F5.2,/,
     -        '  }')

C----     Save the current colour
          CURCOL = COLOUR
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PRINCP  -  Calculate a best-fit plane through the supplied
C                        data points
C
C----------------------------------------------------------------------+---

      SUBROUTINE PRINCP(POINTS,MXPRIN,NPOINT,MATRIX,CENTRE)

      INTEGER       MXPRIN

      INTEGER       I, IORDER, J, NPOINT, NROT, ORDVEC(3), ORIEN3
      LOGICAL       IFAIL
      REAL          CENTRE(3), D, EIGVEC(3,3), EIGVAL(3), MATRIX(3,3),
     -              NORMAL(3), POINTS(3,MXPRIN)

C---- Calculate centre of mass of points and adjust coords such that
C     CofM is at the origin
      CALL GETCOM(POINTS,NPOINT,CENTRE)

C---- Calculate scalar products matrix
      CALL SCPMAT(POINTS,NPOINT,MATRIX,CENTRE)

C---- Calculate eigen values and eigenvectors of matrix
      CALL JACOBI(MATRIX,3,3,EIGVAL,EIGVEC,IFAIL,NROT)
      IF (IFAIL) GO TO 900

C---- Sort the eigen vectors into descending order of eigen value
      CALL EIGSRT(EIGVAL,ORDVEC)

C---- Check whether the sorted eigenvectors make a right-handed set
      IORDER = ORIEN3(
     -    EIGVEC(1,ORDVEC(1)),EIGVEC(2,ORDVEC(1)),EIGVEC(3,ORDVEC(1)),
     -    0.0,0.0,0.0,
     -    EIGVEC(1,ORDVEC(2)),EIGVEC(2,ORDVEC(2)),EIGVEC(3,ORDVEC(2)),
     -    EIGVEC(1,ORDVEC(3)),EIGVEC(2,ORDVEC(3)),EIGVEC(3,ORDVEC(3)))

C---- If the sorted vectors don't make a right-handed set, then reverse the
C     signs on the third vector
      IF (IORDER.EQ.1) THEN
          EIGVEC(1,ORDVEC(3)) = - EIGVEC(1,ORDVEC(3))
          EIGVEC(2,ORDVEC(3)) = - EIGVEC(2,ORDVEC(3))
          EIGVEC(3,ORDVEC(3)) = - EIGVEC(3,ORDVEC(3))
      ENDIF

C---- Compute parameters of best-fit line
      NORMAL(1) = EIGVEC(1,ORDVEC(3))
      NORMAL(2) = EIGVEC(2,ORDVEC(3))
      NORMAL(3) = EIGVEC(3,ORDVEC(3))
      D = NORMAL(1) * CENTRE(1) + NORMAL(2) * CENTRE(2)
     -    + NORMAL(3) * CENTRE(3)

C---- Form the matrix of sorted eigenvectors
      DO 400, J = 1, 3
          DO 300, I = 1, 3
              MATRIX(I,J) = EIGVEC(I,ORDVEC(J))
 300      CONTINUE
 400  CONTINUE

      GO TO 999

C---- Error messages
 900  CONTINUE
      PRINT*, '**** Error. Failed to find eigenvalues of matrix'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETCOM  -  Calculate centre of mass of supplied data points
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETCOM(COORD,NPOINT,CENTRE)

      INTEGER       IPT, NPOINT
      REAL          CENTRE(3), COORD(3,NPOINT), XSUM, YSUM, ZSUM

C---- Initialise values
      XSUM = 0.0
      YSUM = 0.0
      ZSUM = 0.0

C---- Loop through the data points
      DO 300, IPT = 1, NPOINT
          XSUM = XSUM + COORD(1,IPT)
          YSUM = YSUM + COORD(2,IPT)
          ZSUM = ZSUM + COORD(3,IPT)
300   CONTINUE

C---- Calculate centre of mass and adjust all coordinates accordingly
      CENTRE(1) = XSUM / REAL (NPOINT)
      CENTRE(2) = YSUM / REAL (NPOINT)
      CENTRE(3) = ZSUM / REAL (NPOINT)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SCPMAT  -  Calculate scalar products matrix from supplied
C                        coordinates
C
C----------------------------------------------------------------------+---

      SUBROUTINE SCPMAT(COORD,NPOINT,MATRIX,CENTRE)

      INTEGER       IPT, NPOINT
      REAL          CENTRE(3), COORD(3,NPOINT), MATRIX(3,3), X, XXSUM,
     -              XYSUM, XZSUM, Y, YYSUM, YZSUM, Z, ZZSUM


C---- Initialise values
      XXSUM = 0.0
      XYSUM = 0.0
      XZSUM = 0.0
      YYSUM = 0.0
      YZSUM = 0.0
      ZZSUM = 0.0

C---- Loop through all the data points
      DO 500, IPT = 1, NPOINT
          X = COORD(1,IPT) - CENTRE(1)
          Y = COORD(2,IPT) - CENTRE(2)
          Z = COORD(3,IPT) - CENTRE(3)
          XXSUM = XXSUM + X * X
          XYSUM = XYSUM + X * Y
          XZSUM = XZSUM + X * Z
          YYSUM = YYSUM + Y * Y
          YZSUM = YZSUM + Y * Z
          ZZSUM = ZZSUM + Z * Z
500   CONTINUE

C---- Form the scalar products matrix
      MATRIX(1,1) = XXSUM
      MATRIX(1,2) = XYSUM
      MATRIX(1,3) = XZSUM
      MATRIX(2,1) = XYSUM
      MATRIX(2,2) = YYSUM
      MATRIX(2,3) = YZSUM
      MATRIX(3,1) = XZSUM
      MATRIX(3,2) = YZSUM
      MATRIX(3,3) = ZZSUM

      RETURN
      END

C--------------------------------------------------------------------------
C     ******************************************************************
      SUBROUTINE JACOBI(A,N,NP,D,V,IFAIL,NROT)
C     ******************************************************************
C
C     THIS SUBROUTINE COMPUTES ALL EIGENVALUES AND VECTORS OF A REAL
C     SYMMETRIC MATRIX A USING THE JACOBI METHOD (Taken from Numerical
C     Recipes - Press et al.)
C
C     PARAMETERS:
C
C     A     = REAL SYMMETRIC MATRIX, WHICH IS OF SIZE N BY N, STORED IN
C             A PHYSICAL NP BY NP ARRAY. ON EXIT, ELEMENTS OF A ABOVE
C             THE DIAGONAL ARE DESTROYED.
C     N     = ON ENTRY, ORDER OF MATRIX A FOR WHICH COMPUTATIONS ARE
C             DONE. UNCHANGED ON EXIT.
C     NP    = PHYSICAL ARRAY SUBSCRIPTS OF MATRIX A. UNCHANGED ON EXIT.
C     D     = REAL ARRAY OF PHYSICAL DIMENSION NP WHICH, ON EXIT,
C             CONTAINS EIGENVALUES OF A IN ITS FIRST N ELEMENTS.
C     V     = REAL MATRIX WITH THE SAME LOGICAL AND PHYSICAL DIMENSIONS
C             AS A WHOSE COLUMNS CONTAIN, ON EXIT, THE NORMALIZED
C             EIGENVECTORS OF A.
C     IFAIL = FAILURE INDICATOR. THIS IS SET TO 0 FOR NORMAL RETURN, AND
C             TO 1 WHEN MORE THAN 50 * N(N-1)/2 ROTATIONS ARE NEEDED.
C     NROT  = COUNTER WHICH, ON EXIT, CONTAINS THE NUMBER OF ROTATIONS.
C
C     DURING COMPUTATION:
C
C     Z    = VECTOR WHICH ACCUMULATES TERMS OF FORM TA(PQ)
C     B    = VECTOR WHICH CONTAINS CURRENT EIGENVALUES OF A
C
C     OPERATION COUNT:
C
C     TYPICAL MATRICES REQUIRE 6 TO 10 SWEEPS OF N*(N-1)/2 JACOBI
C     ROTATIONS TO ACHIEVE CONVERGENCE, OR 3*N**2 TO 5*N**2
C     ROTATIONS. EACH ROTATION REQUIRES OF ORDER 6*N OPERATIONS, SO
C     THE TOTAL LABOR IS OF THE ORDER 18*N**3 TO 30*N**3.
C
C
      REAL             EMIN
      PARAMETER        (EMIN=1.0E-8)
      INTEGER          NMAX
      PARAMETER        (NMAX=100)

      LOGICAL          IFAIL
      INTEGER          I, IP, IQ, J, N, NP, NROT
      REAL             A(NP,NP), B(NMAX), C, D(NP), G, H, S, SM, T, TAU,
     -                 THETA, TRESH, V(NP,NP),Z(NMAX)

      IFAIL=.FALSE.

C
C   JACOBI METHOD NOT MOST EFFICIENT METHOD FOR MATRICES OF ORDER
C   GREATER THAN 10 ; MAXIMUM ALLOWED PRESET BY NMAX
C
      IF (N.GT.NMAX) THEN
          WRITE(6,10)
10        FORMAT(/' *** MAXIMUM NUMBER OF ELEMENTS EXCEEDED IN ',
     -    'SUBROUTINE JACOBI; CHANGE NMAX - RUN TERMINATED')
          STOP
      ENDIF
C
C   INITIALISE V TO THE IDENTITY MATRIX
C
      DO 12 IP=1,N
          DO 11 IQ=1,N
              V(IP,IQ)=0.0
11        CONTINUE
          V(IP,IP)=1.0
12    CONTINUE
C
C   INITIALISE B AND D TO THE DIAGONAL OF A AND Z TO 0.0
C
      DO 13 IP=1,N
          B(IP)=A(IP,IP)
          D(IP)=B(IP)
          Z(IP)=0.0
13    CONTINUE
C
C   START OF SWEEPS
C
      NROT=0
      DO 24 I=1,50
C
C---SUM OFF-DIAGONAL ELEMENTS OF MATRIX A
C
          SM=0.0
          DO 15 IP=1,N-1
              DO 14 IQ=IP+1,N
                  SM=SM+ABS(A(IP,IQ))
 14           CONTINUE
 15       CONTINUE
C
C---NORMAL RETURN ON QUADRATIC CONVERGENCE TO MACHINE UNDERFLOW
C
          IF (SM.EQ.0.0) RETURN
C
C---SET THRESHOLD
C
C---ON THE FIRST THREE SWEEPS
          IF (I.LT.4) THEN
              TRESH=0.2*SM/N**2
          ELSE

C---THEREAFTER
              TRESH=0.0
          ENDIF

C---PERFORM PQ ROTATIONS
C
          DO 22 IP=1,N-1
              DO 21 IQ=IP+1,N
                  G=100.0*ABS(A(IP,IQ))

C---AFTER 4 SWEEPS, SKIP ROTATION IF THE OFF-DIAGONAL ELEMENT IS SMALL
                  IF ( (I.GT.4) .AND. (ABS(D(IP))+G.EQ.ABS(D(IP)))
     -                .AND. (ABS(D(IQ))+G.EQ.ABS(D(IQ))) ) THEN
                      A(IP,IQ)=0.0

C---OTHERWISE ROTATE DEPENDENT ON THE TRESHOLD
                  ELSE IF (ABS(A(IP,IQ)).GT.TRESH) THEN
                      H=D(IQ)-D(IP)
                      IF (ABS(H)+G.EQ.ABS(H)) THEN

C   T=1/(2THETA)
                          T=A(IP,IQ)/H
                      ELSE

C   T=SIGN(THETA) / (ABS(THETA)+ SQRT(THETA**2 + 1))
                          THETA=0.5*H/A(IP,IQ)
                          T=1.0/(ABS(THETA)+SQRT(1.0+THETA**2))
                          IF (THETA.LT.0.0) T=-T
                      ENDIF
                      C=1.0/SQRT(1+T**2)
                      S=T*C
                      TAU=S/(1.0+C)
                      H=T*A(IP,IQ)
                      Z(IP)=Z(IP)-H
                      Z(IQ)=Z(IQ)+H
                      D(IP)=D(IP)-H
                      D(IQ)=D(IQ)+H
                      A(IP,IQ)=0.0

C   CASE OF ROTATIONS 1.LE.J.LT.P
                      DO 16 J=1,IP-1
                          G=A(J,IP)
                          H=A(J,IQ)
                          A(J,IP)=G-S*(H+G*TAU)
                          IF (ABS(A(J,IP)).LT.EMIN) THEN
                              A(J,IP) = 0.0
                          ENDIF
                          A(J,IQ)=H+S*(G-H*TAU)
                          IF (ABS(A(J,IQ)).LT.EMIN) THEN
                              A(J,IQ) = 0.0
                          ENDIF
16                    CONTINUE

C   CASE OF ROTATIONS P.LT.J.LT.Q
                      DO 17 J=IP+1,IQ-1
                          G=A(IP,J)
                          H=A(J,IQ)
                          A(IP,J)=G-S*(H+G*TAU)
                          IF (ABS(A(IP,J)).LT.EMIN) THEN
                             A(IP,J) = 0.0
                          ENDIF
                          A(J,IQ)=H+S*(G-H*TAU)
                          IF (ABS(A(J,IQ)).LT.EMIN) THEN
                              A(J,IQ) = 0.0
                          ENDIF
17                    CONTINUE

C   CASE OF ROTATIONS Q.LT.J.LE.N
                      DO 18 J=IQ+1,N
                          G=A(IP,J)
                          H=A(IQ,J)
                          A(IP,J)=G-S*(H+G*TAU)
                          IF (ABS(A(IP,J)).LT.EMIN) THEN
                              A(IP,J) = 0.0
                          ENDIF
                          A(IQ,J)=H+S*(G-H*TAU)
                          IF (ABS(A(IQ,J)).LT.EMIN) THEN
                              A(IQ,J) = 0.0
                          ENDIF
18                    CONTINUE
                      DO 19 J=1,N
                          G=V(J,IP)
                          H=V(J,IQ)
                          V(J,IP)=G-S*(H+G*TAU)
                          IF (ABS(V(J,IP)).LT.EMIN) THEN
                              V(J,IP) = 0.0
                          ENDIF
                          V(J,IQ)=H+S*(G-H*TAU)
                          IF (ABS(V(J,IQ)).LT.EMIN) THEN
                              V(J,IQ) = 0.0
                          ENDIF
19                    CONTINUE
                      NROT=NROT+1
                  ENDIF
21            CONTINUE
22        CONTINUE

C---END OF PQ ROTATIONS
C

C---UPDATE D WITH THE SUM OF TA(PQ) AND REINITIALIZE Z TO 0.0
C
          DO 23 IP=1,N
              B(IP)=B(IP)+Z(IP)
              D(IP)=B(IP)
              Z(IP)=0.0
23        CONTINUE
24    CONTINUE

C   END OF SWEEPS
C
C---ABNORMAL RETURN; 50 SWEEPS IN JACOBI SHOULD NEVER HAPPEN
C
      IFAIL=.TRUE.
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE EIGSRT  -  Sort the eigen vectors into descending order
C                        of eigen value
C
C----------------------------------------------------------------------+---

      SUBROUTINE EIGSRT(EIGVAL,ORDVEC)

      INTEGER       ORDVEC(3), I, ISWAP, J, K
      REAL          EIGVAL(3)

C---- Bubble sort the eigenvalues
      ORDVEC(1) = 1
      ORDVEC(2) = 2
      ORDVEC(3) = 3

C---- Repeate the sort twice
      DO 580, K = 1, 2
          DO 560, J = 1, 2
              DO 540, I = J + 1, 3
                  IF (EIGVAL(ORDVEC(I)).GT.EIGVAL(ORDVEC(J))) THEN
                      ISWAP = ORDVEC(I)
                      ORDVEC(I) = ORDVEC(J)
                      ORDVEC(J) = ISWAP
                  ENDIF
 540          CONTINUE
 560      CONTINUE
 580  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION ORIEN3  -  Returns the orientation of the polygon with the
C                      consecutive vertices (x1,y1,z1), (x2,y2,z2), and
C                      (x3,y3,z3) as viewed from (ex,ey,ez).
C
C                      -1  :  clockwise orientation
C                      +1  :  anti-clockwise orientation (desired order)
C                       0  :  degenerate (line or point)
C
C [Taken from Angell & Griffith]
C----------------------------------------------------------------------+---

      INTEGER FUNCTION ORIEN3(X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3,EX,EY,EZ)

      REAL          A, B, C, DOT3, DX1, DY1, DZ1, DX2, DY2, DZ2,
     -              EX, EY, EZ, FE, X1, Y1, Z1, X2, Y2, Z2, X3, Y3, Z3

C---- Initialise variables
      DX1 = X2 - X1
      DY1 = Y2 - Y1
      DZ1 = Z2 - Z1
      DX2 = X3 - X2
      DY2 = Y3 - Y2
      DZ2 = Z3 - Z2

C---- Calculate triple scalar product
      CALL VECPRD(DX1,DY1,DZ1,DX2,DY2,DZ2,A,B,C)
      FE = DOT3(A,B,C,EX-X1,EY-Y1,EZ-Z1)
      ORIEN3 = SIGN(1.0,FE)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE VECPRD  -  Calculates the vector product (vx,vy,vz) of
C                        two vectors (px,py,pz) and (qx,qy,qz)
C
C----------------------------------------------------------------------+---

      SUBROUTINE VECPRD(PX,PY,PZ,QX,QY,QZ,VX,VY,VZ)

      REAL          PX, PY, PZ, QX, QY, QZ, VX, VY, VZ

      VX = PY * QZ - PZ * QY
      VY = PZ * QX - PX * QZ
      VZ = PX * QY - PY * QX

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION DOT3  -  Returns the scalar product of the two vectors
C                    (x1,y1,z1) and (x2,y2,z2)
C
C----------------------------------------------------------------------+---

      REAL FUNCTION DOT3(X1,Y1,Z1,X2,Y2,Z2)

      REAL          X1, Y1, Z1, X2, Y2, Z2

      DOT3 = X1 * X2 + Y1 * Y2 + Z1 * Z2

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.5<--
C**************************************************************************
C
C  SUBROUTINE CONVRT  -  Write out the clip-line for use with CONVERT when
C                        automatically converting the PostScript file to a
C                        gif file in the run.scr script of generate
C
C----------------------------------------------------------------------+---

      SUBROUTINE CONVRT(XLEFT,XRIGHT,YBOT,YTOP)

      CHARACTER*3   CONTXT(4)
      REAL          XLEFT, XRIGHT, YBOT, YTOP
      INTEGER       ILOOP, IPOS(4), IVALUE(4)

C---- Form the four integers required
      IVALUE(1) = NINT(XRIGHT - XLEFT)
      IVALUE(2) = NINT(YTOP - YBOT)
      IVALUE(3) = NINT(XLEFT)
      IVALUE(4) = NINT(YBOT)

C---- Convert each of the numbers into a character-string
      DO 400, ILOOP = 1, 4
          WRITE(CONTXT(ILOOP),120) IVALUE(ILOOP)
 120      FORMAT(I3)
          IPOS(ILOOP) = 1
          IF (CONTXT(ILOOP)(1:1).EQ.' ') IPOS(ILOOP) = 2
          IF (CONTXT(ILOOP)(2:2).EQ.' ') IPOS(ILOOP) = 3
 400  CONTINUE

C---- Write out the convert clip parameters to the PostScript file
      WRITE(11,420) (CONTXT(ILOOP)(IPOS(ILOOP):), ILOOP = 1, 4)
 420  FORMAT('%convert -clip ',A,'x',A,'+',A,'-',A)

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C**************************************************************************
C
C  SUBROUTINE MOLOPE  -  Open PDB-format file for RASMOL output
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE MOLOPE(FNAME)

      INCLUDE 'surfplot.inc'

      CHARACTER*(*)  FNAME

C---- Open output file
      OPEN(UNIT=13, FILE=FNAME, STATUS='UNKNOWN',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write header records out to PDB-format file
      WRITE(13,100)
 100  FORMAT('REMARK  Created by SURFPLOT')

      GO TO 999

C---- Errors on parameter file
 900  CONTINUE
      PRINT*, 'WARNING. Unable to open PDB-format file'
      GO TO 999
 
 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MOLOUT  -  Write out all the vertices as ATOM records in
C                        the PDB_format file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE MOLOUT

      INCLUDE 'surfplot.inc'
 
      CHARACTER*1   CHAIN
      CHARACTER*(MXMAP) CHAINS
      INTEGER       IEND, IMAP, IPOL, ISTART, IVERT, JVERT, PVERT, WVERT
     -             

      DATA CHAINS(1:36)  / '1234567890abcdefghijklmnopqrstuvwxyz' /
      DATA CHAINS(37:50) / 'ABCDEFGHIJKLMN' /

C---- Initialise variables
      IMAP = 1
      WVERT = 0

C---- Determine at which vertex number the next map starts
      IF (NMAP.EQ.1) THEN
          PVERT = NXTVRT
      ELSE
          PVERT = FSTVRT(2)
      ENDIF

C---- Write out all the vertices
      DO 400, IVERT = 1, NXTVRT

C----     Loop, if necessary, until have identified to which map this
C         vertex belongs
 200      CONTINUE

C----     If have started the vertices for the next map, determine
C         which map this is
          IF (IVERT.GT.PVERT) THEN

C----         Determine at which vertex number the next map starts
              IMAP = IMAP + 1
              WVERT = 0
              IF (IMAP.GE.NMAP) THEN
                  PVERT = NXTVRT
              ELSE
                  PVERT = FSTVRT(IMAP + 1)
              ENDIF
              GO TO 200
          ENDIF

C----     Write out this vertex as an ATOM record
          CHAIN = CHAINS(IMAP:IMAP)
          WVERT = WVERT + 1
          WRITE(13,320) IVERT, CHAIN, IMAP, VERTEX(1,IVERT),
     -        VERTEX(2,IVERT), VERTEX(3,IVERT)
 320      FORMAT('HETATM',I5,'  C   MAP ',A1,I4,'    ',3F8.3,
     -        '  1.00 10.00')
 400  CONTINUE

C---- Write out all the connectivity records

C---- Loop through all the polygons
      DO 800, IPOL = 1, NPOL

C----     If the polygon's colour is -999, then don't plot it
          IF (POLCOL(IPOL).NE.-999) THEN

C----         Determine start- and end-vertices for this polygon
              ISTART = IPOLYG(IPOL)
              IF (IPOL.LT.NPOL) THEN
                  IEND = IPOLYG(IPOL + 1) - 1
              ELSE
                  IEND = NVERT
              ENDIF

C----         If this polygon has two edges (ie is a line), then write out
C             a CONECT record joining its two vertices
              IF (IEND - ISTART.EQ.1) THEN
COUT                  WRITE(13,520) VERTNO(ISTART), VERTNO(IEND)
 520              FORMAT('CONECT',2I5)


C----         If this polygon has three edges (is is a triangle) write
C             out the three lines, unless already written out
              ELSE IF (IEND - ISTART.EQ.2) THEN

C----             Loop through each of the three lines making up the
C                 polygon
                  DO 600, IVERT = ISTART, IEND

C----                 Get the other end of the line
                      JVERT = IVERT + 1
                      IF (JVERT.GT.IEND) JVERT = ISTART

C----                 Write out the CONECT record only if second
C                     vertex number is higher
                      IF (VERTNO(JVERT).GT.VERTNO(IVERT)) THEN
COUT                          WRITE(13,520) VERTNO(IVERT), VERTNO(JVERT)
                      ENDIF
 600              CONTINUE
              ENDIF
          ENDIF
 800  CONTINUE


      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION LENSTR  -  Return length of string 'CHARS' excluding
C                      trailing blanks
C
C----------------------------------------------------------------------+---

      INTEGER FUNCTION LENSTR(CHARS)

      CHARACTER*(*) CHARS
      INTEGER J, MVAL

      MVAL = LEN(CHARS)
      DO 10, J = MVAL, 1, -1
          IF (CHARS(J:J).NE.' ') GO TO 20
   10 CONTINUE
      J = 0
   20 CONTINUE
      LENSTR = J

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4<--

