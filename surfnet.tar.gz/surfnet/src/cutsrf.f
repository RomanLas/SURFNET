C*****************************************************************************
C*****************************************************************************
C************                                                   **************
C************        C  U  T  S   R   F   .   F   O   R         **************
C************                                                   **************
C*****************************************************************************
C*****************************************************************************
C
C                     R A Laskowski, University College London
C
C                                 January 1995
C
C----------------------------------------------------------------------+--- 
C
C Program description
C -------------------
C
C This program cuts a given .srf file down to the user-defined size,
C writing out QUANTA,  or SYBYL output files, as required
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.0     Original release version.                   4 May 1995 (RAL)
C
C v.1.1     Update of routines that produce  output files.
C                                                     5-9 May 1995 (RAL)
C v.1.3.1   Minor amendment of integer to logical variable as wouldn't
C           compile under HP FORTRAN.
C                                                      10 Jan 1996 (RAL)
C v.1.3.3   Amendment to check whether user-defined limits are within the
C           bounds of the map. (Rounding errors were often flagging entered
C           values as outside the given range).
C                                                      21 Mar 1996 (RAL)
C
C v.1.4     Amendments to group map-generating routines together in
C           surfmaps.f. Routine CUTARR renamed to GETCUT, and routine
C           ADJARR renamed to CUTARR
C                                                      17 Jun 1996 (RAL)
C           Changes to make all filenames 120 characters long.
C                                                       5 Sep 1996 (RAL)
C
C v.1.4.2   Addition of new parameter to GETSRF routine.
C                                                      13 Feb 1997 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Files
C -----
C
C  3   <filename>.srf  - Input .srf file
C 10   cutsrf.den      - Output CCP4 density file
C 10   cutsrf.grd      - Output InsightII grid file
C 10   cutsrf.mbk      - Output Quanta brick file file
C 10   cutsrf.srf      - Reduced output .srf file
C ??   cutsrf.cnt      - Output Sybyl contour file
C
C----------------------------------------------------------------------+--- 
C
C
C Compilation and linking (on unix)
C -----------------------
C
C f77 -u -c cutsrf.f
C f77 -u -c surfmaps.f
C f77 -o cutsrf cutsrf.o surfmaps.o
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines in surfmaps.f and use surfsyb.scr to link to the Sybyl
C library routines.
C
C If CCP4 density maps are to be generated, uncomment all the CCP4
C lines in surfmaps.f and use surfccp4.scr to link to the CCP4
C library routines.
C
C Subroutine calling tree
C -----------------------
C
C MAIN  --> INITS
C       --> GETSRF
C
C           Reduce extent of array so that it encompasses only the
C           region required
C
C       --> GETCUT
C       --> CUTARR
C       --> MAXMIN
C
C           Write out the reduced grid array in the different formats
C           required
C
C       --> WRIMAP  --> LIMTAR
C                   --> ADJARR
C                   --> GRHIST  --> SHSORT
C                   --> WRISRF
C                   --> COMPRS
C                   --> ASCDEN  --> CCP4 routines to write out density file
C                   --> MBRICK  --> CCP4 routines to read in density files
C                                   and write out brick files (for FRODO)
C                                   [This routine is no longer used]
C                   --> INSIGH
C                   --> QUANTA  --> GETHED
C                               --> MBRWRH
C                               --> MRDSE8
C                   --> SYBYL   --> XCCreate
C                               --> XCWrite
C                               --> XCClose
C
C----------------------------------------------------------------------+--- 


      PROGRAM CUTSRF

CVAX      IMPLICIT NONE

      INCLUDE 'cutsrf.inc'

      CHARACTER*80  TITLE
CHANGE v.1.4-->
C      INTEGER       IMAP, NKEEP, NNEW(3), NPOINT(3)
C      REAL          ARRAY(MAXARR)
      INTEGER       IMAP, IUNIT, NNEW(3), NPOINT(3)
CHANGE v.1.4.2-->
C      LOGICAL       NOMESS, NOPNT, RAWDAT
      LOGICAL       HDONLY, NOMESS, NOPNT, RAWDAT
CHANGE v.1.4.2<--
      REAL          ARRAY(MAXARR), MFACTR, VALTOT
CHANGE v.1.4<--
CHANGE v.1.4-->
CC-Sybyl-->
CCSYBYL      REAL*8        SHEET(MXSHEE)
CC-Sybyl<--
CHANGE v.1.4<--


C---- Initialise variables
CHANGE v.1.4.2-->
      HDONLY = .FALSE.
CHANGE v.1.4.2<--
      FILCNT = 'cutsrf.cnt'
      FILDEN = 'cutsrf.den'
      FILMBK = 'cutsrf.mbk'
      IMAP = 1
      FROMAP = .FALSE.
      TITLE = 'Cut density file'
CHANGE v.1.4-->
CC---- CCP4-->
CCCP4      FROMAP = .TRUE.
CC---- CCP4<--
C      QUAMAP = .TRUE.
C      SYBMAP = .FALSE.
CC-Sybyl-->
CCSYBYL      QUAMAP = .FALSE.
CCSYBYL      SYBMAP = .TRUE.
CC-Sybyl<--
      CALL INTMAP(FROLNK,SYBLNK)
CHANGE v.1.4<--

C---- Accept input file name
      CALL INITS

C---- Read in the grid of values for the given distribution from .srf file
CHANGE v.1.4-->
C      CALL REGRID(ARRAY,MAXARR,NPOINT(1),NPOINT(2),NPOINT(3),NPTS,
C     -    GRDSEP,VALMIN,FILTYP,IFRAG,IATYPE,FILSRF,ICOUNT,GCOUNT,
C     -    FRGFRQ,NX,NY,NZ,IFAIL)
      IUNIT = 3
      NOMESS = .FALSE.
      CALL GETSRF(FILSRF,IUNIT,ARRAY,MAXARR,NPOINT(1),NPOINT(2),
     -    NPOINT(3),FILTYP,GRDSEP,VALMIN,VALMAX,VALTOT,IFRAG,IATYPE,
CHANGE v.1.4.2-->
C     -    ICOUNT,FRGFRQ,NOMESS,IFAIL)
     -    ICOUNT,FRGFRQ,NOMESS,HDONLY,IFAIL)
CHANGE v.1.4.2<--
CHANGE v.1.4<--
      IF (IFAIL) GO TO 999

C---- Get size of reduced array required
CHANGE v.1.4-->
C      CALL CUTARR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
      CALL GETCUT(NPOINT(1),NPOINT(2),NPOINT(3))
CHANGE v.1.4<--
      IF (IFAIL) GO TO 999

C---- Reduce the size of the array
CHANGE v.1.4-->
C      CALL ADJARR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),NNEW(1),NNEW(2),
C     -    NNEW(3))
      CALL CUTARR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),NNEW(1),NNEW(2),
     -    NNEW(3))
CHANGE v.1.4<--
      NPOINT(1) = NNEW(1)
      NPOINT(2) = NNEW(2)
      NPOINT(3) = NNEW(3)

C---- Calculate maximum and minimum values in map
      CALL MAXMIN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))

C---- Write out density and brick files

C---- Write the array to disk as a surface density file
      PRINT*, 'Writing surface density file ...   '
CHANGE v.1.4-->
C      CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C      IF (IFAIL) GO TO 999
C
CC---- If the CCP4 density and brick files are actually required,
CC     then call the appropriate  routines and write them out
C      IF (FROMAP) THEN
C
CC----     Write the array to disk as a CCP4 density file
CC---- CCP4-->
CCCP4          PRINT*, 'Writing CCP4 density file ...   '
CCCP4          CALL ASCDEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCCP4     -        FILDEN,TITLE,LIM,IUVW,VALMAX,
CCCP4     -        VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)
CC---- CCP4<--
C
CC----     Write the array to disk as a brick file [Not used. Use 
CC         routines to convert  format to FRODO format]
CCFRODO          PRINT*, 'Writing brick file ...     ', IMAP
CCFRODO          CALL MBRICK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C      ENDIF
C
C---- If Quanta brick files are required, then write these out
C      IF (QUAMAP) THEN
C
CC----     Write the array to disk as a Quanta density file
C          PRINT*, 'Writing brick file ...   '
C          CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -        IMAP,FILMBK,GRDSEP,MAPAV,MAPMIN,
C     -        MAPMAX,VALMIN,VALMAX)
C      ENDIF
C
CC---- If Sybyl contour files are required, then write these out
C      IF (SYBMAP) THEN
C
CC----     Check that the sheet-size not larger than
CC         allowed in the parameters
C          IF (MXSHEE.GE.NPOINT(1) * NPOINT(2)) THEN
C
CC----         Write the array to disk as a Sybyl contour file
C              PRINT*, 'Writing Sybyl contour file ...     ', IMAP
CC-Sybyl-->
CCSYBYL              CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
CCSYBYL     -            NPOINT(3),IMAP,FILCNT,GRDSEP,MAPAV,
CCSYBYL     -            MAPMIN,MAPMAX,VALMIN,VALMAX,SHEET,TITLE,
CCSYBYL     -            IFAIL)
CC-Sybyl<--
C
CC----     If array not large enough, display error message
C          ELSE
C              PRINT*, '*** ERROR. Array variable MXSHEE ',
C     -            'not large enough for sheets to be'
C              PRINT*, '*          written out to Sybyl ',
C     -            'contour file', MXSHEE, NPOINT(1) * NPOINT(2)
C          ENDIF
C      ENDIF

C---- Write out the array in whichever output format is required
      IUNIT = 10
      MFACTR = 1.0
      RAWDAT = .TRUE.
      FILSRF = 'cutsrf.srf'
      CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,FILTYP,IMAP,IFRAG,
     -    IATYPE,ICOUNT,FRGFRQ,FILCNT,FILDEN,FILGRD,FILMBK,FILSRF,
     -    IUNIT,FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,
     -    RAWDAT,MFACTR,.TRUE.,NOMESS,NOPNT,IFAIL)
CHANGE v.1.4<--


 999  CONTINUE
      IF (.NOT.IFAIL) THEN
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'cutsrf.inc'
          
CHANGE v.1.4-->
      CHARACTER*1   YESNO
CHANGE v.1.4<--
      CHARACTER*2   AT(NRADII)
      INTEGER       I
      REAL          VD(NRADII)

      DATA AT     / ' H', ' C', ' O', ' N',  ' S', ' P', 'FE', ' 0',
     -              ' X' /
      DATA VD     /  1.2,  2.0,  1.4,  1.5,  1.85,  1.9,  1.1,  0.0,
     -               1.5 /


C---- Initialise variables
      DO 200, I = 1, NRADII
          ATYPE(I) = AT(I)
          VDWRAD(I) = VD(I)
200   CONTINUE

C---- Accept filename of input .srf file
      PRINT*, 'Enter name of input .srf density file'
      READ(*,110) FILSRF
 110  FORMAT(A)

CHANGE v.1.4-->
C---- Accept which output map format is required
      FROMAP = .FALSE.
      INSMAP = .FALSE.
      QUAMAP = .FALSE.
      SYBMAP = .FALSE.
      PRINT*, 'Enter map-format required: (Q)uanta, (C)CP4, (S)ybyl',
     -    ', (I)nsightII or (N)one'
      READ(*,110) YESNO
      IF (YESNO.EQ.'Q' .OR. YESNO.EQ.'q') THEN
          QUAMAP = .TRUE.
      ELSE IF (YESNO.EQ.'I' .OR. YESNO.EQ.'i') THEN
          INSMAP = .TRUE.
      ELSE IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          IF (FROLNK) THEN
              FROMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to  librar',
     -            'ies'
              PRINT*, '***          No  density maps will be produ',
     -            'ced'
          ENDIF
      ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
          IF (SYBLNK) THEN
              SYBMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to Sybyl libra',
     -            'ries'
              PRINT*, '***          No Sybyl contour maps will be prod',
     -            'uced'
          ENDIF
      ELSE IF (YESNO.EQ.'N' .OR. YESNO.EQ.'n') THEN
          PRINT*, '*** No map files required'
      ELSE
          PRINT*, '*** INVALID map format requested: [', YESNO, ']'
          PRINT*, '*** No map files will be written out.'
      ENDIF
CHANGE v.1.4<--

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutine REGRID replaced by GETSRF in surfmaps.f
CHANGE v.1.4<--
C**************************************************************************
C
C  SUBROUTINE GETCUT  -  Calculate effective extent of grid (ie region
C                        bounding remaining gap-volumes) so that can chop
C                        down size of grid to a minimum
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      SUBROUTINE CUTARR(ARRAY,N1,N2,N3)
      SUBROUTINE GETCUT(N1,N2,N3)
CHANGE v.1.4<--

      INCLUDE 'cutsrf.inc'

      REAL          DX
      PARAMETER    (DX = 0.0001)
  
CHANGE v.1.4-->
C      INTEGER       IX, IY, IZ, N1, N2, N3
C      REAL          ARRAY(N1,N2,N3), VMIN, VMAX, XMIN, XMAX, X1, X2,
C     -              YMIN, YMAX, Y1, Y2, ZMIN, ZMAX, Z1, Z2
      INTEGER       N1, N2, N3
      REAL          VMIN, VMAX, XMIN, XMAX, X1, X2,YMIN, YMAX, Y1, Y2,
     -              ZMIN, ZMAX, Z1, Z2
CHANGE v.1.4<--


C---- Display current coordinate ranges covered by the .srf file
      XMIN = VALMIN(1)
      XMAX = VALMIN(1) + (N1 - 1) * GRDSEP
      YMIN = VALMIN(2)
      YMAX = VALMIN(2) + (N2 - 1) * GRDSEP
      ZMIN = VALMIN(3)
      ZMAX = VALMIN(3) + (N3 - 1) * GRDSEP
      PRINT 120, XMIN, XMAX, YMIN, YMAX, ZMIN, ZMAX
 120  FORMAT('Coordinate ranges:',/,
     -       12X,'              X:   ',F10.4,'  ->',F10.4,/,
     -       12X,'              Y:   ',F10.4,'  ->',F10.4,/,
     -       12X,'              Z:   ',F10.4,'  ->',F10.4,/)

C---- Accept coord bounds for reduced .srf file
      PRINT*, 'Enter new minimum and maximum x-coords'
      READ*, X1, X2
CHANGE v.1.3.3-->
C      IF (X1.LT.XMIN .OR. X2.GT.XMAX .OR. X1.GE.X2) GO TO 900
C      PRINT*, 'Enter new minimum and maximum y-coords'
C      READ*, Y1, Y2
C      IF (Y1.LT.YMIN .OR. Y2.GT.YMAX .OR. Y1.GE.Y2) GO TO 902
C      PRINT*, 'Enter new minimum and maximum z-coords'
C      READ*, Z1, Z2
C      IF (Z1.LT.ZMIN .OR. Z2.GT.ZMAX .OR. Z1.GE.Z2) GO TO 904
      IF (X1.LT.(XMIN - DX) .OR. X2.GT.(XMAX + DX) .OR.
     -    X1.GE.X2) GO TO 900
      PRINT*, 'Enter new minimum and maximum y-coords'
      READ*, Y1, Y2
      IF (Y1.LT.(YMIN - DX) .OR. Y2.GT.(YMAX + DX) .OR.
     -    Y1.GE.Y2) GO TO 902
      PRINT*, 'Enter new minimum and maximum z-coords'
      READ*, Z1, Z2
      IF (Z1.LT.(ZMIN - DX) .OR. Z2.GT.(ZMAX + DX) .OR.
     -    Z1.GE.Z2) GO TO 904
CHANGE v.1.3.3<--

C---- Compute the arry points these coordinates correspond to
      IXMIN = 1.5 + (X1 - XMIN) / GRDSEP
      IXMAX = 1.5 + (X2 - XMIN) / GRDSEP
      IYMIN = 1.5 + (Y1 - YMIN) / GRDSEP
      IYMAX = 1.5 + (Y2 - YMIN) / GRDSEP
      IZMIN = 1.5 + (Z1 - ZMIN) / GRDSEP
      IZMAX = 1.5 + (Z2 - ZMIN) / GRDSEP

C---- Make sure limits not off either end of grid map
      IXMIN = MAX(1,IXMIN)
      IXMAX = MIN(N1,IXMAX)
      IYMIN = MAX(1,IYMIN)
      IYMAX = MIN(N2,IYMAX)
      IZMIN = MAX(1,IZMIN)
      IZMAX = MIN(N3,IZMAX)

C---- Print effective limits
      PRINT*
      VMIN = VALMIN(1) + (IXMIN - 1) * GRDSEP
      VMAX = VALMIN(1) + (IXMAX - 1) * GRDSEP
      PRINT 420, 'New array limits:  X ', IXMIN, ' -->', IXMAX,
     -    'Coords:', VMIN, VMAX
 420  FORMAT(A,I4,A,I4,5X,A,F10.4,'   -->',F10.4)
      VMIN = VALMIN(2) + (IYMIN - 1) * GRDSEP
      VMAX = VALMIN(2) + (IYMAX - 1) * GRDSEP
      PRINT 420, '                   Y ', IYMIN, ' -->', IYMAX,
     -    'Coords:', VMIN, VMAX
      VMIN = VALMIN(3) + (IZMIN - 1) * GRDSEP
      VMAX = VALMIN(3) + (IZMAX - 1) * GRDSEP
      PRINT 420, '                   Z ', IZMIN, ' -->', IZMAX,
     -    'Coords:', VMIN, VMAX


      GO TO 999


C---- Errors reading parameter file
 900  CONTINUE
      PRINT*, '*** ERROR in supplied x-value range'
CHANGE v.1.3.3-->
      IF (X1.LT.XMIN) THEN
          PRINT*, '          Lower bound', X1,'  is below lower ',
     -        'limit for x:', XMIN
      ENDIF
      IF (X2.GT.XMAX) THEN
          PRINT*, '          Upper bound', X2,'  is above upper ',
     -        'limit for x:', XMAX
      ENDIF
      IF (X1.GE.X2) THEN
          PRINT*, '          Lower bound', X1, '  is greater than',
     -        ' upper bound', X2
      ENDIF
CHANGE v.1.3.3<--
      GO TO 990
 
 902  CONTINUE
      PRINT*, '*** ERROR in supplied y-value range'
CHANGE v.1.3.3-->
      IF (Y1.LT.YMIN) THEN
          PRINT*, '          Lower bound', Y1,'  is below lower ',
     -        'limit for y:', YMIN
      ENDIF
      IF (Y2.GT.YMAX) THEN
          PRINT*, '          Upper bound', Y2,'  is above upper ',
     -        'limit for y:', YMAX
      ENDIF
      IF (Y1.GE.Y2) THEN
          PRINT*, '          Lower bound', Y1, '  is greater than',
     -        ' upper bound', Y2
      ENDIF
CHANGE v.1.3.3<--
      GO TO 990
 
 904  CONTINUE
      PRINT*, '*** ERROR in supplied z-value range'
CHANGE v.1.3.3-->
      IF (Z1.LT.ZMIN) THEN
          PRINT*, '          Lower bound', Z1,'  is below lower ',
     -        'limit for z:', ZMIN
      ENDIF
      IF (Z2.GT.ZMAX) THEN
          PRINT*, '          Upper bound', Z2,'  is above upper ',
     -        'limit for z:', ZMAX
      ENDIF
      IF (Z1.GE.Z2) THEN
          PRINT*, '          Lower bound', Z1, '  is greater than',
     -        ' upper bound', Z2
      ENDIF
CHANGE v.1.3.3<--
      GO TO 990
 
C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CUTARR  -  Reduce the size of the array so that it just 
C                        encompasses all the gap-volumes
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      SUBROUTINE ADJARR(ARRAY,N1,N2,N3,NEW1,NEW2,NEW3)
      SUBROUTINE CUTARR(ARRAY,N1,N2,N3,NEW1,NEW2,NEW3)
CHANGE v.1.4<--

      INCLUDE 'cutsrf.inc'
  
      INTEGER       INEW, IOLD, IX, IXOLD, IY, IYOLD, IZ, IZOLD, N1,
     -              N2, N3, NEW1, NEW2, NEW3
      REAL          ARRAY(N1*N2*N3)

C---- Initialise variables
      NEW1 = IXMAX - IXMIN + 1
      NEW2 = IYMAX - IYMIN + 1
      NEW3 = IZMAX - IZMIN + 1
      VALMIN(1) = VALMIN(1) + (IXMIN - 1) * GRDSEP
      VALMIN(2) = VALMIN(2) + (IYMIN - 1) * GRDSEP
      VALMIN(3) = VALMIN(3) + (IZMIN - 1) * GRDSEP
      VALMAX(1) = VALMIN(1) + (NEW1 - 1) * GRDSEP
      VALMAX(2) = VALMIN(2) + (NEW2 - 1) * GRDSEP
      VALMAX(3) = VALMIN(3) + (NEW3 - 1) * GRDSEP

C---- Loop through all the grid-points in the array, transferring all the
C     points in the reduced array into the corner of the new version
C     of the array
      DO 300, IZ = 1, NEW3
          IZOLD = IZ + IZMIN - 1
          DO 200, IY = 1, NEW2
              IYOLD = IY + IYMIN - 1
              DO 100, IX = 1, NEW1
                  IXOLD = IX + IXMIN - 1

C----             Calculate the array-position of the current grid-point
C                 in the original and reduced versions of the array
                  IOLD = (IZOLD - 1) * N1 * N2 + (IYOLD - 1) * N1
     -                + IXOLD
                  INEW = (IZ - 1) * NEW1 * NEW2 + (IY - 1) * NEW1
     -                + IX
                  ARRAY(INEW) = ARRAY(IOLD)
 100          CONTINUE
 200      CONTINUE
 300  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MAXMIN  -  Find the new maximum and minimum values in the
C                        array
C
C--------------------------------------------------------------------------

      SUBROUTINE MAXMIN(ARRAY,N1,N2,N3)

CVAX      IMPLICIT NONE

      INCLUDE 'cutsrf.inc'

CHANGE v.1.3-->
C      INTEGER       GRPTS, I, NOPNT, N1, N2, N3
      INTEGER       GRPTS, I, N1, N2, N3
      LOGICAL       NOPNT
CHANGE v.1.3<--
      REAL          ARRAY(N1*N2*N3), MMEAN

C---- Initialise variables
      GRPTS = 0

C---- Find the maximum, minimum and mean values of all the grid values
      NOPNT = .FALSE.
      MAPMIN = ARRAY(1)
      MAPAV  = 0.0
      MAPMAX = ARRAY(1)
      MAPRMS = 0.0
      DO 200, I = 1, N1 * N2 * N3

C----     Find minimum and maximum grid values
          MAPMIN = MIN(ARRAY(I),MAPMIN)
          MAPMAX = MAX(ARRAY(I),MAPMAX)
          MAPAV = MAPAV + ARRAY(I)
          IF (ARRAY(I).NE.0.0) GRPTS = GRPTS + 1
200   CONTINUE
      IF (MAPMIN.EQ.0.0 .AND. MAPMAX.EQ.0.0) NOPNT = .TRUE.
      PRINT*
      PRINT*, '   Number of non-zero grid points in MAP:', GRPTS
      PRINT*
      PRINT*, '   Minumum and maximum density values:', MAPMIN, MAPMAX
      MAPAV = MAPAV / (N1 * N2 * N3)

C---- Calculate the RMS deviation of the densities from the mean
      IF (.NOT.NOPNT) THEN
          MMEAN = MAPAV

C----     Loop over all the points in the array
          DO 700, I = 1, N1 * N2 * N3

C----         Calculate RMS difference from mean
              MAPRMS = MAPRMS + (ARRAY(I) - MMEAN) * (ARRAY(I) - MMEAN)
 700      CONTINUE
          MAPRMS = MAPRMS / (N1 * N2 * N3)
          MAPRMS = SQRT(MAPRMS)
          PRINT*, '   Mean density value and RMS diff:', MMEAN,
     -            MAPRMS
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutine WRISRF amended and moved to surfmaps.f
CHANGE v.1.4<--
