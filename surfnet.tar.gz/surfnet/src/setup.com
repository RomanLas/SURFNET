$! SURFNET logical assignments
$! ---------------------------
$!
$! **** Edit the following line to insert the correct path
$  SURFDIR   := "programs directory"
$  DEFINE SURFDIR$ "''SURFDIR'"
$  CURVE     :== RUN SURFDIR$:CURVE
$  CUTSRF    :== RUN SURFDIR$:CUTSRF
$  GENBOX    :== RUN SURFDIR$:GENBOX
$  MAPDIFF   :== RUN SURFDIR$:MAPDIFF
$  MAPSPHERE :== RUN SURFDIR$:MAPSPHERE
$  MASK      :== RUN SURFDIR$:MASK
$  PLANE     :== RUN SURFDIR$:PLANE
$  PRINCIP   :== RUN SURFDIR$:PRINCIP
$  SURFACE   :== RUN SURFDIR$:SURFACE
$  SURFNET   :== @SURFDIR$:SURFNET.COM
$  SURFPLOT  :== RUN SURFDIR$:SURFPLOT
$  TRANSFORM :== RUN SURFDIR$:TRANSFORM
