C*****************************************************************************
C*****************************************************************************
C************                                                   **************
C************     S   U   R   F   N   E   T   .   F   O   R     **************
C************                                                   **************
C*****************************************************************************
C*****************************************************************************
C
C             R A Laskowski, Birkbeck College, University of London
C
C                                  August 1991
C
C----------------------------------------------------------------------+--- 
C
C Program description
C -------------------
C
C This program generates one or more brick maps (and density maps) for the
C supplied coordinates file. The brick map can be displayed on QUANTA,
C SYBYL, O or FRODO together with the atoms. By selecting a contour level
C of 100, one gets the van der Waals surface of the molecule.
C
C The most likely use of this program is for studying protein-inhibitor fits.
C The coordinate file should contain the protein and inhibitor molecule
C coordinates (together with any waters). One can then generate separate
C brick maps for the protein, inhibitor, and water molecules. One can also
C generate a brick map representing gaps between the inhibitor and other
C atoms. When displayed in different colours, these can give an
C indication of the gaps that exist between the molecules.
C
C The program can also be used for studying channels in proteins. In this case,
C there is no inhibitor. Gaps need to be calculated between all atoms, and
C there is an option in the parameter file that allows this.
C     
C The filling of gaps is achieved by a very simple insertion of spheres
C between all possible inhibitor/protein atom pairs.
C
C A crude measure of the volume taken up by each object in a map can be
C obtained by counting up the covered grid-points.
C
C The atom coordinates should be supplied in PDB format (ie Brookhaven format).
C
C The default output format is for QUANTA. To produce SYBYL or CCP4 format
C density files, read the Installation Instructions. Files for O or FRODO
C can be converted from the CCP4 format using either MAPPAGE or MAPMAN
C - both of which are available with the CCP4 suite.
C
C Version 1.2 includes routines to output standard grid files for contouring
C by InsightII.
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.0     Original release version.                   4 May 1995 (RAL)
C
C v.1.1     Fix to store radii of ALL atoms read in if any sort of gap
C           map is required.
C           Update of routines that produce CCP4 output files.
C                                                     5-9 May 1995 (RAL)
C v.1.1.1   Check for metal atoms.
C           Correction to boundary-calculations.
C           New map-type (E) for contouring the B-values.
C                                                    9-12 Jun 1995 (RAL)
C
C v.1.2     Speed-up of gap-filling routines by use of a pre-sort to check
C           for nearest-neighbour clashes by searching from the nearest
C           neighbours outwards
C           Addition of routines to output grid files for contouring by
C           InsightII.                              22-30 Aug 1995 (RAL)
C
C v.1.3     Fixes to correct bug in Sybyl causing numbers of grid-points
C           to be sometimes miscalculated and hence contour maps to be
C           incorrectly displayed. (Routine SYBYL).     1 Dec 1995 (RAL)
C           Removal of ATMVEC routine.
C           Addition of volumes.pdb file, such that molecule volumes
C           get written to the new file rather than to the gaps.pdb
C           file.                                       6 Dec 1995 (RAL)
C           Removal of the error listing sadge.err.
C           Commenting out of cavatoms.pdb file generation.
C                                                      12 Dec 1995 (RAL)
C
C v.1.4     Amendments to group map-generating routines together in
C           surfmaps.f.
C                                                   13-14 Jun 1996 (RAL)
C           Additional file-type of "a", being the same as "A", but with
C           the atoms coloured according to B-factor (0-80).
C                                                   28-29 Aug 1996 (RAL)
C           Changes to make all filenames 120 characters long.
C                                                       5 Sep 1996 (RAL)
C
C v.1.4.2   Amendment to ignore any hydrogen atoms unless specifically
C           requested by the user to be kept in.
C                                                      21 Mar 1997 (RAL)
C
C v.1.5     Addition of dittos option for OUTPUT FILES in surfnet.par.
C                                                      12 Dec 1997 (RAL)
C           Output of input file-name and SITE records to the gaps.pdb
C           and volumes.pdb files.
C                                                      14 Dec 1997 (RAL)
C           Minor adjustments for errors objected to by the linux compiler
C           in mapsphere.f, surface.f and here.
C                                                      30 Jan 1998 (RAL)
C v.1.6     Addition of new options in the parameter file. New option to
C           write out pointers (.pnt) file for each .srf file generated,
C           rather than just for the gaps.srf file.
C                                                       9 Nov 1999 (RAL)
C           Split of FILGAP subroutine into smaller routines. Addition
C           of new sphere-cut check routines, and addition of optional
C           generation of multiple gap-spheres between each atom pair.
C                                                      15 Nov 1999 (RAL)
C           Rewrite of PARAMS function, including reading in of new
C           parameters. Implementation of new sphere-filling algorithm.
C                                                      15 Dec 1999 (RAL)
C           Implementation of gap-sphere clustering and filtering
C           algorithm. Clusters written to clusters.pdb file
C                                                   16-17 Dec 1999 (RAL)
C           Change of output .pdb volume files to .vol files, except
C           for gaps.pdb file.
C           Alterations to gap-clustering routines.
C                                                      27 Mar 2000 (RAL)
C           Amendments to CALVAL function in surfmaps.f to make more
C           efficient
C                                                      18 Apr 2000 (RAL)
C           Amemndments to hydrogen-atom detection to let metals such
C           as HG to pass.
C                                                      18 Jul 2000 (RAL)
C v.1.6.1   Fix in JCHECK for integer variable defined as REAL.
C                                                      29 May 2001 (RAL)
C           Fix in MAPSPH for illegal assignment to variable ARSIZE.
C                                                       1 Jun 2001 (RAL)
C           Addition of option to include hydrogens.
C                                                      13 Sep 2001 (RAL)
C           Minor hack to WRIMAP routine to allow resizing of output
C           ap to be bypassed.
C                                                      17 May 2002 (RAL)
C
C v.1.6.2   Fix in JCHECK for additional check on array bounds.
C                                                      23 May 2003 (RAL)
C
C v.1.6.3   Fix in SRFNET so that gaps.pnt file is calculated.
C                                                       9 Nov 2005 (RAL)
C v.1.6.4   Modification to GETFAC in surfmaps.f to give a better
C           density calculation for maps of type "C"
C                                                      29 Mar 2006 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Files
C -----
C
C  1   surfnet.par     - File holding run parameters for program
C      (sadge.par)       (ie filenames,etc)
C  2   <filename>.pdb  - Input file holding protein coordinates
C  8   <outname>.vol   - File of coordinates of centres of gravity of
C                        individual gap volumes. The file is in Brookhaven
C                        format and can be included in the protein file
C                        so as to locate the various volumes calculated
C                        by the program. For gaps.vol, filename is gaps.pdb.
C  9   <outname>.pnt   - Mask file giving the pointers identifying which
C                        volume each grid-point belongs to
C 10   <outname>.den   - Output density file in CCP4 format
C 10   <outname>.grd   - Output InsightII grid file
C 10   <outname>.mbk   - Output Quanta brick file
C 10   <outname>.srf   - Output .srf file holding the arrays of density
C                        values
C 11   <outname>.cmp   - Compressed version of the data array for a
C                        number-counts map. [Not used]
C 11   clusters.pdb    - Output file holding all the gap-spheres sorted
C                        by cluster
C 12   cavatoms.pdb    - Atoms from the structure in contact with a gap
C                        region
C 14   volumes.pdb     - Like the gaps.pdb file, but for molecule volumes
C ??   <outname>.cnt   - Output Sybyl contour file
C 16   gaps.vol        - File containing all output volumes
C
C----------------------------------------------------------------------+--- 
C
C
C Compilation and linking
C -----------------------
C
C f77 -u -C -c surfnet.f
C f77 -u -C -c surfmaps.f
C f77 -o surfnet surfnet.o surfmaps.o
C
C Compiling under g77:-
C
C f77 -Wimplicit -fbounds-check -c surfnet.f
C f77 -Wimplicit -fbounds-check -c surfmaps.f
C f77 -o surfnet surfnet.o surfmaps.o
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines in surfmaps.f and use surfsyb.scr to link to the Sybyl
C library routines.
C
C If CCP4 density maps are to be generated, uncomment all the CCP4
C lines in surfmaps.f and use surfccp4.scr to link to the CCP4
C library routines.
C
C Subroutine calling tree
C -----------------------
C
C MAIN    --> INTMAP
C         --> PARAMS  --> FINKEY
C                     --> READNO  --> READCH
C                     --> GETOUT  --> FINKEY
C                     --> READCH
C
C         Read in coordinates and calculate grid bounds
C
C         --> INITS
C         --> READCO  --> CHKRNG
C                     --> MAXMIN
C         --> GBOUND
C         --> OPNVOL
C         --> OPNGVL
C
C         Loop for each map to be written out
C
C         --> REINIT
C
C         If gaps required, fill the gaps
C
C         --> DELATM  --> SHSORT
C         --> FILGAP  --> SSDIST
C                     --> SHSORT
C                     --> CALTRN  --> ANGLE
C                                 --> CALMAT
C                                 --> CALINV
C                     --> CALNGP
C                     --> GENSPH
C                     --> MOVEAT
C                     --> TRANSF
C         --> MAKEGR  --> CHKRNG
C                     --> GRID    --> ATMVEC
C         --> GRSCAL
C         --> MAPSPH  --> INCONT
C                     --> CALIDX  --> SHSORT
C                     --> PLASPH  --> GROSPH
C                     --> DELSPH  --> SHSORT
C         --> VOLUME  (see below)
C         --> SPHILT
C         --> ADDBAK
C         --> REGEN
C         --> RECVOL
C         --> GAPSRT  --> SHSORT
C         --> WRIGAP
C         --> WRITOP  --> GETVOL
C                     --> WRIMAP  (see below)
C                     --> GRID    --> ATMVEC
C         --> WRINDX  --> WRIMAP  (see below)
C                     --> GRID    --> ATMVEC
C         --> RESETR
C         --> CLUSTR  --> JOINCL
C         --> GAFILT
C         --> DELGAP
C         --> COUNTC  --> JOINCL
C         --> WRICLU
C
C         If bond or atom file, just write out
C
C         --> ADJFRG  --> CHKRNG
C         --> WRISRF
C
C         If density contour, calculate normalization factor
C
C         --> GETFAC  --> GRID
C
C         Form the grid and write out density and brick map files
C
C         --> MAKEGR  --> CHKRNG
C                     --> GRID    --> ATMVEC
C         --> GRSCAL
C         --> WRIMAP  --> LIMTAR
C                     --> ADJARR
C                     --> GRHIST  --> SHSORT
C                     --> WRISRF
C                     --> ASCDEN  --> CCP4 routines to write out density file
C                     --> MBRICK  --> CCP4 routines to read in density files
C                                     and write out brick files (for FRODO)
C                                     [This routine is no longer used]
C                     --> INSIGH
C                     --> QUANTA  --> GETHED
C                                 --> MBRWRH
C                                 --> MRDSE8
C                     --> SYBYL   --> XCCreate
C                                 --> XCWrite
C                                 --> XCClose
C
C         If volume calculations required, perform them
C
C         --> VOLUME  --> JCHECK
C                     --> CONCAT
C                     --> VOLCAL  --> NEIGHB (not used)
C                                 --> SHSORT
C                     --> WRIMSK
C
C----------------------------------------------------------------------+--- 


      PROGRAM SRFNET

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

CHANGE v.1.4-->
C      CHARACTER*80  STITLE
C      INTEGER       IMAP, NNEW(3)
C      LOGICAL       PASS2
C      REAL          ARRAY(MAXARR)
CHANGE v.1.6-->
C      INTEGER       IFRG, IMAP, IPROBE, IUNIT
      INTEGER       FSTGAP, IFRG, IMAP, IPROBE, IUNIT, MAXSPH, NGAPS,
     -              NTOP
CTEST      INTEGER       NCLUST
CHANGE v.1.6<--
      LOGICAL       NOMESS, NOTZER, PASS2, RAWDAT
CHANGE v.1.6-->
C      REAL          ARRAY(MAXARR), INGTOT, MFACTR
      REAL          ARRAY(MAXARR), INGTOT, MFACTR

CHANGE v.1.6<--
CC-Sybyl-->
CCSYBYL      REAL*8        SHEET(MXSHEE)
CC-Sybyl<--
CHANGE v.1.4<--

CHANGE v.1.4-->
C---- Determine which routines have been linked in during compilation
C     for the different output map formats
      CALL INTMAP(FROLNK,SYBLNK)
      IPROBE = 0
      NOMESS = .FALSE.
CHANGE v.1.4<--

C---- Read in the run parameters
      CALL PARAMS
CHANGE v.1.4-->
C      IF (IFAIL.NE.0) GO TO 999
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--
      GGPASS = .FALSE.

C---- Initialise run variables
      CALL INITS

C---- Read in protein coordinates from supplied file
      CALL READCO
CHANGE v.1.4-->
C      IF (IFAIL.NE.0) GO TO 999
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--

C---- Calculate grid-box boundaries
      CALL GBOUND
CHANGE v.1.4-->
C      IF (IFAIL.NE.0) GO TO 999
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--

CHANGE v.1.6-->
CC---- If calculating volumes, open output files to hold CofG coordinates
C      IF (CALVOL) THEN
CCHANGE v.1.3-->
C          IF (GAPMAP) THEN
CCHANGE v.1.3<--
C              CALL OPNGAP
CCHANGE v.1.4-->
CC              IF (IFAIL.NE.0) GO TO 999
C              IF (IFAIL) GO TO 999
CCHANGE v.1.4<--
CCHANGE v.1.3-->
C          ENDIF
C          CALL OPNVOL
CCHANGE v.1.4-->
CC          IF (IFAIL.NE.0) GO TO 999
C          IF (IFAIL) GO TO 999
CCHANGE v.1.4<--
CCHANGE v.1.3<--
C      ENDIF
CHANGE v.1.6<--

CHANGE v.1.6-->
C---- Open overall volumes output file
      CALL OPNGVL
CHANGE v.1.6<--

C---- Loop for each map to be written out
      DO 100, IMAP = 1, NMAPS

CHANGE v.1.6-->
C----     If calculating volumes, open output files to hold CofG coordinates
          IF (CALVOL) THEN
              CALL OPNVOL(IMAP)
              IF (IFAIL) GO TO 999
          ENDIF
CHANGE v.1.6<--

C----     Reinitialise parameters such as bounds of grid array
          CALL REINIT

C----     If current map is the map of gaps, calculate locations and sizes
C         of the gap-spheres to be placed in the gaps
          IF (GAPMAP .AND. IMAP.EQ.NMAPS) THEN

C----         Firstly, remove any unwanted atoms (ie those outside the grid
C             boundaries) to free up some space for the gap-sphere "atoms"
              CALL DELATM

CHANGE v.1.6-->
C----         Store atom number where first gap-sphere will be held
              FSTGAP = NATOMS + 1
CHANGE v.1.6<--

C----         Generate the gap-spheres
              PASS2 = .FALSE.
              CALL FILGAP(PASS2)

CHANGE v.1.4-->
C              IF (IFAIL.NE.0) GO TO 999
              IF (IFAIL) GO TO 999
CHANGE v.1.4<--
C              IF (GGPASS) THEN
C                  PASS2 = .FALSE.
C                  CALL FILGAP(PASS2)
C                  IF (IFAIL.NE.0) GO TO 999
C              ENDIF
              FILTYP(IMAP) = 'S'

C----         Open file containing atoms adjacent to the gap regions
CHANGE v.1.3-->
C              CALL WRICAV
C              IF (IFAIL.NE.0) GO TO 999
CHANGE v.1.3<--

CHANGE v.1.6-->
C----         If gap-spheres are to be filtered, then perform the filtering
              IF (FILTER) THEN

C----             Form the grid-map of density values for the gap spheres
                  PFACTR = 1.0
                  ENGMAP = .FALSE.
                  CALL MAKEGR(ARRAY,IMAP)

C----             Apply scaling factor to all map-points
                  CALL GRSCAL(ARRAY,NPOINT(1)*NPOINT(2)*NPOINT(3),
     -                FILTYP(IMAP),SUMDEN,PFACTR,INGTOT)

C----             Reset number of gap-spheres to zero
                  NGAPS = 0
                  NATOMS = FSTGAP - 1
                  MAXSPH = MXATOM - NATOMS

C----             Fit the largest spheres possible into the high density
C                 regions of the map
                  CALL MAPSPH(ARRAY,MAXARR,GRDSEP,NPOINT,VALMIN,IPROBE,
     -                IJKREL,INDEXP,DISGRD,MAXPTS,NIJK,MINREJ,MAXREJ,
     -                CLEVEL,IFAIL)

C----             Calculate the volumes of all connected clusters of points in
C                 the current array
                  JUSCAL = .TRUE.
                  CALL VOLUME(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP,
     -                NTOP)

C----             Blank out any volumes that are too small to bother with
                  CALL SPHILT(ARRAY,NPOINT(1)*NPOINT(2)*NPOINT(3),
     -                INDEXA,MAXIND,VOL,MAXVOL,NTOP,NATOMS,VOLCUT,
     -                MAXREJ)

C----             Add back any of the smaller spheres that adjoin any of
C                 the retained volumes
                  CALL ADDBAK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
     -                MINREJ,MAXREJ)

C----             Generate a sphere for every grid-point left
                  CALL REGEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),NGAPS,
     -                RADIUS(FSTGAP),ATNUM(FSTGAP),XYZ(1,FSTGAP),
     -                STOREK(FSTGAP),MAXSPH,CLEVEL,GRDSEP,VALMIN,IFAIL)

C----             Recalculate the new volumes of each new gap region
                  CALL RECVOL(ARRAY,MAXARR,NPOINT(1),NPOINT(2),
     -                NPOINT(3),GRDSEP,VALMIN,VALMAX,MAXSPH,NGAPS,
     -                XYZ(1,FSTGAP),RADIUS(FSTGAP),STOREK(FSTGAP),NTOP,
     -                VOL,MAXVOL,INDEXA)

C----             Reset flag
                  JUSCAL = .FALSE.

C----             Increase number of atoms by the number of new gap
C                 spheres just generated
                  NATOMS = NATOMS + NGAPS

C----             Presort the gap spheres according to which volume they
C                 belong to
                  CALL GAPSRT(MXATOM,STOREK,INDEXA,MAXIND,FSTGAP,NATOMS,
     -                NGAPS)

C----             Write out the gap spheres to the spheres.pdb file
                  CALL WRIGAP(MXATOM,NATOMS,NGAPS,XYZ,STOREK,RADIUS,
     -                INDEXA,MAXIND)

C----             If only the top few gap maps are to be written out,
C                 then loop over these
                  IF (NTOPGP.GT.0 .OR. WNTIDX) THEN

C----                 Loop over the top volumes, generating a density
C                     map for each one and writing each one out
                      JUSCAL = .TRUE.
                      CALL WRITOP(ARRAY,MAXARR,NPOINT(1),NPOINT(2),
     -                    NPOINT(3),GRDSEP,VALMIN,VALMAX,FROMAP,INSMAP,
     -                    QUAMAP,SYBMAP,TITLE,MXATOM,NGAPS,XYZ,RADIUS,
     -                    STOREK,INDEXA,MAXIND,ONEGAP,NTOPGP,WNTIDX,
     -                    NEXTAT)
                  ENDIF

C----             If want an "index" map of the gap regions, then write
C                 that out
                  IF (WNTIDX) THEN

C----                 Write out all the volumes as a .srf map of volume
C                     numbers at the relevant grid-points
                      CALL WRINDX(ARRAY,MAXARR,NPOINT(1),NPOINT(2),
     -                    NPOINT(3),GRDSEP,VALMIN,VALMAX,.FALSE.,
     -                    .FALSE.,.FALSE.,.FALSE.,TITLE,MXATOM,NGAPS,
     -                    XYZ,RADIUS,STOREK,INDEXA,MAXIND)
                  ENDIF

C----             Reset all the sphere STOREK values
                  CALL RESETR(MXATOM,NGAPS,RADIUS,STOREK,INDEXA,MAXIND)

C----             Cluster the oversized gap-spheres into overlapping clusters
CXXX                  CALL CLUSTR(MXATOM,XYZ,RADIUS,INDEXA,FSTGAP,NGAPS,
CXXX     -                NOVER,NCLUST,CLUST)

C----             Filter out any unwanted undersize gap-spheres, and
C                 assign to the existing clusters
CXXX                  CALL GAFILT(MXATOM,XYZ,RADIUS,INDEXA,FSTGAP,NGAPS,
CXXX     -                NOVER,CLUST)

C----             Physically remove the unwanted gap spheres
CXXX                  CALL DELGAP(FSTGAP,NGAPS,NOVER)

C----             Count number of gap spheres in each cluster
CXXX                  CALL COUNTC(FSTGAP,MXATOM,NATOMS,NGAPS,NOVER,CLUST,
CXXX     -                CLSIZE,MXCLUS,NCLUST)

C----             Write out the clusters to the clusters.pdb file
CXXX                  CALL WRICLU(FSTGAP,MXATOM,NATOMS,NGAPS,CLUST,
CXXX     -                CLSIZE,MXCLUS,NCLUST,XYZ,RADIUS)
              ENDIF
CHANGE v.1.6<--
          ENDIF

C----     If current map is a fragment map, write out the fragment atoms
CHANGE v.1.4-->
C          IF (FILTYP(IMAP).EQ.'A' .OR. FILTYP(IMAP).EQ.'B'
          IF (FILTYP(IMAP).EQ.'A' .OR. FILTYP(IMAP).EQ.'a'
     -        .OR. FILTYP(IMAP).EQ.'B'
CHANGE v.1.4<--
     -        .OR. FILTYP(IMAP).EQ.'J' .OR. FILTYP(IMAP).EQ.'P') THEN

C----         Adjust coordinates relative to bounds of grid box
CHANGE v.1.4-->
C              CALL ADJFRG(IMAP,ARRAY)
              CALL ADJFRG(IMAP,ARRAY,IFRG)
CHANGE v.1.4<--

C----         Write out coordinates as a density file
CHANGE v.1.4-->
C              CALL WRISRF(ARRAY,1,1,NFRG,IMAP)
              IF (IFRG.GT.0) THEN
                  IUNIT = 10
                  CALL WRISRF(ARRAY,1,1,NFRG,FILSRF(IMAP),IUNIT,VALMIN,
     -                GRDSEP,FILTYP(IMAP),IFRAG,IATYPE,ICOUNT(IMAP),
     -                FRGFRQ,IFAIL)
              ENDIF
CHANGE v.1.4<--
              GO TO 100
          ENDIF

C----     If current map is a density contour, and default widths for
C         Gaussians being used, then calculate normalization factor
          IF (FILTYP(IMAP).EQ.'C' .AND. .NOT.INRAD(IMAP)) THEN

C----         Calculate normalization factor
CHANGE v.1.4-->
C              CALL GETFAC(ARRAY)
              CALL GETFAC(ARRAY,MAXARR,NPOINT(1),NPOINT(2),NPOINT(3),
     -            VALMIN,VALMAX,GRDSEP,RSCALE,PFACTR)
CHANGE v.1.4<--
COUT              PFACTR = 0.5

C----     Otherwise, set the factor to 1.0
          ELSE
              PFACTR = 1.0
          ENDIF

CHANGE v.1.1.1-->
C----     Set flag for energy map
          IF (FILTYP(IMAP).EQ.'E') THEN
              ENGMAP = .TRUE.
          ELSE
              ENGMAP = .FALSE.
          ENDIF
CHANGE v.1.1.1<--

C----     Form the grid-map of density values
          CALL MAKEGR(ARRAY,IMAP)

CHANGE v.1.4-->
CC----     If not creating FRODO brick files, reduce the size of the
CC         array as much as possible
C          IF (.NOT.FROMAP .AND. (FILTYP(IMAP).EQ.'S' .OR.
CCHANGE v.1.1.1-->
CC     -        FILTYP(IMAP).EQ.'C')) THEN
C     -        FILTYP(IMAP).EQ.'C' .OR. FILTYP(IMAP).EQ.'E')) THEN
CCHANGE v.1.1.1<--
C
CC----         Calculate extent of array so that can reduce its size
CC             to only cover the gap-volume that remain
C              CALL LIMTAR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
C
CC----         Reduce the size of the array
C              CALL ADJARR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -            NNEW(1),NNEW(2),NNEW(3))
C              NPOINT(1) = NNEW(1)
C              NPOINT(2) = NNEW(2)
C              NPOINT(3) = NNEW(3)
C          ENDIF
CHANGE v.1.4<--

C----     Apply scaling factor to all map-points
CHANGE v.1.4-->
C          IF (.NOT.NOPNT) THEN
C              CALL GRHIST(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C          ENDIF
          CALL GRSCAL(ARRAY,NPOINT(1)*NPOINT(2)*NPOINT(3),FILTYP(IMAP),
     -        SUMDEN,PFACTR,INGTOT)
CHANGE v.1.4<--

C----     Check that density file has points to be plotted
CHANGE v.1.4-->
C          IF (NOPNT) THEN
          IF (NUSED.EQ.0) THEN
CHANGE v.1.4<--
              PRINT*, '+*** Density file empty! Not written out'

C----     Write out density and brick files
          ELSE

CHANGE v.1.1.1-->
C----         For energy surface, set file type to surface
              IF (FILTYP(IMAP).EQ.'E') FILTYP(IMAP) = 'S'
CHANGE v.1.1.1<--

CHANGE v.1.4-->
CC----         Write the array to disk as a surface density file
C              PRINT*, 'Writing surface density file ...   ', IMAP
C              CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C
CC----         If file is a contour file, then call the CCP4 routines
CC             to write out a density file and then a brick file
C              IF (FILTYP(IMAP).EQ.'C' .OR. FILTYP(IMAP).EQ.'S' .OR.
C     -            FILTYP(IMAP).EQ.'N') THEN
C
CC----             If a number-count file, then write out a compressed
CC                 version of the data
C                  IF (FILTYP(IMAP).EQ.'N') THEN
CCXXX                      CALL COMPRS(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCXXX     -                    IMAP)
C                  ENDIF
C
CC----             If the CCP4 density and brick files are actually required,
CC                 then call the appropriate CCP4 routines and write them out
C                  IF (FROMAP) THEN
C
CC----                 Write the array to disk as a CCP4 density file
CC---- CCP4-->
CCCP4                      PRINT*, 'Writing CCP4 density file ...   ', IMAP
CCCP4                      CALL ASCDEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCCP4     -                    FILDEN(IMAP),TITLE,LIM,IUVW,VALMAX,
CCCP4     -                    VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)
CC---- CCP4<--
C
CC----                 Write the array to disk as a brick file for FRODO
CC                     [Note, this is no longer used. Use the conversion
CC                     progs supplied with CCP4 to convert from CCP4 density
CC                     map format to FRODO brick map format]
CCFRODO                      PRINT*, 'Writing brick file ...     ', IMAP
CCFRODO                      CALL MBRICK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCFRODO     -                    IMAP)
C
CCHANGE v.1.2-->
CC----             If InsightII grid files are required, then write these out
C                  ELSE IF (INSMAP) THEN
C
CC----                 Write the array to disk as a standard formatted
CC                     InsightII grid file
C                      PRINT*, 'Writing InsightII grid file ...   ', IMAP
C                      CALL INSIGH(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -                    IMAP,FILGRD(IMAP),GRDSEP,VALMIN,VALMAX)
CCHANGE v.1.2<--
C
CC----             If Quanta brick files are required, then write these out
C                  ELSE IF (QUAMAP) THEN
C
CC----                 Write the array to disk as a Quanta density file
C                      PRINT*, 'Writing Quanta brick file ...   ', IMAP
C                      CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -                    IMAP,FILMBK(IMAP),GRDSEP,MAPAV,MAPMIN,
C     -                    MAPMAX,VALMIN,VALMAX)
C
CC----             If Sybyl contour files are required, then write these out
C                  ELSE IF (SYBMAP) THEN
C
CC----                 Check that the sheet-size not larger than
CC                     allowed in the parameters
C                      IF (MXSHEE.GE.NPOINT(1) * NPOINT(2)) THEN
C
CC----                     Write the array to disk as a Sybyl contour
CC                         file
C                          PRINT*, 'Writing Sybyl contour file ...     ',
C     -                        IMAP
C                          STITLE = TITLE
CC-Sybyl-->
CCSYBYL                          CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
CCSYBYL     -                        NPOINT(3),IMAP,FILCNT(IMAP),GRDSEP,MAPAV,
CCSYBYL     -                        MAPMIN,MAPMAX,VALMIN,VALMAX,SHEET,STITLE,
CCSYBYL     -                        IFAIL)
CC-Sybyl<--
C
CC----                 If array not large enough, display error message
C                      ELSE
C                          PRINT*, '*** ERROR. Array variable MXSHEE ',
C     -                        'not large enough for sheets to be'
C                          PRINT*, '*          written out to Sybyl ',
C     -                        'contour file', MXSHEE,
C     -                        NPOINT(1) * NPOINT(2)
C                      ENDIF
C                  ENDIF
C              ENDIF

C----         Write out the array in whichever output format is required
              IUNIT = 10
              MFACTR = 1.0
              IF (PERADJ(IMAP)) THEN
                  RAWDAT = .FALSE.
              ELSE
                  RAWDAT = .TRUE.
              ENDIF

C----         For a contour file, write out in whichever format(s) are
C             required
              IF (FILTYP(IMAP).EQ.'C' .OR. FILTYP(IMAP).EQ.'S' .OR.
     -            FILTYP(IMAP).EQ.'N') THEN
                  NOTZER = .FALSE.
                  IF (FILTYP(IMAP).EQ.'C' .OR. FILTYP(IMAP).EQ.'N') THEN
                      NOTZER = .TRUE.
                  ENDIF
                  CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,
     -                FILTYP(IMAP),IMAP,IFRAG,IATYPE,ICOUNT(IMAP),
     -                FRGFRQ,FILCNT(IMAP),FILDEN(IMAP),FILGRD(IMAP),
     -                FILMBK(IMAP),FILSRF(IMAP),IUNIT,FROMAP,INSMAP,
     -                QUAMAP,SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,RAWDAT,
     -                MFACTR,NOTZER,NOMESS,NOPNT,IFAIL)

C----         Otherwise, only want to write out in .srf format
              ELSE
                  CALL WRISRF(ARRAY,1,1,NFRG,FILSRF(IMAP),IUNIT,VALMIN,
     -                GRDSEP,FILTYP(IMAP),IFRAG,IATYPE,ICOUNT(IMAP),
     -                FRGFRQ,IFAIL)
              ENDIF
CHANGE v.1.4<--
          ENDIF

C----     If volume required, then calculate it
CHANGE v.1.4-->
C          IF (CALVOL .AND. .NOT.NOPNT) THEN
          IF (CALVOL .AND. NUSED.GT.0) THEN
CHANGE v.1.4<--
CHANGE v.1.6-->
C              CALL VOLUME(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
CHANGE v.1.6.3-->
              JUSCAL = .FALSE.
CHANGE v.1.6.3<--
              CALL VOLUME(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP,NTOP)
CHANGE v.1.6<--
          ENDIF
100   CONTINUE

999   CONTINUE
CHANGE v.1.4-->
C      IF (IFAIL.EQ.0) THEN
      IF (.NOT.IFAIL) THEN
CHANGE v.1.4<--
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
CHANGE v.1.6-->
C**************************************************************************
C
C  SUBROUTINE PARAMS  -  Read in the run parameters for the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PARAMS

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      INTEGER        MINPAR
      PARAMETER     (MINPAR = 6)

      CHARACTER*1    YESNO
      CHARACTER*120  FNAME, IREC
      INTEGER        BINPOS, IDITTO, IMAP, IPARAM, IPROBE, LENSTR, LINE
      REAL           FPARAM(NPARM,MXDITO,MXMAPS)

C---- Initialise values
      DO 50, IMAP = 1, NMAPS
          INRAD(IMAP) = .FALSE.
 50   CONTINUE
      LINE = 0
      ALLPNT = .FALSE.
      CALVOL = .FALSE.
      FILTER = .FALSE.
      FROMAP = .FALSE.
      INSMAP = .FALSE.
      MAXREJ = 1.8
      MINREJ = 1.4
      MULTIG = .FALSE.
      NEWPAR = .FALSE.
      NOHYDR = .TRUE.
      NOSURF = .FALSE.
      NTOPGP = 0
      ONEGAP = .FALSE.
      QUAMAP = .FALSE.
      RSCALE = 1.0
      SYBMAP = .FALSE.

C---- Open the new-format parameter file, surfnet.par
      OPEN(UNIT=1, FILE='surfnet.par', STATUS='OLD', FORM='FORMATTED',
     -     ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST', READONLY,
     -     ERR=100)
      NEWPAR = .TRUE.

C---- Open the parameter file, sadge.par
 100  CONTINUE
      IF (.NOT.NEWPAR) THEN
          OPEN(UNIT=1, FILE='sadge.par', STATUS='OLD',
     -        FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -         CARRIAGECONTROL = 'LIST', READONLY,
     -         ERR=900)
      ENDIF

C---- Read in the title
      CALL FINKEY('TITLE',5,LINE)
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) TITLE
 110  FORMAT(A)
      PRINT*
      PRINT*, 'Title: ', TITLE
      PRINT*

C---- Read in filename of coordinates file
      CALL FINKEY('INPUT FILE',10,LINE)
      LINE = LINE + 1
      READ(1,110,END=902,ERR=904) FNAME
      FILPDB = FNAME

C---- Check whether this is a binary file holding an XSITE distribution
      BINPOS = INDEX(FNAME,'.bin')
      IF (BINPOS.GT.0) THEN
          XSITE = .TRUE.
      ELSE
          XSITE = .FALSE.
      ENDIF

C---- Open the coordinates file
      IF (.NOT.XSITE) THEN
          OPEN(UNIT=2,FILE=FNAME,STATUS='OLD',ACCESS='SEQUENTIAL',
CVAX     -         READONLY,
     -         FORM='FORMATTED',ERR=908)
      ELSE
          OPEN(UNIT=2,FILE=FNAME,STATUS='OLD',ACCESS='SEQUENTIAL',
CVAX     -         READONLY,
     -         FORM='UNFORMATTED',ERR=906)
          READ(2,ERR=908,END=910) IPROBE
          PRINT*, 'XSITE binary file for probe', IPROBE
          PRINT*
      ENDIF

C---- Read in the names of the output files
      CALL GETOUT(FPARAM)

C---- Extract the relevant parameters for the files
      DO 200, IMAP = 1, NMAPS
          DO 150, IDITTO = 1, MXDITO
              ASTART(IDITTO,IMAP) = FPARAM(1,IDITTO,IMAP)
              AEND(IDITTO,IMAP) = FPARAM(2,IDITTO,IMAP)
 150      CONTINUE
 200  CONTINUE

C---- Search through the file until find the keyword: SURFNET
      CALL FINKEY('SURFNET',7,LINE)

C---- Read in the remaining parameters
      IPARAM = 0

C---- Loop while reading in records from the file
 300  CONTINUE

C----     Read in the next record
          LINE = LINE + 1
          IPARAM = IPARAM + 1
          READ(1,320,END=902,ERR=904) IREC
 320      FORMAT(A)

C----     Check that haven't reached the end of the SURFNET parameters
          IF (IREC.EQ.' ' .OR. IREC(1:7).EQ.'SURFACE') THEN
              GO TO 800

C----     Otherwise, check if this gives the coords for the origin of
C         the grid-box
          ELSE IF (IPARAM.EQ.1) THEN

C----         Read in the coordinates of the origin of the grid-box
              READ(IREC,*,END=902,ERR=906) BXORIG(1), BXORIG(2),
     -            BXORIG(3)

C----     Read in atom range defining the bounds of the grid-box
          ELSE IF (IPARAM.EQ.2) THEN

              READ(IREC,*,END=902,ERR=906) BOUNAT(1), BOUNAT(2)

C----     Read in the boundary required round the atom-bounds or round
C         the origin
          ELSE IF (IPARAM.EQ.3) THEN

              READ(IREC,110,END=902,ERR=906) IREC
              BOUND(1) = 0.0
              CALL READNO(IREC,BOUND,1,IFAIL)
              IF (IFAIL) GO TO 904
              BOUND(2) = BOUND(1)
              BOUND(3) = BOUND(1)
              CALL READNO(IREC,BOUND,3,IFAIL)
              IF (IFAIL) GO TO 904

C----     Read in the grid separation
          ELSE IF (IPARAM.EQ.4) THEN

              READ(IREC,*,END=902,ERR=906) GRDSEP

C----     Read in minimum gap sphere size
          ELSE IF (IPARAM.EQ.5) THEN

              READ(IREC,*,END=902,ERR=906) MINRAD
              MINRD2 = MINRAD * MINRAD
              MINDIA = 2.0 * MINRAD

C----     Read in maximum gap sphere size
          ELSE IF (IPARAM.EQ.6) THEN

              READ(IREC,*,END=902,ERR=906) MAXRAD
              MAXRD2 = MAXRAD * MAXRAD
              MAXDIA = 2.0 * MAXRAD
              GAPSPN = MAXDIA

C----     Read in whether brick files are actually to be produced
          ELSE IF (IPARAM.EQ.7) THEN

              READ(IREC,110,END=902,ERR=906) YESNO
              IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c' .OR.
     -            YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
                  FROMAP = .TRUE.
              ELSE IF (YESNO.EQ.'I' .OR. YESNO.EQ.'i') THEN
                  INSMAP = .TRUE.
              ELSE IF (YESNO.EQ.'Q' .OR. YESNO.EQ.'q') THEN
                  QUAMAP = .TRUE.
              ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
                  SYBMAP = .TRUE.
              ELSE IF (YESNO.EQ.'X' .OR. YESNO.EQ.'x') THEN
                  NOSURF = .TRUE.
              ENDIF
              IF (FROMAP .AND. .NOT.FROLNK) THEN
                  PRINT*, '*** WARNING. (C)CP4 output selected, but pr',
     -                'ogram not linked to CCP4 routines.'
                  PRINT*, '***          No density files will be creat',
     -                'ed.'
                  FROMAP = .FALSE.
              ENDIF
              IF (SYBMAP .AND. .NOT.SYBLNK) THEN
                  PRINT*, '*** WARNING. (S)ybyl output selected, but p',
     -                'rogram not linked to SYBYL libraries.'
                  PRINT*, '***          No SYBYL contour files will be',
     -                ' created.'
                  SYBMAP = .FALSE.
              ENDIF

C----     Read in whether volumes are to be calculated
          ELSE IF (IPARAM.EQ.8) THEN

              READ(IREC,110,END=902,ERR=906) YESNO
              IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
                  CALVOL = .TRUE.
              ELSE
                  CALVOL = .FALSE.
              ENDIF

C----     Read in scale-factor for calculation of unit volumes for density
C         contours
          ELSE IF (IPARAM.EQ.9) THEN

              READ(IREC,*,END=999,ERR=906) RSCALE
              IF (RSCALE.EQ.0.0) RSCALE = 1.0

C----     Read in whether pointer files are to be output for every map
          ELSE IF (IPARAM.EQ.10) THEN

              READ(IREC,110,END=999,ERR=906) YESNO
              IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
                  ALLPNT = .TRUE.
              ELSE
                  ALLPNT = .FALSE.
              ENDIF

C----     Read in whether new multi-gap algorithm to be applied
          ELSE IF (IPARAM.EQ.11) THEN

              READ(IREC,110,END=902,ERR=906) YESNO
              IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
                  MULTIG = .TRUE.
              ELSE
                  MULTIG = .FALSE.
              ENDIF

C----     Read in the gap span
          ELSE IF (IPARAM.EQ.12) THEN

              READ(IREC,*,END=999,ERR=906) GAPSPN

C----     Read in whether gap regions are to be filtered using "core"
C         gap spheres and their immediate neighbours
          ELSE IF (IPARAM.EQ.13) THEN

              READ(IREC,110,END=902,ERR=906) YESNO
              IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
                  FILTER = .TRUE.
              ELSE
                  FILTER = .FALSE.
              ENDIF

C----     Read in the minimum radius of retained spheres and their
C         neighbours
          ELSE IF (IPARAM.EQ.14) THEN

              READ(IREC,*,END=999,ERR=906) MINREJ

C----     Read in the maximum radius of retained spheres and their
C         neighbours
          ELSE IF (IPARAM.EQ.15) THEN

              READ(IREC,*,END=999,ERR=906) MAXREJ

C----     Read in the number of top gap regions to be written out to
C         individual gaps01.srf, etc files
          ELSE IF (IPARAM.EQ.16) THEN

C----         Check for a plus-sign in the first character position
C             indicating that only a single gap region to be written out
              IF (IREC(1:1).EQ.'+') THEN
                  ONEGAP = .TRUE.
              ENDIF

              READ(IREC,*,END=999,ERR=906) NTOPGP
              IF (NTOPGP.GT.99) NTOPGP = 99

CHANGE v.1.6.1-->
C----     Check whether hydrogen atoms are to be included
          ELSE IF (IPARAM.EQ.17) THEN

              READ(IREC,110,END=902,ERR=906) YESNO
              IF (YESNO.EQ.'Y' .OR. YESNO.EQ.'y') THEN
                  NOHYDR = .FALSE.
              ELSE
                  NOHYDR = .TRUE.
              ENDIF
CHANGE v.1.6.1<--
          ENDIF

C---- Loop back for the next record
      GO TO 300

C---- End of SURFNET parameters
 800  CONTINUE

C---- Close input parameter file
      CLOSE(1)
CDEBUG
      PRINT*, 'NOHYDR [', NOHYDR, ']'
CDEBUG

C---- Check that the minimum number of parameters have been entered
      IF (IPARAM.LT.MINPAR) GO TO 912

      GO TO 999
                                                   

C     E R R O R   C O N D I T I O N S

C---- Unable to open input parameters file
 900  CONTINUE
      PRINT*, '*** Error opening parameter file, sadge.par.'
      GO TO 990

C---- Parameter file incomplete 
 902  CONTINUE
      PRINT 903, LINE
 903  FORMAT(1X,'*** Premature end of file reached in parameter ',
     -       'file at line ', I2)
      GO TO 990

C---- Data format error in parameter file
 904  CONTINUE
      PRINT 905, LINE
 905  FORMAT(1X,'*** Data format error in parameter file at line ',
     -       I2)
      GO TO 990

C---- Data format error in parameter file
 906  CONTINUE
      PRINT 907, LINE
 907  FORMAT(1X,'*** Data format error in parameter file at line ',
     -       I2)
      GO TO 990

C---- Unable to open input coordinates file
 908  CONTINUE
      PRINT*, '*** Error opening coordinates file: [',
     -    FNAME(1:LENSTR(FNAME)), ']'
      GO TO 990

C---- Unable to open X-SITE file
 910  CONTINUE
      PRINT 911
 911  FORMAT(1X,'*** ERROR reading XSITE probe-number from .bin file')
      GO TO 990

C---- Some crucial parameters missing
 912  CONTINUE
      PRINT*, '*** ERROR. Some SURFNET parameters missing from the sur',
     -    'fnet.par file'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C  SUBROUTINE FINKEY  -  Find the required keyword in the parameter file
C
C----------------------------------------------------------------------+---

      SUBROUTINE FINKEY(KEY,LEN,LINE)

      CHARACTER*(*) KEY
      CHARACTER*80  IREC
      INTEGER       LEN, LINE

C---- Search through the file until find the keyword
      REWIND(1)
      LINE = 0
 100  CONTINUE
          LINE = LINE + 1
          READ(1,110,END=900) IREC
 110      FORMAT(A)
      IF (IREC(1:LEN).NE.KEY) GO TO 100

      GO TO 999

C---- Unable to find keyword
 900  CONTINUE
      PRINT*, ' *** ERROR. Unable to find keyword in surfnet.par/',
     -    'sadge.par: ', KEY
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) ' *** ERROR. Unable to find keyword in ',
C     -    'surfnet.par/sadge.par: ', KEY
CHANGE v.1.3<--

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE READNO  -  Find the required keyword in the parameter file
C
C----------------------------------------------------------------------+---

      SUBROUTINE READNO(IREC,ARRAY,NCOLS,IFAIL)

      INTEGER       TLENUM, TSTATE
      PARAMETER    (TLENUM=20, TSTATE=3)

      CHARACTER*1   INCHAR
      CHARACTER*(TLENUM) NUMB
CHANGE v.1.4-->
C      CHARACTER*60  IREC
C      INTEGER       ICOL, IFAIL, INUMB, IPSTN, ISTATE, NCOLS, NDECPT,
C     -              NDIGIT
      CHARACTER*(*) IREC
      INTEGER       ICOL, INUMB, IPSTN, ISTATE, NCOLS, NDECPT, NDIGIT
      LOGICAL       IFAIL
CHANGE v.1.4<--
      REAL          A, ARRAY(NCOLS)

C---- Initialise values
      ISTATE = 1
      ICOL = 0
      IFAIL = .FALSE.
      IPSTN = 0
      NUMB = '0.0'
      NDECPT = 0
      NDIGIT = 0

C---- Loop until all columns have been processed
100   CONTINUE

C----     Increment position
          IF (ISTATE.EQ.TSTATE) GO TO 999
          IPSTN = IPSTN + 1
          INCHAR = IREC(IPSTN:IPSTN)

C----     If upper limit on record length reached, and still reading in
C         numbers, convert last-read character-string to number
          IF (IPSTN.GT.60) THEN
              IF (ISTATE.LT.3) THEN
                  IF (ICOL.GT.0 .AND. ICOL.LE.NCOLS .AND.
     -                NDIGIT.NE.0) THEN
                      CALL READCH(NUMB,A,IFAIL)
CHANGE v.1.4-->
C                      IF (IFAIL.NE.0) GO TO 999
                      IF (IFAIL) GO TO 999
CHANGE v.1.4<--
                      ARRAY(ICOL) = A
                  ENDIF
              ENDIF
              GO TO 999
          ENDIF

C----     State 1: Searching for next number
          IF (ISTATE.EQ.1) THEN

C----         If current character is a number, then assume it is the
C             start of the next column
              IF ((INCHAR.GE.'0' .AND. INCHAR.LE.'9')
     -            .OR. INCHAR.EQ.'-' .OR. INCHAR.EQ.'+'
     -            .OR. INCHAR.EQ.'.') THEN
                  ISTATE = 2
                  ICOL = ICOL + 1
                  INUMB = 1
                  NUMB = INCHAR
                  IF (INCHAR.EQ.'.') NDECPT = 1
                  IF (INCHAR.GE.'0' .AND. INCHAR.LE.'9') NDIGIT = 1
              ENDIF

C----     State 2: Have found a number. Waiting for the end
          ELSE IF (ISTATE.EQ.2) THEN

C----         If blank space reached, then have completed this column
              IF (INCHAR.EQ.' ') THEN
                  IF (NDECPT.EQ.0 .AND. INUMB.LT.TLENUM) THEN
                      NUMB(INUMB+1:INUMB+1) = '.'
                  ENDIF

C----             Convert character string into a real number and store
                  IF (NDIGIT.NE.0) THEN
                      CALL READCH(NUMB,A,IFAIL)
CHANGE v.1.4-->
C                      IF (IFAIL.NE.0) GO TO 999
                      IF (IFAIL) GO TO 999
CHANGE v.1.4<--
                      ARRAY(ICOL) = A
                  ELSE
                      ICOL = ICOL - 1
                  ENDIF
                  ISTATE = 1
                  IF (ICOL.EQ.NCOLS) THEN
                      ISTATE = TSTATE
                      ICOL = 0
                  ENDIF
                  NDECPT = 0
                  NDIGIT = 0

C----         Otherwise, add character to the string making up the
C             number in the current column
              ELSE IF ((INCHAR.GE.'0' .AND. INCHAR.LE.'9')
     -            .OR. INCHAR.EQ.'-' .OR. INCHAR.EQ.'+'
     -            .OR. INCHAR.EQ.'.') THEN
                  INUMB = INUMB + 1
                  IF (INUMB.LE.TLENUM) THEN
                      NUMB(INUMB:INUMB) = INCHAR
                      IF (INCHAR.EQ.'.') NDECPT = 1
                      IF (INCHAR.GE.'0' .AND. INCHAR.LE.'9')
     -                    NDIGIT = 1
                  ENDIF
              ENDIF
          ENDIF

C---- Loop back
      GO TO 100

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETOUT  -  Get the names of the output files and their
C                        associated parameters
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETOUT(FPARAM)

      INCLUDE 'surfnet.inc'

      CHARACTER*1   INCHAR
      CHARACTER*20  CHNUMB
CHANGE v.1.4-->
CCHANGE v.1.2-->
CC      CHARACTER*40  GAPBRD, GAPCNT, GAPDEN, GAPMBK, GAPSRF
C      CHARACTER*26  LOWER, UPPER
C      CHARACTER*40  GAPBRD, GAPCNT, GAPDEN, GAPGRD, GAPMBK, GAPSRF
CCHANGE v.1.2<--
C      CHARACTER*80  FNAME
C      CHARACTER*120 IREC
      CHARACTER*120 FNAME, IREC, GAPCNT, GAPDEN, GAPGRD, GAPMBK, GAPSRF
CHANGE v.1.4<--
      INTEGER       GAPFIL, IFIL, ILEN, IMAP, INUM, IPARM, IPOS, ISTATE,
CHANGE v.1.4-->
C     -              LINE, LPOS, NDECPT, RERROR
CHANGE v.1.5-->
C     -              LINE, NDECPT, RERROR
     -              IDITTO, LINE, NDECPT
      LOGICAL       RERROR
CHANGE v.1.5<--
CHANGE v.1.4<--
CHANGE v.1.5-->
C      REAL          FPARAM(NPARM,MXMAPS), VALUE
      REAL          FPARAM(NPARM,MXDITO,MXMAPS), VALUE
CHANGE v.1.5<--

CHANGE v.1.4-->
C      DATA LOWER  / 'abcdefghijklmnopqrstuvwxyz' /
C      DATA UPPER  / 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' /
CHANGE v.1.4<--

C---- Initialise variables
      DO 80, IMAP = 1, MXMAPS
          FILTYP(IMAP) = ' '
          PERADJ(IMAP) = .FALSE.
CHANGE v.1.5-->
C          DO 60, IPARM = 1, NPARM
C              FPARAM(IPARM,IMAP) = 0.0
C 60       CONTINUE
          NDITTO(IMAP) = 0
          DO 40, IDITTO = 1, MXDITO
              DO 60, IPARM = 1, NPARM
                  FPARAM(IPARM,IDITTO,IMAP) = 0.0
 60           CONTINUE
 40       CONTINUE
CHANGE v.1.5<--
 80   CONTINUE
      GAPALL = .FALSE.
      GAPMAP = .FALSE.
      IMAP = 0
      INHFIL(1) = 0
      INHFIL(2) = 0

C---- Search for the start of the output file names
      CALL FINKEY('OUTPUT FILES',12,LINE)

C---- Read through the names and store the details
 100  CONTINUE
          LINE = LINE + 1
          READ(1,110,END=500) IREC
 110      FORMAT(A)
          IF (IREC.EQ.' ') GO TO 500
          IPARM = 0
          ISTATE = 0

CHANGE v.1.5-->
C----     Check whether this is a ditto entry
          IPOS = INDEX(IREC,'"')
          IF (IPOS.GT.0) THEN

C----         Ditto entry, so check that it isn't the first one
              IF (IMAP.EQ.0) GO TO 914

C----         Check that ditto entry is not on a gap map
              IF (FILTYP(IMAP).EQ.'G') GO TO 918

C----         Initialise state
              ISTATE = 1
          ELSE
CHANGE v.1.5<--

C----         Retrieve the filename and generate the appropriate extensions
CHANGE v.1.4-->
C          FNAME = IREC(1:60)
              FNAME = IREC
CHANGE v.1.4<--
              ILEN = INDEX(FNAME,' ') - 1
CHANGE v.1.4-->
C          IF (ILEN.GT.0 .AND. ILEN.LT.37) THEN
              IF (ILEN.GT.0 .AND. ILEN.LT.80) THEN
CHANGE v.1.4<--
                  IMAP = IMAP + 1
                  IF (IMAP.GT.MXMAPS) GO TO 900
CHANGE v.1.4-->
C              FNAME(ILEN:40) = '.brd'
C              FILBRD(IMAP) = FNAME
C              FNAME(ILEN:40) = '.cmp'
C              FILCMP(IMAP) = FNAME
C              FNAME(ILEN:80) = '.cnt'
C              FILCNT(IMAP) = FNAME
C              FNAME(ILEN:40) = '.den'
C              FILDEN(IMAP) = FNAME
CCHANGE v.1.2-->
C              FNAME(ILEN:40) = '.grd'
C              FILGRD(IMAP) = FNAME
CCHANGE v.1.2<--
C              FNAME(ILEN:40) = '.srf'
C              FILSRF(IMAP) = FNAME
C              FNAME(ILEN:40) = '.mbk'
C              FILMBK(IMAP) = FNAME
                  FILCNT(IMAP) = FNAME(1:ILEN) // '.cnt'
                  FILDEN(IMAP) = FNAME(1:ILEN) // '.den'
                  FILGRD(IMAP) = FNAME(1:ILEN) // '.grd'
                  FILSRF(IMAP) = FNAME(1:ILEN) // '.srf'
                  FILMBK(IMAP) = FNAME(1:ILEN) // '.mbk'
CHANGE v.1.6-->
                  FILPNT(IMAP) = FNAME(1:ILEN) // '.pnt'
                  IF (FNAME(1:ILEN).EQ.'gaps') THEN
                      FILOUT(IMAP) = FNAME(1:ILEN) // '.pdb'
                  ELSE
                      FILOUT(IMAP) = FNAME(1:ILEN) // '.vol'
                  ENDIF
CHANGE v.1.6<--
CHANGE v.1.4<--
                  ISTATE = 1
              ELSE
                  GO TO 908
              ENDIF

C----         Search for file type and other data
              IPOS = ILEN
CHANGE v.1.5-->
          ENDIF

C----     Increment ditto count
          NDITTO(IMAP) = NDITTO(IMAP) + 1

C----     Check that maximum number of ditto entries per map not exceeded
          IDITTO = NDITTO(IMAP)
          IF (IDITTO.GT.MXDITO) GO TO 916
CHANGE v.1.5<--

C----     Loop through the characters in the line until end reached
 200      CONTINUE
              IPOS = IPOS + 1
              INCHAR = IREC(IPOS:IPOS)

C----         State 1 - Search for first non-blank character
              IF (ISTATE.EQ.1) THEN

C----             If this is not a space, check for letters
                  IF (INCHAR.NE.' ') THEN

C----                 If this is an asterisk, then reading in radii from
C                     this file
                      IF (INCHAR.EQ.'*') THEN
                          INRAD(IMAP) = .TRUE.
                      ENDIF

C----                 If this is a percentage sign, then make appropriate
C                     adjustment to record that a counts file is required
C                     with the counts converted to percentages on output
                      IF (INCHAR.EQ.'%') THEN
                          INCHAR = 'C'
                          PERADJ(IMAP) = .TRUE.
                      ENDIF

C----                 If a lower case letter, then convert to upper case
CHANGE v.1.4-->
C                      IF (INCHAR.GE.'a' .AND. INCHAR.LE.'z') THEN
C                          LPOS = INDEX(LOWER,INCHAR)
C                          IF (LPOS.GT.0) INCHAR = UPPER(LPOS:LPOS)
C                      ENDIF
CHANGE v.1.4<--

C----                 If an upper case letter, then interpret
CHANGE v.1.4-->
C                      IF (INCHAR.GE.'A' .AND. INCHAR.LE.'Z') THEN
C                          IF (INCHAR.NE.'A' .AND. INCHAR.NE.'B' .AND.
                      IF ((LGE(INCHAR,'A') .AND. LLE(INCHAR,'Z')) .OR.
     -                    INCHAR.EQ.'a') THEN
                          IF (INCHAR.NE.'A' .AND. INCHAR.NE.'B' .AND.
     -                        INCHAR.NE.'a' .AND.
CHANGE v.1.4<--
     -                        INCHAR.NE.'C' .AND. INCHAR.NE.'J' .AND.
     -                        INCHAR.NE.'P' .AND. INCHAR.NE.'S' .AND.
CHANGE v.1.1.1-->
C     -                        INCHAR.NE.'G' .AND. INCHAR.NE.'N')
     -                        INCHAR.NE.'G' .AND. INCHAR.NE.'N' .AND.
     -                        INCHAR.NE.'E')
CHANGE v.1.1.1<--
     -                        GO TO 904
                          FILTYP(IMAP) = INCHAR
                          ISTATE = 2
                      ENDIF
                  ENDIF

C----         State 2 - Search for first digit of a number
              ELSE IF (ISTATE.EQ.2) THEN

C----             Check for a digit
                  IF (INCHAR.GE.'0' .AND. INCHAR.LE.'9') THEN
                      INUM = 1
                      CHNUMB = INCHAR
                      NDECPT = 0
                      ISTATE = 3

C----             Check for a minus or a plus sign
                  ELSE IF (INCHAR.EQ.'+' .OR. INCHAR.EQ.'-') THEN
                      INUM = 1
                      CHNUMB = INCHAR
                      NDECPT = 0
                      ISTATE = 3

C----             Check for a decimal point
                  ELSE IF (INCHAR.EQ.'.') THEN
                      INUM = 1
                      CHNUMB = INCHAR
                      NDECPT = 1
                      ISTATE = 3
                  ENDIF

C----         State 3 - Storing characters making up a number
              ELSE IF (ISTATE.EQ.3) THEN

C----             If character is a number, add it to the number being built up
                  IF (INCHAR.LE.'9' .AND. INCHAR.GE.'0') THEN
                      INUM = INUM + 1
                      IF (INUM.LE.20) CHNUMB(INUM:INUM) = INCHAR

C----             If character is a decimal point, add on
                  ELSE IF (INCHAR.EQ.'.') THEN
                      IF (NDECPT.EQ.0 .AND. INUM.LE.20) THEN
                          INUM = INUM + 1
                          CHNUMB(INUM:INUM) = INCHAR
                          NDECPT = 1
                      ENDIF

C----             Otherwise, assume end of number reached, so convert
                  ELSE
                      IF (INUM.LT.20 .AND. NDECPT.EQ.0) THEN
                          CHNUMB(INUM+1:INUM+1) = '.'
                      ENDIF
                      CALL READCH(CHNUMB,VALUE,RERROR)
CHANGE v.1.5-->
C                      IF (RERROR.NE.0) GO TO 906
                      IF (RERROR) GO TO 906
CHANGE v.1.5<--
                      IPARM = IPARM + 1
                      IF (IPARM.LE.NPARM) THEN
CHANGE v.1.5-->
C                          FPARAM(IPARM,IMAP) = VALUE
                          FPARAM(IPARM,IDITTO,IMAP) = VALUE
CHANGE v.1.5<--
                      ENDIF
                      ISTATE = 2
                  ENDIF
              ENDIF

C----     Loop back for the next character in this line
          IF (IPOS.LT.120) GO TO 200

C----     If current file is a gaps file, then store filenames, providing
C         haven't already got a gapmap
          IF (FILTYP(IMAP).EQ.'G') THEN
              IF (GAPMAP) GO TO 910
              GAPMAP = .TRUE.
CHANGE v.1.4-->
C              GAPBRD = FILBRD(IMAP)
CHANGE v.1.4<--
              GAPCNT = FILCNT(IMAP)
              GAPDEN = FILDEN(IMAP)
CHANGE v.1.2-->
              GAPGRD = FILGRD(IMAP)
CHANGE v.1.2<--
              GAPSRF = FILSRF(IMAP)
              GAPMBK = FILMBK(IMAP)
              GAPFIL = IMAP

C----         Retrieve atom-set from which gaps are to be calculated. If
C             this is zero, then gaps between ALL atoms are required
CHANGE v.1.5-->
C              INHFIL(1) = FPARAM(1,IMAP)
C              INHFIL(2) = FPARAM(2,IMAP)
              INHFIL(1) = FPARAM(1,1,IMAP)
              INHFIL(2) = FPARAM(2,1,IMAP)
CHANGE v.1.5<--
              IF (INHFIL(1).EQ.0 .AND. INHFIL(2).NE.0) THEN
                  INHFIL(1) = INHFIL(2)
                  INHFIL(2) = 0
              ENDIF
              IF (INHFIL(1).EQ.0 .AND. INHFIL(2).EQ.0) THEN
                  GAPALL = .TRUE.
              ENDIF
CHANGE v.1.5-->
C              FPARAM(1,IMAP) = -999999
C              FPARAM(2,IMAP) = -999999
              FPARAM(1,1,IMAP) = -999999
              FPARAM(2,1,IMAP) = -999999
              NDITTO(IMAP) = 1
CHANGE v.1.5<--
          ENDIF

C---- Loop back for the next line
      GO TO 100

C---- End of output files reached
 500  CONTINUE

C---- Check whether any output files supplied
      NMAPS = IMAP
      IF (NMAPS.EQ.0) GO TO 902

C---- If there is a gap file, make sure it is the last one
      IF (GAPMAP) THEN

C----     Make sure that the two gap-defining files have been correctly
C         specified
          IF (.NOT.GAPALL) THEN
              DO 600, IFIL = 1, 2
                  IF (INHFIL(IFIL).EQ.GAPFIL .OR.
     -                INHFIL(IFIL).LT.0 .OR. INHFIL(IFIL).GT.NMAPS)
     -                GO TO 912
 600          CONTINUE
          ENDIF

C----     If the gap file is not the last one, then swap it with that one
          IF (GAPFIL.NE.NMAPS) THEN
CHANGE v.1.4-->
C              FILBRD(GAPFIL) = FILBRD(NMAPS)
CHANGE v.1.4<--
              FILCNT(GAPFIL) = FILCNT(NMAPS)
              FILDEN(GAPFIL) = FILDEN(NMAPS)
CHANGE v.1.2-->
              FILGRD(GAPFIL) = FILGRD(NMAPS)
CHANGE v.1.2<--
              FILSRF(GAPFIL) = FILSRF(NMAPS)
              FILMBK(GAPFIL) = FILMBK(NMAPS)
CHANGE v.1.4-->
C              FILBRD(NMAPS) = GAPBRD
CHANGE v.1.4<--
              FILCNT(NMAPS) = GAPCNT
              FILDEN(NMAPS) = GAPDEN
CHANGE v.1.2-->
              FILGRD(NMAPS) = GAPGRD
CHANGE v.1.2<--
              FILSRF(NMAPS) = GAPSRF
              FILMBK(NMAPS) = GAPMBK

C----         Check that haven't moved either of the gap-defining files
              IF (INHFIL(1).EQ.NMAPS) INHFIL(1) = GAPFIL
              IF (INHFIL(2).EQ.NMAPS) INHFIL(2) = GAPFIL
              GAPFIL = NMAPS
          ENDIF
      ENDIF

      GO TO 999

C---- Unable to find keyword
 900  CONTINUE
      PRINT*, '*** ERROR. Maximum number of maps exceeded:',
     -    MXMAPS
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** ERROR. Maximum number of maps exceeded:',
C     -    MXMAPS
CHANGE v.1.3<--
      GO TO 990

 902  CONTINUE
      PRINT*, ' *** ERROR. No output filenames supplied'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) ' *** ERROR. No output filenames supplied'
CHANGE v.1.3<--
      GO TO 990

C---- File type is not one of: A, B, C, G, J, P, S, or %
 904  CONTINUE
      PRINT*, '*** Error in file type for file', IMAP, '. ',
     -    FILSRF(IMAP)(1:ILEN)
      PRINT*, '*** File type must be one of: A, B, C, G, J, P, S, or %'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Error in file type for file', IMAP, '. ',
C     -    FILSRF(IMAP)(1:ILEN)
C      WRITE(13,*) '*** File type must be one of: A, B, C, G, J, P,' //
C     -    ' S, or %'
CHANGE v.1.3<--
      GO TO 990

 906  CONTINUE
      PRINT*, ' *** ERROR in number at line', LINE
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) ' *** ERROR in number at line', LINE
CHANGE v.1.3<--
      GO TO 990

 908  CONTINUE
      PRINT*, ' *** ERROR in filename at line', LINE
      PRINT*, ' *** Maximum 40 characters allowed. Length:', ILEN
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) ' *** ERROR in filename at line', LINE
C      WRITE(13,*) ' *** Maximum 80 characters allowed. Length:', ILEN
CHANGE v.1.3<--
      GO TO 990

 910  CONTINUE
      PRINT*, ' *** ERROR. Only ONE gaps file allowed. Line', LINE
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) ' *** ERROR. Only ONE gaps file allowed. Line', LINE
CHANGE v.1.3<--
      GO TO 990

C---- File containing inhibitor coordinates round which gaps to be calculated
C     is not properly defined
 912  CONTINUE
      PRINT*, ' *** ERROR in file defining gaps'
      PRINT*, '     File number given:', INHFIL(IFIL)
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) ' *** ERROR in file defining gaps'
C      WRITE(13,*) '     File number given:', INHFIL(IFIL)
CHANGE v.1.3<--
      GO TO 990

CHANGE v.1.5-->
C---- First filename is a ditto entry
 914  CONTINUE
      PRINT*, ' *** ERROR. First filename is a ditto entry'
      GO TO 990

C---- Maximum number of ditto entries per filename exceeded
 916  CONTINUE
      PRINT*, ' *** ERROR. Maximum number of ditto entries per filenam',
     -    'e exceeded:', MXDITO
      GO TO 990

C---- Ditto entry on gap-map
 918  CONTINUE
      PRINT*, ' *** ERROR. Ditto entry not allowed on gap-map'
      GO TO 990
CHANGE v.1.5<--

 990  CONTINUE
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE READCH  -  Routine to convert character string to real number
C
C----------------------------------------------------------------------+---

      SUBROUTINE READCH(NUMB,A,RERROR)

      CHARACTER*4   EXPO
      CHARACTER*20  NUMB
      REAL          A, RPOWER
CHANGE v.1.5-->
C      INTEGER       EPOS, IPOWER, RERROR
      INTEGER       EPOS, IPOWER
      LOGICAL       RERROR
CHANGE v.1.5<--

CHANGE v.1.5-->
C      RERROR = 0
      RERROR = .FALSE.
CHANGE v.1.5<--
      EPOS = INDEX(NUMB,'E')
      IF (EPOS.GT.0) THEN
          READ(NUMB(1:EPOS - 1),160,ERR=904) A
160       FORMAT(F20.0)
          EXPO = NUMB(EPOS + 1:)
          EPOS = INDEX(EXPO,' ')
          IF (EPOS.GT.0) EXPO(EPOS:EPOS) = '.'
          READ(EXPO,160,ERR=904) RPOWER
          IPOWER = RPOWER
          A = A * 10.0 ** IPOWER
      ELSE
          READ(NUMB,160,ERR=904) A
      ENDIF

      GO TO 999

904   CONTINUE
CHANGE v.1.5-->
C      RERROR = 1
      RERROR = .TRUE.
CHANGE v.1.5<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.3-->
C Subroutine OPNERR removed
CHANGE v.1.3<--
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      CHARACTER*2   AT(NRADII)
CHANGE v.1.5-->
C      INTEGER       I, ICOORD, ILOOK
      INTEGER       I, ICOORD, ILOOK, ISITE
CHANGE v.1.5<--
      REAL          VD(NRADII), X

      DATA AT     / ' H', ' C', ' O', ' N',  ' S', ' P', 'FE', ' 0',
     -              ' X' /
      DATA VD     /  1.2, 1.87,  1.4, 1.65,  1.85,  1.9,  1.1,  0.0,
     -               1.5 /


C---- Initialise variables
      BFOUND = .FALSE.
      FRGFRQ = 0.0
      IFRAG = 0
CHANGE v.1.6-->
      JUSCAL = .FALSE.
      WNTIDX = .TRUE.
CHANGE v.1.6<--
      PFACTR = 1.0
      DO 100, ICOORD = 1, 3
          VALMIN(ICOORD) = 0.0
          VALMAX(ICOORD) = 0.0
100   CONTINUE

C---- Find maximum van der Waals radius for use as a cutoff radius
      MAXVDW = 0.0
      DO 200, I = 1, NRADII
          ATYPE(I) = AT(I)
          VDWRAD(I) = VD(I)
          MAXVDW = MAX(VDWRAD(I),MAXVDW)
200   CONTINUE

C---- Calculate range of grid-points to be updated on each side of each atom
C     and the constant required by the Gaussian function in routine GRID
      IRANGE = MAXVDW / GRDSEP + 1
      DO 400, I = 1, NRADII
          IF (VDWRAD(I).GT.0.00001) THEN
              KVALUE(I) = - LOG (0.5) / (VDWRAD(I) * VDWRAD(I))
          ELSE
              KVALUE(I) = 0.0
          ENDIF
400   CONTINUE

C---- Precompute exponentials
      X = ESTEP / 2.0
      DO 500, ILOOK = 1, NELOOK
          EVALUE(ILOOK) = EXP(X)
          X = X + ESTEP
 500  CONTINUE

CHANGE v.1.5-->
C---- Initialise SITE record details
      NSITE = 0
      DO 600, ISITE = 1, MXSITE
          SITE(ISITE) = ' '
 600  CONTINUE
CHANGE v.1.5<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE READCO  -  Read in the coordinates from the input file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE READCO

CVAX      IMPLICIT NONE


      INCLUDE 'surfnet.inc'

CHANGE v.1.1.1-->
      INTEGER       MXMETP
      PARAMETER    (MXMETP = 25)
CHANGE v.1.1.1<--

CHANGE v.1.1.1-->
C      CHARACTER*4   LSTCOD, BCODE
CHANGE v.1.4.2-->
C      CHARACTER*4   LSTCOD, BCODE, MET(MXMETP)
      CHARACTER*4   ATMNAM, LSTCOD, BCODE, MET(MXMETP)
CHANGE v.1.4.2<--
CHANGE v.1.1.1<--
      CHARACTER*10  LSTRES, SEQRES
      CHARACTER*80  IREC
CHANGE v.1.1.1-->
C      INTEGER       ATMNO, FTYPE, I, IATOM, ICOORD, IMAP, ITOTAL, LINE,
C     -              MAPNUM, PLINE, TATOMS, TOMAP
      INTEGER       ATMNO, FTYPE, I, IATOM, ICOORD, IMAP, IMETYP,
CHANGE v.1.4-->
C     -              ITOTAL, LINE, MAPNUM, PLINE, TATOMS, TOMAP
CHANGE v.1.4.2-->
C     -              ITOTAL, LENSTR, LINE, MAPNUM, TATOMS, TOMAP
     -              ITOTAL, LENSTR, LINE, MAPNUM, NHOUT, TATOMS, TOMAP
CHANGE v.1.4.2<--
CHANGE v.1.4<--
CHANGE v.1.1.1<--
CHANGE v.1.5-->
C      LOGICAL       FOUND, GAPMK1, GAPMK2, NEW, RADREQ, RREQRD
      LOGICAL       FOUND, GAPMK1, GAPMK2, INRANG, NEW, RADREQ, RREQRD
CHANGE v.1.5<--
      REAL          CENTRE(3), CONST, PRBRAD, X, Y, Z

CHANGE v.1.1.1-->
      DATA  MET   / 'CA  ', 'FE  ', 'ZN  ', ' U  ', 'CU  ',
     -              'MN  ', 'CL  ', 'MG  ', 'NA  ', 'HG  ', 
     -              'CO  ', ' K  ', 'CD  ', 'AU  ', 'AG  ', 
     -              'IN  ', 'HO  ', ' F  ', 'PB  ', 'AL  ', 
     -              'YB  ', '....', '....', '....', '....' /
CHANGE v.1.1.1<--

C---- Initialise variables
      CENTRE(1) = 0.0
      CENTRE(2) = 0.0
      CENTRE(3) = 0.0
      DO 20, IATOM = 1, MXATOM
          ATOUCH(IATOM) = .FALSE.
          GAPFRM(IATOM) = .FALSE.
          GAPTO(IATOM) = .FALSE.
          GTOUCH(IATOM) = .FALSE.
          VECPNT(IATOM) = 0
          NEWRES(IATOM) = .FALSE.
 20   CONTINUE
      IATOM = 0
      DO 50, IMAP = 1, MXMAPS
          ICOUNT(IMAP) = 0
 50   CONTINUE
      ITOTAL = 0
      LINE = 0
      LSTCOD = ' '
      LSTRES = ' '
      NEW = .FALSE.
      NVECT = 0
      TATOMS = 0
      TOMAP = NMAPS
      IF (GAPMAP) TOMAP = NMAPS - 1
CHANGE v.1.4.2-->
      NHOUT = 0
CHANGE v.1.4.2<--
      PRINT*
      PRINT*, 'Reading in protein coordinates ...'

C---- Read through the coordinates file, storing coordinates
 100  CONTINUE

C----     Read in the next record
          IF (.NOT.XSITE) THEN
              READ(2,110,END=500) IREC
 110          FORMAT(A)

C----     If this is an XSITE binary file, read the record and convert
C         to a PDB-format line
          ELSE
              READ(2,END=500,ERR=908) FTYPE, X, Y, Z
              WRITE(IREC,115) FTYPE, X, Y, Z, 0.4
 115          FORMAT('ATOM  ',I5,'  C   ASN     1',4X,3F8.3,6X,F6.2)
          ENDIF
          LINE = LINE + 1
          IF (IREC(1:4).EQ.'ATOM' .OR. IREC(1:6).EQ.'HETATM') THEN

C----         Get the atom-number
CHANGE v.1.4.2-->
C              READ(IREC,120,ERR=900) ATMNO, X, Y, Z
C 120          FORMAT(6X,I5,19X,3F8.3)
              READ(IREC,120,ERR=900) ATMNO, ATMNAM, X, Y, Z
 120          FORMAT(6X,I5,1X,A4,14X,3F8.3)
CHANGE v.1.4.2<--

C----         Save atom/fragment number and fragment frequency (for use
C             with atom-sidechain distributions only)
              IF (IREC(18:20).EQ.'FRG') THEN
                  IFRAG = - ATMNO
                  READ(IREC,140) FRGFRQ
 140              FORMAT(60X,F6.0)
              ELSE
                  IATYPE = ATMNO
              ENDIF

C----         Accumulate coordinates to calculate centre of gravity
C             of all the the protein's atoms
              TATOMS = TATOMS + 1
              CENTRE(1) = CENTRE(1) + X
              CENTRE(2) = CENTRE(2) + Y
              CENTRE(3) = CENTRE(3) + Z

C----         Test which map(s) this atom belongs to and increment counts
              IF (GAPALL) THEN
                  GAPMK1 = .TRUE.
                  GAPMK2 = .TRUE.
              ELSE
                  GAPMK1 = .FALSE.
                  GAPMK2 = .FALSE.
              ENDIF
              MAPNUM = 0
              RADREQ = .FALSE.
              RREQRD = .FALSE.
              DO 200, IMAP = 1, TOMAP

CHANGE v.1.5-->
C----             Determine whether the current atom number falls
C                 within one of the ranges for this map
                  CALL CHKRNG(ATMNO,IMAP,INRANG)
CHANGE v.1.5<--

C----             If the atom number falls in the range of the current
C                 map, increment the counts
CHANGE v.1.5-->
C                  IF (ATMNO.GE.ASTART(IMAP) .AND.
C     -                ATMNO.LE.AEND(IMAP)) THEN
                  IF (INRANG) THEN
CHANGE v.1.5<--
                      MAPNUM = IMAP
                      ICOUNT(IMAP) = ICOUNT(IMAP) + 1

C----                 If reading in the atom radius for this map, then set
C                     flag
                      IF (INRAD(MAPNUM)) RADREQ = .TRUE.

C----                 If the current map is one to/from which gaps are
C                     to be generated, then flag this atom
                      IF (IMAP.EQ.INHFIL(1)) GAPMK1 = .TRUE.
                      IF (IMAP.EQ.INHFIL(2)) GAPMK2 = .TRUE.

C----                 Check whether the atom's van der Waals radius is
C                     required
                      IF (FILTYP(MAPNUM).EQ.'S') RREQRD = .TRUE.
                      IF (GAPMK1 .OR. GAPMK2) RREQRD = .TRUE.
CHANGE v.1.1-->
C                     IF (GAPMAP .AND. INHFIL(2).EQ.0) RREQRD = .TRUE.
                      IF (GAPMAP) RREQRD = .TRUE.
CHANGE v.1.1<-

CHANGE v.1.4.2-->
C----                 If hydrogens are to be excluded then check if
C                     this is one
                      IF (NOHYDR) THEN
                          IF (ATMNAM(1:1).EQ.'H' .OR.
     -                        ATMNAM(2:2).EQ.'H' .OR.
     -                        ATMNAM(1:1).EQ.'Q' .OR.
CHANGE v.1.6-->
     -                        ATMNAM(2:2).EQ.'Q' .OR.
CHANGE v.1.6<--
     -                        (ATMNAM(2:2).EQ.'D' .AND.
     -                        (ATMNAM(1:1).EQ.' ' .OR.
     -                        ATMNAM(1:1).EQ.'1' .OR.
     -                        ATMNAM(1:1).EQ.'2' .OR.
     -                        ATMNAM(1:1).EQ.'3'))) THEN

C----                         If not a metal, then exclude
                              IF (ATMNAM.NE.'HG  ' .AND.
     -                            ATMNAM.NE.'HO  ') THEN
                                  MAPNUM = 0
                                  NHOUT = NHOUT + 1
                              ENDIF
                          ENDIF
                      ENDIF
CHANGE v.1.4.2<--
                  ENDIF
 200          CONTINUE

C----         If the atom is required for any of the maps then store it
              IF (MAPNUM.NE.0) THEN

C----             Get the rest of the atom's details
                  IATOM = IATOM + 1
                  IF (IATOM.GT.MXATOM) GO TO 902
                  ATNUM(IATOM) = ATMNO
CHANGE v.1.1.1-->
                  BVALUE(IATOM) = 0.0
CHANGE v.1.1.1<--
                  RADIUS(IATOM) = 0.0
                  STOREK(IATOM) = 0.0
                  XYZ(1,IATOM) = X
                  XYZ(2,IATOM) = Y
                  XYZ(3,IATOM) = Z
                  READ(IREC,250,ERR=900) ATNAME(IATOM), SEQRES, BCODE
 250              FORMAT(12X,A2,3X,A10,40X,A4)

C----             Determine how atom is involved in gap-filling routines,
C                 if at all
                  IF (GAPALL) THEN
                      GAPFRM(IATOM) = .TRUE.
                      GAPTO(IATOM) = .TRUE.
                  ELSE IF (GAPMAP) THEN
                      IF (INHFIL(2).EQ.0) THEN
                          GAPFRM(IATOM) = GAPMK1
                          GAPTO(IATOM) = .NOT.GAPMK1
                      ELSE
                          GAPFRM(IATOM) = GAPMK1
                          GAPTO(IATOM) = GAPMK2
                      ENDIF
                  ENDIF

C----             If this is the start of a new residue, then flag the
C                 atom
                  IF (NEW .OR. SEQRES.NE.LSTRES .OR.
     -                BCODE.NE.LSTCOD) THEN
                      NEWRES(IATOM) = .TRUE.
                      LSTRES = SEQRES
                      LSTCOD = BCODE
                      NEW = .FALSE.
                  ENDIF

C----             If this atom is in the range that determines the
C                 boundaries of the grid-box, then call the maximum/minimum
C                 routine
                  IF (ATMNO.GE.BOUNAT(1) .AND. ATMNO.LE.BOUNAT(2)) THEN
                      CALL MAXMIN(XYZ(1,IATOM))
                  ENDIF

C----             Determine atom's van der Waals radius, if required,
C                 and store K-value used in grid-point calculation
                  IF (RREQRD) THEN
                      CONST = -1.0 * KVALUE(NRADII)
                      RADIUS(IATOM) = VDWRAD(NRADII)
                      FOUND = .FALSE.
                      DO 300, I = 1, NRADII - 1
                          IF (ATNAME(IATOM).EQ.ATYPE(I)) THEN
                              RADIUS(IATOM) = VDWRAD(I)
                              CONST = -1.0 * KVALUE(I)
                              FOUND = .TRUE.
                          ENDIF
300                   CONTINUE
                      IF (.NOT.FOUND) THEN
CHANGE v.1.1.1-->
C----                     Check for various metals
                          DO 320, IMETYP = 1, MXMETP
                              IF (ATNAME(IATOM).EQ.MET(IMETYP)) THEN
                                  RADIUS(IATOM) = 1.2
                                  CONST = LOG (0.5)
     -                                / (RADIUS(IATOM) * RADIUS(IATOM))
                                  FOUND = .TRUE.
                              ENDIF
 320                      CONTINUE
                      ENDIF

                      IF (.NOT.FOUND) THEN
CHANGE v.1.1.1<--
                          DO 350, I = 1, NRADII - 1
                              IF (ATNAME(IATOM)(2:2).EQ.ATYPE(I)(2:2))
     -                            THEN
                                  RADIUS(IATOM) = VDWRAD(I)
                                  CONST = -1.0 * KVALUE(I)
                                  FOUND = .TRUE.
                                  PRINT*, '* Unusual atom name [',
     -                                ATNAME(IATOM), ']. Taken to be [',
     -                                ATNAME(IATOM)(2:2), '], radius:',
     -                                RADIUS(IATOM)
                              ENDIF
350                       CONTINUE
                          IF (.NOT.FOUND) THEN
                              PRINT*, '* Warning: van der Waals radi',
     -                            'us for atom type [', ATNAME(IATOM),
     -                            '] unknown. ', 'Value used:',
     -                            VDWRAD(NRADII)
                          ENDIF 
                      ENDIF 
                      STOREK(IATOM) = CONST
                  ENDIF

C----             If reading in the atom's radius from the file, store that
                  IF (RADREQ) THEN
                      READ(IREC,360,ERR=920) PRBRAD
 360                  FORMAT(60X,F6.0)
                      RADIUS(IATOM) = PRBRAD
                      STOREK(IATOM) = LOG (0.5) / (PRBRAD * PRBRAD)
                      MAXVDW = MAX(PRBRAD,MAXVDW)
                  ENDIF

CHANGE v.1.1.1-->
C----             Read in and store the B-value
                  READ(IREC,360,ERR=920) BVALUE(IATOM)
CHANGE v.1.1.1<--
              ENDIF

C----     If have hit a REMARK record then this may indicate a new residue
C         in either a PAIRS or a TRIPLET distribution
          ELSE IF (IREC(1:6).EQ.'REMARK') THEN
              NEW = .TRUE.

C----     If this is an atom vector record, containing a direction vector
C         for the atom's density, then store the value
          ELSE IF (IREC(1:6).EQ.'ATMVEC') THEN
              IF (IATOM.GT.0 .AND. IATOM.LT.MXATOM) THEN
                  NVECT = NVECT + 1
                  IF (NVECT.GT.MXVECT) GO TO 904
                  VECPNT(IATOM) = NVECT
                  READ(IREC,380,ERR=906) (VECTOR(ICOORD,NVECT),
     -                ICOORD = 1, 3)
 380              FORMAT(6X,3F8.3)
              ENDIF

CHANGE v.1.5-->
C----     If this is a SITE record, then store
          ELSE IF (IREC(1:6).EQ.'SITE  ') THEN

C----         Check that maximum number of SITE records not exceeded
              IF (NSITE.GE.MXSITE) THEN
                  PRINT*, '*** Warning. Maximum number of SITE records',
     -                ' in input PDB file exceeded', MXSITE

C----         Otherwise, store this SITE record
              ELSE
                  NSITE = NSITE + 1
                  SITE(NSITE) = IREC(7:)
              ENDIF
CHANGE v.1.5<--
          ENDIF

C---- Loop back for next atom record
      GO TO 100

C---- All protein coordinates have been read in
500   CONTINUE

C---- Store count of atoms
      NATOMS = IATOM
      NEXTAT = IATOM

CHANGE v.1.4.2-->
C---- If any hydrogen atoms have been excluded, then say so
      IF (NHOUT.GT.0) THEN
          PRINT 580, NHOUT
 580      FORMAT(I6,' hydrogens excluded.')
          PRINT*
      ENDIF
CHANGE v.1.4.2<--

C---- Display number of atoms belonging to each map
      PRINT 620, NATOMS
 620  FORMAT(1X,'Coordinates stored:',I6,/)
      DO 800, IMAP = 1, TOMAP
CHANGE v.1.4-->
C          PRINT 720, IMAP, ICOUNT(IMAP), FILSRF(IMAP)(1:40)
C720       FORMAT(1X,'Atoms for Map ',I2,':  ',I6,3X,A40)
          PRINT 720, IMAP, ICOUNT(IMAP), FILSRF(IMAP)(1:LENSTR(FILSRF))
720       FORMAT(1X,'Atoms for Map ',I2,':  ',I6,3X,A)
CHANGE v.1.4<--
          ITOTAL = ITOTAL + ICOUNT(IMAP)
800   CONTINUE
      PRINT 820, NATOMS
820   FORMAT(1X,'                   ------',/
     -       1X,'Total coordinates: ',I6,//)
      IF (TATOMS.GT.0) THEN
          PRINT 830, (CENTRE(I) / TATOMS, I = 1, 3)
830       FORMAT(1X,'Centre of gravity:  ',3F12.4,/)
      ENDIF

C---- Show number of atom direction-vectors read in
      IF (NVECT.GT.0) THEN
          PRINT*
          PRINT 840, NVECT
 840      FORMAT(1X,'ATOM VECTORS:  ',I8,/)
      ENDIF

C---- Calculate the number of atoms involved in gap-filling routines
      IF (GAPMAP) THEN
          IF (GAPALL) THEN
              FTOTAL = NATOMS
          ELSE
              FTOTAL = ICOUNT(INHFIL(1))
          ENDIF
      ELSE
          FTOTAL = 0
      ENDIF

C---- Close the coordinates file
      CLOSE(2)
      GO TO 999

C---- Fatal errors
900   CONTINUE
      PRINT*, '*** Data error in input coordinate file at line ', LINE
      PRINT*, '[', IREC(1:78), ']'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Data error in input coordinate file at line ',
C     -    LINE
C      WRITE(13,*) '[', IREC(1:78), ']'
CHANGE v.1.3<--
      GO TO 990

902   CONTINUE
      PRINT*, '*** Warning: Maximum no. of allowed atoms exceeded:',
     -    MXATOM
      PRINT*, '*   Program continuing just with those already read in'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Warning: Maximum no. of allowed atoms exceeded:',
C     -    MXATOM
C      WRITE(13,*) '*   Program continuing just with those already ',
C     -    'read in'
CHANGE v.1.3<--
      IATOM = IATOM - 1
      GO TO 500

 904  CONTINUE
      PRINT*, '*** Maximum no. of atom vectors exceeded:', MXVECT
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Maximum no. of atom vectors exceeded:',
C     -    MXVECT
CHANGE v.1.3<--
      GO TO 990

 906  CONTINUE
      PRINT*, '*** Data error in vector record at line ', LINE
      PRINT*, '[', IREC(1:78), ']'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Data error in vector record at line ',
C     -    LINE
C      WRITE(13,*) '[', IREC(1:78), ']'
CHANGE v.1.3<--
      GO TO 990

 908  CONTINUE
      PRINT*, '*** Data error in .bin file at line ', LINE
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Data error in .bin file at line ',
C     -    LINE
CHANGE v.1.3<--
      GO TO 990

920   CONTINUE
      PRINT*, '*** Data error in atom radius at line ', LINE
      PRINT*, '[', IREC(1:78), ']'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Data error in atom radius at line ',
C     -    LINE
C      WRITE(13,*) '[', IREC(1:78), ']'
CHANGE v.1.3<--
      GO TO 990

990   CONTINUE
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.5-->
C**************************************************************************
C
C  SUBROUTINE CHKRNG  -  Determine whether the given atom number belongs
C                        to the given map
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE CHKRNG(ATMNO,IMAP,INRANG)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       ATMNO, IDITTO, IMAP
      LOGICAL       INRANG

C---- Initialise variables
      INRANG = .FALSE.

C---- Loop over all this map's ditto entries
      DO 500, IDITTO = 1, NDITTO(IMAP)

C----     Check whether atom falls in the given range
          IF (ATMNO.GE.ASTART(IDITTO,IMAP) .AND.
     -        ATMNO.LE.AEND(IDITTO,IMAP)) THEN
              INRANG = .TRUE.
              GO TO 999
          ENDIF
 500  CONTINUE

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.5<--
C**************************************************************************
C
C  SUBROUTINE MAXMIN  -  Calculate maximum and minimum coordinates
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE MAXMIN(XYZVAL)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       ICOORD
      REAL          XYZVAL(3)

C---- Find maximum and minimum coordinate values

C---- If this is the first boundary-defining atom, then store its coords
C     as maximum and minimum
      IF (.NOT.BFOUND) THEN
          DO 150, ICOORD = 1, 3
              VALMAX(ICOORD) = XYZVAL(ICOORD)
              VALMIN(ICOORD) = XYZVAL(ICOORD)
150       CONTINUE

C---- Otherwise, adjust current bounds only if atom is outside them
      ELSE
          DO 200, ICOORD = 1, 3
              VALMAX(ICOORD) = MAX(VALMAX(ICOORD),
     -                             XYZVAL(ICOORD))
              VALMIN(ICOORD) = MIN(VALMIN(ICOORD),
     -                             XYZVAL(ICOORD))
200       CONTINUE
      ENDIF
      BFOUND = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GBOUND  -   Calculate boundaries for grid box
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GBOUND

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       ARSIZE, ICOORD, LOWER, UPPER
CHANGE v.1.4-->
C      LOGICAL       FIRST
CHANGE v.1.4<--
      REAL          RESD(3)

CHANGE v.1.4-->
C      DATA  FIRST / .TRUE./
CHANGE v.1.4<--

C---- Check whether any atoms found to define the boundaries
      IF (BOUNAT(1).NE.0 .AND. BOUNAT(2).NE.0 .AND. .NOT.BFOUND)
     -    GO TO 900

C---- If no atom-range given, then use origin supplied by user
      IF (BOUNAT(1).EQ.0 .AND. BOUNAT(2).EQ.0) THEN
          VALMIN(1) = BXORIG(1)
          VALMAX(1) = BXORIG(1)
          VALMIN(2) = BXORIG(2)
          VALMAX(2) = BXORIG(2)
          VALMIN(3) = BXORIG(3)
          VALMAX(3) = BXORIG(3)
          PRINT 620, 'Box coord min:      ',
     -        (VALMIN(ICOORD), ICOORD = 1, 3)
          PRINT 620, 'Box coord max:      ',
     -        (VALMAX(ICOORD), ICOORD = 1, 3)
      ELSE
          PRINT 620, 'Min coords:         ',
     -        (VALMIN(ICOORD), ICOORD = 1, 3)
          PRINT 620, 'Max coords:         ',
     -        (VALMAX(ICOORD), ICOORD = 1, 3)
      ENDIF

C---- Add required border round the grid-box
      DO 100, ICOORD = 1, 3
          VALMIN(ICOORD) = VALMIN(ICOORD) - BOUND(ICOORD)
          VALMAX(ICOORD) = VALMAX(ICOORD) + BOUND(ICOORD)
100   CONTINUE
      ARSIZE = 1

C---- Calculate the array size for the grid
      DO 600, ICOORD = 1, 3
          LOWER = 2 * ICOORD - 1
          UPPER = LOWER + 1

C----     Calculate lowest grid value for this coordinate
          LIM(LOWER) = INT(VALMIN(ICOORD) / GRDSEP)
CHANGE v.1.1.1-->
C          IF (VALMIN(ICOORD).GT.0.0) THEN
CC              LIM(LOWER) = LIM(LOWER) + 1
C          ELSE IF (VALMIN(ICOORD).LT.0.0) THEN
C              LIM(LOWER) = LIM(LOWER) - 1
C          ENDIF
          IF (VALMIN(ICOORD).LT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF
          IF (ABS(LIM(LOWER) - VALMIN(ICOORD) / GRDSEP).LT.0.0001) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF
CHANGE v.1.1.1<--
          IF (GAPMAP) LIM(LOWER) = LIM(LOWER) - IRANGE

C----     Calculate upper grid value for this coordinate
          LIM(UPPER) = INT(VALMAX(ICOORD) / GRDSEP)
CHANGE v.1.1.1-->
C          IF (VALMAX(ICOORD).GT.0.0) THEN
C              LIM(UPPER) = LIM(UPPER) + 1
C          ELSE IF (VALMAX(ICOORD).LT.0.0) THEN
C              LIM(UPPER) = LIM(UPPER) - 1
C          ENDIF
          IF (VALMAX(ICOORD).LT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) - 1
          ENDIF
          IF (ABS(LIM(UPPER) - VALMAX(ICOORD) / GRDSEP).LT.0.0001) THEN
              LIM(UPPER) = LIM(UPPER) + 1
          ENDIF
          LIM(UPPER) = LIM(UPPER) + 1
CHANGE v.1.1.1<--
          IF (GAPMAP) LIM(UPPER) = LIM(UPPER) + IRANGE
      
C----     Calculate number of grid points required for this coordinate
          NPOINT(ICOORD) = LIM(UPPER) - LIM(LOWER) + 1
          ARSIZE = ARSIZE * NPOINT(ICOORD)
      
C----     Adjust the minimum and maximum values to correspond to the
C         grid limits
          VALMIN(ICOORD) = LIM(LOWER) * GRDSEP
          VALMAX(ICOORD) = LIM(UPPER) * GRDSEP
          RESD(ICOORD) = VALMAX(ICOORD) - VALMIN(ICOORD)
600   CONTINUE

C---- Check that array is not too large
      IF (ARSIZE.GT.MAXARR) THEN
          PRINT*, '*** Array required:', ARSIZE, '   is larger',
     -            ' than that allowed:', MAXARR
          PRINT*, '     Grid points:', (NPOINT(ICOORD), ICOORD = 1, 3)
          GO TO 990
      ENDIF
      VOLBOX = RESD(1) * RESD(2) * RESD(3)
      PRINT 620, 'Adjusted min:       ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
 620  FORMAT(1X,A,3F12.4)
      PRINT 620, 'Adjusted max:       ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      PRINT*
      PRINT 640, 'Grid separation:    ', GRDSEP
 640  FORMAT(1X,A,F12.4)
      PRINT*
      PRINT 660, 'Length:             ',
     -    (RESD(ICOORD), ICOORD = 1, 3), 'Volume:         ',
     -     VOLBOX
 660  FORMAT(1X,A,3F12.4,/,1X,A,F16.2)
      PRINT 680, NPOINT(1), NPOINT(2), NPOINT(3), ARSIZE
 680  FORMAT(/,1X,'Array size: ',I8,'  x',I8,'  x',I8,'  = ',I8,
     -    ' points',/) 

C---- Save current boundary values for later use
      DO 700, ICOORD = 1, 3
          SAVPNT(ICOORD) = NPOINT(ICOORD)
          SAVMIN(ICOORD) = VALMIN(ICOORD)
          SAVMAX(ICOORD) = VALMAX(ICOORD)
700   CONTINUE


      GO TO 999

C---- Error conditions
 900  CONTINUE
      PRINT*, '*** No atoms found to define grid boundary. Range ',
     -    'given:', BOUNAT(1), '    to', BOUNAT(2)
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** No atoms found to define grid boundary.',
C     -    ' Range given:', BOUNAT(1), '    to', BOUNAT(2)
CHANGE v.1.3<--
      GO TO 990

990   CONTINUE
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE REINIT  -  Re-initialise parameters such as the grid bounds
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE REINIT

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      INTEGER       ICOORD

C---- Re-initialise variables
      DO 100, ICOORD = 1, 3
          NPOINT(ICOORD) = SAVPNT(ICOORD)
          VALMIN(ICOORD) = SAVMIN(ICOORD)
          VALMAX(ICOORD) = SAVMAX(ICOORD)
100   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE DELATM  -  Remove any atoms that are outside the grid
C                        boundaries
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE DELATM

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       FREE, IATOM, ICOORD, OUTSID
      LOGICAL       REMOVE

C---- Loop through all the atoms
      FREE = 0
      OUTSID = 0
      DO 200, IATOM = 1, NATOMS
          REMOVE = .FALSE.

C----     If atom type is '0', or coordinates outside boundaries, then mark
C         for removal
          IF (ATNAME(IATOM).EQ.' 0') THEN
              REMOVE = .TRUE.
          ELSE
              DO 100, ICOORD = 1, 3
                  IF (XYZ(ICOORD,IATOM).LT.VALMIN(ICOORD) .OR.
     -                XYZ(ICOORD,IATOM).GT.VALMAX(ICOORD)) THEN
                      REMOVE = .TRUE.
                      GO TO 101
                  ENDIF
100           CONTINUE
101           CONTINUE
          ENDIF

C----     If atom is outside the bounds, its location in the arrays is free
C         for use by other atoms
          IF (REMOVE) THEN
              OUTSID = OUTSID + 1
              IF (FREE.EQ.0) FREE = IATOM

C----     Otherwise, move atom up to last free location
          ELSE IF (FREE.GT.0) THEN
              ATNUM(FREE) = ATNUM(IATOM)
              ATNAME(FREE) = ATNAME(IATOM)
              GAPFRM(FREE) = GAPFRM(IATOM)
              GAPTO(FREE) = GAPTO(IATOM)
              RADIUS(FREE) = RADIUS(IATOM)
              STOREK(FREE) = STOREK(IATOM)
              XYZ(1,FREE) = XYZ(1,IATOM)
              XYZ(2,FREE) = XYZ(2,IATOM)
              XYZ(3,FREE) = XYZ(3,IATOM)
              FREE = FREE + 1
          ENDIF
200   CONTINUE

C---- If any atoms removed, reduce the number of atoms
      IF (FREE.GT.0) NATOMS = FREE - 1
      PRINT*
      PRINT*, 'Number of atoms outside grid-box:  ', OUTSID
      PRINT*
      PRINT*, 'Number of atoms within grid-box:   ', NATOMS
      PRINT*

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.3-->
C**************************************************************************
C
C  SUBROUTINE OPNVOL - Open file of C of G coordinates for calculated
C                      molecular volumes
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.6-->
C      SUBROUTINE OPNVOL
      SUBROUTINE OPNVOL(IMAP)
CHANGE v.1.6<--

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
CHANGE v.1.5-->
CHANGE v.1.6-->
C      INTEGER       ISITE, LENSTR
      INTEGER       IMAP, ISITE, LENSTR
CHANGE v.1.6<--
CHANGE v.1.5<--

C---- Open the volumes.pdb file          
CHANGE v.1.6-->
C      OPEN(UNIT=14, FILE='volumes.pdb', STATUS='UNKNOWN',
      OPEN(UNIT=14, FILE=FILOUT(IMAP), STATUS='UNKNOWN',
CHANGE v.1.6<--
     -      FORM='FORMATTED',ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

CHANGE v.1.5-->
C---- Write out the name of the original PDB file
      WRITE(14,120) FILPDB(1:LENSTR(FILPDB))
 120  FORMAT('REMARK Input file: ',A)

C---- Write out any SITE records that were present in the input PDB file
CHANGE v.1.6-->
      IF (GAPMAP .AND. IMAP.EQ.NMAPS) THEN
CHANGE v.1.6<--
          DO 200, ISITE = 1, NSITE
              WRITE(14,140) SITE(ISITE)
 140          FORMAT('SITE  ',A)
 200      CONTINUE

C----     If this is the gaps map, write out a template SITE record
          WRITE(14,220)
 220      FORMAT(
CHANGE v.1.6-->
C     -    'Site Format:      <--------> <--------> <--------> <-------',
C     -    '->',/,
C     -    'Site Format:      Res CnumbI Res CnumbI Res CnumbI Res Cnum',
C     -    'bI',/,
C     -    'Site Format:         where Res  = 3-letter residue name',/,
C     -    'Site Format:         where C    = chain-id',/,
C     -    'Site Format:         where numb = 4-digit residue number',/,
C     -    'Site Format:         where I    = insertion code')
     -    'SITFMT            <--------> <--------> <--------> <-------',
     -    '->',/,
     -    'SITFMT            Res CnumbI Res CnumbI Res CnumbI Res Cnum',
     -    'bI',/,
     -    'SITFMT               where Res  = 3-letter residue name',/,
     -    'SITFMT               where C    = chain-id',/,
     -    'SITFMT               where numb = 4-digit residue number',/,
     -    'SITFMT               where I    = insertion code')
CHANGE v.1.6<--
CHANGE v.1.5<--
CHANGE v.1.6-->
      ENDIF
CHANGE v.1.6<--
      GO TO 999

C---- Fatal error
900   CONTINUE
CHANGE v.1.6-->
C      PRINT*, '*** Error opening output file, volumes.pdb.'
      PRINT*, '*** Error opening output file, ',
     -    FILOUT(IMAP)(1:LENSTR(FILOUT(IMAP)))
CHANGE v.1.6<--
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Error opening output file, volumes.pdb.'
CHANGE v.1.3<--
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.3<--
CHANGE v.1.6-->
C**************************************************************************
C
C  SUBROUTINE OPNGVL - Open file of C of G coordinates for all calculated
C                      volumes
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE OPNGVL

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       LENSTR

C---- Open the gaps.vol file          
      OPEN(UNIT=16, FILE='gaps.vol', STATUS='UNKNOWN',
     -      FORM='FORMATTED',ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write out the name of the original PDB file
      WRITE(16,120) FILPDB(1:LENSTR(FILPDB))
 120  FORMAT('REMARK Input file: ',A)

      GO TO 999

C---- Fatal error
900   CONTINUE
      PRINT*, '*** Error opening output file, gaps.vol'
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE FILGAP  -  Place gap-spheres in gaps between atoms
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE FILGAP(PASS2)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       ATOM1, ATOM2, ATOM3

      PARAMETER    (ATOM1 = 1, ATOM2 = 2, ATOM3 = 3)

      INTEGER       FATOM, FREE, IATOM, IBEGIN, IBOX, IEND, ILOOP,
     -              LSTPOS, JATOM, LSTCUT, NLOOPS,
     -              NSPHRE, NSTORE, NTODO, SINDEX(MXATOM)
      LOGICAL       GAPGAP, INHIB, PASS2, PROCES, VALID, WANTED(MXATOM)
      REAL          ACOORD(3,3), CENTRE(3), DIST, DISTMX, INVMAT(3,3),
     -              INVTRN(3), MATRIX(3,3), MAXD2, MIND2, ORGRAD,
     -              PCDONE, PCSHOW, TRANSL(3), SDIST, SPHRAD, STEPSZ,
     -              STPOS

      EQUIVALENCE  (NEWRES(1), WANTED(1))

C---- Initialise parameters
      IF (FTOTAL.EQ.0) GO TO 902
      PRINT*
      IF (MULTIG) THEN
          PRINT*, 'Filling gaps ... NEW algorithm'
      ELSE
          PRINT*, 'Filling gaps ...'
      ENDIF
      ACTMAX = 0.0
      DISTMX = MAXDIA + 2.0 * MAXVDW
      FATOM = 0
      FREE = NATOMS
      GAPGAP = .FALSE.
      GBEGIN = NATOMS + 1
      IBEGIN = 1
      IBOX = 0
      IEND = 1
      INHIB = .FALSE.
      LSTPOS = 0
      MAXD2 = MAXDIA * MAXDIA
      MIND2 = MINDIA * MINDIA
      NSPHRE = 0
      NTODO = (NATOMS * NATOMS - NATOMS ) / 2
      PCSHOW = 0.0

C---- Loop through all pairs of atoms to fit gap-spheres between them
      DO 800, IATOM = 1, NATOMS

C----     Pre-calculate all surface-to-surface distances for the current
C         atom
          CALL SSDIST(IATOM,NATOMS,STODST,MXATOM,NSTORE,WANTED,GAPFRM,
     -        GAPTO,XYZ,RADIUS,MAXDIA,SINDEX,GAPALL,MULTIG,GAPSPN)

C----     Sort the neighbouring atoms into distance order
          CALL SHSORT(NATOMS,STODST,NSTORE,SINDEX)

C----     Loop for evey other atom not already done
          DO 600, JATOM = IATOM + 1, NATOMS

C----         Retrieve the stored surface-to-surface distance
              SDIST = STODST(JATOM)

C----         If this atom too far away, then mark atom as unwanted
              PROCES = .TRUE.
              IF (.NOT.WANTED(JATOM) .OR. SDIST.LT.0.0) THEN
                  PROCES = .FALSE.
              ENDIF

C----         If have two atoms of interest, then consider for placing
C             a gap sphere (or spheres) between them
              IF (PROCES) THEN

C----             If the surfaces are practically touching, then mark
C                 both atoms as atom-touching atoms (for recording which
C                 protein atoms make contact with inhibitor atoms, and
C                 vice versa)
                  IF (SDIST.LT.MINDIA) THEN
                      IF (.NOT.GAPALL .AND. .NOT.PASS2) THEN
                          ATOUCH(IATOM) = .TRUE.
                          ATOUCH(JATOM) = .TRUE.
                      ENDIF

C----             If the distance between the surfaces is within the
C                 allowed size limits for the gap-spheres, place one
C                 or more between them
                  ELSE

C----                 Calculate the transformation that will place
C                     this pair of atoms such that the first is at the
C                     origin and the second lies on the positive x-axis
                      CALL CALTRN(XYZ(1,IATOM),XYZ(1,J ATOM),MATRIX,
     -                    TRANSL,INVMAT,INVTRN,ACOORD)

C----                 Retrieve the stored centre-to-centre distance
                      DIST = SDIST + RADIUS(IATOM) + RADIUS(JATOM)

C----                 Calculate second atom's transformed coordinates
                      ACOORD(1,ATOM2) = DIST
                      ACOORD(2,ATOM2) = 0.0
                      ACOORD(3,ATOM2) = 0.0

C----                 Calculate number of gap spheres to be placed between
C                     the current two atoms
                      CALL CALNGP(MAXDIA,SDIST,RADIUS(IATOM),NLOOPS,
     -                    STEPSZ,SPHRAD,STPOS,MULTIG)

C----                 Store the sphere radius
                      ORGRAD = SPHRAD

C----                 Loop over all the gap-spheres to be generated
                      DO 500, ILOOP = 1, NLOOPS

C----                     Retrieve the starting gap-sphere radius
                          SPHRAD = ORGRAD

C----                     Generate a trial sphere at the next position
                          CALL GENSPH(ILOOP,VALID,SPHRAD,STEPSZ,
     -                        STPOS,SINDEX,XYZ,STODST,MXATOM,NSTORE,
     -                        IATOM,RADIUS,LSTCUT,CENTRE,MATRIX,TRANSL,
     -                        INVMAT,INVTRN,MINRAD)

C----                     If have a valid gap sphere, then store as a
C                         pseudo atom
                          IF (VALID) THEN

C----                         Store the gap sphere
                              CALL STOSPH(NSPHRE,FREE,ATNUM,MXATOM,XYZ,
     -                            RADIUS,ACTMAX,STOREK,CENTRE,SPHRAD,
     -                            LSTCUT,GTOUCH,IATOM,JATOM,IFAIL)
                              IF (IFAIL) GO TO 990
                          ENDIF
 500                  CONTINUE
                  ENDIF
              ENDIF
 600      CONTINUE

C----     Check what percentage has been done
          FATOM = FATOM + NATOMS - IATOM
          PCDONE = 100.0 * REAL(FATOM) / REAL(NTODO)
          IF (PCDONE - PCSHOW.GT.5.0) THEN
              PCSHOW = PCDONE
              PRINT 720, PCDONE
 720          FORMAT(F10.1,'% done')
          ENDIF
 800  CONTINUE

C---- Adjust number of atoms held
      NATOMS = FREE
      PRINT*
      PRINT*, 'Number of gap-spheres stored: ', NSPHRE
      PRINT*
      PRINT*, 'Maximum sphere radius:        ', ACTMAX

      GO TO 999

C---- Fatal errors
902   CONTINUE
      PRINT*, '*** No atoms from which to generate gap map'
      GO TO 990

990   CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SSDIST - Pre-calculate all surface-to-surface distances for
C                      the current atom
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE SSDIST(IATOM,NATOMS,STODST,MXATOM,NSTORE,WANTED,GAPFRM,
     -    GAPTO,XYZ,RADIUS,MAXDIA,SINDEX,GAPALL,MULTIG,GAPSPN)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM

      INTEGER       IATOM, JATOM, NATOMS, NSTORE, SINDEX(MXATOM)
      LOGICAL       GAPALL, GAPFRM(MXATOM), GAPTO(MXATOM), MULTIG,
     -              WANTED(MXATOM)
      REAL          DIST, DIST2, GAPSPN, MAXDIA, RADIUS(MXATOM), SDIST,
     -              STODST(MXATOM), XYZ(3,MXATOM)

C---- Initialise count of stored neighbouring atoms
      NSTORE = 0

C---- Pre-calculate all surface-to-surface distances for the current
C     atom
      DO 100, JATOM = 1, NATOMS

C----     Initialise distances
          STODST(JATOM) = 0.0

C----     Determine whether this atom-pair is required
          WANTED(JATOM) = .FALSE.
          IF ((GAPFRM(IATOM) .AND. GAPTO(JATOM)) .OR.
     -        (GAPFRM(JATOM) .AND. GAPTO(IATOM))) THEN
              WANTED(JATOM) = .TRUE.
          ENDIF
          IF (GAPALL) WANTED(JATOM) = .TRUE.

C----     Calculate the distance between the two surfaces
          DIST2 = (XYZ(1,IATOM) - XYZ(1,JATOM))
     -        * (XYZ(1,IATOM) - XYZ(1,JATOM))
          DIST2 = DIST2 + (XYZ(2,IATOM) - XYZ(2,JATOM))
     -        * (XYZ(2,IATOM) - XYZ(2,JATOM))
          DIST2 = DIST2 + (XYZ(3,IATOM) - XYZ(3,JATOM))
     -        * (XYZ(3,IATOM) - XYZ(3,JATOM))
          DIST = SQRT(DIST2)
          SDIST = DIST - RADIUS(IATOM) - RADIUS(JATOM)

C----     Store the distance
          STODST(JATOM) = SDIST

C----     If this atom too far away, then mark atom as unwanted
          IF ((MULTIG .AND. SDIST.GT.GAPSPN) .OR.
     -        (.NOT.MULTIG .AND. SDIST.GT.MAXDIA)) THEN
              WANTED(JATOM) = .FALSE.
          ELSE IF (JATOM.NE.IATOM) THEN
              NSTORE = NSTORE + 1
              SINDEX(NSTORE) = JATOM
          ENDIF
 100  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CALTRN  -  Calculate the full transformation that will put
C                        the current pair of atoms such that the first is
C                        at the origin and the other lies on the positive
C                        z-axis
C
C----------------------------------------------------------------------+---

      SUBROUTINE CALTRN(ATOM1,ATOM2,MATRIX,TRANSL,INVMAT,INVTRN,XYZ)

CVAX      IMPLICIT NONE

      INTEGER       ANGLE1, ANGLE2, IX, IY, IZ

      PARAMETER    (ANGLE1 = 1, ANGLE2 = 2)
      PARAMETER    (IX = 1, IY = 2, IZ = 3)

      REAL          PI, PIBY2, RADDEG

      PARAMETER    (
     -              PI = 3.141592654,
     -              PIBY2 = PI / 2.0,
     -              RADDEG = 180.0 / PI
     -             )

      REAL          ANGLE, CALC, ATOM1(3), ATOM2(3), COSTH(2),
     -              INVMAT(3,3), INVTRN(3), MATRIX(3,3), NX, NY, NZ,
     -              SINTH(2), THETA(2), TRANSL(3), XYZ(3,3)

C---- Translation to origin is just the reverse of the coordinates of the
C     first atom
      TRANSL(IX) = ATOM1(IX)
      TRANSL(IY) = ATOM1(IY)
      TRANSL(IZ) = ATOM1(IZ)
      INVTRN(IX) = - ATOM1(IX)
      INVTRN(IY) = - ATOM1(IY)
      INVTRN(IZ) = - ATOM1(IZ)

C---- Translate the two atoms to place atom 1 at the origin
      XYZ(IX,1) = 0.0
      XYZ(IY,1) = 0.0
      XYZ(IZ,1) = 0.0
      XYZ(IX,2) = ATOM2(IX) - TRANSL(IX)
      XYZ(IY,2) = ATOM2(IY) - TRANSL(IY)
      XYZ(IZ,2) = ATOM2(IZ) - TRANSL(IZ)

C---- Calculate vector joining the two atoms
      NX = XYZ(IX,2)
      NY = XYZ(IY,2)
      NZ = XYZ(IZ,2)

C---- Calculate theta1 - the angle to rotate about the z-axis
      THETA(ANGLE1) = - ANGLE(NX,NY)

C---- Calculate theta2 - the angle to rotate about the x-axis to put
      CALC = NX * NX + NY * NY
      THETA(ANGLE2) = ANGLE(SQRT(CALC),NZ)

C---- Precalculate sine and cosine values for the angles
      COSTH(ANGLE1) = COS(THETA(ANGLE1))
      COSTH(ANGLE2) = COS(THETA(ANGLE2))
      SINTH(ANGLE1) = SIN(THETA(ANGLE1))
      SINTH(ANGLE2) = SIN(THETA(ANGLE2))
      IF (ABS(COSTH(ANGLE1)).LT.0.000001) COSTH(ANGLE1) = 0.0
      IF (ABS(COSTH(ANGLE2)).LT.0.000001) COSTH(ANGLE2) = 0.0
      IF (ABS(SINTH(ANGLE1)).LT.0.000001) SINTH(ANGLE1) = 0.0
      IF (ABS(SINTH(ANGLE2)).LT.0.000001) SINTH(ANGLE2) = 0.0

C---- Calculate the transformation matrix
      CALL CALMAT(COSTH,SINTH,MATRIX)

C---- Reverse the angles and the translation to get the inverse
C     matri
      SINTH(ANGLE1) = - SINTH(ANGLE1)
      SINTH(ANGLE2) = - SINTH(ANGLE2)

C---- Calculate the inverse transformation matrix
      CALL CALINV(COSTH,SINTH,INVMAT)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CALMAT  -  Calculate the 3 x 3 transformation matrix
C
C----------------------------------------------------------------------+---

      SUBROUTINE CALMAT(COSTH,SINTH,MAT)

CVAX      IMPLICIT NONE

      REAL          COSTH(2), MAT(3,3), SINTH(2)

C---- Calculate each of the terms in the transformation matrix
      MAT(1,1) =   COSTH(1) * COSTH(2)
      MAT(2,1) = - SINTH(1) * COSTH(2)
      MAT(3,1) =   SINTH(2)
      MAT(1,2) =   SINTH(1)
      MAT(2,2) =   COSTH(1)
      MAT(3,2) =   0.0
      MAT(1,3) = - COSTH(1) * SINTH(2)
      MAT(2,3) =   SINTH(1) * SINTH(2)
      MAT(3,3) =   COSTH(2)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CALINV  -  Calculate the 3 x 3 inverse matrix
C
C----------------------------------------------------------------------+---

      SUBROUTINE CALINV(COSTH,SINTH,MAT)

CVAX      IMPLICIT NONE

      REAL          COSTH(2), MAT(3,3), SINTH(2)

C---- Calculate each of the terms in the transformation matrix
      MAT(1,1) =   COSTH(1) * COSTH(2)
      MAT(2,1) = - SINTH(1)
      MAT(3,1) =   COSTH(1) * SINTH(2)
      MAT(1,2) =   SINTH(1) * COSTH(2)
      MAT(2,2) =   COSTH(1)
      MAT(3,2) =   SINTH(1) * SINTH(2)
      MAT(1,3) = - SINTH(2)
      MAT(2,3) =   0.0
      MAT(3,3) =   COSTH(2)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  FUNCTION ANGLE  -  Function to calculate angle between line from origin
C                     to supplied point (x,y), and the x-axis. The value
C                     returned is between 0 and 2 pi radians.
C
C----------------------------------------------------------------------+---

      REAL FUNCTION ANGLE(X,Y)

CVAX      IMPLICIT NONE

      REAL          ANG, PI, X, Y

      PARAMETER     (PI = 3.141592654)

C---- If both x and y ar close to zero, return zero
      IF (ABS(X).LT.0.0000001 .AND. ABS(Y).LT.0.0000001) THEN
         ANG = 0.0

C---- If x is very close to zero, then return pi/2 or 3pi/2, depending
C     on the y-value
      ELSE IF (ABS(X).LT.0.0000001) THEN
          IF (Y.LT.0.0) THEN
              ANG = 3.0 * PI / 2.0
          ELSE
              ANG =       PI / 2.0
          ENDIF

C---- Otherwise, if y is very close to zero, then return 0 or pi,
C     depending on x-value
      ELSE IF (ABS(Y).LT.0.0000001) THEN
          IF (X.LT.0.0) THEN
              ANG = PI
          ELSE
              ANG = 0.0
          ENDIF

C---- Otherwise, calculate the angle from arctan y/x
      ELSE
          ANG = ATAN(Y / X)
          IF (ANG.GT.0.0) THEN
              IF (Y.LT.0.0) ANG = ANG + PI
          ELSE
              IF (Y.LT.0.0) THEN
                  ANG = 2.0 * PI + ANG
              ELSE
                  ANG =       PI + ANG
              ENDIF
          ENDIF
      ENDIF
      ANGLE = ANG

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CALNGP  -  Calculate number of gap spheres to be placed
C                        between the given two atoms
C
C----------------------------------------------------------------------+---

      SUBROUTINE CALNGP(MAXDIA,SDIST,RADIUS,NLOOPS,STEPSZ,SPHRAD,STPOS,
     -    MULTIG)

CVAX      IMPLICIT NONE

      INTEGER       NDIAM, NLOOPS
      LOGICAL       MULTIG
      REAL          MAXDIA, RADIUS, SDIST, SPHRAD, STEPSZ, STPOS

C---- If placing only a single sphere (ie as in old SURFNET algorithm) or
C     gap between the two atoms is less than the maximum gap radius, then
C     fit only a single sphere between these two atoms
      IF (.NOT.MULTIG .OR. SDIST.LE.MAXDIA) THEN

C----     Define number of spheres as 1
          NLOOPS = 1

C----     Set step-size to zero
          STEPSZ = 0.0

C----     Calculate sphere radius (ie half the surface-to-surface distance
C         between the two atoms)
          SPHRAD = SDIST / 2.0

C---- Otherwise, determine how many spheres of maximum size can be placed
C     between these two atoms
      ELSE

C----     Calculate number of sphere diameters between the two atoms
          NDIAM = (SDIST - MAXDIA) / MAXDIA

C----     Calculate number of loops to go through
          NLOOPS = NDIAM + 2

C----     Calculate step-size
          STEPSZ = (SDIST - MAXDIA) / (NLOOPS - 1)

C----     Set sphere radius to the maximum
          SPHRAD = MAXDIA / 2.0
      ENDIF

C---- Calculate the start position for the first sphere
      STPOS = RADIUS + SPHRAD

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GENSPH  -  Generate a trial sphere at the next position
C
C----------------------------------------------------------------------+---

      SUBROUTINE GENSPH(ILOOP,VALID,SPHRAD,STEPSZ,STPOS,SINDEX,
     -    XYZ,STODST,MXATOM,NSTORE,IATOM,RADIUS,LSTCUT,CENTRE,MATRIX,
     -    TRANSL,INVMAT,INVTRN,MINRAD)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM

      INTEGER       IATOM, ILOOP, ISTORE, KATOM, LSTCUT, NSTORE,
     -              SINDEX(MXATOM)
      LOGICAL       VALID
      REAL          CENTRE(3), DIST, DIST2, DX, DY, DZ, FARDIS,
     -              INVMAT(3,3), INVTRN(3), LIMIT, MATRIX(3,3), MINRAD,
     -              RAD, RADIUS(MXATOM), SPHPOS, SPHRAD,
     -              STEPSZ, STODST(MXATOM), STPOS, TRANSL(3),
     -              XYZ(3,MXATOM), XYZ1(3), XYZNEW(3)

C---- Initialise flag
      VALID = .TRUE.

C---- Calculate the location of the gap-sphere (its x-coord)
      SPHPOS = STPOS + ILOOP * STEPSZ

C---- Initialise furthest distance at which an atom neighbouring our first
C     atom might still interact with the current gap sphere
      FARDIS = SPHPOS - RADIUS(IATOM) + SPHRAD

C---- Initialise atom-count for search for any other atoms penetrating
C     the current gap sphere
      LSTCUT = 0

C---- Loop through all atoms to see if any penetrate the gap sphere
      DO 500, ISTORE = NSTORE, 1, -1 

C----     Get next atom from the sorted list
          KATOM = SINDEX(ISTORE)

C----     Skip this atom if already know that it is too far away to
C         possibly interact with the gap sphere
          IF (STODST(KATOM).LT.FARDIS) THEN

C----         Transform the atom into our gap sphere's reference frame
              CALL MOVEAT(XYZ(1,KATOM),XYZ1,TRANSL)
              CALL TRANSF(XYZ1,XYZNEW,MATRIX)

C----         Get the atom's radius
              RAD = RADIUS(KATOM)

C----         Test if this atom's x, y, z coords are within range of the
C             gap sphere
              IF (XYZNEW(1) + RAD.GE.SPHPOS - SPHRAD .AND.
     -            XYZNEW(1) - RAD.LE.SPHPOS + SPHRAD .AND.
     -            XYZNEW(2) + RAD.GE.- SPHRAD .AND.
     -            XYZNEW(2) - RAD.LE.SPHRAD .AND.
     -            XYZNEW(3) + RAD.GE.- SPHRAD .AND.
     -            XYZNEW(3) - RAD.LE.SPHRAD) THEN

C----             Atom is in range, so calculate distance between it and
C                 the gap sphere
                  DX = XYZNEW(1) - SPHPOS
                  DY = XYZNEW(2)
                  DZ = XYZNEW(3)
                  DIST2 = DX * DX + DY * DY + DZ * DZ
                  LIMIT = SPHRAD + RADIUS(KATOM)
                  IF (DIST2.LT.LIMIT * LIMIT) THEN

C----                 Calculate the distance between this atom and the
C                     gap-sphere
                      DIST = SQRT(DIST2)

C----                 If the gap sphere is wholly within the atom, then
C                     discard altogether
                      IF (DIST.LT.RADIUS(KATOM)) THEN
                          VALID = .FALSE.
                          GO TO 999

C----                 If the atom penetrates the gap sphere, then adjust
C                     sphere's radius until it just touches this atom
                      ELSE IF (DIST.LT.SPHRAD + RADIUS(KATOM)) THEN
                          SPHRAD = DIST - RADIUS(KATOM)
                          FARDIS = SPHPOS - RADIUS(IATOM) + SPHRAD

C----                     Check that current gap-sphere size is not
C                         too small
                          IF (SPHRAD.LT.MINRAD) THEN

C----                         Discard this gap sphere
                              VALID = .FALSE.
                              GO TO 999

C----                     Otherwise, store atom that is in contact with
C                         the reduced gap sphere
                          ELSE
                              LSTCUT = KATOM
                          ENDIF
                      ENDIF
                  ENDIF
              ENDIF
          ENDIF
 500  CONTINUE

C---- If have reached here, then have a valid sphere, so perform inverse
C     tranformation on it to get it in the molecule's reference frame

C---- Store the untransformed coordinated for this gap sphere
      CENTRE(1) = SPHPOS
      CENTRE(2) = 0.0
      CENTRE(3) = 0.0

C---- Apply the inverse rotation and translation
      CALL TRANSF(CENTRE,XYZNEW,INVMAT)
      CALL MOVEAT(XYZNEW,CENTRE,INVTRN)

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE TRANSF  -  Apply the tranformation to the given coordinates
C
C----------------------------------------------------------------------+---

      SUBROUTINE TRANSF(XYZ,XYZNEW,M)

CVAX      IMPLICIT NONE

      REAL          M(3,3), XYZ(3), XYZNEW(3)

C---- Apply the tranformation
      XYZNEW(1) = M(1,1) * XYZ(1) + M(2,1) * XYZ(2) + M(3,1) * XYZ(3)
      XYZNEW(2) = M(1,2) * XYZ(1) + M(2,2) * XYZ(2) + M(3,2) * XYZ(3)
      XYZNEW(3) = M(1,3) * XYZ(1) + M(2,3) * XYZ(2) + M(3,3) * XYZ(3)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MOVEAT  -  Apply the translation to the given coordinates
C
C----------------------------------------------------------------------+---

      SUBROUTINE MOVEAT(XYZ,XYZNEW,TRANSL)

CVAX      IMPLICIT NONE

      REAL          TRANSL(3), XYZ(3), XYZNEW(3)

C---- Apply the tranformation
      XYZNEW(1) = XYZ(1) - TRANSL(1)
      XYZNEW(2) = XYZ(2) - TRANSL(2)
      XYZNEW(3) = XYZ(3) - TRANSL(3)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE STOSPH  -  Store gap-sphere as a pseudo atom
C
C----------------------------------------------------------------------+---

      SUBROUTINE STOSPH(NSPHRE,FREE,ATNUM,MXATOM,XYZ,RADIUS,ACTMAX,
     -    STOREK,CENTRE,SPHRAD,LSTCUT,GTOUCH,IATOM,JATOM,IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM

      INTEGER       ATNUM(MXATOM), FREE, IATOM, JATOM, LSTCUT, NSPHRE
      LOGICAL       GTOUCH(MXATOM), IFAIL
      REAL          ACTMAX, CENTRE(3), RADIUS(MXATOM), SPHRAD,
     -              STOREK(MXATOM), XYZ(3,MXATOM)

C---- Initialise variables
      IFAIL = .FALSE.

C---- Increment count of spheres and free spaces
      NSPHRE = NSPHRE + 1
      FREE = FREE + 1
      IF (FREE.GT.MXATOM) GO TO 900
      ATNUM(FREE) = -999999
      XYZ(1,FREE) = CENTRE(1)
      XYZ(2,FREE) = CENTRE(2)
      XYZ(3,FREE) = CENTRE(3)
      RADIUS(FREE) = SPHRAD
      ACTMAX = MAX(SPHRAD,ACTMAX)
      STOREK(FREE) = LOG (0.5) / (SPHRAD * SPHRAD)

C---- Mark last atom in contact with the current gap sphere
      IF (LSTCUT.NE.0) THEN
          GTOUCH(LSTCUT) = .TRUE.
      ELSE
          GTOUCH(IATOM) = .TRUE.
          GTOUCH(JATOM) = .TRUE.
      ENDIF

      GO TO 999

900   CONTINUE
      PRINT*, '*** Maximum number of atoms exceeded in generating',
     -    ' gap map: ', MXATOM
      GO TO 990

990   CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6-->
C**************************************************************************
C
C   SUBROUTINE MAPSPH  -  Routine to approximate the high-density regions
C                         of the given density file by spheres. The contour
C                         level at which the densities are approximated is
C                         100.0
C
C----------------------------------------------------------------------+---

      SUBROUTINE MAPSPH(ARRAY,ARSIZE,GRDSEP,OPOINT,VALMIN,IPROBE,IJKREL,
     -    INDEXP,DISGRD,MAXPTS,NIJK,MINREJ,MAXREJ,CLEVEL,IFAIL)

      INTEGER       ARSIZE, MAXPTS

      INTEGER       IJKREL(3,MAXPTS), INDEXP(MAXPTS), INPTS, IPOINT,
CHANGE v.1.6.1-->
C     -              IPROBE, NIJK, NX, NY, NZ, OPOINT(3)
     -              IPROBE, NIJK, NPTS, NX, NY, NZ, OPOINT(3)
CHANGE v.1.6.1<--
      LOGICAL       IFAIL
      REAL          ARRAY(ARSIZE), CLEVEL, DISGRD(MAXPTS), GRDSEP,
     -              MAXREJ, MINREJ, VALMIN(3)

C---- Initialise variables
      NX = OPOINT(1)
      NY = OPOINT(2)
      NZ = OPOINT(3)
CHANGE v.1.6.1-->
C      ARSIZE = NX * NY * NZ
      NPTS = NX * NY * NZ
CHANGE v.1.6.1<--

C---- Count the numbers of grid-points within the contour level
CHANGE v.1.6.1-->
C      CALL INCONT(ARRAY,ARSIZE,CLEVEL,INPTS)
      CALL INCONT(ARRAY,NPTS,CLEVEL,INPTS)
CHANGE v.1.6.1<--

C---- If there are any densities high enough, perform the
C     sphere-generation routines
      IF (INPTS.GT.0) THEN

C----     Calculate index of relative grid-points corresponding to larger
C         and larger sphere sizes
          CALL CALIDX(IJKREL,DISGRD,INDEXP,MAXPTS,NIJK,GRDSEP,MAXREJ,
     -        IFAIL)
          IF (IFAIL) GO TO 999

C----     Generate largest sphere at each grid-point
          CALL PLASPH(ARRAY,NX,NY,NZ,DISGRD,INDEXP,IJKREL,MAXPTS,NIJK,
     -        CLEVEL,GRDSEP,VALMIN,MINREJ,MAXREJ)

C----     Process the array to retain only those points at which the
C         trial spheres could be fitted
CHANGE v.1.6.1-->
C          DO 100, IPOINT = 1, ARSIZE
          DO 100, IPOINT = 1, NPTS
CHANGE v.1.6.1<--

C----         If point is above 220.0, then set to 200.0 plus radius 
C             (these being grid-points that can accommodate the
C             maximum-sized spheres)
              IF (ARRAY(IPOINT).GE.220.0) THEN
                  ARRAY(IPOINT) = ARRAY(IPOINT) - 20.0 

C----         Otherwise, grid-points marked 210.0 and above can accommodate
C             spheres between the minimum and maximum rejection sizes
              ELSE IF (ARRAY(IPOINT).GE.210.0) THEN
                  ARRAY(IPOINT) = - (ARRAY(IPOINT) - 10.0)

C----         Otherwise, zero the value
              ELSE
                  ARRAY(IPOINT) = 0.0
              ENDIF
 100      CONTINUE
      ENDIF

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INCONT  -  Count the numbers of grid-points inside and outside
C                        the required contour level
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INCONT(ARRAY,ARSIZE,CLEVEL,INPTS)

CVAX      IMPLICIT NONE

      INTEGER       ARSIZE, I, INPTS, OUTPTS
      REAL          ARRAY(ARSIZE), CLEVEL

C---- Initialise variables
      INPTS = 0
      OUTPTS = 0

C---- Loop over all the points in the array
      DO 200, I = 1, ARSIZE

C----     Adjust the value
          IF (ARRAY(I).GE.CLEVEL) THEN
              INPTS = INPTS + 1
          ELSE
              OUTPTS = OUTPTS + 1
          ENDIF
200   CONTINUE

C---- Show numbers of point inside and outside contour levels
      PRINT*
      PRINT*, '   Number of grid points within contours: ', INPTS
      PRINT*, '   Number of grid points outside contours:', OUTPTS
      PRINT*

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CALIDX  -  Calculate index of relative grid-points corresponding
C                        to larger and larger sphere sizes
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE CALIDX(IJKREL,DIST,INDEXP,MAXPTS,NIJK,GRDSEP,MAXRAD,
     -    IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       MAXPTS

      CHARACTER*22  PLINE
      INTEGER       I, IJKREL(3,MAXPTS), INDEXP(MAXPTS), ISWAP, J, K, N,
     -              NALL, NAPPRX, NIJK, NPTS
      LOGICAL       IFAIL
      REAL          D, DIST(MAXPTS), DISQRD, GRDSEP, MAXRAD, MXRAD2,
     -              VOLUME, X, Y, Y2, Z, Z2

C---- Initialise variables
      IFAIL = .FALSE.
      MXRAD2 = MAXRAD * MAXRAD
      NIJK = 0

C---- Calculate extent of array required to encompass the maximum sphere
      N = NINT(MAXRAD / GRDSEP + 1)
      NPTS = 2 * N + 1
      NALL = NPTS * NPTS * NPTS
      PRINT*, 'Maximum sphere size allowed', MAXRAD
      WRITE(PLINE,20) NPTS, NPTS, NPTS, NALL
 20   FORMAT(I3,' x',I3,' x',I3,' =',I7)

C---- Loop over all the grid-point, calculating their distance from the
C     origin
      DO 400, K = -N, N
          Z = K * GRDSEP
          Z2 = Z * Z
          DO 300, J= -N, N
              Y = J * GRDSEP
              Y2 = Y * Y
              DO 200, I = -N, N
                  X = I * GRDSEP

C----             Calculate the distance of this point from the origin
                  DISQRD = X * X + Y2 + Z2

C----             If this is within the maximum sphere, then store this
C                 point
                  IF (DISQRD.LE.MXRAD2) THEN
                      NIJK = NIJK + 1
                      IF (NIJK.GT.MAXPTS) GO TO 900
                      DIST(NIJK) = SQRT(DISQRD)
                      INDEXP(NIJK) = NIJK
                      IJKREL(1,NIJK) = I
                      IJKREL(2,NIJK) = J
                      IJKREL(3,NIJK) = K
                  ENDIF
 200          CONTINUE
 300      CONTINUE
 400  CONTINUE

C---- Write out number of points generated
      PRINT*, 'Number of reference grid-points generated', NIJK

C---- Sort the grid-points in descending distance from the origin
      CALL SHSORT(MAXPTS,DIST,NIJK,INDEXP)

C---- Adjust all the pointers so that they give the grid-points in
C     ascending distance from origin
      DO 500, I = 1, NIJK / 2
          ISWAP = INDEXP(NIJK - I + 1)
          INDEXP(NIJK - I + 1) = INDEXP(I)
          INDEXP(I) = ISWAP
 500  CONTINUE
      
      GO TO 999

C---- Errors
 900  CONTINUE
      PRINT*, '*** ERROR. Number of points, MAXPTS, insufficient to ',
     -    'encompass maximum sphere, MAXRAD:', MAXRAD
      VOLUME = (4.0 / 3.0) * 4.0 * ATAN(1.0) * MAXRAD * MAXRAD * MAXRAD
      NAPPRX = VOLUME / (GRDSEP * GRDSEP * GRDSEP)
      PRINT*, '***        Need approx.', NAPPRX, ' points'
      GO TO 990
 
C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PLASPH  -  Generate the largest sphere possible at each
C                        occupied grid position to encompass the required
C                        percentage of density points
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PLASPH(ARRAY,NX,NY,NZ,DIST,INDEXP,IJKREL,MAXPTS,NIJK,
     -    CLEVEL,GRDSEP,VALMIN,MINREJ,MAXREJ)

      INTEGER       MAXPTS, NX, NY, NZ

      INTEGER       IJKREL(3,MAXPTS), INDEXP(MAXPTS), IX, IY, IZ,
     -              NIJK, NPOINT
      LOGICAL       IFAIL, FITTED
      REAL          ARRAY(NX,NY,NZ), CLEVEL, DIST(MAXPTS), GRDSEP,
     -              MAXREJ, MINREJ, RADIUS, VALMIN(3), X, Y, Z

C---- Initialise variables
      IFAIL = .FALSE.
      NPOINT = 0

C---- Loop through all the grid-points in the array
      DO 300, IZ = 1, NZ

C----     Calculate z-coordinate
          Z = VALMIN(3) + (IZ - 1) * GRDSEP

C----     Loop over y
          DO 200, IY = 1, NY

C----         Calculate y-coordinate
              Y = VALMIN(2) + (IY - 1) * GRDSEP

C----         Loop over x
              DO 100, IX = 1, NX

C----             Calculate x-coordinate
                  X = VALMIN(1) + (IX - 1) * GRDSEP

C----             If grid-point over the contour level, grow a sphere here
                  IF (ARRAY(IX,IY,IZ).GE.CLEVEL) THEN

C----                 Generate largest sphere possible at this point
                      CALL GROSPH(ARRAY,NX,NY,NZ,IX,IY,IZ,DIST,INDEXP,
     -                    IJKREL,MAXPTS,NIJK,CLEVEL,GRDSEP,RADIUS,
     -                    FITTED)

C----                 If maximum sphere fitted at this point, mark the point
                      IF (FITTED) THEN

C----                     Flag this grid-point as potential sphere-fit point
                          ARRAY(IX,IY,IZ) = 220.0 + MAXREJ
                          NPOINT = NPOINT + 1

C----                 Otherwise, if sphere between the maximum and minimum,
C                     flag this point accordingly
                      ELSE IF (RADIUS.GE.MINREJ) THEN
                          ARRAY(IX,IY,IZ) = 210.0 + RADIUS
                      ENDIF
                  ENDIF
 100          CONTINUE
 200      CONTINUE
 300  CONTINUE

C---- Print details of fitting-points found
      PRINT*
      PRINT*, 'Total number of sphere-fitting points found:', NPOINT

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GROSPH  -  Grow a sphere at the current grid-point
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GROSPH(ARRAY,NX,NY,NZ,I,J,K,DIST,INDEXP,IJKREL,MAXPTS,
     -    NIJK,CLEVEL,GRDSEP,RADIUS,FITTED)

      INTEGER       MAXPTS, NX, NY, NZ

      INTEGER       I, IENTRY, IJKREL(3,MAXPTS), INDEXP(MAXPTS), IPT,
     -              IX, IY, IZ, J, JENTRY, K, NIJK
      LOGICAL       DONE, ENDSPH, FITTED, GONOUT, GOTMAX, VALID
      REAL          ARRAY(NX,NY,NZ), CLEVEL, DIST(MAXPTS), GRDSEP,
     -              MNOVER, NEARVL, RADIUS, RADLST, SPHRAD, VOLFAC

C---- Initialise variables
      DONE = .FALSE.
      FITTED = .FALSE.
      GONOUT = .FALSE.
      GOTMAX = .FALSE.
      IPT = 0
      MNOVER = 200.0
      RADIUS = 0.0
      RADLST = 0.0
      VOLFAC = GRDSEP * GRDSEP * GRDSEP

C---- Initialise minimum value of first below-level grid-point
      NEARVL = CLEVEL

C---- Loop until largest sphere found, or maximum sphere reached
 100  CONTINUE

C----     Increment grid-point and get its corresponding entry number
          IPT = IPT + 1
          IENTRY = INDEXP(IPT)
          SPHRAD = DIST(IENTRY)

C----     Use the relative grid-position to determine the actual
C         grid position
          IX = I + IJKREL(1,IENTRY)
          IY = J + IJKREL(2,IENTRY)
          IZ = K + IJKREL(3,IENTRY)

C----     Check that none of these is off the end of the grid
          VALID = .TRUE.
          IF (IX.LT.1 .OR. IY.LT.1 .OR. IZ.LT.1 .OR.
     -        IX.GT.NX .OR. IY.GT.NY .OR. IZ.GT.NZ ) VALID = .FALSE.

C----     If the grid-point is within the array, check whether it is
C         inside the contour or not
          IF (VALID) THEN

C----         If density value has dropped below the contour level, will
C             need to stop when we finish current shell
              IF (ARRAY(IX,IY,IZ).LT.CLEVEL) THEN

C----             Set flag to indicate that have popped outside the contour
                  GONOUT = .TRUE.

C----             If this is the smallest outside value so far, then store
                  IF (ARRAY(IX,IY,IZ).LT.NEARVL) THEN
                      NEARVL = ARRAY(IX,IY,IZ)
                  ENDIF

C----         Otherwise, is this is the lowest above-contour-level value
C             in this shell, then store
              ELSE IF (ARRAY(IX,IY,IZ).LT.MNOVER) THEN
                  MNOVER = ARRAY(IX,IY,IZ)
              ENDIF
          ENDIF

C----     Check whether this point represents the last point for a
C         given sphere radius
          ENDSPH = .FALSE.

C----     If this is the last point, then have come to the end of
C         the maximum sphere
          IF (IPT.GE.NIJK) THEN
              ENDSPH = .TRUE.
              GOTMAX = .TRUE.

C----     Otherwise, check sphere-radius of the following point
          ELSE

C----         Get the entry for the next point
              JENTRY = INDEXP(IPT + 1)

C----         If it corresponds to a greater sphere, then have closed
C             another shell
              IF (DIST(JENTRY).GT.DIST(IENTRY) + 0.000001) THEN
                  ENDSPH = .TRUE.
              ENDIF
          ENDIF

C----     If have closed off another shell, store previous and current
C         shell radii
          IF (ENDSPH) THEN

C----         Store previous and current shell radii
              RADLST = RADIUS
              RADIUS = DIST(IENTRY)

C----         Test whether have crossed the contour surface
              IF (GONOUT) THEN

C----             Calculate the effective radius of the sphere by
C                 interpolating between the last two shell radii
                  RADIUS = RADLST
     -                + (RADIUS - RADLST) * (MNOVER - CLEVEL)
     -                / (MNOVER - NEARVL)

C----             Set flag to indicate that required sphere generated
                  DONE = .TRUE.
              ENDIF

C----         Reset the minimum "over-value"
              MNOVER = 200.0
          ENDIF

C---- If still more points to search, then loop back
      IF (.NOT.DONE .AND. IPT.LT.NIJK) GO TO 100

C---- If have looped through all the points, then have been able to fit
C     the maximum sphere in
      IF (GOTMAX .AND. .NOT.GONOUT) THEN
          FITTED = .TRUE.
      ELSE
          FITTED = .FALSE.
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SPHILT  -   Filter out all but the largest clusters of grid
C                         points
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE SPHILT(ARRAY,ARSIZE,INDEXA,MAXIND,VOL,MAXVOL,NTOP,
     -    NATOMS,VOLCUT,MAXREJ)

CVAX      IMPLICIT NONE

      INTEGER       ARSIZE, MAXIND, MAXVOL

      INTEGER       INDEXA(MAXIND), IPOINT, IVALUE, IVOL, NATOMS, NTOP,
     -              NTOTAL, NVOLS, NWANT, VOLNUM
      LOGICAL       WANTED
      REAL          ARRAY(ARSIZE), MAXREJ, VOL(MAXVOL), VOLCUT

C---- Initialise variables
      NTOTAL = 0
      NVOLS = 0
      NWANT = 0
      VOLNUM = 0

C---- Loop through the volumes in descending order to determine the point
C     at which they cease to be significant
      DO 100, IVOL = 1, NTOP

C----     If this volume is still above the cut-off, move the stopping point
C         to here
          IF (VOL(INDEXA(IVOL)).GT.VOLCUT) THEN
              NVOLS = IVOL
          ENDIF
 100  CONTINUE

C---- Loop through all the array points
      DO 800, IPOINT = 1, ARSIZE

C----     Get the integer part of the array value
          IVALUE = ARRAY(IPOINT)

C----     Initialise flag
          WANTED = .FALSE.

C----     If non-zero then it corresponds to a volume-cluster
          IF (IVALUE.GT.0) THEN

C----         Loop through all the top volumes to see if this is among
C             them
              DO 200, IVOL = 1, NVOLS

C----             If volume agrees, then want this grid-point
                  IF (IVALUE.EQ.INDEXA(IVOL)) THEN
                      VOLNUM = IVOL
                      WANTED = .TRUE.
                  ENDIF
 200          CONTINUE

C----         Increment count of marked grid-points
              NTOTAL = NTOTAL + 1
          ENDIF

C----     If grid-point is wanted, then save as 200 plus the volume number,
C         plus a tenth of the sphere radius
          IF (WANTED) THEN
              ARRAY(IPOINT) = 200.0 + VOLNUM + MAXREJ / 10.0
              NWANT = NWANT + 1

C----     If no sphere at this grid-point, then zero it
          ELSE IF (ARRAY(IPOINT).GE.0.0) THEN
              ARRAY(IPOINT) = 0.0
          ENDIF
 800  CONTINUE

C---- Show number of grid-point filtered out
      PRINT 820, NWANT, NTOTAL
 820  FORMAT('Number of grid-points retained: ',I8,'  out of ',I8)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE ADDBAK  -  Add back the spheres that are between the minimum
C                        and maximum rejection limits and are adjoining a
C                        valid volume cluster
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE ADDBAK(ARRAY,NX,NY,NZ,MINREJ,MAXREJ)

      INTEGER       NPTS

COUT      PARAMETER    (NPTS = 6)
      PARAMETER    (NPTS = 26)

      INTEGER       NX, NY, NZ

      INTEGER       ADJPNT(3,NPTS), CNTMAX, IPT, IVOL, IX, IXADJ, IY,
     -              IYADJ, IZ, IZADJ, NSMALL, NVOLS, OLDVOL,
     -              VCOUNT(NPTS), VMOST, VNUM, VOLNO(NPTS)
      REAL          ARRAY(NX,NY,NZ), MAXREJ, MINREJ, RADIUS

COUT      DATA ADJPNT /  0,  0,  1,  0,  0, -1,
COUT     -               0,  1,  0,  0, -1,  0,
COUT     -               1,  0,  0, -1,  0,  0 /
      DATA ADJPNT /  -1, -1,  0, -1, -1,  1, -1,  0, -1, -1,  0,  0,  
     -               -1,  0,  1, -1,  1, -1, -1,  1,  0, -1,  1,  1,  
     -                0, -1, -1,  0, -1,  0,  0, -1,  1,  0,  0, -1,  
     -               -1, -1, -1,  0,  0,  1,  0,  1, -1,  0,  1,  0,  
     -                0,  1,  1,  1, -1, -1,  1, -1,  0,  1, -1,  1,  
     -                1,  0, -1,  1,  0,  0,  1,  0,  1,  1,  1, -1,  
     -                1,  1,  0,  1,  1,  1 /

C---- Initialise variables
      NSMALL = 0

C---- Loop through all the grid-points in the array
      DO 800, IZ = 1, NZ

C----     Loop over y
          DO 700, IY = 1, NY

C----         Loop over x
              DO 600, IX = 1, NX

C----             If grid-value is negative, then it'll contain one of
C                 the smaller spheres
                  IF (ARRAY(IX,IY,IZ).LT.0.0) THEN

C----                 Extract its radius
                      RADIUS = - 1000.0 * ARRAY(IX,IY,IZ) - 200.0

C----                 Initialise counts
                      NVOLS = 0
                      CNTMAX = 0
                      VMOST = 0

C----                 Loop over the adjacent grid points
                      DO 500, IPT = 1, NPTS

C----                     Get the subscript of the adjacent grid-point
                          IXADJ = IX + ADJPNT(1,IPT)
                          IYADJ = IY + ADJPNT(2,IPT)
                          IZADJ = IZ + ADJPNT(3,IPT)


C----                     Process only if valid
                          IF (IXADJ.GT.0 .AND. IXADJ.LE.NX .AND.
     -                        IYADJ.GT.0 .AND. IYADJ.LE.NY .AND.
     -                        IZADJ.GT.0 .AND. IZADJ.LE.NZ) THEN

C----                         If this is a volume grid-point, get the
C                             volume
                              IF (ARRAY(IXADJ,IYADJ,IZADJ).GT.0.0) THEN

C----                             Extract the volume number
                                  VNUM = NINT(ARRAY(IXADJ,IYADJ,IZADJ)
     -                                - 200.0)

C----                             Initialise flag
                                  OLDVOL = 0

C----                             Loop through all the stored volumes
C                                 to see if we already have this one
                                  DO 200, IVOL = 1, NVOLS
                                      IF (VOLNO(IVOL).EQ.VNUM) THEN
                                          OLDVOL = IVOL
                                          GO TO 300
                                      ENDIF
 200                              CONTINUE

C----                             If volume not found, then create a 
C                                 new entry for it
                                  IF (OLDVOL.EQ.0) THEN

C----                                 Increment count of volumes
                                      NVOLS = NVOLS + 1
                                      OLDVOL = NVOLS

C----                                 Zero current count
                                      VCOUNT(OLDVOL) = 0

C----                                 Store volume number
                                      VOLNO(OLDVOL) = VNUM
                                  ENDIF

C----                             Increment volume's count
 300                              CONTINUE
                                  VCOUNT(OLDVOL) = VCOUNT(OLDVOL) + 1

C----                             If this is the most common so far,
C                                 then store
                                  IF (VCOUNT(OLDVOL).GT.CNTMAX) THEN

C----                                 Store most common adjoining volume
                                      CNTMAX = VCOUNT(OLDVOL)
                                      VMOST = VOLNO(OLDVOL)
                                  ENDIF
      
                              ENDIF
                          ENDIF
 500                  CONTINUE

C----                 If there is a most commonly occurring volume
C                     neighbouring this grid-point, then store
                      IF (VMOST.GT.0) THEN

C----                     Encode the volume number and radius in the
C                         grid-point value
                          ARRAY(IX,IY,IZ) = - (200.0 + VMOST
     -                        + RADIUS / 10.0)

C----                     Increment count of smaller spheres saved
                          NSMALL = NSMALL + 1

C----                 Otherwise, zero the grid-point
                      ELSE
                          ARRAY(IX,IY,IZ) = 0.0
                      ENDIF
                  ENDIF
 600          CONTINUE
 700      CONTINUE
 800  CONTINUE

C---- Show the number of smaller-sized spheres added to current gap volumes
      PRINT*, 'Number of smaller-sized spheres added', NSMALL

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE REGEN  -  Generate a sphere for every high-value grid-point
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE REGEN(ARRAY,NX,NY,NZ,NSPHER,SPHRAD,ATNUM,SPHLOC,STOREK,
     -    MAXSPH,CLEVEL,GRDSEP,VALMIN,IFAIL)

      INTEGER       MAXSPH, NX, NY, NZ

      INTEGER       ATNUM(MAXSPH), IX, IY, IZ, NSPHER, VOLNUM
      LOGICAL       IFAIL
      REAL          ARRAY(NX,NY,NZ), CLEVEL, GRDSEP, RADIUS,
     -              SPHLOC(3,MAXSPH), SPHRAD(MAXSPH), STOREK(MAXSPH),
     -              VALMIN(3), VALUE, X, Y, Z

C---- Initialise variables
      IFAIL = .FALSE.
      NSPHER = 0

C---- Loop through all the grid-points in the array
      DO 300, IZ = 1, NZ

C----     Calculate z-coordinate
          Z = VALMIN(3) + (IZ - 1) * GRDSEP

C----     Loop over y
          DO 200, IY = 1, NY

C----         Calculate z-coordinate
              Y = VALMIN(2) + (IY - 1) * GRDSEP

C----         Loop over x
              DO 100, IX = 1, NX

C----             Calculate x-coordinate
                  X = VALMIN(1) + (IX - 1) * GRDSEP

C----             Get the absolute value of the grid-point
                  VALUE = ABS(ARRAY(IX,IY,IZ))

C----             If grid-point over the contour level, place a sphere here
                  IF (VALUE.GE.200.0) THEN

C----                 Extract the volume to which the sphere belongs and
C                     its radius
                      VALUE = VALUE - 200.0
                      VOLNUM = NINT(VALUE)
                      RADIUS = 10.0 * (VALUE - VOLNUM)

C----                 Increment sphere-count
                      NSPHER = NSPHER + 1
                      IF (NSPHER.GT.MAXSPH) GO TO 900

C----                 Store the location of this point and the
C                     sphere radius
                      SPHLOC(1,NSPHER) = X
                      SPHLOC(2,NSPHER) = Y
                      SPHLOC(3,NSPHER) = Z

C----                 Identify as a gap sphere
                      ATNUM(NSPHER) = -999999

C----                 Store the radius
                      SPHRAD(NSPHER) = RADIUS

C----                 Store the volume number 
                      STOREK(NSPHER) = VOLNUM
                  ENDIF
 100          CONTINUE
 200      CONTINUE
 300  CONTINUE

C---- Print details of spheres generated
      PRINT*
      PRINT*, 'Total number of regenerated spheres:', NSPHER

      GO TO 999

C---- Errors
 900  CONTINUE
      PRINT*, '*** ERROR. Maximum number of allowed spheres ',
     -    'exceeded:', MAXSPH
      GO TO 990
 

C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE RECVOL  -  Recalculate the gap volumes with the smaller
C                        spheres added back inm
C
C----------------------------------------------------------------------+---

      SUBROUTINE RECVOL(ARRAY,MAXARR,NX,NY,NZ,GRDSEP,SAVMIN,SAVMAX,
     -    MXATOM,NGAPS,XYZ,SPHRAD,VOLNUM,NTOP,VOL,MAXVOL,INDEXA)

CVAX      IMPLICIT NONE

      INTEGER       MAXARR, MXATOM, MAXVOL

      INTEGER       GRPTS, IATOM, ICOORD, INDEXA(MAXVOL), IPOS, IVOL,
     -              JVOL, NATS, NGAPS, NSIZE, NTOP, NUSED, NX, NY, NZ,
     -              TOPVOL
      LOGICAL       ENGMAP, NUMCNT, SUMDEN
      REAL          ARAD, ARRAY(MAXARR), ASTK, BVALUE, COFG(3), GAPVOL,
     -              GRDSEP, MAPMAX, MAPMIN, SAVMAX(3), SAVMIN(3),
     -              SPHRAD(MXATOM), VALMAX(3), VALMIN(3),
     -              VOL(MAXVOL), VOLNUM(MXATOM), XYZ(3,MXATOM)

C---- Initialise variables
      NSIZE = NX * NY * NZ
      ENGMAP = .FALSE.
      NUMCNT = .FALSE.
      SUMDEN = .FALSE.
      DO 50, ICOORD = 1, 3
          VALMIN(ICOORD) = SAVMIN(ICOORD)
          VALMAX(ICOORD) = SAVMAX(ICOORD)
 50   CONTINUE
      TOPVOL = 0

C---- Loop over all the volumes
      DO 800, IVOL = 1, NTOP

C----     Initialise grid array
          DO 100, IPOS = 1, MAXARR
              ARRAY(IPOS) = 0.0
 100      CONTINUE

C----     Initialise count of atoms for this volume
          GAPVOL = 0.0
          NATS = 0

C----     Loop over all the gap spheres
          DO 300, IATOM = 1, NGAPS

C----         If sphere belongs to current volume, then use it
              IF (VOLNUM(IATOM).EQ.IVOL) THEN

C----             Get the radius of the current sphere
                  ARAD = SPHRAD(IATOM)
                  ASTK = - LOG(2.0) / (ARAD * ARAD)

C----             Update array with current sphere
                  CALL GRID(ARRAY,NX,NY,NZ,XYZ(1,IATOM),ASTK,ARAD,
     -                GRDSEP,VALMIN,NUMCNT,SUMDEN,ENGMAP,BVALUE,NUSED,
     -                GRPTS,MAPMIN,MAPMAX)

C----             Increment atom count
                  NATS = NATS + 1
              ENDIF
 300      CONTINUE

C----     Scale all the grid-points in the map
          DO 500, IPOS = 1, NSIZE
              ARRAY(IPOS) = 200.0 * ARRAY(IPOS)
 500      CONTINUE

C----     Calculate the map volume
          CALL GETVOL(ARRAY,NSIZE,NX,NY,NZ,GRDSEP,VALMIN,GAPVOL,COFG)

C----     Store the gap volume
          VOL(IVOL) = GAPVOL
          INDEXA(IVOL) = IVOL
          IF (GAPVOL.GT.0.0) TOPVOL = IVOL
 800  CONTINUE

C---- Sort all volumes by size
      IF (TOPVOL.GT.1) CALL SHSORT(MAXVOL,VOL,TOPVOL,INDEXA)

C---- Convert the index pointers into ranks for quick look-up
      DO 1000, IVOL = 1, NTOP

C----     Get the volume at this rank
          JVOL = INDEXA(IVOL)

C----     Store it in the array
          INDEXA(NTOP + JVOL) = IVOL
 1000 CONTINUE

C---- Retrieve the rank pointers
      DO 1100, IVOL = 1, NTOP

C----     Get the rank of this volume
          INDEXA(IVOL) = INDEXA(NTOP + IVOL)
 1100 CONTINUE

C---- Loop over all the gap spheres to reassign volumes, if necessary
      DO 1200, IATOM = 1, NGAPS

C----     Get this atom's current volume number
          IVOL = VOLNUM(IATOM)

C----     Replace it with the current rank
          VOLNUM(IATOM) = INDEXA(IVOL)
 1200 CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C  SUBROUTINE GAPSRT - Presort the gap spheres according to size, and
C                      determine where the first sphere above the rejection
C                      cut-off is
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GAPSRT(MXATOM,VOLNUM,INDEXA,MAXIND,FSTGAP,NATOMS,NGAPS)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM, MAXIND

      INTEGER       FSTGAP, IATOM, IGAP, INDEXA(MAXIND), NATOMS, NGAPS
      REAL          VOLNUM(MXATOM)

C---- Get number of gap spheres generated
      NGAPS = NATOMS - FSTGAP + 1

C---- Initialise the index of pointer
      DO 400, IGAP = 1, NGAPS
          IATOM = FSTGAP + IGAP - 1
          INDEXA(IGAP) = IATOM
 400  CONTINUE

C---- Perform the shell sort
      IF (NGAPS.GT.1) THEN
          CALL SHSORT(MXATOM,VOLNUM,NGAPS,INDEXA)
      ENDIF

C---- Loop through the sorted list to get the first sphere above the
C     rejection limit
COUT      DO 800, IGAP = 1, NGAPS
COUT          IATOM = INDEXA(IGAP)

C----     If this is the first over the rejection limit, then store
C         which gap-position it occurs at
COUT          IF (RADIUS(IATOM).GE.MINREJ) THEN
COUT              NOVER = IGAP
COUT          ENDIF
COUT 800  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRIGAP  -  Write out all the gap spheres in order of volume
C                        to which they belong
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WRIGAP(MXATOM,NATOMS,NGAPS,XYZ,VOLNUM,RADIUS,INDEXA,
     -    MAXIND)

CVAX      IMPLICIT NONE

      INTEGER       MAXIND, MXATOM

      INTEGER       ATOMNO, I, IATOM, ICOUNT, IGAP,
     -              INDEXA(MAXIND), IPOINT, IRES, NATOMS, NGAPS
      REAL          RADIUS(MXATOM), VOLNUM(MXATOM), XYZ(3,MXATOM)

C---- Initialise variables
      ATOMNO = 0
      ICOUNT = 0
      IRES = 1

C---- Open output spheres.pdb file
      OPEN(UNIT=11, FILE='spheres.pdb', STATUS='UNKNOWN',
     -      FORM='FORMATTED',ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Loop over all the gap spheres
      DO 800, IPOINT = NGAPS, 1, -1

C----     Get the gap number
          IGAP = INDEXA(IPOINT)
          IATOM = IGAP

C----     Increment atom count
          ATOMNO = ATOMNO + 1
          ICOUNT = ICOUNT + 1
          IF (ICOUNT.GT.10) THEN
              ICOUNT = 1
              IRES = IRES + 1
          ENDIF
          IRES = VOLNUM(IATOM)

C----     Write to output spheres.pdb file
          WRITE(11,220) ATOMNO, IRES,
     -         (XYZ(I,IATOM), I = 1, 3), RADIUS(IATOM)
 220      FORMAT('ATOM  ',I5,1X,' C  ',1X,'SPH',2X,I4,4X,3F8.3,
     -         '  1.00',F6.2)
 800  CONTINUE

C---- Close the output file
      CLOSE(11)

      GO TO 999

C---- Fatal error
900   CONTINUE
      PRINT*, '*** Error opening clusters.pdb output file'

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C     SUBROUTINE WRITOP  -  Write out all the required number of high-
C                           volume gap regions
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRITOP(ARRAY,MAXARR,NX,NY,NZ,GRDSEP,SAVMIN,SAVMAX,
     -    FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,MXATOM,NGAPS,XYZ,SPHRAD,
     -    VOLNUM,INDEXA,MAXIND,ONEGAP,NTOPGP,WNTIDX,NEXTAT)

CVAX      IMPLICIT NONE

      INTEGER       MAXARR, MAXIND, MXATOM

      CHARACTER*1   FILTYP
      CHARACTER*5   GAPNAM
      CHARACTER*60  TITLE
      CHARACTER*120 FILCNT, FILDEN, FILGRD, FILMBK, FILSRF
      INTEGER       GRPTS, IATOM, IATYPE, ICOORD, ICOUNT, IFRAG, IGAP,
     -              INDEXA(MAXIND), IPOINT, IPOS, IUNIT, IVOL, LSTVOL,
     -              NEXTAT, NGAPS, NPOINT(3), NSIZE, NTOPGP, NUSED, NX,
     -              NXTATM, NY, NZ
      LOGICAL       ENGMAP, FROMAP, IFAIL, INSMAP, NOMESS, NOPNT,
     -              NOTZER, NUMCNT, ONEGAP, QUAMAP, RAWDAT, SUMDEN,
     -              SYBMAP, WNTIDX
      REAL          ARAD, ARRAY(MAXARR), ASTK, BVALUE, COFG(3), FRGFRQ,
     -              GAPVOL, GRDSEP, MAPMAX, MAPMIN, MFACTR, SAVMAX(3),
     -              SAVMIN(3), SPHRAD(MXATOM), VALMAX(3), VALMIN(3),
     -              VOLNUM(MXATOM), XYZ(3,MXATOM)

C---- Initialise variables
      FILTYP = 'S'
      FRGFRQ = 0.0
      IATYPE = 0
      ICOUNT = 0
      IFRAG = 0
      IUNIT = 10
      LSTVOL = 0
      MFACTR = 1.0
      NOMESS = .TRUE.
      NOPNT = .FALSE.
      NOTZER = .FALSE.
      NPOINT(1) = NX
      NPOINT(2) = NY
      NPOINT(3) = NZ
      NSIZE = NX * NY * NZ
      NXTATM = NEXTAT
      RAWDAT = .TRUE.
      DO 50, ICOORD = 1, 3
          VALMIN(ICOORD) = SAVMIN(ICOORD)
          VALMAX(ICOORD) = SAVMAX(ICOORD)
 50   CONTINUE

C---- Initialise grid array
      DO 100, IPOS = 1, MAXARR
          ARRAY(IPOS) = 0.0
 100  CONTINUE

C---- Loop over all the gap spheres
      DO 800, IPOINT = NGAPS, 1, -1

C----     Get the gap number
          IGAP = INDEXA(IPOINT)
          IATOM = IGAP

C----     Get the volume to which this sphere belongs
          IVOL = VOLNUM(IATOM)

C----     Check whether volume number has changed, or this is the last
C         sphere
          IF (IVOL.NE.LSTVOL .OR. IPOINT.EQ.1) THEN

C----         If have a previous volume to be written out, then do so
              IF (LSTVOL.NE.0 .AND. IPOINT.NE.1) THEN

C----             Scale all the grid-points in the map
                  DO 300, IPOS = 1, NSIZE
                      ARRAY(IPOS) = 200.0 * ARRAY(IPOS)
 300              CONTINUE

C----             Calculate the map volume
                  CALL GETVOL(ARRAY,NSIZE,NPOINT(1),NPOINT(2),NPOINT(3),
     -                GRDSEP,VALMIN,GAPVOL,COFG)

C----             Write out to volumes file, gaps.vol
                  NXTATM = NXTATM + 1
                  WRITE(16,340) NXTATM, 'GAP', LSTVOL,
     -                (COFG(ICOORD), ICOORD = 1, 3), GAPVOL
 340              FORMAT('HETATM',I5,'  C   ',A3,2X,I4,4X,3F8.3,
     -                 '  1.00','  0.00',2X,F12.3)

C----             If gap regions are each to be written out to a separate
C                 gapxx.srf file, then write out in all formats required
                  IF ((ONEGAP .AND. LSTVOL.EQ.NTOPGP) .OR.
     -                LSTVOL.LE.NTOPGP) THEN
                      CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,
     -                    FILTYP,LSTVOL,IFRAG,IATYPE,ICOUNT,FRGFRQ,
     -                    FILCNT,FILDEN,FILGRD,FILMBK,FILSRF,IUNIT,
     -                    FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,VALMIN,
     -                    VALMAX,GRDSEP,RAWDAT,MFACTR,NOTZER,NOMESS,
     -                    NOPNT,IFAIL)
                  ENDIF
              ENDIF

C----         If volume higher than required, end here
              IF (IVOL.GT.NTOPGP .AND. .NOT.WNTIDX) GO TO 999

C----         Initialise new array
              IF (IVOL.NE.LSTVOL) THEN
                  DO 400, IPOS = 1, MAXARR
                      ARRAY(IPOS) = 0.0
 400              CONTINUE
                  BVALUE = 0.0
                  ENGMAP = .FALSE.
                  GRPTS = 0
                  ICOUNT = 0
                  MAPMIN = 999999.9
                  MAPMAX = -999999.9
                  NPOINT(1) = NX
                  NPOINT(2) = NY
                  NPOINT(3) = NZ
                  NUSED = 0
                  NUMCNT = .FALSE.
                  SUMDEN = .FALSE.
                  DO 500, ICOORD = 1, 3
                      VALMIN(ICOORD) = SAVMIN(ICOORD)
                      VALMAX(ICOORD) = SAVMAX(ICOORD)
 500              CONTINUE

C----             Form the output file names for the new map
                  WRITE(GAPNAM,520) IVOL
 520              FORMAT('gap',I2.2)
                  FILCNT = GAPNAM // '.cnt'
                  FILDEN = GAPNAM // '.den'
                  FILGRD = GAPNAM // '.grd'
                  FILMBK = GAPNAM // '.mbk'
                  FILSRF = GAPNAM // '.srf'
              ENDIF

C----         Save current volume number
              LSTVOL = IVOL
          ENDIF

C----     Get the radius of the current sphere
          ARAD = SPHRAD(IATOM)
          ASTK = - LOG(2.0) / (ARAD * ARAD)

C----     Update array with current sphere
          CALL GRID(ARRAY,NX,NY,NZ,XYZ(1,IATOM),ASTK,ARAD,GRDSEP,
     -        VALMIN,NUMCNT,SUMDEN,ENGMAP,BVALUE,NUSED,GRPTS,
     -        MAPMIN,MAPMAX)

C----     Increment atom count
          ICOUNT = ICOUNT + 1
 800  CONTINUE

C---- Write out the final map, if have one
      IF (LSTVOL.NE.0) THEN

C----     Scale all the grid-points in the map
          DO 900, IPOS = 1, NSIZE
              ARRAY(IPOS) = 200.0 * ARRAY(IPOS)
 900      CONTINUE

C----     Calculate the map volume
          CALL GETVOL(ARRAY,NSIZE,NPOINT(1),NPOINT(2),NPOINT(3),
     -        GRDSEP,VALMIN,GAPVOL,COFG)

C----     Write out to volumes file, gaps.vol
          NXTATM = NXTATM + 1
          WRITE(16,340) NXTATM, 'GAP', LSTVOL,
     -        (COFG(ICOORD), ICOORD = 1, 3), GAPVOL

C----     Write out the map
          IF ((ONEGAP .AND. LSTVOL.EQ.NTOPGP) .OR.
     -        LSTVOL.LE.NTOPGP) THEN
              CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,FILTYP,
     -            LSTVOL,IFRAG,IATYPE,ICOUNT,FRGFRQ,FILCNT,FILDEN,
     -            FILGRD,FILMBK,FILSRF,IUNIT,FROMAP,INSMAP,QUAMAP,
     -            SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,RAWDAT,MFACTR,
     -            NOTZER,NOMESS,NOPNT,IFAIL)
          ENDIF
      ENDIF

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6-->
C**************************************************************************
C
C  SUBROUTINE GETVOL  -  Calculate the total volume of current gap region
C
C----------------------------------------------------------------------+--- 


      SUBROUTINE GETVOL(ARRAY,NPTS,NX,NY,NZ,GRDSEP,VALMIN,GAPVOL,COFG)

CVAX      IMPLICIT NONE

      REAL          LIMIT1, LIMIT2
      PARAMETER    (
     -              LIMIT1 =  85.0,
     -              LIMIT2 = 125.0
     -             )

      INTEGER       I, ILOC, J, K, NPTS

      INTEGER       ICOORD, IPT, NCOORD, NX, NY, NZ
      REAL          ARRAY(NPTS), COFG(3), GAPVOL, GRDSEP, VALMIN(3),
     -              VOLADJ, VOLFAC, X, Y, Z

C---- Initialise variables
      GAPVOL = 0.0
      VOLFAC = GRDSEP * GRDSEP * GRDSEP
      NCOORD = 0
      DO 100, ICOORD = 1, 3
          COFG(ICOORD) = 0.0
 100  CONTINUE

C---- Calculate the volume of the current gap region
      DO 500, IPT = 1, NPTS
          IF (ARRAY(IPT).GT.LIMIT1) THEN
              IF (ARRAY(IPT).GT.LIMIT2) THEN
                  GAPVOL = GAPVOL + VOLFAC
              ELSE
                  VOLADJ = (ARRAY(IPT) - LIMIT1) / (LIMIT2 - LIMIT1)
                  GAPVOL = GAPVOL + VOLFAC * VOLADJ
              ENDIF

C----         Retrieve the grid-point and convert into i, j, k
              ILOC = IPT
              I = MOD(ILOC,NX)
              IF (I.EQ.0) I = NX
              ILOC = (ILOC - I) / NX
              J = MOD(ILOC,NY) + 1
              K = (ILOC - (J - 1)) / NY + 1

C----         Determine x-, y-, and z-coordinates of this point
              X = VALMIN(1) + (I - 1) * GRDSEP
              Y = VALMIN(2) + (J - 1) * GRDSEP
              Z = VALMIN(3) + (K - 1) * GRDSEP

C----         Update C of G accumulatore 
              COFG(1) = COFG(1) + X
              COFG(2) = COFG(2) + Y
              COFG(3) = COFG(3) + Z
              NCOORD = NCOORD + 1

          ENDIF
 500  CONTINUE

C---- Calculate CofG of the volume positions
      IF (NCOORD.GT.0) THEN
          DO 600, ICOORD = 1, 3
              COFG(ICOORD) = COFG(ICOORD) / NCOORD
 600      CONTINUE
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C     SUBROUTINE WRINDX  -  Write out all the required number of high-
C                           volume gap regions
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRINDX(ARRAY,MAXARR,NX,NY,NZ,GRDSEP,SAVMIN,SAVMAX,
     -    FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,MXATOM,NGAPS,XYZ,SPHRAD,
     -    VOLNUM,INDEXA,MAXIND)

CVAX      IMPLICIT NONE

      INTEGER       MAXARR, MAXIND, MXATOM

      CHARACTER*1   FILTYP
      CHARACTER*60  TITLE
      CHARACTER*120 FILCNT, FILDEN, FILGRD, FILMBK, FILSRF
      INTEGER       GRPTS, IATOM, IATYPE, ICOORD, ICOUNT, IFRAG, IGAP,
     -              INDEXA(MAXIND), IPOINT, IPOS, IUNIT, IVOL,
     -              NGAPS, NPOINT(3), NSIZE, NUSED, NX, NY, NZ
      LOGICAL       ENGMAP, FROMAP, IFAIL, INSMAP, NOMESS, NOPNT,
     -              NOTZER, NUMCNT, QUAMAP, RAWDAT, SUMDEN, SYBMAP
      REAL          ARAD, ARRAY(MAXARR), ASTK, BVALUE, FRGFRQ, GRDSEP,
     -              MAPMAX, MAPMIN, MFACTR, SAVMAX(3), SAVMIN(3),
     -              SPHRAD(MXATOM), VALMAX(3), VALMIN(3),
     -              VOLNUM(MXATOM), XYZ(3,MXATOM)

C---- Initialise variables
      BVALUE = 0.0
      ENGMAP = .FALSE.
      FILTYP = 'S'
      FRGFRQ = 0.0
      GRPTS = 0
      IATYPE = 0
      ICOUNT = 0
      IFRAG = 0
      IUNIT = 10
      MAPMIN = 999999.9
      MAPMAX = -999999.9
      MFACTR = 1.0
      NOMESS = .TRUE.
      NOPNT = .FALSE.
      NOTZER = .FALSE.
      NPOINT(1) = NX
      NPOINT(2) = NY
      NPOINT(3) = NZ
      NSIZE = NX * NY * NZ
      NUSED = 0
      NUMCNT = .FALSE.
      SUMDEN = .FALSE.
      RAWDAT = .TRUE.
      DO 50, ICOORD = 1, 3
          VALMIN(ICOORD) = SAVMIN(ICOORD)
          VALMAX(ICOORD) = SAVMAX(ICOORD)
 50   CONTINUE

C---- Form the output file names for the new map
      FILCNT = 'gapidx.cnt'
      FILDEN = 'gapidx.den'
      FILGRD = 'gapidx.grd'
      FILMBK = 'gapidx.mbk'
      FILSRF = 'gapidx.srf'

C---- Initialise grid array
      DO 100, IPOS = 1, MAXARR
          ARRAY(IPOS) = 0.0
 100  CONTINUE

C---- Loop over all the gap spheres
      DO 800, IPOINT = NGAPS, 1, -1

C----     Get the gap number
          IGAP = INDEXA(IPOINT)
          IATOM = IGAP

C----     Get the volume to which this sphere belongs
          IVOL = VOLNUM(IATOM)

C----     Encode the volume number to let the GRID function know this is
C         a volume index file
          GRPTS = - IVOL - 100

C----     Get the radius of the current sphere
          ARAD = SPHRAD(IATOM)
          ASTK = - LOG(2.0) / (ARAD * ARAD)

C----     Update array with current sphere
          CALL GRID(ARRAY,NX,NY,NZ,XYZ(1,IATOM),ASTK,ARAD,GRDSEP,
     -        VALMIN,NUMCNT,SUMDEN,ENGMAP,BVALUE,NUSED,GRPTS,
     -        MAPMIN,MAPMAX)

C----     Increment atom count
          ICOUNT = ICOUNT + 1
 800  CONTINUE

C---- Write out the map
      CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),FILSRF,IUNIT,
     -    VALMIN,GRDSEP,FILTYP,IFRAG,IATYPE,ICOUNT,FRGFRQ,IFAIL)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE RESETR  -  Reset each sphere's radius (currently storing
C                        its associated volume number) to 1.8
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE RESETR(MXATOM,NGAPS,RADIUS,STOREK,INDEXA,MAXIND)

CVAX      IMPLICIT NONE

      INTEGER       MAXIND, MXATOM

      INTEGER       IATOM, INDEXA(MAXIND), IPOINT, NGAPS
      REAL          ARAD, RADIUS(MXATOM), STOREK(MXATOM)

C---- Loop over all the gap spheres
      DO 800, IPOINT = 1, NGAPS

C----     Get the gap number
          IATOM = INDEXA(IPOINT)

C----     Reset the STOREK value
          ARAD = RADIUS(IATOM)
          STOREK(IATOM) = - LOG(2.0) / (ARAD * ARAD)
 800  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CLUSTR - Cluster the oversized gap-spheres into overlapping
C                      clusters
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE CLUSTR(MXATOM,XYZ,RADIUS,INDEXA,FSTGAP,NGAPS,NOVER,
     -    NCLUST,CLUST)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM, NGAPS

      INTEGER       CLUST(MXATOM), FSTGAP, HIGHER, IATOM, IGAP,
     -              INDEXA(NGAPS), JATOM, JGAP, LOWER, NCLUST, NOVER
      LOGICAL       NEWCLU
      REAL          DSQRD, OTHRAD, OVERLP, RADIUS(MXATOM), SPHRAD, X,
     -              X1, XYZ(3,MXATOM), Y, Y1, Z, Z1

C---- Initialise variables
      PRINT*, 'Clustering gap-spheres ...'
      PRINT*, '  Number of over-sized spheres', NOVER
      NCLUST = 0
      DO 100, IATOM = 1, MXATOM
          CLUST(IATOM) = 0
 100  CONTINUE

C---- Loop through the list of oversized gap spheres
      DO 600, IGAP = 1, NOVER

C----     Get appropriate atom number
          IATOM = INDEXA(IGAP)

C----     Initialise flag
          NEWCLU = .FALSE.

C----     Get sphere's radius
          SPHRAD = RADIUS(IATOM)

C----     Get its coordinates
          X = XYZ(1,IATOM)
          Y = XYZ(2,IATOM)
          Z = XYZ(3,IATOM)

C----     If sphere has no cluster number, then assign next one to it
          IF (CLUST(IATOM).EQ.0) THEN

C----         Increment cluster number and assign to this sphere
              NCLUST = NCLUST + 1
              CLUST(IATOM) = NCLUST

C----         Set flag to indicate this is currently an orphan sphere
              NEWCLU = .TRUE.
          ENDIF

C----     Loop through all remaining gap-spheres to find which penetrate
C         this one
          DO 500, JGAP = IGAP + 1, NOVER

C----         Get appropriate atom number
              JATOM = INDEXA(JGAP)

C----         Get this atom's radius
              OTHRAD = RADIUS(JATOM)

C----         Define the overlap distance as the minimum of the two radii
              OVERLP = MIN(SPHRAD,OTHRAD)

C----         Get its coordinates
              X1 = XYZ(1,JATOM)
              Y1 = XYZ(2,JATOM)
              Z1 = XYZ(3,JATOM)

C----         Calculate distance squared
              DSQRD = (X - X1) * (X - X1) + (Y - Y1) * (Y - Y1)
     -            + (Z - Z1) * (Z - Z1)

C----         If the two spheres overlap then both belong to the same
C             cluster
              IF (DSQRD.LT.OVERLP * OVERLP) THEN

C----             Easy case is where second sphere hasn't yet been assigned
C                 to a cluster
                  IF (CLUST(JATOM).EQ.0) THEN

C----                 Assign it to our current cluster number
                      CLUST(JATOM) = CLUST(IATOM)

C----                 Reset flag
                      NEWCLU = .FALSE.

C----             Otherwise, sphere has already been assigned to a cluster
                  ELSE IF (CLUST(IATOM).NE.CLUST(JATOM)) then

C----                 If our sphere was a new sphere, then reassign its
C                     cluster number
                      IF (NEWCLU) THEN

C----                     Assign current sphere to other sphere's cluster
                          CLUST(IATOM) = CLUST(JATOM)

C----                     Reset flag
                          NEWCLU = .FALSE.

C----                     Decrement cluster number
                          NCLUST = NCLUST - 1

C----                 Otherwise, need to join two sphere-clusters into one
                      ELSE

C----                     Join the two clusters, using the smaller of the
C                         two numbers
                          IF (CLUST(IATOM).GT.CLUST(JATOM)) THEN

C----                         Store the higher cluster-number
                              HIGHER = CLUST(IATOM)
                              LOWER = CLUST(JATOM)

C----                     Second cluster number is the higher one
                          ELSE

C----                         Store the higher cluster-number
                              HIGHER = CLUST(JATOM)
                              LOWER = CLUST(IATOM)

                          ENDIF

C----                     Join the clusters
                          CALL JOINCL(FSTGAP,NGAPS,LOWER,HIGHER,CLUST,
     -                        MXATOM)

C----                     If we have renamed the current cluster number,
C                         then reset
                          IF (HIGHER.EQ.NCLUST) THEN
                              NCLUST = NCLUST - 1
                          ENDIF
                      ENDIF
                  ENDIF
              ENDIF
 500      CONTINUE
 600  CONTINUE

C---- Show number of sphere clusters
      PRINT*, '  Number of clusters:          ', NCLUST
      PRINT*

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE JOINCL - Join together the two given clusters, assigning
C                      all gap-spheres to the lower-numbered cluster of
C                      the two
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE JOINCL(FSTGAP,NGAPS,CLUST1,CLUST2,CLUST,MXATOM)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM

      INTEGER       CLUST(MXATOM), CLUST1, CLUST2, FSTGAP, IATOM, IGAP,
     -              NGAPS

C---- Loop through all the gap spheres
      DO 800, IGAP = 1, NGAPS

C----     Get atom number
          IATOM = FSTGAP + IGAP - 1

C----     If this sphere's cluster-number needs to be altered, then do so
          IF (CLUST(IATOM).EQ.CLUST2) THEN
              CLUST(IATOM) = CLUST1
          ENDIF
 800  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GAFILT - Filter out any unwanted gap-spheres, keeping all
C                      those above the minimum rejection radius and any
C                      below it that interpenetrate one of those above
C                      it
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GAFILT(MXATOM,XYZ,RADIUS,INDEXA,FSTGAP,NGAPS,NOVER,
     -    CLUST)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM, NGAPS

      INTEGER       CLUST(MXATOM), FSTGAP, NOVER, IATOM, IGAP,
     -              INDEXA(NGAPS), JATOM, JGAP, NEAROV
      REAL          DSQRD, MINDIS, OVERLP, RADIUS(MXATOM), RAD1, RAD2,
     -              X1, X2, XYZ(3,MXATOM), Y1, Y2, Z1, Z2

C---- Initialise variables
      PRINT*, 'Filtering out unwanted gap-spheres ...'

C---- Loop through the sorted list of undersized gap spheres
      DO 800, JGAP = NOVER + 1, NGAPS
          JATOM = INDEXA(JGAP)

C----     Initialise this under-sphere's closest distance to an 
C         over-sphere and pointer to over-sphere
          MINDIS = 0.0
          NEAROV = 0

C----     Get sphere's radius
          RAD1 = RADIUS(JATOM)

C----     Get its coordinates
          X1 = XYZ(1,JATOM)
          Y1 = XYZ(2,JATOM)
          Z1 = XYZ(3,JATOM)

C----     Loop through the list of oversized gap spheres to see if any
C         penetrate our current sphere
          DO 600, IGAP = 1, NOVER
              IATOM = INDEXA(IGAP)

C----         Get sphere's radius
              RAD2 = RADIUS(IATOM)

C----         Define the overlap distance as the radius of the 
C             larger of the two spheres
C              OVERLP = RAD2
              OVERLP = RAD1 + RAD2

C----         Get its coordinates
              X2 = XYZ(1,IATOM)
              Y2 = XYZ(2,IATOM)
              Z2 = XYZ(3,IATOM)

C----         Calculate distance squared
              DSQRD = (X2 - X1) * (X2 - X1) + (Y2 - Y1) * (Y2 - Y1)
     -            + (Z2 - Z1) * (Z2 - Z1)

C----         If the under-sphere overlaps the over-sphere then want
C             to retain it
              IF (DSQRD.LT.OVERLP * OVERLP) THEN

C----             Check whether the sphere was previously found to
C                 overlap an over-sphere
                  IF (NEAROV.NE.0) THEN

C----                 Check if distance is smaller than what we had before
                      IF (DSQRD.LT.MINDIS) THEN

C----                     Store pointer and distance
                          NEAROV = IATOM
                          MINDIS = DSQRD
                      ENDIF

C----             Otherwise, store this over-sphere
                  ELSE

C----                 Store pointer and distance
                      NEAROV = IATOM
                      MINDIS = DSQRD
                  ENDIF
              ENDIF
 600      CONTINUE

C----     If have found an oversized gap-sphere for the current undersized
C         one, assign to the same cluster
          IF (NEAROV.NE.0) THEN

C----         Assign cluster
              CLUST(JATOM) = CLUST(NEAROV)
          ENDIF
 800  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE DELGAP  -  Remove any gap spheres that have not been assigned
C                        to clusters
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE DELGAP(FSTGAP,NGAPS,NOVER)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'
          
      INTEGER       FREE, FSTGAP, IATOM, NDEL, NGAPS, NOVER

C---- Initialise variables
      PRINT*, 'Deleting unwanted gap-spheres ...'
      NDEL = 0
      FREE = 0

C---- Loop through all the atoms
      DO 200, IATOM = FSTGAP, NATOMS

C----     If gap sphere not assigned to a cluster, then can remove it
          IF (CLUST(IATOM).EQ.0) THEN

C----         If don't have a free slot assigned yet, make this the
C             first available
              IF (FREE.EQ.0) FREE = IATOM

C----         Increment count of deleted gap spheres 
              NDEL = NDEL + 1

C----     If gap sphere wanted, move up to first available slot (if there
C         is one)
          ELSE IF (FREE.GT.0) THEN

C----         Transfer atom's data
              ATNUM(FREE) = ATNUM(IATOM)
              ATNAME(FREE) = ATNAME(IATOM)
              GAPFRM(FREE) = GAPFRM(IATOM)
              GAPTO(FREE) = GAPTO(IATOM)
              RADIUS(FREE) = RADIUS(IATOM)
              STOREK(FREE) = STOREK(IATOM)
              XYZ(1,FREE) = XYZ(1,IATOM)
              XYZ(2,FREE) = XYZ(2,IATOM)
              XYZ(3,FREE) = XYZ(3,IATOM)
              CLUST(FREE) = CLUST(IATOM)

C----         Increase pointer to next free slot
              FREE = FREE + 1
          ENDIF
200   CONTINUE

C---- If any spheres removed, reduce the number of atoms and spheres
      IF (FREE.GT.0) THEN
          NATOMS = FREE - 1
          NGAPS = NATOMS - FSTGAP + 1
      ENDIF

C---- Show numbers of spheres removed
      PRINT*, '  Number of gap-spheres removed:      ', NDEL
      PRINT*, '  Number of gap-spheres remaining:    ', NGAPS
      PRINT*

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE COUNTC  -  Determine size of each cluster
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE COUNTC(FSTGAP,MXATOM,NATOMS,NGAPS,NOVER,CLUST,CLSIZE,
     -    MXCLUS,NCLUST)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM, MXCLUS

      INTEGER       CLUST(MXATOM), FSTGAP, HIGHST, IATOM, ICLUST,
     -              NATOMS, NCLUST, NGAPS, NOVER
      REAL          CLSIZE(MXCLUS)

C---- Initialise variables
      DO 100, ICLUST = 1, MXCLUS
          CLSIZE(ICLUST) = 0.0
 100  CONTINUE
      HIGHST = 0
      NCLUST = 0

C---- Loop through all the gap spheres to get their cluster numbers
      DO 200, IATOM = FSTGAP + 1, NATOMS

C----     Get this atom's cluster
          ICLUST = CLUST(IATOM)

C----     Check that cluster not zero
          IF (ICLUST.EQ.0) THEN
Cxx              PRINT*, '*** Warning. Zero cluster for sphere', IATOM,
Cxx     -            '  (program error)'
              GO TO 200

C----     If valid cluster, increment its atom-count
          ELSE
C----         If a valid cluster, increment count
              IF (ICLUST.LE.MXCLUS) THEN
                  CLSIZE(ICLUST) = CLSIZE(ICLUST) + 1.0

C----         Otherwise, store highest cluster-number encountered
              ELSE IF (ICLUST.GT.HIGHST) THEN
                  HIGHST = ICLUST
              ENDIF
          ENDIF
 200  CONTINUE

C---- Show cluster sizes
      DO 500, ICLUST = 1, MXCLUS

C----     Print only if non-zero
          IF (CLSIZE(ICLUST).GT.0.0) THEN

C----         Increment count of non-zero clusters
              NCLUST = NCLUST + 1

C----         Print out size of this cluster
              PRINT 220, NCLUST, CLSIZE(ICLUST)
 220          FORMAT('Cluster ',I4,'   size:',F8.0)

C----         If cluster-number differs from count of non-zero clusters,
C             then reassign all atoms to the latter number
              IF (ICLUST.NE.NCLUST) THEN

C----             Renumber all the atom cluster assignments
                  CALL JOINCL(FSTGAP,NGAPS,NCLUST,ICLUST,CLUST,MXATOM)

C----             Correct the sphere count
                  CLSIZE(NCLUST) = CLSIZE(ICLUST)
              ENDIF
          ENDIF
 500  CONTINUE

C---- If any clusters missed, then show warning
      IF (HIGHST.GT.0) THEN
          PRINT*, '*** Warning. Some clusters missed as over maximum ',
     -        'allowed for:', MXCLUS
      ENDIF

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRICLU  -  Write out all the clusters in order to the
C                        clusters.pdb file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WRICLU(FSTGAP,MXATOM,NATOMS,NGAPS,CLUST,CLSIZE,
     -    MXCLUS,NCLUST,XYZ,RADIUS)

CVAX      IMPLICIT NONE

      INTEGER       MXATOM, MXCLUS

      INTEGER       ATOMNO, CLUST(MXATOM), FSTGAP, I, IATOM, ICLUST,
     -              NATOMS, NCLUST, NGAPS
      REAL          CLSIZE(MXCLUS), RADIUS(MXATOM), XYZ(3,MXATOM)

C---- Initialise variables
      ATOMNO = 0

C---- Open output clusters.pdb file
      OPEN(UNIT=11, FILE='clusters.pdb', STATUS='UNKNOWN',
     -      FORM='FORMATTED',ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Loop over all the clusters
      DO 500, ICLUST = 1, NCLUST

C----     Write out cluster size
          WRITE(11,120) ICLUST, INT(CLSIZE(ICLUST))
 120      FORMAT('REMARK',/,
     -        'REMARK Cluster:',I5,'  Size:',I8,/,
     -        'REMARK')

C----     Loop through all the gap spheres to get those belonging to
C         the current cluster
          DO 400, IATOM = FSTGAP + 1, NATOMS

C----         If atom belongs to current cluster, then write out
              IF (CLUST(IATOM).EQ.ICLUST) THEN

C----             Increment atom count
                  ATOMNO = ATOMNO + 1

C----             Write to output clusters.pdb file
                  WRITE(11,220) ATOMNO, ICLUST,
     -                (XYZ(I,IATOM), I = 1, 3), RADIUS(IATOM)
 220              FORMAT('ATOM  ',I5,1X,' C  ',1X,'SPH',2X,I4,4X,3F8.3,
     -                '  1.00',F6.2)
              ENDIF

 400      CONTINUE

C----     Write out a TER record
          WRITE(11,420) 
 420      FORMAT('TER')
 500  CONTINUE

C---- Close the output file
      CLOSE(11)

      GO TO 999

C---- Fatal error
900   CONTINUE
      PRINT*, '*** Error opening clusters.pdb output file'

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C  SUBROUTINE WRICAV - Write out all atoms bordering gap regions
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE WRICAV

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      CHARACTER*6   TTYPE
      INTEGER       IATOM, ICOORD

C---- Open output pdb file
      OPEN(UNIT=12, FILE='cavatoms.pdb', STATUS='UNKNOWN',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Loop through all the atoms in the structure, writing any that have
C     been marked as in contact
      DO 100, IATOM = 1, NATOMS
          IF (ATOUCH(IATOM) .OR. GTOUCH(IATOM)) THEN
              IF (ATOUCH(IATOM)) THEN
                  TTYPE = 'ATOUCH'
              ELSE
                  TTYPE = 'GTOUCH'
              ENDIF
              WRITE(12,40) ATNUM(IATOM), ATNAME(IATOM), 1,
     -            (XYZ(ICOORD,IATOM), ICOORD = 1, 3), TTYPE
 40           FORMAT('ATOM  ',I5,' ',A2,'  ',5X,I4,4X,3F8.3,
     -            '  1.00','  0.00  ',A6)
          ENDIF
 100  CONTINUE

C---- Close the file
      CLOSE(12)

      GO TO 999

C---- Fatal error
900   CONTINUE
      PRINT*, '*** Error opening output file, cavatoms.pdb.'
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Error opening output file, cavatoms.pdb.'
CHANGE v.1.3<--
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutine GETFAC amended and moved to surfmaps.f
CHANGE v.1.4<--
C**************************************************************************
C
C  SUBROUTINE MAKEGR  -  Form the grid of values
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE MAKEGR(ARRAY,IMAP)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      INTEGER       I, IATOM, IMAP
CHANGE v.1.5-->
      LOGICAL       INRANG
CHANGE v.1.5<--
      REAL          ARAD, ARRAY(MAXARR), ASTK
          
C---- Initialise grid array
      DO 10, I = 1, MAXARR
          ARRAY(I) = 0.0
10    CONTINUE
      GRPTS = 0
      MAPMIN = 999999.9
      MAPMAX = -999999.9
      NUSED = 0
      IF (FILTYP(IMAP).EQ.'C' .OR. FILTYP(IMAP).EQ.'N') THEN
          SUMDEN = .TRUE.
      ELSE
          SUMDEN = .FALSE.
      ENDIF
      IF (FILTYP(IMAP).EQ.'N') THEN
          NUMCNT = .TRUE.
      ELSE
          NUMCNT = .FALSE.
      ENDIF
      PRINT*
      PRINT*, 'Calculating density map ...', IMAP

C---- Loop through the coordinates of current map file only
      DO 100, IATOM = 1, NATOMS

CHANGE v.1.5-->
C          IF (ATNUM(IATOM).GE.ASTART(IMAP) .AND.
C     -        ATNUM(IATOM).LE.AEND(IMAP)) THEN

C----     Determine whether the current atom number falls
C         within one of the ranges for this map
          CALL CHKRNG(ATNUM(IATOM),IMAP,INRANG)

C----     If the atom number falls in the range of the current
C         map, then process
          IF (INRANG) THEN
CHANGE v.1.5<--

C----         If density contour, then set standard radius
              IF (FILTYP(IMAP).EQ.'C' .AND. .NOT.INRAD(IMAP)) THEN
                  ARAD = RSCALE * 0.62035049
                  ASTK = - LOG(2.0) / (ARAD * ARAD)

C----         If only counting numbers, make apparent radius
C             equal to grid separation
              ELSE IF (FILTYP(IMAP).EQ.'N') THEN
                  ARAD = GRDSEP
                  ASTK = 0.0

CHANGE v.1.1.1-->
C----         If contouring energy values, make apparent radius
C             equal to grid separation
              ELSE IF (FILTYP(IMAP).EQ.'E') THEN
                  ARAD = GRDSEP
                  ASTK = - LOG(2.0) / (ARAD * ARAD)
CHANGE v.1.1.1<--

C----         Otherwise use atom's stored radius
              ELSE
                  ARAD = RADIUS(IATOM)
                  ASTK = STOREK(IATOM)
              ENDIF

C----         Update grid point for current atom
CHANGE v.1.4-->
C              CALL GRID(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -            XYZ(1,IATOM),IATOM,ASTK,ARAD)
              CALL GRID(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
     -            XYZ(1,IATOM),ASTK,ARAD,GRDSEP,VALMIN,NUMCNT,SUMDEN,
     -            ENGMAP,BVALUE(IATOM),NUSED,GRPTS,MAPMIN,MAPMAX)
CHANGE v.1.4<--
          ENDIF
100   CONTINUE

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutines GRID, GRHIST LIMTAR and ADJARR amended and moved to surfmaps.f
C Subroutine ATMVEC (no longer used) removed entirely
CHANGE v.1.4<--
C**************************************************************************
C
C  SUBROUTINE ADJFRG  -   Adjust coordinates of fragment atoms to be within
C                         boundaries of grid box
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      SUBROUTINE ADJFRG(IMAP,ARRAY)
      SUBROUTINE ADJFRG(IMAP,ARRAY,IFRG)
CHANGE v.1.4<--

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

CHANGE v.1.1.1-->
      INTEGER       MXMETP
      PARAMETER    (MXMETP = 25)

      CHARACTER*4   MET(MXMETP)
CHANGE v.1.1.1<--

CHANGE v.1.1.1-->
C      INTEGER       ATTYPE, I, IATOM, ICOORD, IFRG, IMAP
      INTEGER       ATTYPE, I, IATOM, ICOORD, IFRG, IMAP, IMETYP
CHANGE v.1.1.1<--
CHANGE v.1.5-->
C      LOGICAL       FOUND
      LOGICAL       FOUND, INRANG
CHANGE v.1.5<--
      REAL          ARRAY(MAXARR), VALMRK, X, Y, Z

CHANGE v.1.1.1-->
      DATA  MET   / 'CA  ', 'FE  ', 'ZN  ', ' U  ', 'CU  ',
     -              'MN  ', 'CL  ', 'MG  ', 'NA  ', 'HG  ', 
     -              'CO  ', ' K  ', 'CD  ', 'AU  ', 'AG  ', 
     -              'IN  ', 'HO  ', ' F  ', 'PB  ', 'AL  ', 
     -              'YB  ', '....', '....', '....', '....' /
CHANGE v.1.1.1<--

C---- Initialise variables
      PRINT*
      PRINT*, 'Writing out fragment coordinates ...', IMAP
      IFRG = 0
      NFRG = 0
      VALMRK = MIN(VALMIN(1),VALMIN(2))
      VALMRK = MIN(VALMRK,VALMIN(3))
      IF (VALMRK.LT.0.0) VALMRK = 2.0 * VALMRK
      IF (VALMRK.GT.0.0) VALMRK = -1.0 * VALMRK
      IF (VALMRK.EQ.0.0) VALMRK = -1.0

C---- Pick out the coordinates of current map file, adjust, and transfer
C     to the large array for writing out
      DO 200, IATOM = 1, NATOMS

C----     Check whether atom belongs to current file
CHANGE v.1.5-->
C          IF (ATNUM(IATOM).GE.ASTART(IMAP) .AND.
C     -        ATNUM(IATOM).LE.AEND(IMAP)) THEN
          CALL CHKRNG(ATNUM(IATOM),IMAP,INRANG)

C----     If the atom number falls in the range of the current
C         map, then process
          IF (INRANG) THEN
CHANGE v.1.5<--

C----         Check that atom lies within the grid boundaries
              X = XYZ(1,IATOM)
              Y = XYZ(2,IATOM)
              Z = XYZ(3,IATOM)
              IF (X.GE.VALMIN(1) .AND. X.LE.VALMAX(1) .AND.
     -            Y.GE.VALMIN(2) .AND. Y.LE.VALMAX(2) .AND.
     -            Z.GE.VALMIN(3) .AND. Z.LE.VALMAX(3)) THEN

C----             For a PAIRS distribution, check whether the atom is the
C                 first of a new residue
                  IF (FILTYP(IMAP).EQ.'P' .AND. NEWRES(IATOM)) THEN
                      IF (NFRG + 1.GT.MAXARR) GO TO 900
                      NFRG = NFRG + 1
                      ARRAY(NFRG) = VALMRK
                  ENDIF

C----             Transfer coordinates into the next three positions in the
C                 array
                  IF (NFRG + 3.GT.MAXARR) GO TO 900
                  DO 100, ICOORD = 1, 3
                      IFRG = IFRG + 1
                      NFRG = NFRG + 1
                      ARRAY(NFRG) = (XYZ(ICOORD,IATOM)
     -                    - VALMIN(ICOORD)) / GRDSEP + 1.0
 100              CONTINUE

C----             Get atom-type of this atom and write it out
                  ATTYPE = 0
                  FOUND = .FALSE.
                  DO 150, I = 1, NRADII - 1
                      IF (ATNAME(IATOM).EQ.ATYPE(I)) THEN
                          ATTYPE = I
                          FOUND = .TRUE.
                      ENDIF
 150              CONTINUE
                  IF (.NOT.FOUND) THEN
CHANGE v.1.1.1-->
C----                 Check for various metals
                      DO 160, IMETYP = 1, MXMETP
                          IF (ATNAME(IATOM).EQ.MET(IMETYP)) THEN
                              ATTYPE = 9
                              FOUND = .TRUE.
                          ENDIF
 160                  CONTINUE
                  ENDIF

                  IF (.NOT.FOUND) THEN
CHANGE v.1.1.1<--
                      DO 170, I = 1, NRADII - 1
                          IF (ATNAME(IATOM)(2:2).EQ.ATYPE(I)(2:2))
     -                        ATTYPE = I
 170                  CONTINUE
                  ENDIF
                  NFRG = NFRG + 1
CHANGE v.1.4-->
C                  ARRAY(NFRG) = ATTYPE
                  IF (FILTYP(IMAP).EQ.'a') THEN
                      ARRAY(NFRG) = BVALUE(IATOM)
                  ELSE
                      ARRAY(NFRG) = ATTYPE
                  ENDIF
CHANGE v.1.4<--
              ENDIF
          ENDIF
 200  CONTINUE

C---- Summarise
      IF (IFRG.EQ.0) THEN
          PRINT*, '*** No fragment atoms found'
      ELSE
          PRINT*, 'Number of fragment atoms ...', IFRG
      ENDIF
      GO TO 999

C---- Error condition
 900  CONTINUE
      PRINT*, '+ Warning. Number of fragment-atom coords exceeds',
     -    ' array bounds', MAXARR

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutine WRISRF amended and transferred to surfmaps.f
C Subroutine COMPRS removed as no longer required
CHANGE v.1.4<--
CHANGE v.1.4-->
C Subroutine NEIGHB (not used) removed entirely
CHANGE v.1.4<--
CHANGE v.1.2-->
CHANGE v.1.4-->
C Subroutine INSIGH moved to surfmaps.f
CHANGE v.1.4<--
CHANGE v.1.2<--
C**************************************************************************
C
C  SUBROUTINE VOLUME  -  Calculate the total volume of the objects in the
C                        current grid-map
C
C----------------------------------------------------------------------+--- 


CHANGE v.1.6-->
C      SUBROUTINE VOLUME(ARRAY,N1,N2,N3,IMAP)
      SUBROUTINE VOLUME(ARRAY,N1,N2,N3,IMAP,NTOP)
CHANGE v.1.6<--

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

CHANGE v.1.6-->
C      INTEGER       I, ILOC, IMAP, IVOL, J, K, N1, N2, N3,
C     -              VOLIST(MXATOM)
C      REAL          ARRAY(N1,N2,N3), VOL(MXATOM)
      INTEGER       I, ILOC, IMAP, IVOL, J, K, N1, N2, N3, NTOP
      REAL          ARRAY(N1,N2,N3)
CHANGE v.1.6<--

CHANGE v.1.6-->
C      EQUIVALENCE  (INDEXA,  VOLIST),
C     -             (RADIUS, VOL)
CHANGE v.1.6<--

C---- Initialise values
      NXTLST = NATOMS
      NXTVOL = NATOMS
      DO 100, I = NATOMS + 1, MXATOM
          LSTVOL(I) = 0
          VOLIST(I) = 0
100   CONTINUE

C---- Loop through all the grid-points
      DO 700, K = 1, NPOINT(3)
          DO 600, J = 1, NPOINT(2)
              DO 500, I = 1, NPOINT(1)

C----             If grid-point is part of an object, add to volume list
                  IF (ARRAY(I,J,K).GE.100.0) THEN

C----                 Initialise values and calculate grid-point's location
                      NXTLST = NXTLST + 1
                      IF (NXTLST.GT.MXATOM) GO TO 900
                      ILOC = (K - 1) * NPOINT(1) * NPOINT(2)
     -                     + (J - 1) * NPOINT(1) + I
                      GRDPOS(NXTLST) = ILOC

C----                 Check the three adjacent points already done to see if
C                     any of them belonged to a volume object
                      CALL JCHECK(ARRAY,NPOINT(1),NPOINT(2), NPOINT(3),
     -                    I,J,K)

C----                 If no previous volumes encountered, then this is a
C                     new one
                      IF (NOVOLS) THEN
                          NXTVOL = NXTVOL + 1
                          IF (NXTVOL.GT.MXATOM) GO TO 900
                          IVOL = NXTVOL
                          LSTVOL(IVOL) = NXTLST
                          VOLIST(NXTLST) = 0

C----                 Otherwise, use whichever was the minimum
                      ELSE
                          IVOL = MINVOL
                          VOLIST(NXTLST) = LSTVOL(IVOL)
                          LSTVOL(IVOL) = NXTLST

C----                     If there was more than one volume, concatenate
C                         to the lowest-numbered of them
                          IF (TWOVOL) THEN
                              CALL CONCAT(ARRAY,NPOINT(1),NPOINT(2),
     -                            NPOINT(3))
                          ENDIF
                      ENDIF

C----                 Set grid-point to current volume
                      ARRAY(I,J,K) = IVOL + ARRAY(I,J,K) / 1000.0

C----             Otherwise, if not part of volume, set to range 0.0 -> 1.0
                  ELSE
                      ARRAY(I,J,K) = ARRAY(I,J,K) / 1000.0
                  ENDIF
500           CONTINUE
600       CONTINUE
700   CONTINUE

C---- Calculate volumes
CHANGE v.1.4-->
C      CALL VOLCAL(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
CHANGE v.1.6-->
C      CALL VOLCAL(IMAP)
      CALL VOLCAL(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP,NTOP)
CHANGE v.1.6<--
CHANGE v.1.4<--

C---- If current map is the map of gaps, write out the mask file
CHANGE v.1.6-->
C      IF (GAPMAP .AND. IMAP.EQ.NMAPS) THEN
C          CALL WRIMSK(NPOINT(1),NPOINT(2),NPOINT(3))
      IF (.NOT.JUSCAL .AND. (ALLPNT .OR.
     -    (GAPMAP .AND. IMAP.EQ.NMAPS))) THEN
          CALL WRIMSK(IMAP,NPOINT(1),NPOINT(2),NPOINT(3))
CHANGE v.1.6<--
      ENDIF

      GO TO 999

C---- Fatal errors
900   CONTINUE
CHANGE v.1.4-->
C      PRINT*, 'Array exceeded in volume calculation: MXATOM =', MXATOM
      PRINT*, '*** Warning. Array exceeded in volume calculations: MXA',
     -    'TOM =', MXATOM
      PRINT*, '***          Volumes will not be calculated for this ma',
     -    'p'
      NXTLST = MXATOM
      GO TO 999
CHANGE v.1.4<--
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) 'Array exceeded in volume calculation: MXATOM =',
C     -    MXATOM
CHANGE v.1.3<--
CHANGE v.1.4-->
C      GO TO 990
C
C990   CONTINUE
C      IFAIL = 1
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6--> Re-written (old version in surfnet_out.f)
C**************************************************************************
C
C  SUBROUTINE JCHECK  -  Check whether grid-point joins onto any previously
C                        defined volumes
C
C----------------------------------------------------------------------+--- 


      SUBROUTINE JCHECK(ARRAY,N1,N2,N3,I,J,K)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      INTEGER       I, IPOINT, IX, IY, IZ, J, K, N1, N2, N3,
CHANGE v.1.6.1-->
C     -              ISTEP(3,NSTEPS)
C      REAL          ARRAY(N1,N2,N3), VOLMAX
     -              ISTEP(3,NSTEPS), VOLMAX
      REAL          ARRAY(N1,N2,N3)
CHANGE v.1.6.1<--

      DATA ISTEP /  -1, -1, -1,
     -              -1, -1,  0,
     -              -1,  0, -1,
     -              -1,  0,  0,
     -               0, -1, -1,
     -               0, -1,  0,
     -               0,  0, -1,
     -               1, -1,  0,
     -               1,  0, -1,
     -               1, -1, -1,
     -               1,  1, -1,
     -               0,  1, -1,
     -              -1,  1, -1 /

C---- Initialise variables
      MINVOL = MXATOM * 2
      VOLMAX = 0
      NOVOLS = .TRUE.
      TWOVOL = .FALSE.

C---- Check the seven adjacent points already done to see if
C     any of them belonged to a volume object
      DO 800, IPOINT = 1, NSTEPS

C----     Initialise
          BCKVOL(IPOINT) = 0

C----     Get the subscripts of this backward point
          IX = I + ISTEP(1,IPOINT)
          IY = J + ISTEP(2,IPOINT)
          IZ = K + ISTEP(3,IPOINT)

C----     If have a valid point, check its associated volume
CHANGE v.1.6.1-->
C          IF (IX.GT.0 .AND. IY.GT.0 .AND. IZ.GT.0) THEN
          IF (IX.GT.0 .AND. IY.GT.0 .AND. IZ.GT.0 .AND.
     -        IX.LE.N1 .AND. IY.LE.N2 .AND. IZ.LE.N3) THEN
CHANGE v.1.6.1<--

C----         Store the backward volume
              BCKVOL(IPOINT) = NINT(ARRAY(IX,IY,IZ))

C----         If a valid volume, then compare with min and max values
              IF (BCKVOL(IPOINT).GT.0) THEN
                  MINVOL = MIN(BCKVOL(IPOINT),MINVOL)
                  VOLMAX = MAX(BCKVOL(IPOINT),VOLMAX)
              ENDIF
          ENDIF
 800  CONTINUE

C---- Check whether one or more different volumes have been encountered
      IF (VOLMAX.GT.0) THEN
          NOVOLS = .FALSE.
          IF (MINVOL.NE.VOLMAX) TWOVOL = .TRUE.
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C  SUBROUTINE CONCAT  -  Concatenate two existing volumes that have just been
C                        found to join on to one another
C
C----------------------------------------------------------------------+--- 


      SUBROUTINE CONCAT(ARRAY,N1,N2,N3)

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

CHANGE v.1.6-->
C      INTEGER       I, ILOC, IPOINT, IVOL, J, K, N1, N2, N3, SPOINT,
C     -              VOLIST(MXATOM)
C      REAL          ARRAY(N1,N2,N3), VOL(MXATOM)
      INTEGER       I, ILOC, IPOINT, IVOL, J, K, N1, N2, N3, SPOINT
      REAL          ARRAY(N1,N2,N3)
CHANGE v.1.6<--

CHANGE v.1.6-->
C      EQUIVALENCE  (INDEXA,  VOLIST),
C     -             (RADIUS, VOL)
CHANGE v.1.6<--

C---- Loop through all the volumes encountered
      DO 200, IVOL = 1, NSTEPS
          IF (BCKVOL(IVOL).GT.MINVOL) THEN

C----         Chase down the points stored for the higher-numbered volume
C             to adjust all the corresponding grid-points
              IPOINT = LSTVOL(BCKVOL(IVOL))
              IF (IPOINT.GT.0) THEN
120               CONTINUE

C----                 Retrieve the grid-point and convert into i, j, k
                      ILOC = GRDPOS(IPOINT)
                      I = MOD(ILOC,NPOINT(1))
                      IF (I.EQ.0) I = NPOINT(1)
                      ILOC = (ILOC - I) / NPOINT(1)
                      J = MOD(ILOC,NPOINT(2)) + 1
                      K = (ILOC - (J - 1)) / NPOINT(2) + 1
                      ARRAY(I,J,K) = ARRAY(I,J,K) - NINT(ARRAY(I,J,K))
     -                    + MINVOL
                      IPOINT = VOLIST(IPOINT)
                  IF (IPOINT.GT.0) GO TO 120
              ENDIF
      
C----         Chase down the points stored for the lowest-numbered volume
C             until reach end
              IPOINT = LSTVOL(MINVOL)
              IF (IPOINT.GT.0) THEN
150               CONTINUE
                      SPOINT = IPOINT
                      IPOINT = VOLIST(IPOINT)
                  IF (IPOINT.GT.0) GO TO 150
      
C----             Have found end of list
                  VOLIST(SPOINT) = LSTVOL(BCKVOL(IVOL))
                  LSTVOL(BCKVOL(IVOL)) = 0
              ENDIF
          ENDIF
200   CONTINUE

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE VOLCAL  -  Calculate the actual volume of each object in
C                        the grid
C
C----------------------------------------------------------------------+--- 


CHANGE v.1.4-->
C      SUBROUTINE VOLCAL(ARRAY,N1,N2,N3,IMAP)
CHANGE v.1.6-->
C      SUBROUTINE VOLCAL(IMAP)
      SUBROUTINE VOLCAL(ARRAY,N1,N2,N3,IMAP,NTOP)
CHANGE v.1.6<--
CHANGE v.1.4<--

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

      CHARACTER*3   MAPID
CHANGE v.1.4-->
C      INTEGER       I, ILOC, IMAP, IPOINT, IVOL, J, K, N1, N2, N3,
      INTEGER       I, ILOC, IMAP, IPOINT, IVOL, J, K,
CHANGE v.1.4<--
CHANGE v.1.6-->
C     -              NPT, NTOP, VOLIST(MXATOM)
     -              NPT, NTOP, N1, N2, N3
CHANGE v.1.6<--
CHANGE v.1.4-->
C      REAL          ARRAY(N1,N2,N3), COFG(3,MXATOM), VOL(MXATOM),
C     -              VOLFAC, VOLTOT, X, Y, Z
CHANGE v.1.6-->
C      REAL          COFG(3,MXATOM), VOL(MXATOM), VOLFAC, VOLTOT, X,
C     -             Y, Z
      REAL          ARRAY(N1,N2,N3), VOLFAC, VOLTOT, X, Y, Z
CHANGE v.1.6<--
CHANGE v.1.4<--

CHANGE v.1.6-->
C      EQUIVALENCE  (INDEXA,  VOLIST),
C     -             (XYZ,    COFG),
C     -             (RADIUS, VOL)
CHANGE v.1.6<--

C---- Initialise values
      NVOL = NATOMS
      VOLFAC = GRDSEP * GRDSEP * GRDSEP
CHANGE v.1.6-->
      IF (JUSCAL) THEN
          VOLFAC = 1.0
      ENDIF
CHANGE v.1.6<--

C---- Loop through all the volumes in the grid map, chasing each one down
      DO 200, IVOL = NATOMS + 1, NXTVOL
          IPOINT = LSTVOL(IVOL)
          IF (IPOINT.GT.0) THEN
              NPT = 0
              NVOL = NVOL + 1
              COFG(1,NVOL) = 0.0
              COFG(2,NVOL) = 0.0
              COFG(3,NVOL) = 0.0
              VOL(NVOL) = 0.0

C----         Chase down the points belonging to this volume
100           CONTINUE

C----             Retrieve the grid-point and convert into i, j, k
                  ILOC = GRDPOS(IPOINT)
                  I = MOD(ILOC,NPOINT(1))
                  IF (I.EQ.0) I = NPOINT(1)
                  ILOC = (ILOC - I) / NPOINT(1)
                  J = MOD(ILOC,NPOINT(2)) + 1
                  K = (ILOC - (J - 1)) / NPOINT(2) + 1

CHANGE v.1.6-->
C----             Update current array value with the new volume-number
                  ARRAY(I,J,K) = ARRAY(I,J,K) - IVOL + NVOL
CHANGE v.1.6<--

C----             Count number of neighbouring grid-points that belong to this
C                 volume
CHANGE v.1.4-->
CCNOT USED                  CALL NEIGHB(ARRAY,NPOINT(1),NPOINT(2), NPOINT(3),
CCNOT USED     -                I,J,K)
CHANGE v.1.4<--
                  NPT = NPT + 1
CHANGE v.1.4-->
CCNOT USED                  VOL(NVOL) = VOL(NVOL) + VOLFAC * SQRT(VFRAC / 6.0)
CHANGE v.1.4<--
                  VOL(NVOL) = VOL(NVOL) + VOLFAC

C----             Determine x-, y-, and z-coordinates of this point
                  X = VALMIN(1) + (I - 1) * GRDSEP
                  Y = VALMIN(2) + (J - 1) * GRDSEP
                  Z = VALMIN(3) + (K - 1) * GRDSEP
                  COFG(1,NVOL) = COFG(1,NVOL) + X
                  COFG(2,NVOL) = COFG(2,NVOL) + Y
                  COFG(3,NVOL) = COFG(3,NVOL) + Z

C----             Go to the next point for this volume
                  IPOINT = VOLIST(IPOINT)
              IF (IPOINT.GT.0) GO TO 100

C----         Adjust C of G values
              IF (NPT.GT.0) THEN
                  COFG(1,NVOL) = COFG(1,NVOL) / REAL(NPT)
                  COFG(2,NVOL) = COFG(2,NVOL) / REAL(NPT)
                  COFG(3,NVOL) = COFG(3,NVOL) / REAL(NPT)
              ENDIF
          ENDIF
 200  CONTINUE

C---- Sort all volumes by size

C---- Initialize sort index
      NTOP = NVOL - NATOMS
      DO 400, I = 1, NTOP
          IVOL = NATOMS + I
          INDEXA(I) = IVOL
 400  CONTINUE
      IF (NTOP.GT.1) CALL SHSORT(MXATOM,VOL,NTOP,INDEXA)

CHANGE v.1.6-->
C---- If not just calculating, write out the gap-volumes calculated
      IF (.NOT.JUSCAL) THEN

C----     Write out a sorted list of the topmost volumes
          IF (NTOP.GT.MXTOP) THEN
              PRINT 405, MXTOP, NVOL - NATOMS
 405          FORMAT(//,1X,'Top', I4, ' volumes only, out of ', I4)
          ENDIF
          VOLTOT = 0.0
CHANGE v.1.4-->
          IF (NTOP.GT.0) THEN
CHANGE v.1.4<--
              PRINT 410
 410          FORMAT(//,1X,7X,'Volume    At. No. Map   Res. no. ',
     -            '<----C of G coords---->  ',6X,'Volume')
CHANGE v.1.4-->
          ENDIF
CHANGE v.1.4<--
          DO 500, IVOL = 1, NTOP
              IF (IVOL.LE.MXTOP) THEN
                  NEXTAT = NEXTAT + 1
                  WRITE(MAPID,420) IMAP
 420              FORMAT('M',I2.2)
                  IF (GAPMAP .AND. IMAP.EQ.NMAPS) MAPID = 'GAP'
                  PRINT 430, IVOL, NEXTAT, MAPID, IVOL,
     -                (COFG(I,INDEXA(IVOL)), I = 1, 3),
     -                VOL(INDEXA(IVOL))
 430              FORMAT(7X,I5,'.    ',I5,4X,A3,5X,I6,3F8.3,2X,F12.4)
CHANGE v.1.3-->
CHANGE v.1.6-->
C              IF (MAPID.EQ.'GAP') THEN
CCHANGE v.1.3<--
C                  WRITE(8,440) NEXTAT, MAPID, IVOL,
C     -                (COFG(I,INDEXA(IVOL)), I = 1, 3),
C     -                VOL(INDEXA(IVOL))
C440               FORMAT('HETATM',I5,'  C   ',A3,2X,I4,4X,3F8.3,
C     -                '  1.00','  0.00',2X,F12.3)
CCHANGE v.1.3-->
C              ELSE
CHANGE v.1.6<--
                  WRITE(14,440) NEXTAT, MAPID, IVOL,
     -                (COFG(I,INDEXA(IVOL)), I = 1, 3),
     -                 VOL(INDEXA(IVOL))
CHANGE v.1.6-->
 440              FORMAT('HETATM',I5,'  C   ',A3,2X,I4,4X,3F8.3,
     -                 '  1.00','  0.00',2X,F12.3)
                  IF (MAPID.NE.'GAP') THEN
                      WRITE(16,440) NEXTAT, MAPID, IVOL,
     -                    (COFG(I,INDEXA(IVOL)), I = 1, 3),
     -                    VOL(INDEXA(IVOL))
                  ENDIF
C                  ENDIF
CHANGE v.1.6<--
CHANGE v.1.3<--
              ENDIF
              VOLTOT = VOLTOT + VOL(INDEXA(IVOL))
500       CONTINUE 

C----     Print total volume
CHANGE v.1.4-->
          IF (NTOP.GT.0) THEN
CHANGE v.1.4<--
              PRINT 520, VOLTOT
520           FORMAT(66X,'------------',/,66X,F12.4)
              PRINT*
              PRINT*
CHANGE v.1.4-->
          ENDIF
CHANGE v.1.4<--

CHANGE v.1.6-->
      ENDIF
CHANGE v.1.6<--

999   CONTINUE
      RETURN
      END

C-----------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRIMSK  -   Write out pointers giving the grid-points belonging
C                         to each of the identified gap volumes
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.6-->
C      SUBROUTINE WRIMSK(NX,NY,NZ)
      SUBROUTINE WRIMSK(IMAP,NX,NY,NZ)
CHANGE v.1.6<--

CVAX      IMPLICIT NONE

      INCLUDE 'surfnet.inc'

CHANGE v.1.6-->
C      INTEGER       IVOL, NFREE, NTOP, NX, NY, NZ, VOLIST(MXATOM)
      INTEGER       IMAP, IVOL, LENSTR, NFREE, NTOP, NX, NY, NZ
CHANGE v.1.6<--

CHANGE v.1.6-->
C      EQUIVALENCE  (INDEXA,  VOLIST)
CHANGE v.1.6<--
            
C---- Open output file that will hold the array of density values
CHANGE v.1.6-->
C      OPEN(UNIT=9, FILE='gaps.pnt', STATUS='UNKNOWN',
      OPEN(UNIT=9, FILE=FILPNT(IMAP), STATUS='UNKNOWN',
CHANGE v.1.6<--
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write out index giving sorted order for gap-volumes in order of
C     decreasing volume
      NTOP = NVOL - NATOMS
      DO 100, IVOL = 1, NTOP
          INDEXA(IVOL) = INDEXA(IVOL) - NATOMS
 100  CONTINUE
      WRITE(9,*) NTOP, NX, NY, NZ
      WRITE(9,50) (INDEXA(IVOL), IVOL = 1, NTOP)
 50   FORMAT(10I8)

C---- Write out gap-volume start-pointers, shuffling them together to
C     remove the zero values
      NFREE = NATOMS + 1
      DO 200, IVOL = NATOMS + 1, NXTVOL
          IF (LSTVOL(IVOL).NE.0) THEN
              LSTVOL(IVOL) = LSTVOL(IVOL) - NATOMS

C----         If can shuffle up to free spot before current point, then
C             do so
              IF (NFREE.LT.IVOL) THEN
                  LSTVOL(NFREE) = LSTVOL(IVOL)
                  LSTVOL(IVOL) = 0
              ENDIF
              NFREE = NFREE + 1
          ENDIF
 200  CONTINUE
      WRITE(9,50) (LSTVOL(IVOL), IVOL = NATOMS + 1, NATOMS + NTOP)

C---- Write out location pointers
      NVOL = NXTLST - NATOMS
      DO 300, IVOL = NATOMS + 1, NXTLST
          IF (VOLIST(IVOL).NE.0) THEN
              VOLIST(IVOL) = VOLIST(IVOL) - NATOMS
          ENDIF
 300  CONTINUE
      WRITE(9,*) NVOL
      WRITE(9,310) (VOLIST(IVOL), IVOL = NATOMS + 1, NXTLST)
 310  FORMAT(10I8)

C---- Write out grid-positions
      NVOL = NXTLST - NATOMS
      WRITE(9,*) NVOL
      WRITE(9,410) (GRDPOS(IVOL), IVOL = NATOMS + 1, NXTLST)
 410  FORMAT(10I8)

C---- Close the file
      CLOSE(9)

      GO TO 999

C---- Fatal error
900   CONTINUE
CHANGE v.1.6-->
C      PRINT*, '*** Error opening output file: gaps.pnt'
      PRINT*, '*** Error opening output file: [',
     -    FILPNT(IMAP)(1:LENSTR(FILPNT(IMAP))), ']'
CHANGE v.1.6<--
CHANGE v.1.3-->
C      CALL OPNERR
C      WRITE(13,*) '*** Error opening output file: gaps.pnt'
CHANGE v.1.3<--
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutine SHSORT transferred to surfmaps.f
CHANGE v.1.4<--




