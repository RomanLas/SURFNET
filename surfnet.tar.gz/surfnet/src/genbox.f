C*****************************************************************************
C
C GENBOX.F  -  Program to generate a rectangular mask for use with xsite.f
C              The location and size of the box are defined by the user
C
C R A Laskowski, University College, London. October 1993
C
C-----------------------------------------------------------------------------
C
C Program description
C -------------------
C
C
C The aim of this program is to produce a rectangular "box" density file.
C 
C The program asks for the centre of the box, its dimensions in the x-, y-
C and z-directions, and the grid-spacing to be used.
C
C--------------------------------------------------------------------------
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.0     Original release version.                   4 May 1995 (RAL)
C
C v.1.1     Update of routines that produce CCP4 output files.
C                                                     5-9 May 1995 (RAL)
C
C v.1.3     Addition of option on type of map to be output.
C           Addition of Sybyl and Insight output formats.
C                                                       4 Dec 1995 (RAL)
C v.1.3.1   Minor amendment of integer to logical variable as wouldn't
C           compile under HP FORTRAN.
C                                                      10 Jan 1996 (RAL)
C
C v.1.4     Amendments to group map-generating routines together in
C           surfmaps.f.
C                                                      17 Jun 1996 (RAL)
C           Changes to make all filenames 120 characters long.
C                                                       5 Sep 1996 (RAL)
C v.1.4.1   Minor bug-fix to use of IFAIL.
C                                                       7 Nov 1996 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Files
C -----
C
C 10   box.den         - Output CCP4 density file
C 10   box.grd         - Output InsightII grid file
C 10   box.mbk         - Output Quanta brick file file
C 10   box.srf         - Output mask file, being a density file in .srf
C                        format
C ??   box.cnt         - Output Sybyl contour file
C
C--------------------------------------------------------------------------
C
C
C Compilation and linking (on unix)
C -----------------------
C
C f77 -u -c genbox.f
C f77 -u -c surfmaps.f
C f77 -o genbox genbox.o surfmaps.o
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines in surfmaps.f and use surfsyb.scr to link to the Sybyl
C library routines.
C
C If CCP4 density maps are to be generated, uncomment all the CCP4
C lines in surfmaps.f and use surfccp4.scr to link to the CCP4
C library routines.
C
C Subroutine calling tree
C -----------------------
C
C MAIN  --> INITS
C       --> GBOUND
C       --> SETARR
C       --> MAXMIN
C       --> WRIMAP  --> LIMTAR
C                   --> ADJARR
C                   --> GRHIST  --> SHSORT
C                   --> WRISRF
C                   --> COMPRS
C                   --> ASCDEN  --> CCP4 routines to write out density file
C                   --> MBRICK  --> CCP4 routines to read in density files
C                                   and write out brick files (for FRODO)
C                                   [This routine is no longer used]
C                   --> INSIGH
C                   --> QUANTA  --> GETHED
C                               --> MBRWRH
C                               --> MRDSE8
C                   --> SYBYL   --> XCCreate
C                               --> XCWrite
C                               --> XCClose
C
C----------------------------------------------------------------------+--- 


      PROGRAM GENBOX

CVAX      IMPLICIT NONE

      INCLUDE 'genbox.inc'

      CHARACTER*80  TITLE
CHANGE v.1.4-->
C      INTEGER       IMAP, NPOINT(3)
C      REAL          ARRAY(MAXARR)
      INTEGER       IMAP, IUNIT, NPOINT(3)
      LOGICAL       NOPNT, RAWDAT
      REAL          ARRAY(MAXARR), MFACTR
CHANGE v.1.4<--
CHANGE v.1.4-->
CCHANGE v.1.3-->
CC-Sybyl-->
CCSYBYL      REAL*8        SHEET(MXSHEE)
CC-Sybyl<--
CCHANGE v.1.3<--
CHANGE v.1.4<--


C---- Initialise variables
      FILDEN = 'box.den'
      FILMBK = 'box.mbk'
CHANGE v.1.3-->
      FILCNT = 'box.cnt'
      FILGRD = 'box.grd'
CHANGE v.1.3<--
      IMAP = 1
      TITLE = 'Box map'
CHANGE v.1.4-->
CCHANGE v.1.3-->
CC      FROMAP = .FALSE.
CCC---- CCP4-->
CCccpold      FROMAP = .TRUE.
CCC---- CCP4<--
CC      QUAMAP = .TRUE.
C
CC---- Set flags indicating which routines will be linked in during 
CC     compilation
C      FROLNK = .FALSE.
CC---- CCP4-->
CCCP4      FROLNK = .TRUE.
CC---- CCP4<--
C      SYBLNK = .FALSE.
CC-Sybyl-->
CCSYBYL      SYBLNK = .TRUE.
CC-Sybyl<--
CCHANGE v.1.3<--
      CALL INTMAP(FROLNK,SYBLNK)
CHANGE v.1.4<--

C---- Accept input parameters
      CALL INITS

C---- Calculate array size and boundaries
      CALL GBOUND(NPOINT)

C---- Set all the grid-points in array to 200.0, except outer ones
      CALL SETARR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))

C---- Calculate maximum and minimum values in map
      CALL MAXMIN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))

C---- Write out density and brick files

C---- Write the array to disk as a surface density file
      PRINT*, 'Writing surface density file ...   '
CHANGE v.1.4-->
C      CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C      IF (IFAIL) GO TO 999
C
CC---- If the  density and brick files are actually required,
CC     then call the appropriate  routines and write them out
C      IF (FROMAP) THEN
C
CC----     Write the array to disk as a CCP4 density file
CC---- CCP4-->
CCCP4          PRINT*, 'Writing CCP4 density file ...   '
CCCP4          CALL ASCDEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCCP4     -        FILDEN,TITLE,LIM,IUVW,VALMAX,
CCCP4     -        VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)
CC---- CCP4<--
C
CC----     Write the array to disk as a brick file [Not used. Use 
CC         routines to convert  format to FRODO format]
CCFRODO          PRINT*, 'Writing brick file ...     ', IMAP
CCFRODO          CALL MBRICK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C      ENDIF
C
CCHANGE v.1.3-->
CC---- If InsightII grid files are required, then write these out
C      IF (INSMAP) THEN
C
CC----     Write the array to disk as a standard formatted
CC         InsightII grid file
C          PRINT*, 'Writing InsightII grid file ...   ', IMAP
C          CALL INSIGH(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -        IMAP,FILGRD,GRDSEP,VALMIN,VALMAX)
C      ENDIF
CCHANGE v.1.3<--
C
CC---- If Quanta brick files are required, then write these out
C      IF (QUAMAP) THEN
C
CC----     Write the array to disk as a Quanta density file
C          PRINT*, 'Writing brick file ...   '
C          CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -        IMAP,FILMBK,GRDSEP,MAPAV,MAPMIN,
C     -        MAPMAX,VALMIN,VALMAX)
C      ENDIF
C
CC---- If Sybyl contour files are required, then write these out
C      IF (SYBMAP) THEN
C
CC----     Check that the sheet-size not larger than
CC         allowed in the parameters
C          IF (MXSHEE.GE.NPOINT(1) * NPOINT(2)) THEN
C
CC----         Write the array to disk as a Sybyl contour file
C              PRINT*, 'Writing Sybyl contour file ...     ', IMAP
CC-Sybyl-->
CCSYBYL              CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
CCSYBYL     -            NPOINT(3),IMAP,FILCNT,GRDSEP,MAPAV,
CCSYBYL     -            MAPMIN,MAPMAX,VALMIN,VALMAX,SHEET,TITLE,
CCSYBYL     -            IFAIL)
CC-Sybyl<--
C
CC----     If array not large enough, display error message
C          ELSE
C              PRINT*, '*** ERROR. Array variable MXSHEE ',
C     -            'not large enough for sheets to be'
C              PRINT*, '*          written out to Sybyl ',
C     -            'contour file', MXSHEE, NPOINT(1) * NPOINT(2)
C          ENDIF
C      ENDIF

C---- Write out the array in whichever output format is required
      IFRAG = 0
      IATYPE = 0
      ICOUNT = 0
      FRGFRQ = 0.0
      IUNIT = 10
      MFACTR = 1.0
      RAWDAT = .TRUE.
      FILSRF = 'box.srf'
      FILTYP = 'S'
      CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,FILTYP,IMAP,IFRAG,
     -    IATYPE,ICOUNT,FRGFRQ,FILCNT,FILDEN,FILGRD,FILMBK,FILSRF,
     -    IUNIT,FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,
     -    RAWDAT,MFACTR,.FALSE.,.FALSE.,NOPNT,IFAIL)
CHANGE v.1.4<--


 999  CONTINUE
      IF (.NOT.IFAIL) THEN
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'genbox.inc'

CHANGE v.1.3-->
      CHARACTER*1   YESNO
CHANGE v.1.3<--
      INTEGER       ICOORD
      REAL          LENTHX, LENTHY, LENTHZ

C---- Accept centre coordinates of box
      PRINT*, 'Enter coordinates of centre of box'
      READ*, (BOXMID(ICOORD), ICOORD = 1, 3)

C---- Accept length of box in x-, y- and z-directions
      PRINT*, 'Enter length of box in x-, y- and z-directions'
      READ*, LENTHX, LENTHY, LENTHZ
      VALMIN(1) = BOXMID(1) - LENTHX / 2.0
      VALMAX(1) = BOXMID(1) + LENTHX / 2.0
      VALMIN(2) = BOXMID(2) - LENTHY / 2.0
      VALMAX(2) = BOXMID(2) + LENTHY / 2.0
      VALMIN(3) = BOXMID(3) - LENTHZ / 2.0
      VALMAX(3) = BOXMID(3) + LENTHZ / 2.0

C---- Accept grid separation
      PRINT*, 'Enter grid separation'
      READ*, GRDSEP

CHANGE v.1.3-->
C---- Accept which output map format is required
      FROMAP = .FALSE.
      INSMAP = .FALSE.
      QUAMAP = .FALSE.
      SYBMAP = .FALSE.
      PRINT*, 'Enter map-format required: (Q)uanta, (C)CP4, (S)ybyl',
     -    ', (I)nsightII or (N)one'
      READ(*,110) YESNO
 110  FORMAT(A)
      IF (YESNO.EQ.'Q' .OR. YESNO.EQ.'q') THEN
          QUAMAP = .TRUE.
      ELSE IF (YESNO.EQ.'I' .OR. YESNO.EQ.'i') THEN
          INSMAP = .TRUE.
      ELSE IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          IF (FROLNK) THEN
              FROMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to  librar',
     -            'ies'
              PRINT*, '***          No  density maps will be produ',
     -            'ced'
          ENDIF
      ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
          IF (SYBLNK) THEN
              SYBMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to Sybyl libra',
     -            'ries'
              PRINT*, '***          No Sybyl contour maps will be prod',
     -            'uced'
          ENDIF
      ELSE IF (YESNO.EQ.'N' .OR. YESNO.EQ.'n') THEN
          PRINT*, '*** No map files required'
      ELSE
          PRINT*, '*** INVALID map format requested: [', YESNO, ']'
          PRINT*, '*** No map files will be written out.'
      ENDIF
CHANGE v.1.3<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GBOUND  -   Calculate boundaries for grid box
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GBOUND(NPOINT)

CVAX      IMPLICIT NONE

      INCLUDE 'genbox.inc'
          
      INTEGER       ARSIZE, ICOORD, LOWER, NPOINT(3), UPPER
      REAL          RESD(3)

C---- Initialise values
      ARSIZE = 1

C---- Calculate the array size for the grid
      DO 600, ICOORD = 1, 3
          LOWER = 2 * ICOORD - 1
          UPPER = LOWER + 1

C----     Calculate lowest grid value for this coordinate
          LIM(LOWER) = INT(VALMIN(ICOORD) / GRDSEP)
          IF (VALMIN(ICOORD).GT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) + 1
          ELSE IF (VALMIN(ICOORD).LT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF

C----     Calculate upper grid value for this coordinate
          LIM(UPPER) = INT(VALMAX(ICOORD) / GRDSEP)
          IF (VALMAX(ICOORD).GT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) + 1
          ELSE IF (VALMAX(ICOORD).LT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) - 1
          ENDIF

CHANGE v.1.3-->
C----     For a Sybyl map, adjust upper boundary by 1
          IF (SYBMAP .AND. ICOORD.EQ.3) THEN
              LIM(UPPER) = LIM(UPPER) + 1
          ENDIF
CHANGE v.1.3<--
      
C----     Calculate number of grid points required for this coordinate
          NPOINT(ICOORD) = LIM(UPPER) - LIM(LOWER) + 1
          ARSIZE = ARSIZE * NPOINT(ICOORD)
      
C----     Adjust the minimum and maximum values to correspond to the
C         grid limits
          VALMIN(ICOORD) = LIM(LOWER) * GRDSEP
          VALMAX(ICOORD) = LIM(UPPER) * GRDSEP
          RESD(ICOORD) = VALMAX(ICOORD) - VALMIN(ICOORD)
600   CONTINUE

C---- Check that array is not too large
      IF (ARSIZE.GT.MAXARR) THEN
          PRINT*, '*** Array required:', ARSIZE, '   is larger',
     -            ' than that allowed:', MAXARR
          PRINT*, '     Grid points:', (NPOINT(ICOORD), ICOORD = 1, 3)
          GO TO 990
      ENDIF
      PRINT 620, 'Adjusted min:       ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
 620  FORMAT(1X,A,3F12.4)
      PRINT 620, 'Adjusted max:       ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      PRINT*
      PRINT 640, 'Grid separation:    ', GRDSEP
 640  FORMAT(1X,A,F12.4)
      PRINT*
      PRINT 660, 'Length:             ', (RESD(ICOORD), ICOORD = 1, 3)
 660  FORMAT(1X,A,3F12.4,/,1X,A,F16.2)
      PRINT 680, NPOINT(1), NPOINT(2), NPOINT(3), ARSIZE
 680  FORMAT(/,1X,'Array size: ',I8,'  x',I8,'  x',I8,'  = ',I8,
     -    ' points',/) 

      GO TO 999

C---- Error conditions
990   CONTINUE
CHECK v.1.4.1-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHECK v.1.4.1<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SETARR  -  Set all the grid-points in the array to 200.0,
C                        except the outermost points which are set to zero
C
C--------------------------------------------------------------------------

      SUBROUTINE SETARR(GRID,N1,N2,N3)

CVAX      IMPLICIT NONE

      INCLUDE 'genbox.inc'

      INTEGER       I1, I2, I3, N1, N2, N3
      LOGICAL       XSET, YSET, ZSET
      REAL          GRID(N1,N2,N3)

C---- Loop through all the grid-points
      DO 500, I3 = 1, N3
CHANGE v.1.3-->
C          IF (I3.EQ.1 .OR. I3.EQ.N3) THEN
          IF (I3.EQ.1 .OR. I3.EQ.N3 .OR.
     -        (SYBMAP .AND. I3.EQ.N3 - 1)) THEN
CHANGE v.1.3-->
              ZSET = .TRUE.
          ELSE
              ZSET = .FALSE.
          ENDIF
          DO 400, I2 = 1, N2
              IF (I2.EQ.1 .OR. I2.EQ.N2) THEN
                  YSET = .TRUE.
              ELSE
                  YSET = .FALSE.
              ENDIF
              DO 300, I1 = 1, N1
                  IF (I1.EQ.1 .OR. I1.EQ.N1) THEN
                      XSET = .TRUE.
                  ELSE
                      XSET = .FALSE.
                  ENDIF

C----             Set grid value to 0 or 200 depening on whether it is on
C                 the outside or not
                  IF (XSET .OR. YSET .OR. ZSET) THEN
                      GRID(I1,I2,I3) = 0.0
                  ELSE
                      GRID(I1,I2,I3) = 200.0
                  ENDIF
 300          CONTINUE
 400      CONTINUE
 500  CONTINUE
200   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MAXMIN  -  Find the new maximum and minimum values in the
C                        array
C
C--------------------------------------------------------------------------

      SUBROUTINE MAXMIN(ARRAY,N1,N2,N3)

CVAX      IMPLICIT NONE

      INCLUDE 'genbox.inc'

CHANGE v.1.3-->
C      INTEGER       GRPTS, I, NOPNT, N1, N2, N3
      INTEGER       GRPTS, I, N1, N2, N3
      LOGICAL       NOPNT
CHANGE v.1.3<--
      REAL          ARRAY(N1*N2*N3), MMEAN

C---- Initialise variables
      GRPTS = 0

C---- Find the maximum, minimum and mean values of all the grid values
      NOPNT = .FALSE.
      MAPMIN = ARRAY(1)
      MAPAV  = 0.0
      MAPRMS = 0.0
      MAPMAX = ARRAY(1)
      DO 200, I = 1, N1 * N2 * N3

C----     Find minimum and maximum grid values
          MAPMIN = MIN(ARRAY(I),MAPMIN)
          MAPMAX = MAX(ARRAY(I),MAPMAX)
          MAPAV = MAPAV + ARRAY(I)
          IF (ARRAY(I).NE.0.0) GRPTS = GRPTS + 1
200   CONTINUE
      IF (MAPMIN.EQ.0.0 .AND. MAPMAX.EQ.0.0) NOPNT = .TRUE.
      PRINT*
      PRINT*, '   Number of non-zero grid points in MAP:', GRPTS
      PRINT*
      PRINT*, '   Minumum and maximum density values:', MAPMIN, MAPMAX
      MAPAV = MAPAV / (N1 * N2 * N3)

C---- Calculate the RMS deviation of the densities from the mean
      IF (.NOT.NOPNT) THEN
          MMEAN = MAPAV

C----     Loop over all the points in the array
          DO 700, I = 1, N1 * N2 * N3

C----         Calculate RMS difference from mean
              MAPRMS = MAPRMS + (ARRAY(I) - MMEAN) * (ARRAY(I) - MMEAN)
 700      CONTINUE
          MAPRMS = MAPRMS / (N1 * N2 * N3)
          MAPRMS = SQRT(MAPRMS)
          PRINT*, '   Mean density value and RMS diff:', MMEAN,
     -            MAPRMS
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutine WRISRF amended and moved to surfmaps.f
CHANGE v.1.4<--
CHANGE v.1.3-->
CHANGE v.1.4-->
C Subroutine INSIGH moved to surfmaps.f
CHANGE v.1.4<--
CHANGE v.1.3<--
