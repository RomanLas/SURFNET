$!++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$!  SURFNET.COM
$!  -----------
$!  Command file for running SURFNET
$!  Roman Laskowski, October 1996
$!
$!  VAX VMS version
$!++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$!
$ WRITE SYS$OUTPUT "  "
$ WRITE SYS$OUTPUT "S   U   R   F   N   E   T      v  .   1   .   4"
$ WRITE SYS$OUTPUT "  "
$ WRITE SYS$OUTPUT "SURFNET  -  Molecular surfaces, cavities, etc."
$ WRITE SYS$OUTPUT "------------------------------------------------"
$ WRITE SYS$OUTPUT "  "
$ WRITE SYS$OUTPUT "  "
$ WRITE SYS$OUTPUT "  "
$!
$! Check if parameter file, surfnet.par, exists
$ PARFILE:="surfnet.par"
$ FILE_SPEC = F$SEARCH(PARFILE)
$ IF (FILE_SPEC.NES."") THEN $ GOTO RUNPROG
$ WRITE SYS$OUTPUT "*** Parameter file surfnet.par not found"
$ WRITE SYS$OUTPUT "  "
$ WRITE SYS$OUTPUT "A new file has been created for you. Please edit it and re-run surfnet"
$ WRITE SYS$OUTPUT "  "
$ COPY SURFDIR$:surfnet.par []
$ DIR/SIZE/DATE surfnet.par
$ WRITE SYS$OUTPUT "  "
$ EXIT
$!
$ RUNPROG:
$!
$ WRITE SYS$OUTPUT "Running SURFNET ..."
$!
$ RUN SURFDIR$:SURFNET.EXE


