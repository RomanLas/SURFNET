C*****************************************************************************
C*****************************************************************************
C**********                                                       ************
C**********     S   U   R   F   M   A   P   S   .   F   O   R     ************
C**********                                                       ************
C*****************************************************************************
C*****************************************************************************
C
C                Roman A Laskowski, University College London
C
C                                  June 1996
C
C----------------------------------------------------------------------+--- 
C
C Program description
C -------------------
C
C Map-writing routines for SURFNET and X-SITE, outputting density maps in
C different formats. Routines to read in standard .srf format files.
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines.
C
C If CCP4 contour files are to be generated, uncomment all the CCP4
C lines.
C
C Important note:  When compiling on a Silicon Graphics, need to
C                  set the SGI flag to .TRUE. in SUBROUTINE QUANTA below.
C                  Otherwise the brick files generated will not be read
C                  in correctly by Quanta.
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the SURFNET version number corresponding to the change
C
C v.1.4.1   Removal of unused variables in call to SYBYL routine.
C                                                      17 Nov 1996 (RAL)
C
C v.1.4.2   Correction to CALVAL routine to give a better calculation of
C           interpolated grid values at points close to the grid boundaries.
C           Additional parameter to GETSRF routine to allow it to only
C           pick up the header information from the .srf file.
C                                                   11-12 Feb 1997 (RAL)
C
C v.1.6     Addition of REAGRD routine to read in InsightII-format .grd
C           files
C                                                      18 Apr 1999 (RAL)
C           Bug-fix to CALVAL routine for errors on some points on grid-
C           boundaries.
C                                                      24 Nov 1999 (RAL)
C           Removal of sort routine from GRHIST is no messages required.
C                                                      26 Apr 2000 (RAL)
C
C v.1.6.1   Bug-fix to SYBYL routine in surfsybyl.f on lengths of
C           characater strings passed to the array.
C                                                      25 May 2001 (RAL)
C v.1.6.4   Modification to GETFAC in surfmaps.f to give a better
C           density calculation for maps of type "C"
C                                                      29 Mar 2006 (RAL)
C v.1.6.5   Changes to make loop parameters integer.
C                                                      29 Aug 2019 (RAL)
C v.1.6.6   Modifications for more recent compilers.
C                                                      14 Jul 2026 (RAL)
C
C Files
C -----
C
C  2   <filename>.den  - Output density file in CCP4 format
C  7   <filename>.srf  - Output .srf file holding the arrays of density
C                        values
C 10   <filename>.mbk  - Output Quanta brick file
C 10   <filename>.grd  - Output InsightII grid file
C ??   <filename>.cnt  - Output Sybyl contour file
C
C----------------------------------------------------------------------+--- 

C**************************************************************************
C
C  SUBROUTINE INTMAP  -  Determine which output map formats are available
C
C----------------------------------------------------------------------+---

      SUBROUTINE INTMAP(FROLNK,SYBLNK)

      LOGICAL       FROLNK, SYBLNK

C---- Set flags indicating which routines will be linked in during 
C     compilation
      FROLNK = .FALSE.
C---- -->
      FROLNK = .TRUE.
C---- <--
      SYBLNK = .FALSE.
C-Sybyl-->
CSYBYL      SYBLNK = .TRUE.
C-Sybyl<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRIMAP  -  Write out the current density map in whichever
C                        format(s) are required
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,FILTYP,IMAP,
     -    IFRAG,IATYPE,ICOUNT,FRGFRQ,FILCNT,FILDEN,FILGRD,FILMBK,FILSRF,
     -    IUNIT,FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,
     -    RAWDAT,MFACTR,NOTZER,NOMESS,NOPNT,IFAIL)

      INTEGER       MXSHEE
      PARAMETER    (MXSHEE =  6000)

      INTEGER       MAXARR, MAXIND

      CHARACTER*1   FILTYP
      CHARACTER*60  TITLE
      CHARACTER*120 FILCNT, FILDEN, FILGRD, FILMBK, FILSRF
      INTEGER       I, IATYPE, ICOUNT, IFRAG, IMAP, INDEXA(MAXIND),
     -              IUNIT, IUVW(3), IXMAX, IXMIN, IYMAX, IYMIN, IZMAX,
CHANGE v.1.4-->
C     -              IZMIN, LIM(6), NNEW(3), NPOINT(3)
     -              IZMIN, LENSTR, LIM(6), NNEW(3), NPOINT(3)
CHANGE v.1.4<--
CHANGE v.1.6.1-->
C      LOGICAL       IFAIL, FROMAP, INSMAP, NOMESS, NOPNT, NOTZER,
C     -              QUAMAP, RAWDAT, SYBMAP
      LOGICAL       IFAIL, FROMAP, INSMAP, NOLIMT, NOMESS, NOPNT,
     -              NOTZER, QUAMAP, RAWDAT, SYBMAP
CHANGE v.1.6.1<--
      REAL          ARRAY(MAXARR), FRGFRQ, GRDSEP, MAPAV, MAPMAX,
     -              MAPMIN, MAPRMS, MFACTR, VALMAX(3), VALMIN(3)
C-Sybyl-->
CSYBYL      REAL*8        SHEET(MXSHEE)
C-Sybyl<--

CHANGE v.1.6.1-->
C---- If grid separation is negative, then don't want to reduce the
C     map size when writing out
      IF (GRDSEP.LT.0.0) THEN
          GRDSEP = -1 * GRDSEP
          NOLIMT = .TRUE.
      ELSE
          NOLIMT = .FALSE.
      ENDIF
      NOPNT = .FALSE.
CHANGE v.1.6.1<--

C---- Reduce the size of the array as much as possible to remove any
C     blank regions on the borders
CHANGE v.1.6.1-->
      IF (.NOT.NOLIMT) THEN
CHANGE v.1.6.1<--

C----     Calculate extent of array so that can reduce its size to only
C         cover the gap-volume that remain
          CALL LIMTAR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),GRDSEP,VALMIN,
     -        IXMAX,IXMIN,IYMAX,IYMIN,IZMAX,IZMIN,NOMESS,NOTZER)

C----     Reduce the size of the array
          CALL ADJARR(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),GRDSEP,VALMIN,
     -        VALMAX,NNEW(1),NNEW(2),NNEW(3),IXMAX,IXMIN,IYMAX,IYMIN,
     -        IZMAX,IZMIN,NOMESS,NOPNT)
          NPOINT(1) = NNEW(1)
          NPOINT(2) = NNEW(2)
          NPOINT(3) = NNEW(3)
CHANGE v.1.6.1-->
      ENDIF
CHANGE v.1.6.1<--

C---- Compute map parameters
      DO 100, I = 1, 3
          IUVW(I) = I
          LIM(2 * I - 1) = NINT(VALMIN(I) / GRDSEP)
          LIM(2 * I) = NINT(VALMAX(I) / GRDSEP)
 100  CONTINUE

C---- Calculate maximum and minimum values in map
      CALL GRHIST(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),INDEXA,MAXIND,
     -    MAPAV,MAPMAX,MAPMIN,MAPRMS,NOMESS,NOPNT,RAWDAT,MFACTR)

C---- If density array not blank, write out to file
      IF (.NOT.NOPNT) THEN

C----     Write grid out to .srf file
          CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),FILSRF,IUNIT,
     -        VALMIN,GRDSEP,FILTYP,IFRAG,IATYPE,ICOUNT,FRGFRQ,IFAIL)

C----     If the  density and brick files are actually required,
C         then call the appropriate  routines and write them out
          IF (FROMAP) THEN

C----         Write the array to disk as a  density file
C---- -->
              PRINT*, 'Writing  density file ...   '
CHANGE v.1.4-->
                  PRINT*, 'File: ', FILDEN(1:LENSTR(FILDEN))
CHANGE v.1.4<--
CCP4          CALL ASCDEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCP4     -            FILDEN,TITLE,LIM,IUVW,VALMAX,
CCP4     -            VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)
C---- <--


C----         Write the array to disk as a FRODO brick file [Not used. Use 
C             routines to convert  format to FRODO format]
CFRODO              PRINT*, 'Writing brick file ...     ', IMAP
CFRODO              CALL MBRICK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
          ENDIF

C----     If InsightII grid files are required, then write these out
          IF (INSMAP) THEN

C----         Write the array to disk as a standard formatted
C             InsightII grid file
              PRINT*, 'Writing InsightII grid file ...    ', IMAP
              CALL INSIGH(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
     -            FILGRD,IUNIT,GRDSEP,VALMIN,VALMAX,TITLE)
          ENDIF

C----     If Quanta brick files are required, then write these out
          IF (QUAMAP) THEN

C----         Write the array to disk as a Quanta density file
              PRINT*, 'Writing brick file ...   '
CHANGE v.1.4-->
C              CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),1,FILMBK,
              CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),FILMBK,
CHANGE v.1.4<--
     -            GRDSEP,MAPAV,MAPMIN,MAPMAX,VALMIN,VALMAX)
          ENDIF

C----     If Sybyl contour files are required, then write these out
          IF (SYBMAP) THEN

C----         Check that the sheet-size not larger than
C             allowed in the parameters
              IF (MXSHEE.GE.NPOINT(1) * NPOINT(2)) THEN

C----             Write the array to disk as a Sybyl contour file
                  PRINT*, 'Writing Sybyl contour file ...'
                  TITLE = 'Mask file'
CHANGE v.1.4-->
                  PRINT*, 'File: ', FILCNT(1:LENSTR(FILCNT))
CHANGE v.1.4<--
C-Sybyl-->
CHANGE v.1.4.1-->
Ccsybylold                  CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
Ccsybylold     -                NPOINT(3),1,FILCNT,GRDSEP,MAPAV,
Ccsybylold     -                MAPMIN,MAPMAX,VALMIN,VALMAX,SHEET,TITLE,
Ccsybylold     -                IFAIL)
CSYBYL                  CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
CSYBYL     -                NPOINT(3),FILCNT,GRDSEP,VALMIN,VALMAX,
CSYBYL     -                SHEET,TITLE,IFAIL)
CHANGE v.1.4.1<--
C-Sybyl<--

C----          If array not large enough, display error message
               ELSE
                   PRINT*, '*** ERROR. Array variable MXSHEE ',
     -                 'not large enough for sheets to be'
                   PRINT*, '*          written out to Sybyl ',
     -                 'contour file', MXSHEE, NPOINT(1) * NPOINT(2)
              ENDIF
          ENDIF

C---- If no point to be written out, show warning message
      ELSE
          IF (.NOT.NOMESS) THEN
              PRINT*, '*** Warning. Map empty, so no density files wil',
     -            'l be written out'
          ENDIF
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE LIMTAR  -  Calculate effective extent of grid (ie region
C                        bounding remaining gap-volumes) so that can chop
C                        down size of grid to a minimum
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE LIMTAR(ARRAY,N1,N2,N3,GRDSEP,VALMIN,IXMAX,IXMIN,IYMAX,
     -    IYMIN,IZMAX,IZMIN,NOMESS,NOTZER)

      INTEGER       IX, IXMAX, IXMIN, IY, IYMAX, IYMIN, IZ, IZMAX,
     -              IZMIN, N, N1, N2, N3
      LOGICAL       NOMESS, NOTZER
      REAL          ARRAY(N1,N2,N3), CUTOFF, GRDSEP, MAPMAX, MAPMIN,
     -              VALMIN(3), VMIN, VMAX

C---- Initialise variables
      IXMIN = N1
      IXMAX = 0
      IYMIN = N2
      IYMAX = 0
      IZMIN = N3
      IZMAX = 0
      MAPMIN = ARRAY(1,1,1)
      MAPMAX = ARRAY(1,1,1)
      N = N1 * N2 * N3

C---- Loop over all the points in the grid to find the maximum and
C     minimum values
      DO 400, IZ = 1, N3
          DO 300, IY = 1, N2
              DO 200, IX = 1, N1

C----             Adjust max and min values, if necessary
                  MAPMIN = MIN(ARRAY(IX,IY,IZ),MAPMIN)
                  MAPMAX = MAX(ARRAY(IX,IY,IZ),MAPMAX)
 200          CONTINUE
 300      CONTINUE
 400  CONTINUE

C---- Set the cut-off value (ie effective zero value)
      IF (NOTZER) THEN
          CUTOFF = MAPMIN + 0.00000001 * (MAPMAX - MAPMIN)
          IF (CUTOFF.LE.0.0) CUTOFF = 0.00000001
      ELSE
          CUTOFF = 100.0
      ENDIF

C---- Loop through all the grid-points in the array
      DO 800, IZ = 1, N3
          DO 700, IY = 1, N2
              DO 600, IX = 1, N1
                  IF (ARRAY(IX,IY,IZ).GE.CUTOFF) THEN
                      IXMIN = MIN(IX,IXMIN)
                      IXMAX = MAX(IX,IXMAX)
                      IYMIN = MIN(IY,IYMIN)
                      IYMAX = MAX(IY,IYMAX)
                      IZMIN = MIN(IZ,IZMIN)
                      IZMAX = MAX(IZ,IZMAX)
                  ENDIF
 600          CONTINUE
 700      CONTINUE
 800  CONTINUE

C---- Check that maximum is greater than minimum
      IF (IXMAX.LT.IXMIN) IXMAX = IXMIN
      IF (IYMAX.LT.IYMIN) IYMAX = IYMIN
      IF (IZMAX.LT.IZMIN) IZMAX = IZMIN

C---- Extend limits by one grid point either side
      IXMIN = MAX(1,IXMIN - 1)
      IXMAX = MIN(N1,IXMAX + 1)
      IYMIN = MAX(1,IYMIN - 1)
      IYMAX = MIN(N2,IYMAX + 1)
      IZMIN = MAX(1,IZMIN - 1)
      IZMAX = MIN(N3,IZMAX + 1)

C---- Print effective limits
      IF (.NOT.NOMESS) THEN
          PRINT*
      ENDIF
      VMIN = VALMIN(1) + (IXMIN - 1) * GRDSEP
      VMAX = VALMIN(1) + (IXMAX - 1) * GRDSEP
      IF (.NOT.NOMESS) THEN
          PRINT 420, ' New array limits:  X ', IXMIN, ' -->', IXMAX,
     -        'Coords:', VMIN, VMAX
 420      FORMAT(A,I4,A,I4,5X,A,F10.4,'   -->',F10.4)
      ENDIF
      VMIN = VALMIN(2) + (IYMIN - 1) * GRDSEP
      VMAX = VALMIN(2) + (IYMAX - 1) * GRDSEP
      IF (.NOT.NOMESS) THEN
          PRINT 420, '                    Y ', IYMIN, ' -->', IYMAX,
     -        'Coords:', VMIN, VMAX
      ENDIF
      VMIN = VALMIN(3) + (IZMIN - 1) * GRDSEP
      VMAX = VALMIN(3) + (IZMAX - 1) * GRDSEP
      IF (.NOT.NOMESS) THEN
          PRINT 420, '                    Z ', IZMIN, ' -->', IZMAX,
     -        'Coords:', VMIN, VMAX
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE ADJARR  -  Reduce the size of the array so that it just 
C                        encompasses all the gap-volumes
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE ADJARR(ARRAY,N1,N2,N3,GRDSEP,VALMIN,VALMAX,NEW1,NEW2,
     -    NEW3,IXMAX,IXMIN,IYMAX,IYMIN,IZMAX,IZMIN,NOMESS,NOPNT)

      INTEGER       INEW, IOLD, IX, IXMAX, IXMIN, IXOLD, IY, IYMAX,
     -              IYMIN, IYOLD, IZ, IZMAX, IZMIN, IZOLD, N1, N2, N3,
     -              NEW1, NEW2, NEW3, NSIZE
      LOGICAL       NOMESS, NOPNT
      REAL          ARRAY(N1*N2*N3), GRDSEP, VALMAX(3), VALMIN(3)

C---- Initialise variables
      NOPNT = .FALSE.
      NEW1 = IXMAX - IXMIN + 1
      NEW2 = IYMAX - IYMIN + 1
      NEW3 = IZMAX - IZMIN + 1
      NSIZE = N1 * N2 * N3
      VALMIN(1) = VALMIN(1) + (IXMIN - 1) * GRDSEP
      VALMIN(2) = VALMIN(2) + (IYMIN - 1) * GRDSEP
      VALMIN(3) = VALMIN(3) + (IZMIN - 1) * GRDSEP
      VALMAX(1) = VALMIN(1) + (NEW1 - 1) * GRDSEP
      VALMAX(2) = VALMIN(2) + (NEW2 - 1) * GRDSEP
      VALMAX(3) = VALMIN(3) + (NEW3 - 1) * GRDSEP

C---- Loop through all the grid-points in the array, transferring all the
C     points in the reduced array into the corner of the new version
C     of the array
      DO 300, IZ = 1, NEW3
          IZOLD = IZ + IZMIN - 1
          DO 200, IY = 1, NEW2
              IYOLD = IY + IYMIN - 1
              DO 100, IX = 1, NEW1
                  IXOLD = IX + IXMIN - 1

C----             Calculate the array-position of the current grid-point
C                 in the original and reduced versions of the array
                  IOLD = (IZOLD - 1) * N1 * N2 + (IYOLD - 1) * N1
     -                + IXOLD
                  INEW = (IZ - 1) * NEW1 * NEW2 + (IY - 1) * NEW1
     -                + IX
                  IF (INEW.LT.1 .OR. IOLD.LT.1 .OR. INEW.GT.NSIZE .OR.
     -                IOLD.GT.NSIZE) THEN
                      PRINT 80, '* Warning. Error in array-limits' //
     -                    ' during adjust: IOLD, INEW, NSIZE', IOLD,
     -                    INEW, NSIZE
 80                   FORMAT(A,3I8)
                  ELSE
                      ARRAY(INEW) = ARRAY(IOLD)
                  ENDIF
 100          CONTINUE
 200      CONTINUE
 300  CONTINUE
      IF (.NOT.NOMESS) THEN
          PRINT*
 320      FORMAT(A,I8)
      ENDIF
      IF (NEW1 * NEW2 * NEW3.LT.1) THEN
          NOPNT = .TRUE.
      ELSE IF (.NOT.NOMESS) THEN
          PRINT 320, '    New array size:', NEW1 * NEW2 * NEW3
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GRHIST  -  Calculate a histogram of density values in the
C                        array
C
C----------------------------------------------------------------------+---

      SUBROUTINE GRHIST(ARRAY,N1,N2,N3,INDEXA,MAXIND,MAPAV,MAPMAX,
     -    MAPMIN,MAPRMS,NOMESS,NOPNT,RAWDAT,MFACTR)

CVAX      IMPLICIT NONE

      INTEGER       MAXIND, N1, N2, N3

      CHARACTER*8   CBOUND(10)
      INTEGER       I, IBAND, INDEXA(MAXIND), IPOINT, IPOS, MAXARR,
     -              NLOOP
      LOGICAL       NOMESS, NOPNT, RAWDAT
      REAL          ARRAY(N1*N2*N3), GBOUND(10), MAPAV, MAPMAX, MAPMIN,
     -              MAPRMS, MAPTOT, MFACTR, MMEAN

C---- Initialise variables
      IPOINT = 0
      MAXARR = N1 * N2 * N3

C---- Find the maximum, minimum and mean values of all the grid values
      NOPNT = .FALSE.
      MAPMIN = ARRAY(1)
      MAPAV  = 0.0
      MAPTOT  = 0.0
      MAPMAX = ARRAY(1)
      DO 200, I = 1, MAXARR

C----     If grid-point is non-zero, store a pointer to it
          IF (ARRAY(I).GT.0.0) THEN
              IPOINT = IPOINT + 1
CHANGE v.1.6-->
C              IF (IPOINT.LE.MAXIND) THEN
              IF ((.NOT.NOMESS .OR. .NOT.RAWDAT) .AND.
     -            IPOINT.LE.MAXIND) THEN
CHANGE v.1.6<--
                  INDEXA(IPOINT) = I
              ENDIF
          ENDIF

C----     Adjust max and min values, if necessary
          MAPMIN = MIN(ARRAY(I),MAPMIN)
          MAPMAX = MAX(ARRAY(I),MAPMAX)
          MAPAV = MAPAV + ARRAY(I)
          MAPTOT = MAPTOT + ARRAY(I)
 200  CONTINUE
      IF (MAPMIN.EQ.0.0 .AND. MAPMAX.EQ.0.0) NOPNT = .TRUE.
      IF (IPOINT.EQ.0) NOPNT = .TRUE.
      IF (.NOT.NOMESS) THEN
          PRINT*
          PRINT*, '   Number of non-zero grid points in MAP:', IPOINT
          PRINT*
          IF (NOPNT) THEN
              PRINT*, '   No density/brick files written out'
          ELSE
              PRINT*, '   Minimum and maximum density values:', MAPMIN,
     -            MAPMAX
              PRINT*, '   Map total:                         ', MAPTOT
          ENDIF
      ENDIF
C      MAPAV = MAPAV / (N1 * N2 * N3)
C      PRINT*, '   Minimum grid value', MINGRD

C---- Sort the non-zero values in the array
      IPOINT = MIN(MAXIND,IPOINT)
CHANGE v.1.6-->
C      IF (IPOINT.GT.0) THEN
      IF ((.NOT.NOMESS .OR. .NOT.RAWDAT) .AND. IPOINT.GT.0) THEN
CHANGE v.1.6<--
          CALL SHSORT(MAXARR,ARRAY,IPOINT,INDEXA)
      ENDIF

C---- Show values corresponding to percentage bands of 10%
CHANGE v.1.6-->
C      IF (IPOINT.GT.10) THEN
      IF (.NOT.NOMESS .AND. IPOINT.GT.10) THEN
CHANGE v.1.6<--

C----     Loop through the sorted grid points and determine the values
C         of the bands that group the points into 10% intervals
          DO 400, IBAND = 1, 10
              IPOS = IPOINT * REAL(IBAND - 1) / 10.0
              IF (IPOS.EQ.0) IPOS = 1
              IF (IPOS.GT.IPOINT) IPOS = IPOINT
              GBOUND(IBAND) = ARRAY(INDEXA(IPOS))
 400      CONTINUE

C----     Write out the density values in 10% intervals
          IF (.NOT.NOMESS) THEN
              PRINT*
              PRINT*, '   Histogram of non-zero density values:'
              PRINT*
              PRINT*, '      0%     10%     20%     30%     40%    ' //
     -            ' 50%     60%     70%     80%     90%'
          ENDIF
          DO 500, IBAND = 1, 10
              IF (ABS(GBOUND(IBAND)).LT.0.0001) THEN
                  CBOUND(IBAND) = '  0.0000'
              ELSE IF (ABS(GBOUND(IBAND)).LT.0.01) THEN
                  WRITE(CBOUND(IBAND),420) GBOUND(IBAND)
 420              FORMAT(F8.4)
              ELSE IF (ABS(GBOUND(IBAND)).LT.10.0) THEN
                  WRITE(CBOUND(IBAND),440) GBOUND(IBAND)
 440              FORMAT(F8.2)
              ELSE IF (ABS(GBOUND(IBAND)).LT.1000.0) THEN
                  WRITE(CBOUND(IBAND),460) GBOUND(IBAND)
 460              FORMAT(F8.1)
              ELSE
                  WRITE(CBOUND(IBAND),480) GBOUND(IBAND)
 480              FORMAT(F8.0)
              ENDIF
 500      CONTINUE
          IF (.NOT.NOMESS) THEN
              PRINT 520, (CBOUND(IBAND), IBAND = 1, 10)
 520          FORMAT(10A)
              PRINT*
          ENDIF
      ENDIF

C---- Reinitialise maximum and minimum values
      MAPMIN = 0.0
      MAPAV  = 0.0
      MMEAN  = 0.0
      MAPMAX = 0.0

C---- If array values not to be changed, then loop through whole lot to
C     get maximum and minimum values
      IF (RAWDAT) THEN
          NLOOP = MAXARR

C---- Otherwise, just loop over the non-zero points to be updated
      ELSE
          NLOOP = IPOINT
      ENDIF

C---- Loop over the relevant grid-points
      DO 600, I = 1, NLOOP

C----     If just a simple multiplying factor, then apply that
          IF (RAWDAT) THEN
              IPOS = I
              ARRAY(IPOS) = ARRAY(IPOS) * MFACTR

C----     Otherwise, adjust all the array values so that they reflect
C         percentages (ie 90% contour has the top 10% points within it)
          ELSE
              IPOS = INDEXA(I)
              ARRAY(IPOS) = 100.0 * REAL(IPOINT - I + 1) / REAL(IPOINT)
          ENDIF

C----     Adjust max and min values, if necessary
          MAPMIN = MIN(ARRAY(IPOS),MAPMIN)
          MAPMAX = MAX(ARRAY(IPOS),MAPMAX)
          MAPAV = MAPAV + ARRAY(IPOS)
          MMEAN = MMEAN + ARRAY(IPOS)
 600  CONTINUE
      IF (.NOT.NOMESS) THEN
          PRINT*, '   Adjusted min and max density values:', MAPMIN,
     -        MAPMAX
      ENDIF

C---- Calculate the RMS distance from the mean
      MAPRMS = 0.0
      IF (.NOT.NOPNT) THEN
          MMEAN = MMEAN / IPOINT

C----     Loop over all the points in the array
          DO 700, I = 1, N1 * N2 * N3

C----         Calculate RMS difference from mean
              MAPRMS = MAPRMS + (ARRAY(I) - MMEAN) * (ARRAY(I) - MMEAN)
 700      CONTINUE
          MAPRMS = MAPRMS / (N1 * N2 * N3)
          MAPRMS = SQRT(MAPRMS)
          IF (.NOT.NOMESS) THEN
              PRINT*, '   Mean density value and RMS diff:', MMEAN,
     -                MAPRMS
          ENDIF
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SHSORT  -  Sort routine using the SHELL sort method. Sorts the
C                       integer array IARRAY, of size NSIZE, as indexed by the
C                       array INDEX. The latter array has pointers to only
C                       NINDEX of the elements in IARRAY. The routine
C                       returns the indices in INDEX rearranged in descending
C                       order of the corresponding values in IARRAY.
C
C----------------------------------------------------------------------+---

      SUBROUTINE SHSORT(NSIZE,RARRAY,NINDEX,INDEX)

CVAX      IMPLICIT NONE

      REAL          ALN2I, TINY
      PARAMETER (ALN2I=1.4426950, TINY=1.E-5)

      INTEGER       NSIZE, NINDEX
      INTEGER       INDEX(NINDEX)
      REAL          RARRAY(NSIZE)

      INTEGER       I, ISWAP, J, K, L, LOGNB2, M, N, NN

      N = NINDEX
      LOGNB2 = INT(ALOG(FLOAT(N)) * ALN2I + TINY)
      M = N
      DO 12, NN = 1, LOGNB2
          M = M / 2
          K = N - M
          DO 11, J = 1, K
              I = J
3             CONTINUE
              L = I + M
              IF (RARRAY(INDEX(L)).GT.RARRAY(INDEX(I))) THEN
                  ISWAP = INDEX(I)
                  INDEX(I) = INDEX(L)
                  INDEX(L) = ISWAP
                  I = I - M
                  IF (I.GE.1) GO TO 3
              ENDIF
11        CONTINUE
12    CONTINUE

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE WRISRF  -   Write data out to binary file (.srf) for use by
C                         program surface.f for generating polygons for
C                         plotting by program surfplot.f.
C
C----------------------------------------------------------------------+---

      SUBROUTINE WRISRF(ARRAY,N1,N2,N3,FILSRF,IUNIT,VALMIN,GRDSEP,
     -    FILTYP,IFRAG,IATYPE,ICOUNT,FRGFRQ,IFAIL)

CVAX      IMPLICIT NONE

      CHARACTER*1   FILTYP
      CHARACTER*(*) FILSRF
      INTEGER       I, IATYPE, ICOUNT, IFRAG, IUNIT, LENSTR, N1, N2, N3,
     -              NX, NY, NZ
      LOGICAL       IFAIL
      REAL          ARRAY(N1*N2*N3), FRGFRQ, GRDSEP, VALMIN(3)


C---- Open output file that will hold the array of density values
      OPEN(UNIT=IUNIT, FILE=FILSRF(1:LENSTR(FILSRF)), STATUS='UNKNOWN',
     -     FORM='UNFORMATTED', ACCESS='SEQUENTIAL',
     -     ERR=900)

C---- Write out coordinates of reference corner of array, grid separation,
C     and file type
      WRITE(IUNIT) (VALMIN(I), I = 1, 3), GRDSEP, FILTYP

C---- Write out the number of points in the grid
      NX = N1
      NY = N2
      NZ = N3
      WRITE(IUNIT) NX, NY, NZ

C---- Write out the array itself
      WRITE(IUNIT) (ARRAY(I), I = 1, N1 * N2 * N3)

C---- Write out fragment number and probe atom type
      WRITE(IUNIT) IFRAG, IATYPE, ICOUNT, FRGFRQ

C---- Close the file
      CLOSE(IUNIT)

      GO TO 999

C---- Fatal error
900   CONTINUE
      PRINT*, '**** Error opening output file:',
     -    FILSRF(1:LENSTR(FILSRF))
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INSIGH  -  Write out a formatted grid file for contouring by
C                        InsightII
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INSIGH(ARRAY,NX,NY,NZ,FILGRD,IUNIT,GRDSEP,VALMIN,
     -    VALMAX,TITLE)

CVAX      IMPLICIT NONE

      INTEGER       NX, NY, NZ

      CHARACTER*(*) FILGRD, TITLE
      INTEGER       I, IPT, IUNIT, LENSTR, LIM(6), NPTS
      REAL          ARRAY(NX*NY*NZ), GRDSEP, VALMIN(3), VALMAX(3)

C---- Initialise variables
      LIM(1) = NINT(VALMIN(1) / GRDSEP)
      LIM(2) = NINT(VALMAX(1) / GRDSEP)
      LIM(3) = NINT(VALMIN(2) / GRDSEP)
      LIM(4) = NINT(VALMAX(2) / GRDSEP)
      LIM(5) = NINT(VALMIN(3) / GRDSEP)
      LIM(6) = NINT(VALMAX(3) / GRDSEP)
      NPTS = NX * NY * NZ

C---- Open the output file
      OPEN(UNIT=IUNIT,FILE=FILGRD,STATUS='UNKNOWN',FORM='FORMATTED',
     -     ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write out the header records
      WRITE(IUNIT,20) TITLE(1:LENSTR(TITLE)), FILGRD(1:LENSTR(FILGRD))
 20   FORMAT(A,' Filename: ',A)
      WRITE(IUNIT,40)
 40   FORMAT('(1F15.10)')
      WRITE(IUNIT,60) VALMAX(1) - VALMIN(1), VALMAX(2) - VALMIN(2),
     -    VALMAX(3) - VALMIN(3), 90.0, 90.0, 90.0
 60   FORMAT(6F10.3)
      WRITE(IUNIT,100) NX - 1, NY - 1, NZ - 1
 100  FORMAT(3I6)
      WRITE(IUNIT,120) 1, (LIM(I), I = 1, 6)
 120  FORMAT(7I6)

C---- Write out the array values
      WRITE(IUNIT,140) (ARRAY(IPT), IPT = 1, NPTS)
 140  FORMAT(1F15.10)

C---- Close output file
      CLOSE(IUNIT)

      GO TO 999

C---- Fatal error
900   CONTINUE
      PRINT*, '*** Error opening output InsightII file, ',
     -    FILGRD(1:LENSTR(FILGRD))

999   CONTINUE
      RETURN
      END

C-----------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE QUANTA  -  Routines to output brick maps in Quanta format.
C                        Based heavily on Rod Hubbard's map conversion
C                        routines supplied with Quanta v.3
C
C REHu 15 June 1987
C
C This program converts an electron density map into a bricked
C map ready for HYDRA to use
C based very closely on the FRODO bricked map format
C but not quite the same
C I am not convinced I have fully coped with axis swapping
C the aim is that this comes out with bricks still fractional
C in coordinate system but with the axes ordered a b c.
C
C The unformatted direct access ouput map file has a size of
C 54 words ie a brick of 6x6x6
C the density is stored in byte format - the scale and offset in 
C the header record scale the density to its 'real' value
C note that each brick shares a common plane of density with 
C adjacent bricks.
C
C Important note:  When compiling on a Silicon Graphics, need to
C                  set the SGI flag to .TRUE. below. Otherwise
C                  the brick files generated will not be read in
C                  correctly by Quanta.
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      SUBROUTINE QUANTA(ARRAY,NX,NY,NZ,IMAP,outfile,GRDSEP,MAPAV,
C     -    MAPMIN,MAPMAX,VALMIN,VALMAX)
      SUBROUTINE QUANTA(ARRAY,NX,NY,NZ,outfile,GRDSEP,MAPAV,MAPMIN,
     -    MAPMAX,VALMIN,VALMAX)
CHANGE v.1.4<--

CVAX      IMPLICIT NONE


      common/limits/nx1,nx2,ny1,ny2,nz1,nz2
c
c
c
        integer    lenbrk, maxtit, mxrrho
      parameter (maxtit=10,mxrrho=300,lenbrk=6)
c the parameter mxrrho should be altered if your map is bigger than 200
c grid points on any one axis
      real rho(mxrrho,mxrrho)
      integer brick(mxrrho,mxrrho,lenbrk)
      real rhobrk(mxrrho,mxrrho,lenbrk)
      integer*2 intbrk(mxrrho,mxrrho,lenbrk)
      integer i,inz,irecno,iu,iu1,iu2,iv,iv1,iv2,iw,ix,iy,iz,j,k,
     -         ldslab,m,maxrrh,ncode,nsec,numb2,iuvw,mxyz,nw1,nu1,nu2,
     -          nv1,nv2,nx1,nx2,ny1,ny2,nz1,nz2
      real offset,scale,cell,rhmin,rhmax,rhrms
      common/maphed/nsec,iuvw(3),mxyz(3),nw1,nu1,nu2,nv1,nv2,rhrms,
     1            offset,scale,cell(6),rhmin,rhmax,ncode
      character*100 title
      character*40 outfile
      integer ntitle,nbuvw,lenbrc,iformat
      common/hbriks/ntitle,lenbrc,nbuvw(3)
      common/hbrikc/title(maxtit)
      logical format
      integer nuvw(3),ixyz(3),nbxyz,isort
      logical print,output_file,input_file
      character*1 output_type
      equivalence (brick(1,1,1),intbrk(1,1,1),rhobrk(1,1,1))
      common/forgotit/nbxyz(3),iformat,print,output_file,input_file
      common/typeout/output_type
      LOGICAL     SGI
      COMMON/MACHIN/ SGI

CHANGE v.1.4-->
C      INTEGER       IMAP, MXARR, NX, NY, NZ
      INTEGER       MXARR, NX, NY, NZ
CHANGE v.1.4<--

      REAL          ARRAY(NX*NY*NZ), GRDSEP, MAPAV, MAPMAX, MAPMIN,
     -              VALMIN(3), VALMAX(3)

      save

C---- If compiling on a Silicon Graphics, set flag to true
      SGI = .TRUE.

      MXARR = NX * NY * NZ
      print = .TRUE.
      lenbrc=lenbrk
      maxrrh=mxrrho

c     zero all brick density
CHANGE v.1.6.6-->
C      do 1 k=1,lenbrk
C      do 1 j=1,mxrrho
      do 3 k=1,lenbrk
          do 2 j=1,mxrrho
CHANGE v.1.6<--
              do 1 i=1,mxrrho
                  intbrk(i,j,k)=0
                  rhobrk(i,j,k)=0
CHANGE v.1.6.6-->
C 1    brick(i,j,k)=0
                  brick(i,j,k)=0
 1            continue
 2        continue
 3    continue
CHANGE v.1.6<--

c     pack away all input command line arguments
      format=.false.
      input_file = .true.
      output_file = .true.
      output_type = 'S'
      iformat=8
      format=.true.
CHANGE v.1.4-->
C      CALL GETHED(NX,NY,NZ,mxrrho,IMAP,GRDSEP,MAPAV,MAPMIN,MAPMAX,
      CALL GETHED(NX,NY,NZ,mxrrho,GRDSEP,MAPAV,MAPMIN,MAPMAX,
CHANGE v.1.4<--
     -    VALMIN,VALMAX)

c     work out the sort code for the map
      nx1=nu1
      nx2=nu2
      ny1=nv1
      ny2=nv2
      nz1=nw1
      nz2=nw1+nsec-1
      isort = 1

c     calculate the appropriate scale and offset values to convert to a byte
      scale=16000./(rhmax-rhmin)
      offset=-rhmin

c     calculate the number of points in the map
      nuvw(1)=nu2-nu1+1
      nuvw(2)=nv2-nv1+1
      nuvw(3)=nsec

c     calculate the number of bricks in the map
      do 101 i=1,3
CHANGE v.1.6.6-->
C 101  nbuvw(i)=1 + (nuvw(i) - 2)/(lenbrk-1)
         nbuvw(i)=1 + (nuvw(i) - 2)/(lenbrk-1)
 101  continue
CHANGE v.1.6<--
c
      do 103 i=1,3
CHANGE v.1.6.6-->
C 103  nbxyz(iuvw(i))=nbuvw(i)
          nbxyz(iuvw(i))=nbuvw(i)
 103  continue
CHANGE v.1.6<--

c     write out all information for debugging
      if(print)write(*,102)iuvw,nuvw,nbuvw
 102  format(///,' Converting a map to HYDRA brick format',/,
     1           '           order of axes:',3i7,/,
     2           ' number of points in map:',3i7,/,
     3           ' number of bricks in map:',3i7)

      do 105 i=1,3
          if(nuvw(i).gt.mxrrho) then
              write(*,106)nuvw(i),mxrrho
 106          format('One of the dimensions of the map ',i6,
     1            ' is greater than the program can accept',i6,
     2            ' edit mhbmap.f and change mxrrho ')
              stop
          endif
 105  continue

c     open up the output brick map and write the title
      call mbrwrh(outfile)
      iz=nw1-1
      ix=nu2-nu1+1
      iy=nv2-nv1+1

c     loop over the bricks in the slowest axis
CROMAN
      inz = 0
CROMAN
      do 200 m=1,nbuvw(3)

c         load up lenbrk sections to make a slab
              if(m.eq.1) then

c             for the first slab load up lenbrk sections starting at
c             position 1
              ldslab=1
          else

c             for subsequent sections transfer the last section to
c             the first section
CHANGE v.1.6.6-->
C              do 221 j=1,iy
              do 222 j=1,iy
CHANGE v.1.6<--
                  do 221 i=1,ix
                      intbrk(i,j,1)=intbrk(i,j,lenbrk)
 221              continue
CHANGE v.1.6.6-->
 222          continue
CHANGE v.1.6<--

c             and zero the rest of the brick
CHANGE v.1.6.6-->
C              do 2021 k=2,lenbrk
C              do 2021 j=1,iy
              do 2023 k=2,lenbrk
                  do 2022 j=1,iy
CHANGE v.1.6<--
                      do 2021 i=1,ix
                          intbrk(i,j,k)=0
 2021                 continue
CHANGE v.1.6.6-->
 2022             continue
 2023         continue
CHANGE v.1.6<--
              ldslab=2
          endif
          do 202 k=ldslab,lenbrk
CROMAN
              inz = inz + 1
              call mrdse8(rho,maxrrh,inz,ix,iy,ARRAY,NX,NY,NZ)
CROMAN
              if(inz.eq.-1) go to 2041
              do 203 j=1,iy
CHANGE v.1.6.6-->
C              do 203 i=1,ix
                  do 204 i=1,ix
CHANGE v.1.6<--
                      numb2=nint((rho(i,j)+offset)*scale)
                      intbrk(i,j,k)=numb2
CHANGE v.1.6.6-->
 204              continue
CHANGE v.1.6<--
 203          continue
 202      continue
 2041     continue

c         having loaded the bricks now write them out appropriately
C         Write(*,*)' nbuvw ',nbuvw
CHANGE v.1.6.6-->
C          do 210 j=1,nbuvw(2)
          do 211 j=1,nbuvw(2)
CHANGE v.1.6<--
          do 210 i=1,nbuvw(1)

c             deconvolute i,j,m into indices on xyz
              ixyz(iuvw(1))=i
              ixyz(iuvw(2))=j
              ixyz(iuvw(3))=m

c             calculate the record number for this brick
              irecno=(ixyz(3)-1)*nbxyz(2)*nbxyz(1)
     1            +(ixyz(2)-1)*nbxyz(1)
     1            +ixyz(1)

c             allow for the titles and header records
              irecno=irecno+2+ntitle
cdebug
C write(*,*)' irecno i j m, ixyz ',irecno,i,j,m,(ixyz(k),k=1,3)

c             calculate the beginning and end of the x,y and z
              iu1=(i-1)*(lenbrk-1)+1
              iu2=i*(lenbrk-1)+1
              iv1=(j-1)*(lenbrk-1)+1
              iv2=j*(lenbrk-1)+1
C Write(*,*)' iu1 iu2 iv1 iv2 ',iu1,iu2,iv1,iv2
              go to (301,302,303,304,305,306)isort

 301          continue
              write(10,rec=irecno)(((intbrk(iu,iv,iw),iu=iu1,iu2),
     1            iv=iv1,iv2),iw=1,lenbrk)
              goto 310

 302          continue
              write(10,rec=irecno)(((intbrk(iu,iv,iw),iu=iu1,iu2),
     1            iw=1,lenbrk),iv=iv1,iv2)
              goto 310

 303          continue
              write(10,rec=irecno)(((intbrk(iu,iv,iw),iw=1,lenbrk),
     1            iu=iu1,iu2),iv=iv1,iv2)
              goto 310

 304          continue
              write(10,rec=irecno)(((intbrk(iu,iv,iw),iv=iv1,iv2),
     1            iu=iu1,iu2),iw=1,lenbrk)
              goto 310

 305          continue
              write(10,rec=irecno)(((intbrk(iu,iv,iw),iv=iv1,iv2),
     1            iw=1,lenbrk),iu=iu1,iu2)
              goto 310

 306          continue
              write(10,rec=irecno)(((intbrk(iu,iv,iw),iw=1,lenbrk),
     1            iv=iv1,iv2),iu=iu1,iu2)
 310          continue

c write(*,209)(((brick(u,v,w),l=iu1,iu2),n=iv1,iv2),
c     1            k=1,lenbrk)
 209          format(6i4)
 210      continue
CHANGE v.1.6.6-->
 211      continue
CHANGE v.1.6<--
 200  continue

      if(print)write(*,*)' finished '
      CLOSE(10)

      RETURN
      end

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETHED  -  Routine to set-up header information for the
C                        brick file
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      subroutine GETHED(NXPTS,NYPTS,NZPTS,MXRRHO,IMAP,GRDSEP,MAPAV,
C     -      MAPMIN,MAPMAX,VALMIN,VALMAX)
      subroutine GETHED(NXPTS,NYPTS,NZPTS,MXRRHO,GRDSEP,MAPAV,MAPMIN,
     -      MAPMAX,VALMIN,VALMAX)
CHANGE v.1.4<--


CHANGE v.1.4-->
C      integer ICOORD,IMAP,iuvwp,mode,mxyz,n,ncode,nsec,nsg,nu,nu1,
      integer ICOORD,iuvwp,mode,mxyz,n,ncode,nsec,nsg,nu,nu1,
CHANGE v.1.4<--
     -          nu2,nv,nv1,nv2,nw,nw1,lspgrp
      real offset,rhrms,rl,rm,ru,sc,scalep,cell,rhmin,rhmax
      common/maphed/nsec,iuvwp(3),mxyz(3),nw1,nu1,nu2,nv1,nv2,rhrms,
     1            offset,scalep,cell(6),rhmin,rhmax,ncode


      CHARACTER*45  ENDBIT
      INTEGER       LIM(6), LOWER, MXRRHO, NPTS(3), NXPTS, NYPTS,
     -              NZPTS, UPPER
      REAL          GRDSEP, MAPAV, MAPMAX, MAPMIN, VALMIN(3), VALMAX(3)


C---- Total number of grid points
      N = NXPTS * NYPTS * NZPTS

C---- Display grid size
      WRITE(ENDBIT,90) NXPTS, NYPTS, NZPTS, N
 90   FORMAT(I8,2('  x',I8),'  =',I8)
      PRINT*, 'Size of grid-box array:        ', ENDBIT
      PRINT*

C---- Check that number of points along any axis not greater than allowed by
C     brick-generating routines
      IF (NXPTS.GT.MXRRHO .OR. NYPTS.GT.MXRRHO .OR. NZPTS.GT.MXRRHO)
     -    GO TO 914

C---- Set up the variables required for generating a brick map

C---- Number of grid-points in each direction
      NPTS(1) = NXPTS
      NPTS(2) = NYPTS
      NPTS(3) = NZPTS
      DO 400, ICOORD = 1, 3
          LOWER = 2 * ICOORD - 1
          UPPER = LOWER + 1
          LIM(LOWER) = NINT(VALMIN(ICOORD) / GRDSEP)
          LIM(UPPER) = LIM(LOWER) + NPTS(ICOORD) - 1
 400  CONTINUE
      LSPGRP = 0
      NW1 = LIM(5)
      NU1 = LIM(1)
      NU2 = LIM(2)
      NV1 = LIM(3)
      NV2 = LIM(4)

C---- Number of sections and fast, medium and slow axes
      N = (LIM(2) - LIM(1) + 1) * (LIM(4) - LIM(3) + 1)
      NU = LIM(2) - LIM(1) + 1
      NV = LIM(4) - LIM(3) + 1
      NW = LIM(6) - LIM(5) + 1
      NSEC = NW
      IUVWP(1) = 1
      IUVWP(2) = 2
      IUVWP(3) = 3
      
C---- Number of x-, y-, and z-points, NSG, MODE and scale factor
      MXYZ(1) = NU - 1
      MXYZ(2) = NV - 1
      MXYZ(3) = NW - 1
      NSG = 1
      MODE = 2
      NCODE = 1
      SC = 1.0
  
C---- Cell coordinates
      VALMAX(1) = VALMIN(1) + GRDSEP * MXYZ(1)
      VALMAX(2) = VALMIN(2) + GRDSEP * MXYZ(2)
      VALMAX(3) = VALMIN(3) + GRDSEP * MXYZ(3)
      CELL(1) = VALMAX(1) - VALMIN(1)
      CELL(2) = VALMAX(2) - VALMIN(2)
      CELL(3) = VALMAX(3) - VALMIN(3)
      CELL(4) = 90.0
      CELL(5) = 90.0
      CELL(6) = 90.0

C---- Lowest, highest, and mean values in map
      RHRMS = 0.0
      RL = MAPMIN
      RU = MAPMAX
      RM = MAPAV
      RHMIN = MAPMIN
      RHMAX = MAPMAX
  
      GO TO 999

C---- Errors
 914  CONTINUE
      PRINT*, '*** ERROR. Maximum number of points along a single axis',
     -    ' exceeded:', MXRRHO
      PRINT*, '    Cannot create a Quanta brick file'
      GO TO 990

C---- Set error flag to true
 990  CONTINUE
      STOP

 999  CONTINUE
      return      
      end 


C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MRDSE8  -  Routine to pick up next grid section from the
C                        grid
C
C----------------------------------------------------------------------+--- 

      subroutine mrdse8(rho,mxrrho,nz,nnx,nny,GRID,NXPTS,NYPTS,NZPTS)
        integer mxrrho
      real rho(mxrrho,mxrrho)
      integer iuvw,mxyz,ncode,nnx,nny,nsec,nw1,nu1,nu2,nv1,nv2,nz
      real offset,scale,cell,rhmin,rhmax,rhrms
      common/maphed/nsec,iuvw(3),mxyz(3),nw1,nu1,nu2,nv1,nv2,rhrms,
     1            offset,scale,cell(6),rhmin,rhmax,ncode

      INTEGER       I, J, NXPTS, NYPTS, NZPTS
      REAL          GRID(NXPTS,NYPTS,NZPTS)

C---- Transfer array values across to density array for further processing
      IF (NZ.LE.NZPTS) THEN
          DO 200, J = 1, NNY
              DO 100, I = 1, NNX
                  RHO(I,J) = GRID(I,J,NZ)
 100          CONTINUE
 200      CONTINUE
      ELSE
          DO 400, J = 1, NNY
              DO 300, I = 1, NNX
                  RHO(I,J) = -OFFSET
 300          CONTINUE
 400      CONTINUE
      ENDIF

      return
      end

C-------------------------------------------------------------------------- 
C**************************************************************************
C
C  SUBROUTINE MBRWRH  -  Routine to write header for Quanta brick map
C
C----------------------------------------------------------------------+--- 

      subroutine mbrwrh(filnam)
        integer    maxtit
      parameter (maxtit=10)
      integer i,iformat,ir,iuvw,jk,mxyz,ncode,nr,nsec,nw1,
     -          nu1,nu2,nv1,nv2,nx1,nx2,ny1,ny2,nz1,nz2
      real offset,scale,cell,rhmin,rhmax,rhrms
      common/maphed/nsec,iuvw(3),mxyz(3),nw1,nu1,nu2,nv1,nv2,rhrms,
     1            offset,scale,cell(6),rhmin,rhmax,ncode
      character*100 title
      common/limits/nx1,nx2,ny1,ny2,nz1,nz2
      integer ftype,ntitle,nbuvw,lenbrc
      common/hbriks/ntitle,lenbrc,nbuvw(3)
      common/hbrikc/title(maxtit)
      LOGICAL     SGI
      COMMON/MACHIN/ SGI

      character*40 filnam
      integer nbxyz
      logical print,output_file,input_file
      character*1 output_type
      common/forgotit/nbxyz(3),iformat,print,output_file,input_file
        common/typeout/output_type
c
      ntitle = 0
      ftype = 2
      if(.not.output_file) then
          write(*,*)' Enter output bricked map filename:'      
          read(*,10)filnam
 10       format(a)
      endif
      ir=2
      nr=ir*216
CSGI
C---- If the machine is a Silicon Graphics (bloody nuisance), have
C     to reduce the size of the record length by a factor of 4
      IF (SGI) THEN
          nr = nr / 4
      ENDIF
CSGI
      open(10,file=filnam,form='unformatted',access='direct',
     1    recl=nr,status='unknown',err=99)
c
c write header units
      ntitle = ntitle + 1
      write(10,rec=1)'mbk_1.0',ntitle,output_type
      PRINT*, 'mbk_1.0',ntitle,output_type
      PRINT*, 'Record length = ', nr, ir
      title(1)='HEADER Brick Map Converted'//'S'//char(48+ir)
      do 20 i=1,ntitle
          write(10,rec=(i+1))title(i)
          PRINT*, title(i)
 20   continue
      write(10,rec=ntitle+2)nz2-nz1+1,mxyz,(nbxyz(jk),jk=1,3),
     1    nz1,nx1,nx2,ny1,ny2,
     1    cell,rhrms,offset,scale,lenbrc,ncode,rhmin,
     2    rhmax
      PRINT*, nz2-nz1+1,mxyz,(nbxyz(jk),jk=1,3),
     1    nz1,nx1,nx2,ny1,ny2,
     1    cell,rhrms,offset,scale,lenbrc,ncode,rhmin,
     2    rhmax
      if(print) then
          write(*,*)
          write(*,*)
          write(*,*)' written header for file ', filnam
      endif
      return

 99   write(*,*)' problems opening file for bricked map output'      
      stop
      end

C-------------------------------------------------------------------------- 
C**************************************************************************
C
C  SUBROUTINE GETSRF  -  Read in the array of density values from the
C                        given .srf file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GETSRF(FILSRF,IUNIT,ARRAY,MAXARR,NX,NY,NZ,FILTYP,
     -    GRDSEP,GRDMIN,GRDMAX,GRDTOT,IFRAG,IATYPE,ICOUNT,FRGFRQ,NOMESS,
CHANGE v.1.4.2-->
C     -    IFAIL)
     -    HDONLY,IFAIL)
CHANGE v.1.4.2<--

      INTEGER       MAXARR

      CHARACTER*1   FILTYP
      CHARACTER*45  ENDBIT
      CHARACTER*(*) FILSRF
      INTEGER       GCOUNT, I, IATYPE, ICOUNT, IFRAG, IUNIT, LENSTR,
     -              LINE, N, NX, NY, NZ
CHANGE v.1.4.2-->
C      LOGICAL       IFAIL, NOMESS
      LOGICAL       HDONLY, IFAIL, NOMESS
CHANGE v.1.4.2<--
      REAL          ARRAY(MAXARR), FRGFRQ, GRDMAX(3), GRDMIN(3), GRDSEP,
     -              GRDTOT

C---- Initialise variables
      DO 50, I = 1, MAXARR
          ARRAY(I) = 0.0
 50   CONTINUE
      DO 100, I = 1, 3
          GRDMIN(I) = 0.0
          GRDMAX(I) = 0.0
 100  CONTINUE
      FRGFRQ = 0.0
      GRDTOT = 0.0
      IATYPE = 0
      ICOUNT = 0
      IFAIL = .FALSE.
      IFRAG = 0
      LINE = 0
      NX = 0
      NY = 0
      NZ = 0
      IF (.NOT.NOMESS) THEN
          PRINT*, 'Reading in .srf file: ', FILSRF(1:LENSTR(FILSRF))
          PRINT*
      ENDIF

C---- Open the .srf file
      OPEN(UNIT=IUNIT, FILE=FILSRF, STATUS='OLD', FORM='UNFORMATTED',
     -     ACCESS='SEQUENTIAL',
CVAX     -     READONLY,
     -     ERR=900)

C---- Read in reference corner coordinates and grid separation
      LINE = LINE + 1
      READ(IUNIT,ERR=902,END=912) (GRDMIN(I), I = 1, 3), GRDSEP,
     -    FILTYP

C---- Check that the file-type is valid
      IF (FILTYP.NE.'S' .AND. FILTYP.NE.'C' .AND. FILTYP.NE.'N')
     -    GOTO 914

C---- Read in grid size
      LINE = LINE + 1
      READ(IUNIT,ERR=904,END=912) NX, NY, NZ
      N = NX * NY * NZ

C---- Compute the maximum coordinates of the grid
      GRDMAX(1) = GRDMIN(1) + GRDSEP * (NX - 1)
      GRDMAX(2) = GRDMIN(2) + GRDSEP * (NY - 1)
      GRDMAX(3) = GRDMIN(3) + GRDSEP * (NZ - 1)

C---- Display grid size AND check that array not too large for array bounds
      WRITE(ENDBIT,90) NX, NY, NZ, N
 90   FORMAT(I8,2('  x',I8),'  =',I8)
      IF (.NOT.NOMESS) THEN
          PRINT*, 'Size of grid-box array:        ', ENDBIT
          PRINT*
      ENDIF
      IF (N.GT.MAXARR) GO TO 906

CHANGE v.1.4.2-->
C---- If data required (ie not just header info), then read it in
      IF (.NOT.HDONLY) THEN
CHANGE v.1.4.2<--

C----     Read in data array
          LINE = LINE + 1
          READ(IUNIT,ERR=908,END=912) (ARRAY(I), I = 1, N)

C----     Read in fragment number and probe atom type
          LINE = LINE + 1
          READ(IUNIT,ERR=910,END=912) IFRAG, IATYPE, ICOUNT, FRGFRQ

C----     Sum all the points in the array
          GCOUNT = 0
          DO 200, I = 1, N
              GRDTOT = GRDTOT + ARRAY(I)
              IF (ARRAY(I).GT.0.0) GCOUNT = GCOUNT + 1
 200      CONTINUE
          IF (.NOT.NOMESS) THEN
              PRINT*, 'Number of non-zero grid points: ', GCOUNT
              PRINT*
          ENDIF
CHANGE v.1.4.2-->
      ENDIF
CHANGE v.1.4.2<--

C---- Close the data file
      CLOSE(IUNIT)

      GO TO 999

C     E R R O R   C O N D I T I O N S

C---- Fatal errors
 900  CONTINUE
      IF (.NOT.NOMESS) THEN
          PRINT*, '*** ERROR. File not found. [',
     -        FILSRF(1:LENSTR(FILSRF)), ']'
      ENDIF
      GO TO 990

 902  CONTINUE
      PRINT 903, '*** ERROR. Reading input .srf file at line',
     -     LINE, '.  [VALMIN,GRDSEP,FILTYP]'
 903  FORMAT(A,I4,A)
      GO TO 980

 904  CONTINUE
      PRINT 903, '*** ERROR. Reading input .srf file at line',
     -     LINE, '.  [NX,NY,NZ]'
      GO TO 980

 906  CONTINUE
      PRINT*, '*** ERROR. Maximum array size exceeded for input .srf f',
     -    'ile: ', MAXARR
      GO TO 980

 908  CONTINUE
      PRINT*, '*** ERROR. Reading input .srf file at line',
     -     LINE, '.  [Array]'
      GO TO 980

 910  CONTINUE
      PRINT*, '*** ERROR. Reading input .srf file at line',
     -     LINE, '.  [IFRAG,IATYPE,ICOUNT,FRGFRQ]'
      GO TO 980

 912  CONTINUE
      PRINT*, '*** ERROR. Premature end-of-file in .srf file ',
     -      'at line', LINE
      GO TO 980

 914  CONTINUE
      PRINT*, '*** ERROR. Invalid file-type [', FILTYP, ']'
      GO TO 980

C---- Set error flag to true
 980  CONTINUE
      PRINT*, '***        in file [', FILSRF(1:LENSTR(FILSRF)), ']'

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6-->
C**************************************************************************
C
C  SUBROUTINE REAGRD  -  Read in the grid values from an InsightII-format
C                        .grd file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE REAGRD(FILGRD,IUNIT,ARRAY,MAXARR,NX,NY,NZ,FILTYP,
     -    GRDSEP,GRDMIN,GRDMAX,GRDTOT,IFRAG,IATYPE,ICOUNT,FRGFRQ,NOMESS,
     -    TITLE,IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       MAXARR

      CHARACTER*1   FILTYP
      CHARACTER*20  FMT
      CHARACTER*45  ENDBIT
      CHARACTER*(*) FILGRD, TITLE
      INTEGER       GCOUNT, I, IATYPE, ICOUNT, IFRAG, IPT, IUNIT,
     -              LENSTR, LIM(6), LINE, N, NX, NY, NZ
      LOGICAL       IFAIL, NOMESS
      REAL          ARRAY(MAXARR), FRGFRQ, GRDSEP, GRDMIN(3), GRDMAX(3),
     -              GRDTOT, GRDWID(3)

C---- Initialise variables
      DO 50, I = 1, MAXARR
          ARRAY(I) = 0.0
 50   CONTINUE
      GRDTOT = 0.0
      DO 100, I = 1, 3
          GRDMIN(I) = 0.0
          GRDMAX(I) = 0.0
 100  CONTINUE
      FILTYP = 'S'
      FRGFRQ = 0.0
      GRDTOT = 0.0
      IATYPE = 0
      ICOUNT = 0
      IFAIL = .FALSE.
      IFRAG = 0
      LINE = 0
      NX = 0
      NY = 0
      NZ = 0
      IF (.NOT.NOMESS) THEN
          PRINT*, 'Reading in .grd file: ', FILGRD(1:LENSTR(FILGRD))
          PRINT*
      ENDIF

C---- Open the output file
      OPEN(UNIT=IUNIT,FILE=FILGRD,STATUS='OLD',FORM='FORMATTED',
     -     ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Read in the header records
      LINE = LINE + 1
      READ(IUNIT,120,ERR=902,END=916) TITLE
 120  FORMAT(A)
      LINE = LINE + 1
      READ(IUNIT,120,ERR=904,END=916) FMT
      LINE = LINE + 1
      READ(IUNIT,160,ERR=906,END=916) GRDWID(1), GRDWID(2), GRDWID(3)
 160  FORMAT(3F10.3)
      LINE = LINE + 1
      READ(IUNIT,200,ERR=908,END=916) NX, NY, NZ
 200  FORMAT(3I6)
      NX = NX + 1
      NY = NY + 1
      NZ = NZ + 1
      LINE = LINE + 1
      READ(IUNIT,220,ERR=910,END=916) (LIM(I), I = 1, 6)
 220  FORMAT(6X,6I6)

C---- Display grid size AND check that array not too large for array bounds
      N = NX * NY * NZ
      WRITE(ENDBIT,250) NX, NY, NZ, N
 250  FORMAT(I8,2('  x',I8),'  =',I8)
      IF (.NOT.NOMESS) THEN
          PRINT*, 'Size of grid-box array:        ', ENDBIT
          PRINT*
      ENDIF
      IF (N.LE.0 .OR. N.GT.MAXARR) GO TO 912

C---- Calculate grid parameters from data read in
      GRDSEP = GRDWID(1) / (NX - 1)
      GRDMIN(1) = LIM(1) * GRDSEP
      GRDMAX(1) = LIM(2) * GRDSEP
      GRDMIN(2) = LIM(3) * GRDSEP
      GRDMAX(2) = LIM(4) * GRDSEP
      GRDMIN(3) = LIM(5) * GRDSEP
      GRDMAX(3) = LIM(6) * GRDSEP

C---- Read in the array values
      DO 500, IPT = 1, N
          LINE = LINE + 1
          READ(IUNIT,FMT,ERR=914,END=916) ARRAY(IPT)
 500  CONTINUE

C---- Count the num,ber of non-zero grid point and their sum
      GCOUNT = 0
      DO 600, I = 1, N
          GRDTOT = GRDTOT + ARRAY(I)
          IF (ARRAY(I).GT.0.0) GCOUNT = GCOUNT + 1
 600  CONTINUE
      IF (.NOT.NOMESS) THEN
          PRINT*, 'Number of non-zero grid points: ', GCOUNT
          PRINT*
      ENDIF

C---- Close output file
      CLOSE(IUNIT)

      GO TO 999

C---- Fatal error
900   CONTINUE
      IF (.NOT.NOMESS) THEN
          PRINT*, '*** Error opening output InsightII file, ',
     -        FILGRD(1:LENSTR(FILGRD))
      ENDIF

 902  CONTINUE
      PRINT*, '*** ERROR. Reading input .grd file at line',
     -     LINE, '.  [TITLE]'
      GO TO 990

 904  CONTINUE
      PRINT*, '*** ERROR. Reading input .grd file at line',
     -     LINE, '.  [FORMAT]'
      GO TO 990

 906  CONTINUE
      PRINT*, '*** ERROR. Reading input .grd file at line',
     -     LINE, '.  [GRDWID]'
      GO TO 990

 908  CONTINUE
      PRINT*, '*** ERROR. Reading input .grd file at line',
     -     LINE, '.  [NX,NY,NZ]'
      GO TO 990

 910  CONTINUE
      PRINT*, '*** ERROR. Reading input .grd file at line',
     -     LINE, '.  [LIM(I), I = 1, 6]'
      GO TO 990

 912  CONTINUE
      PRINT*, '*** ERROR. Maximum array size exceeded for input .grd f',
     -    'ile: ', MAXARR
      GO TO 990

 914  CONTINUE
      PRINT*, '*** ERROR. Reading input .grd file at line',
     -     LINE, '.  [Array]'
      GO TO 990

 916  CONTINUE
      PRINT*, '*** ERROR. Premature end-of-file in .grd file ',
     -      'at line', LINE
      GO TO 990

C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C-----------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C  SUBROUTINE GETFAC  -  Calculate normalization factor for density
C                        contours. Place a single point in the middle of
C                        the grid, calculate the values of the surrounding
C                        grid-points and sum them. The value obtained is
C                        used as a normalization factor
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GETFAC(ARRAY,MAXARR,NX,NY,NZ,VALMIN,VALMAX,GRDSEP,
     -    RSCALE,PFACTR)

CVAX      IMPLICIT NONE

      INTEGER       NFAC
CHANGE v.1.6.4-->
C      PARAMETER    (NFAC = 3)
      PARAMETER    (NFAC = 12)
CHANGE v.1.6.4<--

CHANGE v.1.6.4-->
C      INTEGER       GRPTS, I, IFAC, MAXARR, NUSED, NX, NY, NZ
      INTEGER       GRPTS, I, J, K, MAXARR, NUSED, NX, NY, NZ
CHANGE v.1.6.4<--
      LOGICAL       NUMCNT, SUMDEN
CHANGE v.1.6.4-->
C      REAL          ARAD, ARRAY(MAXARR), ASTK, COORDS(3), GRDSEP,
C     -              MAPMAX, MAPMIN, PFACTR, RSCALE, VALMAX(3),
C     -              VALMIN(3)
      REAL          ARAD, ARRAY(MAXARR), ASTK, CALVAL, COORDS(3),
     -              CUTOFF, GRDSEP, MAPMAX, MAPMIN, ORIGIN(3), PFACTR,
     -              RSCALE, VALUE, VALMAX(3), VALMIN(3)
CHANGE v.1.6.4<--

C---- Initialise grid array
      DO 100, I = 1, MAXARR
          ARRAY(I) = 0.0
 100  CONTINUE
      NUSED = 0
      GRPTS = 0
      MAPMIN = 0.0
      MAPMAX = 0.0
      PFACTR = 0.0

C---- Initialise grid parameters
      SUMDEN = .TRUE.
      NUMCNT = .FALSE.
      ARAD = RSCALE * 0.62035049
      ASTK = - LOG(2.0) / (ARAD * ARAD)
      PRINT*
      PRINT*, 'Calculating normalization factor ...'

CHANGE v.1.6.4-->
CC---- Place first point at the centre of the grid-box
C      COORDS(1) = (VALMIN(1) + VALMAX(1)) / 2.0
C      COORDS(2) = (VALMIN(2) + VALMAX(2)) / 2.0
C      COORDS(3) = (VALMIN(3) + VALMAX(3)) / 2.0
C---- Determine coords of first dummy atom
      ORIGIN(1) = (VALMIN(1) + VALMAX(1)) / 2.0 - NFAC / 2
      ORIGIN(2) = (VALMIN(2) + VALMAX(2)) / 2.0 - NFAC / 2
      ORIGIN(3) = (VALMIN(3) + VALMAX(3)) / 2.0 - NFAC / 2
CHANGE v.1.6.4<--

CHANGE v.1.6.4-->
CC---- Loop over the points to be tried
C      DO 200, IFAC = 1, NFAC
C---- Loop over the dummy atoms to be placed
      DO 250, I = 1, NFAC

C----     Compute the x-coord of this dummy atom
          COORDS(1) = ORIGIN(1) + (I - 1)

          DO 200, J = 1, NFAC

C----         Compute the y-coord of this dummy atom
              COORDS(2) = ORIGIN(2) + (J - 1)

              DO 150, K = 1, NFAC

C----             Compute the z-coord of this dummy atom
                  COORDS(3) = ORIGIN(3) + (K - 1)
CHANGE v.1.6.4<--

C----             Update grid array for this dummy atom
                  CALL GRID(ARRAY,NX,NY,NZ,COORDS,ASTK,1.0,GRDSEP,
     -                VALMIN,NUMCNT,SUMDEN,.FALSE.,1.0,NUSED,GRPTS,
     -                MAPMIN,MAPMAX)

CHANGE v.1.6.4-->
CC----     Shift the coordinates of the point for next loop
C          COORDS(1) = COORDS(1) + GRDSEP / 4.0
C          COORDS(2) = COORDS(2) + GRDSEP / 4.0
C          COORDS(3) = COORDS(3) + GRDSEP / 4.0
C 200  CONTINUE
 150          CONTINUE
 200      CONTINUE
 250  CONTINUE
CHANGE v.1.6.4<--

CHANGE v.1.6.4-->
CC---- Sum all the grid-points
C      DO 400, I = 1, MAXARR
C          PFACTR = PFACTR + ARRAY(I)
C 400  CONTINUE

CC---- Average over the number of points placed
C      PFACTR = PFACTR / NFAC
C---- Initialise top density value
      CUTOFF = 0.0

C---- Loop over all the internal grid-points to get the density values
C     returned
      DO 800, I = 3, NFAC - 2
          DO 700, J = 3, NFAC - 2
              DO 600, K = 3, NFAC - 2

C----             Calculate coords of this point
                  COORDS(1) = ORIGIN(1) + (I - 1)
                  COORDS(2) = ORIGIN(2) + (J - 1)
                  COORDS(3) = ORIGIN(3) + (K - 1)

C----             Get the map density at this point
                  VALUE = CALVAL(ARRAY,NX,NY,NZ,VALMIN,GRDSEP,
     -                 COORDS(1),COORDS(2),COORDS(3))

C----             Store value if lowest so far
                  IF (CUTOFF.EQ.0.0 .OR. VALUE.LT.CUTOFF)
     -                CUTOFF = VALUE
 600          CONTINUE
 700      CONTINUE
 800  CONTINUE

C---- Calculate the scaling factor
      IF (CUTOFF.GT.0.0) THEN
          PFACTR = CUTOFF
      ENDIF
CHANGE v.1.6.4<--

C---- Make sure the factor is non-zero
      IF (PFACTR.EQ.0.0) PFACTR = 1.0

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GRID  -  Update the grid-points in the vicinity of the current
C                      atom using a Gaussian weighting scheme
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GRID(ARRAY,N1,N2,N3,XYZVAL,CONST,RAD,GRDSEP,VALMIN,
     -    NUMCNT,SUMDEN,ENGMAP,BVALUE,NUSED,GRPTS,MAPMIN,MAPMAX)

CVAX      IMPLICIT NONE

      INTEGER       GRPTS, I, ICOORD, IP, IPOINT(3), J, K, N1, N2, N3,
CHANGE v.1.6-->
C     -              NPOINT(3), NUSED
C      LOGICAL       ATUSED, ENGMAP, NUMCNT, OFFMAP, SUMDEN
CHANGE v.1.6.5-->
C     -              NPOINT(3), NUSED, VOLNUM
     -              FROM(3), TO(3), NPOINT(3), NUSED, VOLNUM
CHANGE v.1.6.5<--
      LOGICAL       ATUSED, ENGMAP, NUMCNT, OFFMAP, STOVOL, SUMDEN
CHANGE v.1.6<--
      REAL          ADJUST, ARRAY(N1,N2,N3), BVALUE, CALC, CDIST, CONST,
CHANGE v.1.6.5-->
C     -              CUTOFF, DIAM, DISTSQ, DIST2(3), FROM(3), GRDSEP,
C     -              MAPMAX, MAPMIN, OPVECT(3), PCOORD(3), R, RAD, TO(3),
C     -              VALMIN(3), XYZVAL(3)
     -              CUTOFF, DIAM, DISTSQ, DIST2(3), GRDSEP,
     -              MAPMAX, MAPMIN, OPVECT(3), PCOORD(3), R, RAD,
     -              VALMIN(3), XYZVAL(3)
CHANGE v.1.6.5<--

C---- Initialise variables
      ATUSED = .FALSE.
      DIAM = RAD + RAD
      CDIST = RAD + GRDSEP
      CUTOFF = CDIST * CDIST
      DISTSQ = 0.0
      NPOINT(1) = N1
      NPOINT(2) = N2
      NPOINT(3) = N3
      OFFMAP = .FALSE.

CHANGE v.1.6-->
C---- If generating gap index, extract the gap number
      IF (GRPTS.LT.0) THEN
          VOLNUM = - GRPTS
          STOVOL = .TRUE.
      ELSE
          VOLNUM = 0
          STOVOL = .FALSE.
      ENDIF
CHANGE v.1.6<--

C---- Process current atom
      DO 100, ICOORD = 1, 3

C----     Find the nearest grid-point to the atom's position and 
C         calculate its coordinates
          IP = (XYZVAL(ICOORD) - VALMIN(ICOORD)) / GRDSEP + 1.5
          IF (IP.LT.1) IP = 1
          IF (IP.GT.NPOINT(ICOORD)) IP = NPOINT(ICOORD)
          IPOINT(ICOORD) = IP
          PCOORD(ICOORD) = (IP - 1) * GRDSEP + VALMIN(ICOORD)
          CALC = XYZVAL(ICOORD) - PCOORD(ICOORD)
          DISTSQ = DISTSQ + CALC * CALC
 100  CONTINUE

C---- If grid-point is further than three times the atom's van der Waals
C     radius then atom has effectively no influence on any grid-points
C     at all
      IF (DISTSQ.GT.CUTOFF) OFFMAP = .TRUE.

C---- If point is not off map, update the values of the surrounding grid points
      IF (.NOT.OFFMAP .AND. .NOT.NUMCNT) THEN

C----     Calculate number of grid-points either side of nearest
C         that need to be updated
          DO 200, ICOORD = 1, 3
              IP = (XYZVAL(ICOORD) - CDIST - VALMIN(ICOORD))
     -            / GRDSEP + 1.5
              IF (IP.LT.1) IP = 1
              IF (IP.GT.NPOINT(ICOORD)) IP = NPOINT(ICOORD)
              FROM(ICOORD) = IP
              IP = (XYZVAL(ICOORD) + CDIST - VALMIN(ICOORD))
     -            / GRDSEP + 1.5
              IF (IP.LT.1) IP = 1
              IF (IP.GT.NPOINT(ICOORD)) IP = NPOINT(ICOORD)
              TO(ICOORD) = IP
 200      CONTINUE

C----     Loop through the points either side of nearest one in z-direction
          DO 380, K = FROM(3), TO(3)
              PCOORD(3) = (K - 1) * GRDSEP + VALMIN(3)
              OPVECT(3) =  PCOORD(3) - XYZVAL(3)
              DIST2(3) = OPVECT(3) * OPVECT(3)

C----         Loop through the points either side of nearest one in
C             y-direction
              DO 360, J = FROM(2), TO(2)
                  PCOORD(2) = (J - 1) * GRDSEP + VALMIN(2)
                  OPVECT(2) =  PCOORD(2) - XYZVAL(2)
                  DIST2(2) = OPVECT(2) * OPVECT(2)

C----             Loop through the points either side of nearest one in
C                 x-direction
                  DO 340, I = FROM(1), TO(1)
                      PCOORD(1) = (I - 1) * GRDSEP + VALMIN(1)
                      OPVECT(1) =  PCOORD(1) - XYZVAL(1)
                      DIST2(1) = OPVECT(1) * OPVECT(1)

C----                 Calculate adjustment required to current grid-point
                      ADJUST = 0.0

C----                 Calculate value at grid point using a Gaussian
C                     function
                      R = DIST2(1) + DIST2(2) + DIST2(3)

C----                 Use a spherically-symmetric Gaussian fn to update
C                     the current grid-point
                      ADJUST = EXP (CONST * R)

C----                 For energy map, use the value stored in the atom's
C                     B-value field
                      IF (ENGMAP) THEN
                          ADJUST = ADJUST * BVALUE
                      ENDIF

CHANGE v.1.6-->
C-----                If updating a gap-index file, score the grid-point
C                     using the appropriate gap-volume number
                      IF (STOVOL) THEN
                          IF (ADJUST.GT.0.5) THEN
                              ADJUST = VOLNUM
                          ELSE
                              ADJUST = 0.0
                          ENDIF
                      ENDIF
CHANGE v.1.6<--

C----                 Update grid point
                      ATUSED = .TRUE.
                      IF (ARRAY(I,J,K).EQ.0.0) GRPTS = GRPTS + 1
                      IF (SUMDEN) THEN
                          ARRAY(I,J,K) = ARRAY(I,J,K) + ADJUST
                      ELSE
                          ARRAY(I,J,K) = MAX(ADJUST,ARRAY(I,J,K))
                      ENDIF
                      MAPMAX = MAX(ARRAY(I,J,K),MAPMAX)
                      MAPMIN = MIN(ARRAY(I,J,K),MAPMIN)
340               CONTINUE
360           CONTINUE
380       CONTINUE

C---- If simply updating the array with number-counts of data points
      ELSE IF (.NOT.OFFMAP) THEN
          
C----     Update grid point
          I = IPOINT(1)
          J = IPOINT(2)
          K = IPOINT(3)
          ATUSED = .TRUE.
          IF (ARRAY(I,J,K).EQ.0.0) GRPTS = GRPTS + 1
          ARRAY(I,J,K) = ARRAY(I,J,K) + 1.0
      ENDIF

C---- If the current atom was used for updating the map, increment
C     count of atoms used
      IF (ATUSED) NUSED = NUSED + 1

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GRSCAL  -  Apply scaling factor to all points in the grid
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GRSCAL(ARRAY,NSIZE,FILTYP,SUMDEN,PFACTR,MAPTOT)

CVAX      IMPLICIT NONE

      INTEGER       NSIZE

      CHARACTER*1   FILTYP
      INTEGER       I
      LOGICAL       SUMDEN
      REAL          ARRAY(NSIZE), FACTOR, MAPTOT, PFACTR

C---- Initialise variables
      IF (SUMDEN .OR. FILTYP.EQ.'E') THEN
          FACTOR = 1.0 / PFACTR
      ELSE
          FACTOR = 200.0
      ENDIF
      MAPTOT = 0.0

C---- Loop through all the points in the grid
      DO 200, I = 1, NSIZE

C----     Apply multiplying factor of 200.0 such that, if doing van der
C         Waals surfaces, the surface will be at the density value of 100.0
          ARRAY(I) = FACTOR * ARRAY(I)
          MAPTOT = MAPTOT + ARRAY(I)
200   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE DELSRF  -  Delete the given .srf file
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE DELSRF(FILSRF,IUNIT)

      CHARACTER*(*) FILSRF
      INTEGER       IUNIT

C---- Open the .srf file
      OPEN(UNIT=IUNIT, FILE=FILSRF, STATUS='OLD', FORM='UNFORMATTED',
     -     ACCESS='SEQUENTIAL',
CVAX     -     READONLY,
     -     ERR=999)

C---- Delete the .srf file
      CLOSE(IUNIT,STATUS='DELETE')

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6-->
C**************************************************************************
C
C  REAL FUNCTION CALVAL  -  Calculate value at supplied coordinate by
C                           interpolation from nearby grid-points in the
C                           distribution array, ARRAY
C
C----------------------------------------------------------------------+--- 

      REAL FUNCTION CALVAL(ARRAY,NX,NY,NZ,GRDMIN,GRDSEP,X,Y,Z)

CVAX      IMPLICIT NONE

      REAL          EMIN
      PARAMETER    (EMIN = 1.0E-20)

      INTEGER       I, ICOORD, IP, IPOINT(3), IX, IY, IZ, J, K,
     -              NPOINT(3), NX, NY, NZ
      REAL          ARRAY(NX,NY,NZ), CALC, FACTOR(2,3), GRDMIN(3),
     -              GRDSEP, PCOORD, VALUE, X, XYZVAL(3), Y, Z

C---- Initialise variables
      VALUE = 0.0
      NPOINT(1) = NX
      NPOINT(2) = NY
      NPOINT(3) = NZ
      XYZVAL(1) = X
      XYZVAL(2) = Y
      XYZVAL(3) = Z

C---- Process current coordinates
      DO 100, ICOORD = 1, 3

C----     Find the reference corner grid-point defining the 3D cell
C         in which the coordinates are located
          CALC = (XYZVAL(ICOORD) - GRDMIN(ICOORD)) / GRDSEP
          IF (CALC.LT.0.0) THEN
              IP = CALC
          ELSE
              IP = CALC + 1.0
          ENDIF
          IPOINT(ICOORD) = IP
          IF (IP.LT.1 .OR. IP.GE.NPOINT(ICOORD)) GO TO 500
          PCOORD = (IP - 1) * GRDSEP + GRDMIN(ICOORD)
          FACTOR(2,ICOORD) = (XYZVAL(ICOORD) - PCOORD) / GRDSEP
          FACTOR(1,ICOORD) = 1.0 - FACTOR(2,ICOORD)
 100  CONTINUE

C---- Loop over the 2 z-coords 
      DO 400, K = 1, 2

C----     Calculate array subscript
          IZ = IPOINT(3) + K - 1

C----     Loop over the 2 y-coords 
          DO 300, J = 1, 2

C----         Calculate array subscript
              IY = IPOINT(2) + J - 1

C----         Loop over the 2 x-coords 
              DO 200, I = 1, 2

C----             Calculate array subscript
                  IX = IPOINT(1) + I - 1

C----             Calculate interpolated value
                  VALUE = VALUE
     -                + FACTOR(I,1) * FACTOR(J,2) * FACTOR(K,3)
     -                * ARRAY(IX,IY,IZ)
 200          CONTINUE
 300      CONTINUE
 400  CONTINUE

C---- Return the interpolated value
 500  CONTINUE
      CALVAL = VALUE

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.6<--
C**************************************************************************
C
C  FUNCTION LENSTR  -  Return length of string 'CHARS' excluding
C                      trailing blanks
C
C----------------------------------------------------------------------+---

      INTEGER FUNCTION LENSTR(CHARS)

      CHARACTER*(*) CHARS
      INTEGER J, MVAL

      MVAL = LEN(CHARS)
      DO 10, J = MVAL, 1, -1
          IF (CHARS(J:J).NE.' ') GO TO 20
   10 CONTINUE
      J = 0
   20 CONTINUE
      LENSTR = J

      RETURN
      END

C--------------------------------------------------------------------------
