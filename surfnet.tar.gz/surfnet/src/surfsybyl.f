C**************************************************************************
C
C  SUBROUTINE SYBYL   -  Routines to output contour files in Sybyl 
C	                 format.
C
C                        Based on program CNTWRITE, supplied with
C                        Sybyl and written by Perry Simeroth
C                        (12-Jan-1988).
C
C Written by R A Laskowski, UCL, June 1994.
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.3     Bug-fix to calculation of number of sheets to be written out.
C           Fix to counteract bug in the Sybyl library routines in
C           which the number of x- or y-points is miscalculated due to
C           rounding errors not being properly taken into account.
C                                                       1 Dec 1995 (RAL)
C
C v.1.4.1   Removal of unused variables.
C                                                      17 Nov 1996 (RAL)
C
C v.1.6.1   Bug-fix to SYBYL routine in surfsybyl.f on lengths of
C           characater strings passed to the array.
C                                                      25 May 2001 (RAL)
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4.1-->
C      SUBROUTINE SYBYL(ARRAY,NX,NY,NZ,IMAP,filename,GRDSEP,MAPAV,
C     -    MAPMIN,MAPMAX,VALMIN,VALMAX,sheet,sourcename,IFAIL)
      SUBROUTINE SYBYL(ARRAY,NX,NY,NZ,filename,GRDSEP,VALMIN,VALMAX,
     -    sheet,sourcename,IFAIL)
CHANGE v.1.4.1<--

CVAX      IMPLICIT NONE


CHANGE v.1.4.1-->
C      INTEGER       IMAP, NX, NY, NZ
      INTEGER       NX, NY, NZ
CHANGE v.1.4.1<--
      LOGICAL       IFAIL
CHANGE v.1.4.1-->
C      REAL          ADJAMT, ARRAY(NX,NY,NZ), GRDSEP, MAPAV, MAPMAX,
C     -              MAPMIN, VALMIN(3), VALMAX(3)
      REAL          ADJAMT, ARRAY(NX,NY,NZ), GRDSEP, VALMIN(3),
     -              VALMAX(3)
CHANGE v.1.4.1<--
CHANGE v.1.3-->
      INTEGER       NUMBX, NUMBY
CHANGE v.1.3<--

       integer*4 i, j, k, numshts, cntblk
CHANGE v.1.6.1-->
C       character*80 filename
C       character*80 sourcename
       CHARACTER*(*) filename
       CHARACTER*(*) sourcename
CHANGE v.1.6.1<--

CHANGE v.1.4-->
C       real*8    ysq, zsq, x, y, z, sheet(NX,NY), cell(6),
C     +           delta(6), limits(6)
       real*8    sheet(NX,NY), cell(6),
     +           delta(6), limits(6)
CHANGE v.1.4<--

C   For IRIS 3130, the these variables have to be declared as
C   real*4.
C      real*4    ysq, zsq, x, y, z, sheet(NX,NY), cell(6),
C    +           delta(6), limits(6)

      SAVE

C---- Initialise variables
      IFAIL = .FALSE.

C----Initialize the cell parameters for the map (for a Cartesian
C    axial system)
      do 11, i = 1, 3
         cell(i) = 1.0
         cell(i+3) = 90.0
CHANGE v.1.3-->
C         delta(i) = GRDSEP
         delta(i) = GRDSEP - 0.0000001
CHANGE v.1.3<--
 11   continue 

C---- Initialise the x-, y- and z-coordinate limits and calculate
C     the number of sheets to be written out in the z-direction
      ADJAMT = - GRDSEP
      limits(1) = VALMIN(1)
      limits(4) = VALMAX(1)
      limits(2) = VALMIN(2)
      limits(5) = VALMAX(2)
      limits(3) = VALMIN(3) + ADJAMT
      limits(6) = VALMAX(3) + ADJAMT
CHANGE v.1.3-->
C      numshts = (limits(6) - limits(3)) / delta(3) + 1
      numshts = NINT((limits(6) - limits(3)) / delta(3) + 1)

C---- Check that Sybyl will correctly compute the numbers of points in
C     the x- and y-directions
      NUMBX = (limits(4) - limits(1)) / delta(1) + 1
      NUMBY = (limits(5) - limits(2)) / delta(2) + 1
      IF (NUMBX.NE.NX .OR. NUMBY.NE.NY) THEN
          PRINT*, '*** WARNING. SYBYL WILL DISPLAY MAP INCORRECTLY!!'
          PRINT*, '***          Actual NX, NY:', NX, NY
          PRINT*, '***          Sybyl NX, NY: ', NUMBX, NUMBY
      ENDIF
CHANGE v.1.3<--

C---- Open the contour file
      call XCCreate (cntblk,filename,sourcename,cell,
     +   delta,limits)
      if (cntblk .eq. 0) GO TO 900

C---- Print statistics on contour data written out
      PRINT*, '      Number of sheets ...                   ', numshts
      PRINT*, '      Number of columns in each sheet ...    ', NY
      PRINT*, '      Number of rows in each sheet ...       ', NX
      PRINT 80, '      Limits: ', (limits(I), I = 1, 6)
80    FORMAT(A,6F10.3)

C---- Loop through each of the sheets in the z-direction, writing
C     each one out to the contour file
      do 14, k = 1, numshts

C----     Move the appropriate values from the 3D array into the
C         2D sheet
          do 13, j = 1, NY
              do 12, i = 1, NX
                  sheet(i,j) = ARRAY(i,j,k)
  12          continue 
  13      continue 

C----     Write the sheet out to the contour file
          call XCWrite (j,cntblk,k,sheet(1,1))
          if (j .eq. 0) GO TO 902
  14  continue

C---- Close the contour file
      call XCClose (j,cntblk)
      if (j .eq. 0) GO TO 904

      GO TO 999

C---- Errors in writing to contour file
900   CONTINUE
      PRINT*, '*** ERROR opening output Sybyl contour file'
      PRINT*, filename, ' *'
      GO TO 990

902   CONTINUE
      PRINT*, '*** ERROR writing to Sybyl contour file at ',
     -    'section ', k
      GO TO 990

904   CONTINUE
      PRINT*, '*** ERROR closing Sybyl contour file'
      GO TO 990

990   CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      end

C--------------------------------------------------------------------------
