echo Compile SURFNET programs for Windows

echo Compile
echo -------
gfortran -c curve.f
gfortran -c cutsrf.f
gfortran -c genbox.f
gfortran -c mapdiff.f
gfortran -c mapsphere.f
gfortran -c mask.f
gfortran -c plane.f
gfortran -c surfmaps.f
gfortran -c surfnet.f
gfortran -c surfsybyl.f

echo Compile and link
echo ----------------
gfortran -o princip princip.f
gfortran -o surface surface.f
gfortran -o surfplot surfplot.f
gfortran -o transform transform.f

echo Link for various output formats
echo -------------------------------
gfortran -o curve     curve.o     surfmaps.o
gfortran -o cutsrf    cutsrf.o    surfmaps.o
gfortran -o genbox    genbox.o    surfmaps.o
gfortran -o mapdiff   mapdiff.o   surfmaps.o
gfortran -o mapsphere mapsphere.o surfmaps.o
gfortran -o mask      mask.o      surfmaps.o
gfortran -o plane     plane.o     surfmaps.o
gfortran -o surfnet   surfnet.o   surfmaps.o

echo Speedfill compilation
echo ---------------------
gcc -O2 -funroll-loops -DWIN -c common.c
gcc -O2 -funroll-loops -c reapar.c
gcc -O2 -funroll-loops -c readpdb.c
gcc -O2 -funroll-loops -c kdtree.c
gcc -O2 -funroll-loops -c ras3d.c
gcc -O2 -funroll-loops -c speedfill.c
gcc -o speedfill -static speedfill.o common.o reapar.o readpdb.o kdtree.o ras3d.o -lm -lz

echo Move all the executable files and delete .o files
echo -------------------------------------------------
copy *.exe ..\exe
del *.o

