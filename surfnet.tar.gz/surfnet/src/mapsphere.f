C*****************************************************************************
C*****************************************************************************
C************                                                   **************
C************                M A P S P H E R E . F              **************
C************                                                   **************
C*****************************************************************************
C*****************************************************************************
C
C                    R A Laskowski, University College, London
C
C                                 December 1995
C
C----------------------------------------------------------------------+--- 
C
C Program description
C -------------------
C
C
C To read in a user-defined map file in .srf format and to approximate
C the high-density regions by spheres of density. The spheres are written
C out as a PDB-format file, mapsphere.pdb, giving the centre and radius
C of each sphere, in descending order of volume. The contour level at which
C the densities are approximated is user-defined (usually 100.0 for maps
C from SURFNET and 90.0 for maps from X-SITE).
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.5     Minor adjustments for errors objected to by the linux compiler.
C           Variable SPHLOC defined as REAL and used as INTEGER.
C                                                      30 Jan 1998 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Files
C -----
C
C  3   <filename>.srf  - Input .srf file holding the map file to be
C                        processed
C  8   mapsphere.pdb   - Output pdb file holding the sphere approximations
C
C----------------------------------------------------------------------+--- 
C
C Compilation and linking
C -----------------------
C
C f77 -u -c mapsphere.f
C f77 -u -c surfmaps.f
C f77 -o mapsphere mapsphere.o surfmaps.o
C
C
C
C Subroutine calling tree
C -----------------------
C
C MAIN    --> INITS
C         --> GETSRF
C         --> COGRID
C         --> INCONT
C         --> CALIDX  --> SHSORT
C         --> GENSPH  --> GROSPH
C         --> DELSPH  --> SHSORT
C         --> SPHOUT
C
C----------------------------------------------------------------------+--- 


      PROGRAM MAPSPH

CVAX      IMPLICIT NONE

      INCLUDE 'mapsphere.inc'

      INTEGER       IATYPE, ICOUNT, IFRAG, IUNIT
      LOGICAL       HDONLY, NOMESS
      REAL          ARRAY(MAXARR), FRGFRQ, GRDTOT

C---- Initialise variables
      HDONLY = .FALSE.
      IFAIL = .FALSE.
      NOMESS = .FALSE.

C---- Accept input file name
      CALL INITS

C---- Read in the grid of values for the given distribution from .srf file
      IUNIT = 3
      CALL GETSRF(FILSRF,IUNIT,ARRAY,MAXARR,NX,NY,NZ,
     -    FILTYP,GRDSEP,VALMIN,VALMAX,GRDTOT,IFRAG,IATYPE,
     -    ICOUNT,FRGFRQ,NOMESS,HDONLY,IFAIL)
      IF (IFAIL) GO TO 999

C---- Count up the number of grid-points above the given contour level
      CALL COGRID(ARRAY,MAXARR,NX,NY,NZ,CLEVEL,IFAIL)
      IF (IFAIL) GO TO 999

C---- Count the numbers of grid-points within the contour level
      CALL INCONT(ARRAY,NX,NY,NZ,CLEVEL)

C---- Calculate index of relative grid-points corresponding to larger
C     and larger sphere sizes
      CALL CALIDX(IJKREL,DIST,INDEXP,MAXPTS,NIJK,GRDSEP,MAXRAD,
     -    IFAIL)
      IF (IFAIL) GO TO 999

C---- Generate largest sphere at each grid-point
      CALL GENSPH(ARRAY,NX,NY,NZ,NSPHER,SPHRAD,SPHLOC,MAXSPH,
     -    DIST,INDEXP,IJKREL,MAXPTS,NIJK,CUTOFF,CLEVEL,GRDSEP,IFAIL)
      IF (IFAIL) GO TO 999

C---- Sort the spheres by size and delete any smaller spheres that
C     overlap the larger ones
      CALL DELSPH(NX,NY,SPHRAD,SPHLOC,MAXSPH,INDEXA,NSPHER,GRDSEP,
     -    VALMIN,RLIMIT)

C---- Write out the spheres in decreasing order of size
      IF (NSPHER.GT.0) THEN
          CALL SPHOUT(NX,NY,SPHRAD,SPHLOC,MAXSPH,INDEXA,NSPHER,FILSRF,
     -        GRDSEP,VALMIN,IFAIL)
      ENDIF

 999  CONTINUE
      IF (.NOT.IFAIL) THEN
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'mapsphere.inc'

      INTEGER       ISPHER

C---- Initialise variables
      NSPHER = 0
      DO 100, ISPHER = 1, MAXSPH
          SPHLOC(ISPHER) = 0
          SPHRAD(ISPHER) = 0.0
 100  CONTINUE
          
C---- Accept filename of input .srf file
      PRINT*, 'Enter name of input .srf density file'
      READ(*,110) FILSRF
 110  FORMAT(A)

C---- Accept contour level at which sphere approximations are required
      PRINT*, 'Enter contour level at which sphere approximations are ',
     -    'required'
      READ*, CLEVEL

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE COGRID  -  Count the number of grid-points above the given
C                        contour level
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE COGRID(ARRAY,MAXARR,NX,NY,NZ,CLEVEL,IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       CCOUNT, I, MAXARR, NPTS, NX, NY, NZ
      LOGICAL       IFAIL
      REAL          ARRAY(MAXARR), CLEVEL

C---- Initialise number of grid-points
      NPTS = NX * NY * NZ

C---- Count up the number of non-zero grid points
      CCOUNT = 0
      DO 200, I = 1, NPTS
          IF (ARRAY(I).GE.CLEVEL) CCOUNT = CCOUNT + 1
 200  CONTINUE
      IF (CCOUNT.EQ.0) GO TO 900

      GO TO 999


C---- Errors reading parameter file
 900  CONTINUE
      PRINT*, '*** ERROR. No grid points above the contour level',
     -    CLEVEL
      GO TO 990

C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INCONT  -  Count the numbers of grid-points inside and outside
C                        the required contour level
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INCONT(ARRAY,NX,NY,NZ,CLEVEL)

CVAX      IMPLICIT NONE

      INTEGER       I, INPTS, NX, NY, NZ, OUTPTS
      REAL          ARRAY(NX*NY*NZ), CLEVEL

C---- Initialise variables
      INPTS = 0
      OUTPTS = 0

C---- Loop over all the points in the array
      DO 200, I = 1, NX * NY * NZ

C----     Adjust the value
          IF (ARRAY(I).GE.CLEVEL) THEN
              INPTS = INPTS + 1
          ELSE
              OUTPTS = OUTPTS + 1
          ENDIF
200   CONTINUE

C---- Show numbers of point inside and outside contour levels
      PRINT*
      PRINT*, '   Number of grid points within contours: ', INPTS
      PRINT*, '   Number of grid points outside contours:', OUTPTS
      PRINT*

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CALIDX  -  Calculate index of relative grid-points corresponding
C                        to larger and larger sphere sizes
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE CALIDX(IJKREL,DIST,INDEXP,MAXPTS,NIJK,GRDSEP,MAXRAD,
     -    IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       MAXPTS

      CHARACTER*22  PLINE
      INTEGER       I, IJKREL(3,MAXPTS), INDEXP(MAXPTS), ISWAP, J, K, N,
     -              NALL, NAPPRX, NIJK, NPTS
      LOGICAL       IFAIL
      REAL          D, DIST(MAXPTS), GRDSEP, MAXRAD, VOLUME, X, Y, Y2,
     -              Z, Z2

C---- Initialise variables
      IFAIL = .FALSE.
      NIJK = 0

C---- Calculate extent of array required to encompass the maximum sphere
      N = NINT(MAXRAD / GRDSEP + 1)
      NPTS = 2 * N + 1
      NALL = NPTS * NPTS * NPTS
      PRINT*, 'Maximum sphere size allowed', MAXRAD
      WRITE(PLINE,20) NPTS, NPTS, NPTS, NALL
 20   FORMAT(I3,' x',I3,' x',I3,' =',I7)

C---- Loop over all the grid-point, calculating their distance from the
C     origin
      DO 400, K = -N, N
          Z = K * GRDSEP
          Z2 = Z * Z
          DO 300, J= -N, N
              Y = J * GRDSEP
              Y2 = Y * Y
              DO 200, I = -N, N
                  X = I * GRDSEP

C----             Calculate the distance of this point from the origin
                  D = SQRT(X * X + Y2 + Z2)

C----             If this is within the maximum sphere, then store this
C                 point
                  IF (D.LE.MAXRAD) THEN
                      NIJK = NIJK + 1
                      IF (NIJK.GT.MAXPTS) GO TO 900
                      DIST(NIJK) = SQRT(X * X + Y2 + Z2)
                      INDEXP(NIJK) = NIJK
                      IJKREL(1,NIJK) = I
                      IJKREL(2,NIJK) = J
                      IJKREL(3,NIJK) = K
                  ENDIF
 200          CONTINUE
 300      CONTINUE
 400  CONTINUE

C---- Write out number of points generated
      PRINT*, 'Number of reference grid-points generated', NIJK

C---- Sort the grid-points in descending distance from the origin
      CALL SHSORT(MAXPTS,DIST,NIJK,INDEXP)

C---- Adjust all the pointers so that they give the grid-points in
C     ascending distance from origin
      DO 500, I = 1, NIJK / 2
          ISWAP = INDEXP(NIJK - I + 1)
          INDEXP(NIJK - I + 1) = INDEXP(I)
          INDEXP(I) = ISWAP
 500  CONTINUE
      
      GO TO 999

C---- Errors
 900  CONTINUE
      PRINT*, '*** ERROR. Number of points, MAXPTS, insufficient to ',
     -    'encompass maximum sphere, MAXRAD:', MAXRAD
      VOLUME = (4.0 / 3.0) * 4.0 * ATAN(1.0) * MAXRAD * MAXRAD * MAXRAD
      NAPPRX = VOLUME / (GRDSEP * GRDSEP * GRDSEP)
      PRINT*, '***        Need approx.', NAPPRX, ' points'
      GO TO 990
 
C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GENSPH  -  Generate the largest sphere possible at each
C                        occupied grid position to encompass the required
C                        percentage of density points
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GENSPH(ARRAY,NX,NY,NZ,NSPHER,SPHRAD,SPHLOC,MAXSPH,
     -    DIST,INDEXP,IJKREL,MAXPTS,NIJK,CUTOFF,CLEVEL,GRDSEP,IFAIL)

      INTEGER       MAXPTS, MAXSPH, NX, NY, NZ

      INTEGER       IJKREL(3,MAXPTS), ILOC, INDEXP(MAXPTS), IX, IY, IZ,
     -              NIJK, NSPHER, SPHLOC(MAXSPH)
      LOGICAL       IFAIL
      REAL          ARRAY(NX,NY,NZ), CLEVEL, CUTOFF, DIST(MAXPTS),
     -              GRDSEP, RADIUS, SPHRAD(MAXSPH)

C---- Initialise variables
      IFAIL = .FALSE.
      NSPHER = 0

C---- Loop through all the grid-points in the array
      DO 300, IZ = 1, NZ
          DO 200, IY = 1, NY
              DO 100, IX = 1, NX
                  IF (ARRAY(IX,IY,IZ).GE.CLEVEL) THEN

C----                 Generate largest sphere possible at this point
                      CALL GROSPH(ARRAY,NX,NY,NZ,IX,IY,IZ,DIST,INDEXP,
     -                    IJKREL,MAXPTS,NIJK,CUTOFF,CLEVEL,GRDSEP,
     -                    RADIUS)

C----                 If radius of sphere is non-zero, then store
                      IF (RADIUS.GT.0.0) THEN
                          NSPHER = NSPHER + 1
                          IF (NSPHER.GT.MAXSPH) GO TO 900

C----                     Store the location of this point and the
C                         sphere radius
                          ILOC = (IZ - 1) * NX * NY
     -                        + (IY - 1) * NX + IX
                          SPHLOC(NSPHER) = ILOC
                          SPHRAD(NSPHER) = RADIUS
                      ENDIF
                  ENDIF
 100          CONTINUE
 200      CONTINUE
 300  CONTINUE

C---- Print details of spheres generated
      PRINT*
      PRINT*, 'Total number of spheres generated:', NSPHER

      GO TO 999

C---- Errors
 900  CONTINUE
      PRINT*, '*** ERROR. Maximum number of allowed spheres ',
     -    'exceeded:', MAXSPH
      GO TO 990
 

C---- Set error flag to true
 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GROSPH  -  Grow a sphere at the current grid-point
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE GROSPH(ARRAY,NX,NY,NZ,I,J,K,DIST,INDEXP,IJKREL,MAXPTS,
     -    NIJK,CUTOFF,CLEVEL,GRDSEP,RADIUS)

      INTEGER       MAXPTS, NX, NY, NZ

      INTEGER       I, IENTRY, IJKREL(3,MAXPTS), INDEXP(MAXPTS), IPT,
     -              IX, IY, IZ, J, JENTRY, K, NIJK, NIN, NOUT
      LOGICAL       DONE, ENDSPH, VALID
      REAL          ARRAY(NX,NY,NZ), CLEVEL, CUTOFF, DIST(MAXPTS),
     -              GRDSEP, PI, RADIUS, RATIO, RELVOL, SPHRAD, VOLFAC

C---- Initialise variables
      DONE = .FALSE.
      IPT = 0
      NIN = 0
      NOUT = 0
      PI = 4.0 * ATAN(1.0)
      RADIUS = 0.0
      RELVOL = 0.0
      VOLFAC = GRDSEP * GRDSEP * GRDSEP

C---- Loop until largest sphere found, or maximum sphere reached
 100  CONTINUE

C----     Increment grid-point and get its corresponding entry number
          IPT = IPT + 1
          IENTRY = INDEXP(IPT)
          SPHRAD = DIST(IENTRY)

C----     Use the relative grid-position to determine the actual
C         grid position
          IX = I + IJKREL(1,IENTRY)
          IY = J + IJKREL(2,IENTRY)
          IZ = K + IJKREL(3,IENTRY)

C----     Check that none of these is off the end of the grid
          VALID = .TRUE.
          IF (IX.LT.1 .OR. IY.LT.1 .OR. IZ.LT.1 .OR.
     -        IX.GT.NX .OR. IY.GT.NY .OR. IZ.GT.NZ ) VALID = .FALSE.

C----     If the grid-point is within the array, check whether it is
C         inside the contour or not
          IF (VALID) THEN
              IF (ARRAY(IX,IY,IZ).GE.CLEVEL) THEN
                  NIN = NIN + 1
              ELSE
                  NOUT = NOUT + 1
              ENDIF
              RELVOL = RELVOL + ARRAY(IX,IY,IZ) / CLEVEL
          ENDIF

C----     Check whether this point represents the last point for a
C         given sphere radius
          ENDSPH = .FALSE.

C----     If this is the last point, then have come to the end of
C         the maximum sphere
          IF (IPT.GE.NIJK) THEN
              ENDSPH = .TRUE.

C----     Otherwise, check sphere-radius of the following point
          ELSE

C----         Get the entry for the next point
              JENTRY = INDEXP(IPT + 1)

C----         If it corresponds to a greater sphere, then have closed
C             another shell
              IF (DIST(JENTRY).GT.DIST(IENTRY) + 0.000001) THEN
                  ENDSPH = .TRUE.
              ENDIF
          ENDIF

C----     If have closed of another shell, test whether the ratio of
C         high- to low-density points has fallen below the acceptance
C         threshold
          IF (ENDSPH) THEN
              RATIO = 100.0 * REAL(NIN) / REAL (NIN + NOUT)
              IF (RATIO.LT.CUTOFF) DONE = .TRUE.
          ENDIF

C---- If still more points to search, then loop back
      IF (.NOT.DONE .AND. IPT.LT.NIJK) GO TO 100

C---- If have reached maximum sphere size, print message
      IF (.NOT.DONE) THEN
          PRINT*, '*** WARNING. Maximum sphere size reached'
      ENDIF

C---- If only one grid-point involved, then discard this sphere
      IF (NIN.EQ.1) THEN
          RADIUS = 0.0

C---- Otherwise, calculate the effective radius of the sphere
      ELSE
          RELVOL = RELVOL * VOLFAC
          RADIUS = 3.0 * RELVOL / (4.0 * PI)
          RADIUS = RADIUS ** (1.0 / 3.0)
      ENDIF

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE DELSPH  -  Sort the spheres by size and dispose of any smaller
C                        ones that significantly overlap the larger ones
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE DELSPH(NX,NY,SPHRAD,SPHLOC,MAXSPH,INDEXA,NSPHER,GRDSEP,
     -    VALMIN,RLIMIT)

CVAX      IMPLICIT NONE

      INTEGER       MAXSPH, NX, NY

      INTEGER       I, ILOC, INDEXA(MAXSPH), IPOINT, ISPHER, J, JLOC,
     -              JPOINT, JSPHER, K, NSPHER, SPHLOC(MAXSPH)
      REAL          DIST, GRDSEP, OVRLAP, RADI, RADJ, RADMIN, RLIMIT,
     -              SPHRAD(MAXSPH), VALMIN(3), XI, XJ, YI, YJ, ZI, ZJ

C---- Initialize sort index
      DO 100, ISPHER = 1, NSPHER
          INDEXA(ISPHER) = ISPHER
100   CONTINUE

C---- Sort the sphere in decreasing order of size
      IF (NSPHER.GT.1) THEN
          CALL SHSORT(MAXSPH,SPHRAD,NSPHER,INDEXA)
      ENDIF

C---- Loop over all the spheres, from the second-largest downwards
      DO 800, IPOINT = 2, NSPHER

C----     Get the current sphere
          ISPHER = INDEXA(IPOINT)
          RADI = SPHRAD(ISPHER)

C----     Retrieve this sphere's x-, y- and z-coordinates
          ILOC = SPHLOC(ISPHER)
          I = MOD(ILOC,NX)
          IF (I.EQ.0) I = NX
          ILOC = (ILOC - I) / NX
          J = MOD(ILOC,NY) + 1
          K = (ILOC - (J - 1)) / NY + 1
          XI = VALMIN(1) + (I - 1) * GRDSEP
          YI = VALMIN(2) + (J - 1) * GRDSEP
          ZI = VALMIN(3) + (K - 1) * GRDSEP

C----     Loop over all the spheres larger than this one
          DO 600, JPOINT = 1, IPOINT - 1

C----         Get the current sphere and its radius
              JSPHER = INDEXA(JPOINT)
              RADJ = SPHRAD(JSPHER)

C----         Process if sphere hasn't already been deleted
              IF (RADI.GT.0.0 .AND. RADJ.GT.0.0) THEN

C----             Retrieve this sphere's x-, y- and z-coordinates
                  JLOC = SPHLOC(JSPHER)
                  I = MOD(JLOC,NX)
                  IF (I.EQ.0) I = NX
                  JLOC = (JLOC - I) / NX
                  J = MOD(JLOC,NY) + 1
                  K = (JLOC - (J - 1)) / NY + 1
                  XJ = VALMIN(1) + (I - 1) * GRDSEP
                  YJ = VALMIN(2) + (J - 1) * GRDSEP
                  ZJ = VALMIN(3) + (K - 1) * GRDSEP

C----             Calculate the distance between the points
                  DIST = (XJ - XI) * (XJ - XI) + (YJ - YI) * (YJ - YI)
     -                + (ZJ - ZI) * (ZJ - ZI)
                  DIST = SQRT(DIST)

C----             If the spheres overlap too much, then delete the smaller
C                 of the two
                  OVRLAP = RADI + RADJ - DIST
                  IF (OVRLAP.GT.0.0) THEN
                      RADMIN = MIN(RADI,RADJ)
                      IF (OVRLAP.GT.RLIMIT * RADMIN) THEN
                          RADI = 0.0
                          SPHRAD(ISPHER) = 0.0
                      ENDIF
                  ENDIF
              ENDIF
600       CONTINUE
800   CONTINUE 


      RETURN
      END

C-----------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE SPHOUT  -  Write out the remaining spheres in decreasing
C                        order of size
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE SPHOUT(NX,NY,SPHRAD,SPHLOC,MAXSPH,INDEXA,NSPHER,FILSRF,
     -    GRDSEP,VALMIN,IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       MAXSPH

      CHARACTER*80  FILSRF
      INTEGER       I, ILEN, ILOC, INDEXA(MAXSPH), IPOINT, ISPHER, J, K,
     -              NOUT, NPOINT, NX, NY, NSPHER, SPHLOC(MAXSPH)
      LOGICAL       IFAIL
      REAL          GRDSEP, SPHRAD(MAXSPH), VALMIN(3), X, Y, Z

C---- Open output file
      OPEN(UNIT=8, FILE='mapsphere.pdb', STATUS='UNKNOWN',
     -     FORM='FORMATTED', ACCESS='SEQUENTIAL',
CVAX     -     CARRIAGECONTROL = 'LIST',
     -     ERR=900)

C---- Write header records to cavout.pdb
      ILEN = INDEX(FILSRF,' ') - 1
      WRITE(8,20) FILSRF(1:ILEN)
 20   FORMAT(
     -    'REMARK  Sphere approximations to high-density regions',/,
     -    'REMARK  ---------------------------------------------',/,
     -    'REMARK  ',/,
     -    'REMARK  Generated by program mapsphere',/,
     -    'REMARK  ',/,
     -    'REMARK  From density file: ',A,/,
     -    'REMARK  ',/,
     -    'REMARK  ',/,
     -    'REMARK  ')

C---- Write out the sorted list of the remaining spheres and their
C     volumes
      NOUT = 0
CHANGE v.1.5-->
C      NPOINT = 0.0
      NPOINT = 0
CHANGE v.1.5<--

C---- Loop over all the spheres
      DO 500, IPOINT = 1, NSPHER

C----     Get the current sphere
          ISPHER = INDEXA(IPOINT)

C----     If radius non-zero, then write the sphere out
          IF (SPHRAD(ISPHER).GT.0.0) THEN

C----         Increment number of points written out
              NPOINT = NPOINT + 1

C----         Retrieve this sphere's x-, y- and z-coordinates
              ILOC = SPHLOC(ISPHER)
              I = MOD(ILOC,NX)
              IF (I.EQ.0) I = NX
              ILOC = (ILOC - I) / NX
              J = MOD(ILOC,NY) + 1
              K = (ILOC - (J - 1)) / NY + 1
              X = VALMIN(1) + (I - 1) * GRDSEP
              Y = VALMIN(2) + (J - 1) * GRDSEP
              Z = VALMIN(3) + (K - 1) * GRDSEP

C----         Print the details
              NOUT = NOUT + 1
 430          FORMAT(7X,I5,'.    ',I5,18X,3F8.3,2X,F12.4)

C----         Write out to the mapsphere.pdb file
              WRITE(8,440) NOUT, NOUT, X, Y, Z, SPHRAD(ISPHER),
     -            SPHRAD(ISPHER)
440           FORMAT('HETATM',I5,'  C   SPH  ',I4,4X,3F8.3,'  1.00',
     -            F6.2,2X,F12.3)
          ENDIF
500   CONTINUE 

C---- Close the output file
      CLOSE(8)
      PRINT*
      PRINT*, 'Number of spheres written out:', NOUT

      GO TO 999

C---- Fatal errors
900   CONTINUE
      PRINT*, '*** ERROR. Unable to open output mapsphere.pdb file'
      GO TO 990

 990  CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C-----------------------------------------------------------------------------
