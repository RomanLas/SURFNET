C*****************************************************************************
C*****************************************************************************
C************                                                   **************
C************         M  A  P  D  I  F  F  .  F  O  R           **************
C************                                                   **************
C*****************************************************************************
C*****************************************************************************
C
C                  R A Laskowski, University College London
C
C                                 June 1996
C
C----------------------------------------------------------------------+--- 
C
C Program description
C -------------------
C
C This program compares two .srf files, writing out two more .srf files
C (and, if required, files in QUANTA, SYBYL, CCP4 or Insight II formats)
C of just the differences in values, or a single .srf file of their common
C regions.
C
C----------------------------------------------------------------------+--- 
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the SURFNET version number corresponding to the change
C
C v.1.4.1   Addition of new option to give combined maps.
C                                                       5 Dec 1996 (RAL)
C
C v.1.4.2   Addition of new option to give an equidistant surface between
C           the surfaces in one map and those in another (eg if one map
C           represents surface of chain A, and the other of chain B, the
C           new surface will be a contour of points equidistant between
C           chains A and B.
C                                                   10-11 Feb 1997 (RAL)
C           Correction of NOMESS variable various routines to LOGICAL.
C                                                      26 Sep 1997 (RAL)
C
C
C Files
C -----
C
C  3   <filename>.srf   - Input .srf files
C 10   mapdiffN.den     - Output CCP4 density files (for N = 1, 2)
C 10   mapdiffN.grd     - Output InsightII grid files (for N = 1, 2)
C 10   mapdiffN.mbk     - Output Quanta brick file files (for N = 1, 2)
C 10   mapdiffN.srf     - Reduced output .srf files (for N = 1, 2)
C ??   mapdiffN.cnt     - Output Sybyl contour files (for N = 1, 2)
C      mapcommon.*      - As above, but for the regions common to both
C                         the input maps
C      mapcombined.*    - As above, but for the combined regions of the
C                         two input maps
C      mapsurface.*     - As above, but giving the equidistant surface(s)
C                         between the high-density regions in the two
C                         input maps
C
C----------------------------------------------------------------------+--- 
C
C
C Compilation and linking (on unix)
C -----------------------
C
C f77 -u -c mapdiff.f
C f77 -u -c surfmaps.f
C f77 -o mapdiff mapdiff.o surfmaps.o
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines in surfmaps.f and use surfsyb.scr to link to the Sybyl
C library routines.
C
C If CCP4 density maps are to be generated, uncomment all the CCP4
C lines in surfmaps.f and use surfccp4.scr to link to the CCP4
C library routines.
C
C Subroutine calling tree
C -----------------------
C
C MAIN  --> INITS
C       --> PREPRO  --> GETSRF
C                   --> GETLIM
C                   --> TRNGRD  --> CALVAL
C                               --> GRDUPD
C                   --> GRINIT
C                   --> CNDIST
C                   --> WRISRF
C       --> GETSRF
C
C           Calculate the differences between the two maps
C
C       --> CALDIF  --> GRDGET
C                   --> CALVAL
C                   --> GRDUPD
C
C           Write out the reduced grid array in the different formats
C           required
C
C       --> WRIMAP  --> LIMTAR
C                   --> ADJARR
C                   --> GRHIST  --> SHSORT
C                   --> WRISRF
C                   --> COMPRS
C                   --> ASCDEN  --> CCP4 routines to write out density file
C                   --> MBRICK  --> CCP4 routines to read in density files
C                                   and write out brick files (for FRODO)
C                                   [This routine is no longer used]
C                   --> INSIGH
C                   --> QUANTA  --> GETHED
C                               --> MBRWRH
C                               --> MRDSE8
C                   --> SYBYL   --> XCCreate
C                               --> XCWrite
C                               --> XCClose
C
C----------------------------------------------------------------------+--- 


      PROGRAM MAPDIFF

CVAX      IMPLICIT NONE

      INCLUDE 'mapdiff.inc'

      CHARACTER*40  FROOT
      CHARACTER*120 OUTSRF, SWAP, TITLE
      INTEGER       ICOMP, IFILE, IUNIT, LENSTR, NCOMP, NPOINT(3,2)
CHANGE v.1.4.2-->
C      LOGICAL       NOMESS, NOPNT, RAWDAT, SURF(2)
      LOGICAL       HDONLY, NOMESS, NOPNT, RAWDAT, SURF(2)
CHANGE v.1.4.2<--
      REAL          ARRAY(MAXARR,2), MFACTR, VALTOT


C---- Initialise variables
      FROMAP = .FALSE.
CHANGE v.1.4.2-->
      HDONLY = .FALSE.
CHANGE v.1.4.2<--
      NOMESS = .FALSE.
      TITLE = 'Density difference file'

C---- Determine which map formats can be written out for those that need
C     libraries to be linked in
      CALL INTMAP(FROLNK,SYBLNK)

C---- Accept input file names
      CALL INITS

C---- Determine number of loop required
CHANGE v.1.4.1-->
C      IF (SIMLAR) THEN
CHANGE v.1.4.2-->
C      IF (SIMLAR .OR. COMBIN) THEN
      IF (SIMLAR .OR. COMBIN .OR. EQUIDI) THEN
CHANGE v.1.4.2<--
CHANGE v.1.4.1<--
          NCOMP = 1
      ELSE
          NCOMP = 2
      ENDIF

CHANGE v.1.4.2-->
C---- If an equidistant surface or a combination of the input regions is
C     required, then read in and preprocess both input files
      IF (EQUIDI .OR. COMBIN) THEN
          CALL PREPRO(ARRAY,MAXARR,FILSRF,SUFACE,EQUIDI,COMBIN,IFAIL)
      ENDIF
CHANGE v.1.4.2<--

C---- Loop twice, first to compare map 2 against map 1, and then map 1
C     against map 2, or, if similarities are required, just loop the once
      DO 500, ICOMP = 1, NCOMP

C----     Read in the two .srf files
          IUNIT = 3
          DO 100, IFILE = 1, 2
              CALL GETSRF(FILSRF(IFILE),IUNIT,ARRAY(1,IFILE),MAXARR,
     -            NPOINT(1,IFILE),NPOINT(2,IFILE),NPOINT(3,IFILE),
     -            FILTYP,GRDSEP(IFILE),VALMIN(1,IFILE),VALMAX(1,IFILE),
CHANGE v.1.4.2-->
C     -            VALTOT,IFRAG,IATYPE,ICOUNT,FRGFRQ,NOMESS,IFAIL)
     -            VALTOT,IFRAG,IATYPE,ICOUNT,FRGFRQ,NOMESS,HDONLY,IFAIL)
CHANGE v.1.4.2<--
              IF (IFAIL) GO TO 999

C----         Check if this is a surface map from SURFNET
              SURF(IFILE) = .FALSE.
              IF (FILTYP.EQ.'S' .OR. FILTYP.EQ.'G') THEN
                  SURF(IFILE) = .TRUE.
              ENDIF
 100      CONTINUE

C----     If both maps are surface maps, then set surfaces flag
          IF (SURF(1) .AND. SURF(2)) SUFACE = .TRUE.

C----     Calculate the differences in the two files
          CALL CALDIF(ARRAY,MAXARR,NPOINT(1,1),NPOINT(2,1),NPOINT(3,1),
     -        NPOINT(1,2),NPOINT(2,2),NPOINT(3,2),VALMIN,GRDSEP,SIMLAR,
CHANGE v.1.4.1-->
C     -        SUFACE)
CHANGE v.1.4.2-->
C     -        COMBIN,SUFACE)
     -        COMBIN,EQUIDI,SUFACE)
CHANGE v.1.4.2<--
CHANGE v.1.4.1<--

C----     Prepare root file name, and all required filenames
          IF (SIMLAR) THEN
              FROOT = 'mapcommon'
CHANGE v.1.4.1-->
          ELSE IF (COMBIN) THEN
              FROOT = 'mapcombine'
CHANGE v.1.4.1<--
CHANGE v.1.4.2-->
          ELSE IF (EQUIDI) THEN
              FROOT = 'mapsurface'
CHANGE v.1.4.2<--
          ELSE
              WRITE(FROOT,120) ICOMP
 120          FORMAT('mapdiff',I1)
          ENDIF
          OUTSRF = FROOT(1:LENSTR(FROOT)) // '.srf'
          FILCNT = FROOT(1:LENSTR(FROOT)) // '.cnt'
          FILDEN = FROOT(1:LENSTR(FROOT)) // '.den'
          FILGRD = FROOT(1:LENSTR(FROOT)) // '.grd'
          FILMBK = FROOT(1:LENSTR(FROOT)) // '.mbk'

C----     Write out the array in whichever output format is required
          IF (SIMLAR) THEN
              PRINT*, 'Writing file of common regions ...'
CHANGE v.1.4.1-->
          ELSE IF (COMBIN) THEN
              PRINT*, 'Writing file of combined regions ...'
CHANGE v.1.4.1<--
          ELSE
              PRINT*, 'Writing density difference file', ICOMP, ' ...'
          ENDIF
          IUNIT = 10
          MFACTR = 1.0
          RAWDAT = .TRUE.
          CALL WRIMAP(ARRAY(1,1),MAXARR,NPOINT(1,1),INDEXA,
     -        MAXIND,FILTYP,ICOMP,IFRAG,IATYPE,ICOUNT,FRGFRQ,FILCNT,
     -        FILDEN,FILGRD,FILMBK,OUTSRF,IUNIT,FROMAP,INSMAP,
     -        QUAMAP,SYBMAP,TITLE,VALMIN(1,1),VALMAX(1,1),
     -        GRDSEP(1),RAWDAT,MFACTR,.TRUE.,NOMESS,NOPNT,IFAIL)

C----     Swap the input filenames round
          SWAP = FILSRF(1)
          FILSRF(1) = FILSRF(2)
          FILSRF(2) = SWAP
 500  CONTINUE


 999  CONTINUE
      IF (.NOT.IFAIL) THEN
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'mapdiff.inc'
          
      CHARACTER*1   YESNO

C---- Initialise variables
      SUFACE = .FALSE.
CHANGE v.1.4.2-->
      EQUIDI = .FALSE.
CHANGE v.1.4.2<--


C---- Accept filenames of input .srf files
      PRINT*, 'Enter name of first .srf density file'
      READ(*,110) FILSRF(1)
 110  FORMAT(A)
      PRINT*, 'Enter name of second .srf density file'
      READ(*,110) FILSRF(2)

C---- Accept whether differences or similarities between the maps are
C     required
 200  CONTINUE
CHANGE v.1.4.1-->
C      PRINT*, 'Are (D)ifferences or (S)imilarities required - (D/S)?'
      COMBIN = .FALSE.
CHANGE v.1.4.2-->
C      PRINT*, '(D)ifferences in maps, (S)imilarities of (C)ombined map',
C     -    ' - (D/S/C)?'
      PRINT*, 'Enter type of output map required:-'
      PRINT*, '   (D)ifferences - showing differences between the inpu',
     -    't maps'
      PRINT*, '   (S)imilarities - showing regions common to both'
      PRINT*, '   (C)ombined map - showing regions present in either'
      PRINT*, '   (E)quidistant surfaces - between objects in two maps'
CHANGE v.1.4.2<--
CHANGE v.1.4.1<--
      READ(*,110) YESNO
      IF (YESNO.EQ.'D' .OR. YESNO.EQ.'d') THEN
          SIMLAR = .FALSE.
CHANGE v.1.4.1-->
      ELSE IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          SIMLAR = .FALSE.
          COMBIN = .TRUE.
CHANGE v.1.4.1<--
CHANGE v.1.4.2-->
      ELSE IF (YESNO.EQ.'E' .OR. YESNO.EQ.'e') THEN
          SIMLAR = .FALSE.
          EQUIDI = .TRUE.
CHANGE v.1.4.2<--
      ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
          SIMLAR = .TRUE.
      ELSE
          GO TO 200
      ENDIF

C---- Accept which output map format is required
      FROMAP = .FALSE.
      INSMAP = .FALSE.
      QUAMAP = .FALSE.
      SYBMAP = .FALSE.
      PRINT*, 'Enter map-format required: (Q)uanta, (C)CP4, (S)ybyl',
     -    ', (I)nsightII or (N)one'
      READ(*,110) YESNO
      IF (YESNO.EQ.'Q' .OR. YESNO.EQ.'q') THEN
          QUAMAP = .TRUE.
      ELSE IF (YESNO.EQ.'I' .OR. YESNO.EQ.'i') THEN
          INSMAP = .TRUE.
      ELSE IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          IF (FROLNK) THEN
              FROMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to  librar',
     -            'ies'
              PRINT*, '***          No  density maps will be produ',
     -            'ced'
          ENDIF
      ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
          IF (SYBLNK) THEN
              SYBMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to Sybyl libra',
     -            'ries'
              PRINT*, '***          No Sybyl contour maps will be prod',
     -            'uced'
          ENDIF
      ELSE IF (YESNO.EQ.'N' .OR. YESNO.EQ.'n') THEN
          PRINT*, '*** No map files required'
      ELSE
          PRINT*, '*** INVALID map format requested: [', YESNO, ']'
          PRINT*, '*** No map files will be written out.'
      ENDIF
      PRINT*
      PRINT*

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4.2-->
C**************************************************************************
C
C  SUBROUTINE PREPRO  -   Preprocess both map files required for generating
C                         an equidistant surface between two molecules
C
C----------------------------------------------------------------------+---

      SUBROUTINE PREPRO(ARRAY,MAXARR,FILSRF,SUFACE,EQUIDI,COMBIN,IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       MAXARR

      CHARACTER*1   FILTYP
      CHARACTER*120 FILSRF(2), OUTSRF(2)
      INTEGER       IATYPE, ICOORD, ICOUNT, IFILE, IFRAG, IGRID, IPOINT,
CHANGE v.1.4.2-->
C     -              IUNIT, NOMESS, NX, NY, NZ, OUTNX, OUTNY, OUTNZ
C      LOGICAL       EQUIDI, COMBIN, HDONLY, IFAIL, SUFACE, SURF(2)
     -              IUNIT, NX, NY, NZ, OUTNX, OUTNY, OUTNZ
      LOGICAL       EQUIDI, COMBIN, HDONLY, IFAIL, NOMESS, SUFACE,
     -              SURF(2)
CHANGE v.1.4.2<--
      REAL          ARRAY(MAXARR,2), FRGFRQ, GRDSEP, OUTSEP, OUTMAX(3),
     -              OUTMIN(3), VALMAX(3), VALMIN(3), VALTOT

C---- Initialise variables
      HDONLY = .TRUE.
      IFAIL = .FALSE.
      IGRID = 1
      IUNIT = 3
      NOMESS = .TRUE.
      OUTSRF(1) = 'tmp1.srf'
      OUTSRF(2) = 'tmp2.srf'

C---- Read in the header records of both .srf files and compute extent
C     of grid-map that would encompass both
      DO 200, IFILE = 1, 2

C----     Read in the current file for its header information
          CALL GETSRF(FILSRF(IFILE),IUNIT,ARRAY,MAXARR,NX,NY,NZ,FILTYP,
     -        GRDSEP,VALMIN,VALMAX,VALTOT,IFRAG,IATYPE,ICOUNT,FRGFRQ,
     -        NOMESS,HDONLY,IFAIL)
          IF (IFAIL) GO TO 999

C----     If this is the first file, store the defining data
          IF (IFILE.EQ.1) THEN
              OUTSEP = GRDSEP
              OUTMIN(1) = VALMIN(1)
              OUTMIN(2) = VALMIN(2)
              OUTMIN(3) = VALMIN(3)
              OUTMAX(1) = VALMAX(1)
              OUTMAX(2) = VALMAX(2)
              OUTMAX(3) = VALMAX(3)

C----     Otherwise, store only if outside the current bounds
          ELSE

C----         For the combined regions, want the maximum extents of the
C             two maps
              IF (COMBIN) THEN
                  DO 100, ICOORD = 1, 3
                      IF (VALMIN(ICOORD).LT.OUTMIN(ICOORD)) 
     -                    OUTMIN(ICOORD) = VALMIN(ICOORD)
                      IF (VALMAX(ICOORD).GT.OUTMAX(ICOORD)) 
     -                    OUTMAX(ICOORD) = VALMAX(ICOORD)
 100              CONTINUE

C----         For equidistant surfaces, only need the overlap region
              ELSE IF (EQUIDI) THEN
                  DO 150, ICOORD = 1, 3
                      IF (VALMAX(ICOORD).GT.OUTMIN(ICOORD)) THEN
                          IF (VALMAX(ICOORD).LT.OUTMAX(ICOORD)) THEN
                              OUTMAX(ICOORD) = VALMAX(ICOORD)
                              IF (VALMIN(ICOORD).GT.OUTMIN(ICOORD)) THEN
                                  OUTMIN(ICOORD) = VALMIN(ICOORD)
                              ENDIF
                          ELSE
                              IF (VALMIN(ICOORD).GT.OUTMAX(ICOORD)) THEN
                                  OUTMAX(ICOORD) = VALMAX(ICOORD)
                              ELSE IF (VALMIN(ICOORD).GT.OUTMIN(ICOORD))
     -                            THEN
                                  OUTMIN(ICOORD) = VALMIN(ICOORD)
                              ENDIF
                          ENDIF
                      ELSE
                          OUTMIN(ICOORD) = VALMIN(ICOORD)
                      ENDIF
 150              CONTINUE
              ENDIF
          ENDIF
 200  CONTINUE

C---- Compute the size of the output map (which, for all regions, has to
C     be large enough to encompass the extents of both input maps, whereas,
C     for equidistant surfaces needs only be big enough to hold the surface)
      CALL GETLIM(OUTMIN,OUTMAX,GRDSEP,OUTNX,OUTNY,OUTNZ,MAXARR,IFAIL) 
      IF (IFAIL) GO TO 999

C---- Reset flag so that all data read in from .srf file, not just header
C     info
      HDONLY = .FALSE.
      NOMESS = .FALSE.

C---- Loop over the two .srf files to process each one
      DO 800, IFILE = 1, 2

C----     Read in the current file
          CALL GETSRF(FILSRF(IFILE),IUNIT,ARRAY,MAXARR,NX,NY,NZ,FILTYP,
     -        GRDSEP,VALMIN,VALMAX,VALTOT,IFRAG,IATYPE,ICOUNT,FRGFRQ,
     -        NOMESS,HDONLY,IFAIL)
          IF (IFAIL) GO TO 999

C----     Check if this is a surface map from SURFNET
          SURF(IFILE) = .FALSE.
          IF (FILTYP.EQ.'S' .OR. FILTYP.EQ.'G') THEN
              SURF(IFILE) = .TRUE.
          ENDIF

C----     Initialise the array holding the output version of the map
C         just read in
          DO 300, IPOINT = 1, MAXARR
              ARRAY(IPOINT,2) = 0.0
 300      CONTINUE

C----     Transfer the data across to the output grid
          CALL TRNGRD(ARRAY,MAXARR,NX,NY,NZ,VALMIN,GRDSEP,OUTNX,OUTNY,
     -        OUTNZ,OUTMIN,OUTSEP)

C----     If generating a combined map, then can write current output
C         map as it stands
          IF (COMBIN) THEN
              IGRID = 2

C----     Otherwise, for equidistant surface, need to generate the distances
C         map
          ELSE IF (EQUIDI) THEN

C----         Initialise new output grid array
              IGRID = 1
              DO 400, IPOINT = 1, MAXARR
                  IF (ARRAY(IPOINT,2).GE.100.0) THEN
                      ARRAY(IPOINT,1) = 0.0
                  ELSE
                      ARRAY(IPOINT,1) = 99999999.0
                  ENDIF
                  ARRAY(IPOINT,2) = ARRAY(IPOINT,2) - 100.0
 400          CONTINUE

C----         Process array to give required output (ie such that each
C             grid point in the output array corresponds to distance
C             from a contour surface in the input array)
              CALL CNDIST(ARRAY(1,1),ARRAY(1,2),OUTNX,OUTNY,OUTNZ,
     -            OUTSEP,IFILE)
          ENDIF

C----     Write out the output grid file to a temporary file for processing
C         in the routines that follow
          IUNIT = 10
          CALL WRISRF(ARRAY(1,IGRID),OUTNX,OUTNY,OUTNZ,OUTSRF(IFILE),
     -        IUNIT,OUTMIN,OUTSEP,FILTYP,IFRAG,IATYPE,ICOUNT,FRGFRQ,
     -        IFAIL)
          IF (IFAIL) GO TO 999

 800  CONTINUE

C---- If both maps are surface maps, then set surfaces flag
      IF (SURF(1) .AND. SURF(2)) SUFACE = .TRUE.

C---- Save the temporary file names as the input file names for the
C     routines that follow
      FILSRF(1) = OUTSRF(1)
      FILSRF(2) = OUTSRF(2)

 999  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GETLIM  -  Calculate the limits and numbers of grid-points
C                        for the output grid array
C
C----------------------------------------------------------------------+---

      SUBROUTINE GETLIM(VALMIN,VALMAX,GRDSEP,NX,NY,NZ,MAXARR,IFAIL)

CVAX      IMPLICIT NONE

      INTEGER       ARSIZE, ICOORD, LIM(6), LOWER, MAXARR, NPOINT(3),
     -              NX, NY, NZ, UPPER
      LOGICAL       IFAIL
      REAL          GRDSEP, RESD(3), VALMAX(3), VALMIN(3), VOLBOX


C---- Initialise values
      ARSIZE = 1

C---- Calculate the array size for the grid
      DO 600, ICOORD = 1, 3
          LOWER = 2 * ICOORD - 1
          UPPER = LOWER + 1

C----     Calculate lowest grid value for this coordinate
          LIM(LOWER) = INT(VALMIN(ICOORD) / GRDSEP)
          IF (VALMIN(ICOORD).LT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF
          IF (ABS(LIM(LOWER) - VALMIN(ICOORD) / GRDSEP).LT.0.0001) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF

C----     Calculate upper grid value for this coordinate
          LIM(UPPER) = INT(VALMAX(ICOORD) / GRDSEP)
          IF (VALMAX(ICOORD).LT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) - 1
          ENDIF
          IF (ABS(LIM(UPPER) - VALMAX(ICOORD) / GRDSEP).LT.0.0001) THEN
              LIM(UPPER) = LIM(UPPER) + 1
          ENDIF
          LIM(UPPER) = LIM(UPPER) + 1
      
C----     Calculate number of grid points required for this coordinate
          NPOINT(ICOORD) = LIM(UPPER) - LIM(LOWER) + 1
          ARSIZE = ARSIZE * NPOINT(ICOORD)
      
C----     Adjust the minimum and maximum values to correspond to the
C         grid limits
          VALMIN(ICOORD) = LIM(LOWER) * GRDSEP
          VALMAX(ICOORD) = LIM(UPPER) * GRDSEP
          RESD(ICOORD) = VALMAX(ICOORD) - VALMIN(ICOORD)
600   CONTINUE

C---- Check that array is not too large
      IF (ARSIZE.GT.MAXARR) THEN
          PRINT*, '*** Array required:', ARSIZE, '   is larger',
     -            ' than that allowed:', MAXARR
          PRINT*, '     Grid points:', (NPOINT(ICOORD), ICOORD = 1, 3)
          GO TO 990
      ENDIF
      VOLBOX = RESD(1) * RESD(2) * RESD(3)
      PRINT 620, 'Adjusted min:       ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
 620  FORMAT(1X,A,3F12.4)
      PRINT 620, 'Adjusted max:       ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      PRINT*
      PRINT 640, 'Grid separation:    ', GRDSEP
 640  FORMAT(1X,A,F12.4)
      PRINT*
      PRINT 660, 'Length:             ',
     -    (RESD(ICOORD), ICOORD = 1, 3), 'Volume:         ',
     -     VOLBOX
 660  FORMAT(1X,A,3F12.4,/,1X,A,F16.2)
      PRINT 680, NPOINT(1), NPOINT(2), NPOINT(3), ARSIZE
 680  FORMAT(/,1X,'Array size: ',I8,'  x',I8,'  x',I8,'  = ',I8,
     -    ' points',/) 

C---- Save the calculated grid limits
      NX = NPOINT(1)
      NY = NPOINT(2)
      NZ = NPOINT(3)

      GO TO 999

990   CONTINUE
      IFAIL = .TRUE.

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE TRNGRD  -   Transfer the data from smaller to larger grid
C
C----------------------------------------------------------------------+---

      SUBROUTINE TRNGRD(ARRAY,MAXARR,NX,NY,NZ,VALMIN,GRDSEP,OUTNX,OUTNY,
     -    OUTNZ,OUTMIN,OUTSEP)

CVAX      IMPLICIT NONE

      INTEGER       MAXARR

      INTEGER       IX, IY, IZ, NX, NY, NZ, OUTNX, OUTNY, OUTNZ
      REAL          ARRAY(MAXARR,2), CALVAL, GRDSEP, OUTMIN(3), OUTSEP,
     -              VALUE, VALMIN(3), X, Y, Z


C---- Loop through all the points of the output array
      DO 500, IZ = 1, OUTNZ

C----     Calculate the z-coordinate of this point
          Z = (IZ - 1) * OUTSEP + OUTMIN(3)

C----     Loop over the y-points
          DO 400, IY = 1, OUTNY

C----         Calculate the y-coordinate of this point
              Y = (IY - 1) * OUTSEP + OUTMIN(2)

C----         Loop over the x-points
              DO 300, IX = 1, OUTNX

C----             Calculate the x-coordinate of this point
                  X = (IX - 1) * OUTSEP + OUTMIN(1)

C----             Compute the value at this point in the original grid
                  VALUE = CALVAL(ARRAY(1,1),NX,NY,NZ,VALMIN,GRDSEP,
     -                X,Y,Z)

C----             Transfer the value across to the output grid
                  CALL GRDUPD(ARRAY(1,2),OUTNX,OUTNY,OUTNZ,VALUE,IX,IY,
     -                IZ)
 300          CONTINUE
 400      CONTINUE
 500  CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE CNDIST  -  Calculate distance of every grid-point from the
C                        nearest contour cross-over point
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE CNDIST(ARRAY1,ARRAY2,NX,NY,NZ,GRDSEP,IFILE)

      SAVE

CVAX      IMPLICIT NONE

      INTEGER       ADDON(3,3), I, IFILE, ILINE, IPOINT, IPT(3), ITARG,
     -              IX, IY, IZ, JX, JY, JZ, KFROM(3), KTO(3), KX, KY,
     -              KZ, NPOINT(3), NX, NY, NZ
      LOGICAL       GOTLIN(3)
      REAL          ARRAY1(NX,NY,NZ), ARRAY2(NX,NY,NZ), CX, CY, CZ,
     -              CROSS, DIFF1, DIFF2, DIST, DX, DY, DZ,  GRDSEP,
     -              PSHOW, PTARG

      DATA ADDON  / 1, 0, 0, 0, 1, 0, 0, 0, 1 /
      DATA PSHOW  / 0.05 /

C---- Initialise variables
      IPOINT = 0
      NPOINT(1) = NX
      NPOINT(2) = NY
      NPOINT(3) = NZ
      PTARG = PSHOW
      ITARG = PTARG * NX * NY * NZ

C---- Loop through the entire array
      DO 800, IZ = 1, NZ
          IPT(3) = IZ

C----     Loop over y
          DO 700, IY = 1, NY
              IPT(2) = IY

C----         Loop over x
              DO 600, IX = 1, NX

C----             Report on progress
                  IPOINT = IPOINT + 1
                  IF (IPOINT.GT.ITARG) THEN
                      PRINT 55, 100.0 * PTARG, '% done for file', IFILE
 55                   FORMAT(F8.2,A,I2)
                      PTARG = PTARG + PSHOW
                      IPOINT = 0
                  ENDIF

C----             Loop in the x-, y-, and z-directions to find any
C                 contour cross-over points in the three lines extending
C                 forwards from the current point
                  DO 500, ILINE = 1, 3

C----                 Get the point on the other end of the line
                      JX = IX + ADDON(1,ILINE)
                      JY = IY + ADDON(2,ILINE)
                      JZ = IZ + ADDON(3,ILINE)
                      IPT(1) = IX

C----                 If not off the end of the array, check if there's
C                     a cross over here
                      IF (JX.LE.NX .AND. JY.LE.NY .AND. JZ.LE.NZ) THEN

C----                     Check for cross-over
                          IF ((ARRAY2(IX,IY,IZ).LE.0.0 .AND.
     -                        ARRAY2(JX,JY,JZ).GT.0.0) .OR.
     -                        (ARRAY2(IX,IY,IZ).GT.0.0 .AND.
     -                        ARRAY2(JX,JY,JZ).LE.0.0)) THEN

C----                         Have cross-over, so compute position
C                             of cross-over point
                              DIFF1 = ABS(ARRAY2(IX,IY,IZ))
                              DIFF2 = ABS(ARRAY2(JX,JY,JZ))
                              CROSS = (DIFF1 / (DIFF1 + DIFF2))
                              IF (CROSS.GT.1.0) CROSS = 1.0

C----                         Calculate coordinates of cross-over point
                              CX = (IX + ADDON(1,ILINE) * CROSS)
                              CY = (IY + ADDON(2,ILINE) * CROSS)
                              CZ = (IZ + ADDON(3,ILINE) * CROSS)

C----                         Compute the limits for the grid-points
C                             whose distances need to be updated
                              DO 100, I = 1, 3
                                  KFROM(I) = 1
                                  KTO(I) = NPOINT(I)
 100                          CONTINUE
                              IF (ARRAY2(IX,IY,IZ).LT.ARRAY2(JX,JY,JZ))
     -                            THEN
                                  KTO(ILINE) = IPT(ILINE)
                              ELSE
                                  KFROM(ILINE) = IPT(ILINE)
                              ENDIF

C----                         Alter x-direction range, if can
                              IF (GOTLIN(ILINE) .AND.
     -                            KFROM(1).LT.IX) THEN
                                  KFROM(1) = IX
                              ENDIF

C----                         Save info that already have this line
                              GOTLIN(ILINE) = .TRUE.

C----                         Loop through all points to be updated
C                             with their distances from the current
C                             cross-over point
                              DO 400, KZ = KFROM(3), KTO(3)

C----                             Calculate z-distance
                                  DZ = (KZ - CZ) * (KZ - CZ)

C----                             Loop over y
                                  DO 300, KY = KFROM(2), KTO(2)

C----                                 Calculate y-distance
                                      DY = (KY - CY) * (KY - CY)

C----                                 Loop over x
                                      DO 200, KX = KFROM(1), KTO(1)

C----                                     Calculate total distance
                                          DX = (KX - CX) * (KX - CX)
                                          DIST = DX + DY + DZ

C----                                     If this is the smallest distance
C                                         for this grid-point so far, then
C                                         store it
                                          IF (DIST.LT.ARRAY1(KX,KY,KZ))
     -                                        THEN
                                              ARRAY1(KX,KY,KZ) = DIST
                                          ENDIF
 200                                  CONTINUE
 300                              CONTINUE
 400                         CONTINUE
                          ELSE
                              GOTLIN(ILINE) = .FALSE.
                          ENDIF
                      ELSE
                          GOTLIN(ILINE) = .FALSE.
                      ENDIF

C----             Next line from current point
 500              CONTINUE

C----         Next cell x-value
 600          CONTINUE

C----     Next cell y-value
 700      CONTINUE

C---- Next cell z-value
 800  CONTINUE

C---- Loop through all the grid-points to adjust distances
      DO 1800, IZ = 1, NZ

C----     Loop over y
          DO 1700, IY = 1, NY

C----         Loop over x
              DO 1600, IX = 1, NX

C----             Adjust the distance
                  IF (ARRAY1(IX,IY,IZ).GT.0.0) THEN
                      ARRAY1(IX,IY,IZ) = SQRT(ARRAY1(IX,IY,IZ))
                  ENDIF
 1600         CONTINUE
 1700     CONTINUE
 1800 CONTINUE

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4.2<--
C**************************************************************************
C
C  SUBROUTINE CALDIF  -   Calculate the differences in the two maps
C
C----------------------------------------------------------------------+---

      SUBROUTINE CALDIF(ARRAY,MAXARR,NX1,NY1,NZ1,NX2,NY2,NZ2,VALMIN,
CHANGE v.1.4.1-->
C     -    GRDSEP,SIMLAR,SUFACE)
CHANGE v.1.4.2-->
C     -    GRDSEP,SIMLAR,COMBIN,SUFACE)
     -    GRDSEP,SIMLAR,COMBIN,EQUIDI,SUFACE)
CHANGE v.1.4.2<--
CHANGE v.1.4.1<--

CVAX      IMPLICIT NONE

      INTEGER       MAXARR

CHANGE v.1.4.2-->
C      INTEGER       IGRID, IX, IY, IZ, JGRID, NPOINT(3,2), NX1, NX2,
C     -              NY1, NY2, NZ1, NZ2
      INTEGER       IGRID, IPOINT, IX, IY, IZ, JGRID, NPOINT(3,2),
     -              NX1, NX2, NY1, NY2, NZ1, NZ2
CHANGE v.1.4.2<--
CHANGE v.1.4.1-->
C      LOGICAL       SIMLAR, SUFACE
CHANGE v.1.4.2-->
C      LOGICAL       COMBIN, SIMLAR, SUFACE
      LOGICAL       COMBIN, EQUIDI, SIMLAR, SUFACE
CHANGE v.1.4.2<--
CHANGE v.1.4.1<--
CHANGE v.1.4.2-->
C      REAL          ARRAY(MAXARR,2), CALVAL, GRDGET, GRDSEP(2), OTHVAL,
C     -              VALUE, VALMIN(3,2), X, Y, Z
      REAL          ARRAY(MAXARR,2), CALVAL, FACTOR, GRDGET, GRDSEP(2),
     -              OTHVAL, VALUE, VALMIN(3,2), VMAX, X, Y, Z
CHANGE v.1.4.2<--

C---- Initialise variables
      NPOINT(1,1) = NX1
      NPOINT(2,1) = NY1
      NPOINT(3,1) = NZ1
      NPOINT(1,2) = NX2
      NPOINT(2,2) = NY2
      NPOINT(3,2) = NZ2
      IGRID = 1
      JGRID = 2
CHANGE v.1.4.2-->
      VMAX = 0.0
CHANGE v.1.4.2<--

C---- Loop through all the points of the first array
      DO 500, IZ = 1, NPOINT(3,IGRID)

C----     Calculate the z-coordinate of this point
          Z = (IZ - 1) * GRDSEP(IGRID) + VALMIN(3,IGRID)

C----     Loop over the y-points
          DO 400, IY = 1, NPOINT(2,IGRID)

C----         Calculate the y-coordinate of this point
              Y = (IY - 1) * GRDSEP(IGRID) + VALMIN(2,IGRID)

C----         Loop over the x-points
              DO 300, IX = 1, NPOINT(1,IGRID)

C----             Calculate the x-coordinate of this point
                  X = (IX - 1) * GRDSEP(IGRID) + VALMIN(1,IGRID)

C----             Retrieve the value at this grid-point
                  VALUE = GRDGET(ARRAY(1,IGRID),NPOINT(1,IGRID),
     -                NPOINT(2,IGRID),NPOINT(3,IGRID),IX,IY,IZ)

C----             Compute the value at this point in the other grid
                  OTHVAL = CALVAL(ARRAY(1,JGRID),NPOINT(1,JGRID),
     -                NPOINT(2,JGRID),NPOINT(3,JGRID),
     -                VALMIN(1,JGRID),GRDSEP(JGRID),X,Y,Z)

C                 If similarities between the two maps are required, then
C                 average the values
                  IF (SIMLAR) THEN

C----                 If both are surface maps, then don't want a straight
C                     average, but take higher value if both are over 100.0
C                     and lower value if either one is below 100.0
                      IF (SUFACE) THEN
                          IF (VALUE.GT.100.0 .AND. OTHVAL.GT.100.0) THEN
                              VALUE = MAX(VALUE,OTHVAL)
                          ELSE
                              VALUE = MIN(VALUE,OTHVAL)
                          ENDIF
                      ELSE
                          VALUE = (VALUE + OTHVAL) / 2.0
                      ENDIF

CHANGE v.1.4.1-->
C                 If a combined map is required, then take whichever
C                 value is the higher
                  ELSE IF (COMBIN) THEN

C----                 Take the maximum value from either map
                      VALUE = MAX(VALUE,OTHVAL)
CHANGE v.1.4.1<--

CHANGE v.1.4.2-->
C                 For an equidistant surface, subtract one map's value
C                 from the other
                  ELSE IF (EQUIDI) THEN

C----                 Subtract the map values
                      VALUE = VALUE - OTHVAL

C----                 Accumulate maximum map values for scaling at
C                     the end
                      VMAX = MAX(ABS(VALUE),VMAX)
CHANGE v.1.4.2<--

C----             Otherwise, if differences between the two maps are
C                 required, subtract the values
                  ELSE

C----                 If both are surface maps, then don't want a straight
C                     difference
                      IF (SUFACE) THEN
                          IF (VALUE.GT.100.0 .AND. OTHVAL.GT.100.0) THEN
                              VALUE = 0.0
                          ELSE IF (VALUE.LT.100.0 .AND.
     -                        OTHVAL.LT.100.0) THEN
                              VALUE = 0.0
                          ELSE IF (VALUE.LT.100.0 .AND.
     -                        OTHVAL.GT.100.0) THEN
                              VALUE = - OTHVAL
                          ENDIF
                      ELSE
                          VALUE = VALUE - OTHVAL
                      ENDIF
                  ENDIF

C----             Take the difference and update the current
C                 grid-point
                  CALL GRDUPD(ARRAY(1,IGRID),NPOINT(1,IGRID),
     -                NPOINT(2,IGRID),NPOINT(3,IGRID),VALUE,IX,IY,
     -                IZ)
 300          CONTINUE
 400      CONTINUE
 500  CONTINUE

CHANGE v.1.4.2-->
C---- For an equidistant surface, calculate the scaling factor to make
C     the values stretch from -100 to +100
      IF (EQUIDI) THEN
          IF (VMAX.NE.0.0) THEN
              FACTOR = 100.0 / VMAX
          ELSE
              FACTOR = 1.0
          ENDIF

C----     Apply the sclaing factor to all the grid points, and shift
C         by 100 so that the values range from 0 to 200
          DO 800, IPOINT = 1, NX1 * NY1 * NZ1
              ARRAY(IPOINT,IGRID) = 100.0 + FACTOR * ARRAY(IPOINT,IGRID)
 800      CONTINUE
      ENDIF
CHANGE v.1.4.2<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  REAL FUNCTION GRDGET  -   Retrieve the value of the given grid-point
C
C----------------------------------------------------------------------+---

      REAL FUNCTION GRDGET(ARRAY,NX,NY,NZ,IX,IY,IZ)

CVAX      IMPLICIT NONE

      INTEGER       NX, NY, NZ

      INTEGER       IX, IY, IZ
      REAL          ARRAY(NX,NY,NZ)

C---- Update the current point
      GRDGET = ARRAY(IX,IY,IZ)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GRDUPD  -   Update the given grid-point with the given
C                         value
C
C----------------------------------------------------------------------+---

      SUBROUTINE GRDUPD(ARRAY,NX,NY,NZ,VALUE,IX,IY,IZ)

CVAX      IMPLICIT NONE

      INTEGER       NX, NY, NZ

      INTEGER       IX, IY, IZ
      REAL          ARRAY(NX,NY,NZ), VALUE

C---- Update the current point
      ARRAY(IX,IY,IZ) = VALUE

      RETURN
      END

C--------------------------------------------------------------------------
