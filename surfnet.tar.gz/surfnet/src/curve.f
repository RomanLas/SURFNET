C**************************************************************************
C
C  CURVE.F  -  Program to generate a density array for a user-defined
C              curve of the form:
C
C              z = A * x * x + B * y * y + 2 * C * x * y
C                + D * x + E * y + F
C
C**************************************************************************
C--------------------------------------------------------------------------
C
C Program description
C -------------------
C
C Program accepts equation of a 3D curve and boundaries of a grid-box within
C which the curve is to be generated. Outputs a density map in one of
C several formats which, when displayed, produces the desired curve on the
C graphics.
C
C--------------------------------------------------------------------------
C
C Amendments
C ----------
C Amendments labelled by CHANGE v.m.n--> and CHANGE v.m.n<-- where m.n
C is the version number corresponding to the change
C
C v.1.0     Original release version.                   4 May 1995 (RAL)
C v.1.3     Addition of option on type of map to be output.
C           Addition of InsightII and Sybyl output maps.
C                                                       5 Dec 1995 (RAL)
C v.1.3.2   Bug-fix for CCP4 output: MAPRMS not defined, and routines to
C           calculate it added to GRHIST.
C                                                       6 Feb 1996 (RAL)
C
C v.1.4     Amendments to group map-generating routines together in
C           surfmaps.f.
C                                                      17 Jun 1996 (RAL)
C
C v.1.5     Addition of ellipsoid option
C                                                      15 Feb 1998 (RAL)
C
C----------------------------------------------------------------------+--- 
C
C Files
C -----
C
C 10  curve.den  - Output CCP4 density map
C 10  curve.grd  - Output InsightII grid file
C 10  curve.mbk  - Output Quanta brick file file
C 10  curve.srf  - Output .srf file holding the arrays of density
C                  values
C ??  curve.cnt  - Output Sybyl contour file
C
C--------------------------------------------------------------------------
C
C
C Compilation and linking (on unix)
C -----------------------
C
C f77 -u -c curve.f
C f77 -u -c surfmaps.f
C f77 -o curve curve.o surfmaps.o
C
C If Sybyl contour files are to be generated, uncomment all the CSYBYL
C lines in surfmaps.f and use surfsyb.scr to link to the Sybyl
C library routines.
C
C If CCP4 density maps are to be generated, uncomment all the CCP4
C lines in surfmaps.f and use surfccp4.scr to link to the CCP4
C library routines.
C
C Subroutine calling tree
C -----------------------
C
C MAIN    --> PARAMS  --> FINKEY
C                     --> GETOUT  --> FINKEY
C                     --> READCH
C                     --> OPNERR
C
C         Read in coordinates and calculate grid bounds
C
C         --> INITS
C         --> GBOUND
C
C         Form the grid and write out denisty and brick map files
C
C         --> MAKEGR  --> GRIDUP
C         --> GRSCAL
C         --> WRIMAP  --> LIMTAR
C                     --> ADJARR
C                     --> GRHIST  --> SHSORT
C                     --> WRISRF
C                     --> COMPRS
C                     --> ASCDEN  --> CCP4 routines to write out density file
C                     --> MBRICK  --> CCP4 routines to read in density files
C                                     and write out brick files (for FRODO)
C                                     [This routine is no longer used]
C                     --> INSIGH
C                     --> QUANTA  --> GETHED
C                                 --> MBRWRH
C                                 --> MRDSE8
C                     --> SYBYL   --> XCCreate
C                                 --> XCWrite
C                                 --> XCClose
C
C----------------------------------------------------------------------+--- 


      PROGRAM SRFNET

CVAX      IMPLICIT NONE

      INCLUDE 'curve.inc'

CHANGE v.1.4-->
C      INTEGER       IMAP
C      REAL          ARRAY(MAXARR)
      INTEGER       IMAP, IUNIT
      LOGICAL       RAWDAT
      REAL          ARRAY(MAXARR), MAPTOT, MFACTR
CHANGE v.1.4<--
CHANGE v.1.4-->
CHANGE v.1.3-->
CC-Sybyl-->
CCSYBYL      REAL*8        SHEET(MXSHEE)
CC-Sybyl<--
CHANGE v.1.4<--

C---- Set flags indicating which routines will be linked in during 
C     compilation
CHANGE v.1.4-->
C      FROLNK = .FALSE.
CC---- CCP4-->
CCCP4      FROLNK = .TRUE.
CC---- CCP4<--
C      SYBLNK = .FALSE.
CC-Sybyl-->
CCSYBYL      SYBLNK = .TRUE.
CC-Sybyl<--
CCHANGE v.1.3<--
      CALL INTMAP(FROLNK,SYBLNK)
CHANGE v.1.4<--

C---- Read in the run parameters
      CALL PARAMS
CHANGE v.1.4-->
C      IF (IFAIL.NE.0) GO TO 999
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--

C---- Initialise run variables
      IMAP = 1
CHANGE v.1.3-->
      FILCNT = 'curve.cnt'
      FILDEN = 'curve.den'
      FILGRD = 'curve.grd'
      FILMBK = 'curve.mbk'
      FILSRF = 'curve.srf'
CHANGE v.1.3<--
      CALL INITS

C---- Calculate grid-box boundaries
      CALL GBOUND
CHANGE v.1.4-->
C      IF (IFAIL.NE.0) GO TO 999
      IF (IFAIL) GO TO 999
CHANGE v.1.4<--

C---- Form the grid-map of density values
CHANGE v.1.4-->
C      CALL MAKEGR(ARRAY,IMAP)
      CALL MAKEGR(ARRAY)
CHANGE v.1.4<--

CHANGE v.1.4-->
C---- Apply scaling factor to all map-points
      CALL GRSCAL(ARRAY,NPOINT(1)*NPOINT(2)*NPOINT(3),'S',.FALSE.,200.0,
     -    MAPTOT)
CHANGE v.1.4<--

C---- Calculate maximum and minimum values in map
CHANGE v.1.4-->
C      CALL GRHIST(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
C
CC---- Check that density file has points to be plotted
C      IF (NOPNT) THEN
C          PRINT*, '+*** Density file empty! Not written out'
C
CC---- Write out density and brick files
C      ELSE
C
CC----     Write the array to disk as a surface density file
C          PRINT*, 'Writing surface density file ...   ', IMAP
C          CALL WRISRF(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C
CCHANGE v.1.3-->
CC----     If the  density and brick files are actually required,
CC         then call the appropriate  routines and write them out
C          IF (FROMAP) THEN
C
CC----         Write the array to disk as a CCP4 density file
CC---- CCP4-->
CCCP4              PRINT*, 'Writing CCP4 density file ...   '
CCCP4              CALL ASCDEN(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
CCCP4     -            FILDEN,TITLE,LIM,IUVW,VALMAX,
CCCP4     -            VALMIN,MAPAV,MAPMAX,MAPMIN,MAPRMS)
CC---- CCP4<--
C
CC----         Write the array to disk as a FRODO brick file [Not used. Use 
CC             routines to convert  format to FRODO format]
CCFRODO          PRINT*, 'Writing brick file ...     ', IMAP
CCFRODO          CALL MBRICK(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),IMAP)
C          ENDIF
C
CC----     If InsightII grid files are required, then write these out
C          IF (INSMAP) THEN
C
CC----         Write the array to disk as a standard formatted
CC             InsightII grid file
C              PRINT*, 'Writing InsightII grid file ...   ', IMAP
C              CALL INSIGH(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -            IMAP,FILGRD,GRDSEP,VALMIN,VALMAX)
C          ENDIF
CCHANGE v.1.3<--
C
CC----     Write the array to disk as a Quanta density file
CCHANGE v.1.3-->
C          IF (QUAMAP) THEN
CCHANGE v.1.3<--
C              PRINT*, 'Writing brick file ...   ', IMAP
C              CALL QUANTA(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3),
C     -            IMAP,FILMBK,GRDSEP,MAPAV,MAPMIN,
C     -            MAPMAX,VALMIN,VALMAX)
CCHANGE v.1.3-->
C          ENDIF
C
CC----     If Sybyl contour files are required, then write these out
C          IF (SYBMAP) THEN
C
CC----         Check that the sheet-size not larger than
CC             allowed in the parameters
C              IF (MXSHEE.GE.NPOINT(1) * NPOINT(2)) THEN
C
CC----             Write the array to disk as a Sybyl contour file
C                  PRINT*, 'Writing Sybyl contour file ...     ', IMAP
CC-Sybyl-->
CCSYBYL                  CALL SYBYL(ARRAY,NPOINT(1),NPOINT(2),
CCSYBYL     -                NPOINT(3),IMAP,FILCNT,GRDSEP,MAPAV,
CCSYBYL     -                MAPMIN,MAPMAX,VALMIN,VALMAX,SHEET,TITLE,
CCSYBYL     -                IFAIL)
CC-Sybyl<--
C
CC----         If array not large enough, display error message
C              ELSE
C                  PRINT*, '*** ERROR. Array variable MXSHEE ',
C     -                'not large enough for sheets to be'
C                  PRINT*, '*          written out to Sybyl ',
C     -                'contour file', MXSHEE, NPOINT(1) * NPOINT(2)
C              ENDIF
C          ENDIF
CCHANGE v.1.3<--
C      ENDIF

C---- Write out the array in whichever output format is required
      IFRAG = 0
      IATYPE = 0
      ICOUNT = 0
      FRGFRQ = 0.0
      IUNIT = 10
      MFACTR = 1.0
      RAWDAT = .TRUE.
      FILTYP = 'S'
      CALL WRIMAP(ARRAY,MAXARR,NPOINT,INDEXA,MAXIND,FILTYP,IMAP,IFRAG,
     -    IATYPE,ICOUNT,FRGFRQ,FILCNT,FILDEN,FILGRD,FILMBK,FILSRF,
     -    IUNIT,FROMAP,INSMAP,QUAMAP,SYBMAP,TITLE,VALMIN,VALMAX,GRDSEP,
     -    RAWDAT,MFACTR,.FALSE.,.FALSE.,NOPNT,IFAIL)
CHANGE v.1.4<--

999   CONTINUE
CHANGE v.1.4-->
C      IF (IFAIL.EQ.0) THEN
      IF (.NOT.IFAIL) THEN
CHANGE v.1.4<--
          PRINT*, '    Program completed'
      ELSE
          PRINT*, '    Program terminated with error'
      ENDIF
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE PARAMS  -  Read in the run parameters for the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE PARAMS

CVAX      IMPLICIT NONE

      INCLUDE 'curve.inc'

CHANGE v.1.3-->
      CHARACTER*1   YESNO
CHANGE v.1.3<--
      INTEGER        IPARM
      REAL           CX, CY, CZ, WX, WY, WZ

C---- Initialise variables
      CUBIC = .FALSE.
CHANGE v.1.5-->
      ELLIPS = .FALSE.
CHANGE v.1.5<--
      IFAIL = .FALSE.
      PARAB = .FALSE.
      PLANE = .FALSE.

C---- Accept type of surface to be generated
      PRINT*, 'Enter type of surface to be generated:'
      PRINT*, '   1. Plane'
      PRINT*, '   2. Paraboloid'
      PRINT*, '   3. Cubic'
CHANGE v.1.5-->
      PRINT*, '   4. Ellipsoid'
CHANGE v.1.5<--
      READ*, IPARM
      IF (IPARM.EQ.1) THEN
          PLANE = .TRUE.
          NPARM = 4
      ELSE IF (IPARM.EQ.2) THEN
          PARAB = .TRUE.
          NPARM = 6
      ELSE IF (IPARM.EQ.3) THEN
          CUBIC = .TRUE.
          NPARM = 10
CHANGE v.1.5-->
      ELSE IF (IPARM.EQ.4) THEN
          ELLIPS = .TRUE.
          NPARM = 3
CHANGE v.1.5<--
      ELSE
          GO TO 900
      ENDIF

C---- Accept input parameters
      IF (PLANE) THEN
          PRINT*, 'Enter 4 parameters defining plane: A, B, C, D'
          PRINT*, '   where eqtn of plane is:'
          PRINT*
          PRINT*, '   Ax + By + Cz = D'
          PRINT*
      ELSE IF (PARAB) THEN
          PRINT*, 'Enter 6 parameters defining curve: A, B, C, D, E, F'
          PRINT*, '   where eqtn of curve is:'
          PRINT*
          PRINT*, '         2    2'
          PRINT*, '   z = Ax + By + 2Cxy + Dx + Ey + F'
          PRINT*
      ELSE IF (CUBIC) THEN
          PRINT*, 'Enter 10 parameters defining curve: A - J'
          PRINT*, '   where eqtn of cubic is:'
          PRINT*
          PRINT*, '         2    2                         3    3' //
     -        '    2       2'
          PRINT*, '   z = Ax + By + 2Cxy + Dx + Ey + F + Gx + Hy ' //
     -        '+ Ix y + Jxy '
          PRINT*
CHANGE v.1.5-->
      ELSE IF (ELLIPS) THEN
          PRINT*, 'Enter the 3 ellipsoid semi-major axes: A, B, C'
          PRINT*, '   where eqtn of ellipsoid is:'
          PRINT*
          PRINT*, '    2        2        2        '
          PRINT*, '   x        y        z         '
          PRINT*, '   -    +   -    +   -    =   1'
          PRINT*, '    2        2        2        '
          PRINT*, '   A        B        C         '
          PRINT*
CHANGE v.1.5<--
      ENDIF
      READ*, (CURVE(IPARM), IPARM = 1, NPARM)
      IF (PLANE .AND. CURVE(3).EQ.0.0) GO TO 902
CHANGE v.1.5-->
      IF (ELLIPS .AND. (CURVE(1).EQ.0.0 .OR. CURVE(2).EQ.0.0 .OR.
     -    CURVE(3).EQ.0.0)) GO TO 904
CHANGE v.1.5<--

C---- Accept coordinates of box-centre
      PRINT*
      PRINT*, 'Enter coordinates of centre of box'
      READ*, CX, CY, CZ

C---- Accept size of box
      PRINT*
      PRINT*, 'Enter size of box in each direction'
      READ*, WX, WY, WZ

C---- Find minimum and maximum coordinates
      VALMIN(1) = CX - WX / 2.0
      VALMIN(2) = CY - WY / 2.0
      VALMIN(3) = CZ - WZ / 2.0
      VALMAX(1) = CX + WX / 2.0
      VALMAX(2) = CY + WY / 2.0
      VALMAX(3) = CZ + WZ / 2.0

C---- Accept grid-separation
      PRINT*
      PRINT*, 'Enter grid separation'
      READ*, GRDSEP

CHANGE v.1.3-->
C---- Accept which output map format is required
      FROMAP = .FALSE.
      INSMAP = .FALSE.
      QUAMAP = .FALSE.
      SYBMAP = .FALSE.
      PRINT*, 'Enter map-format required: (Q)uanta, (C)CP4, (S)ybyl',
     -    ', (I)nsightII or (N)one'
      READ(*,110) YESNO
 110  FORMAT(A)
      IF (YESNO.EQ.'Q' .OR. YESNO.EQ.'q') THEN
          QUAMAP = .TRUE.
      ELSE IF (YESNO.EQ.'I' .OR. YESNO.EQ.'i') THEN
          INSMAP = .TRUE.
      ELSE IF (YESNO.EQ.'C' .OR. YESNO.EQ.'c') THEN
          IF (FROLNK) THEN
              FROMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to  librar',
     -            'ies'
              PRINT*, '***          No  density maps will be produ',
     -            'ced'
          ENDIF
      ELSE IF (YESNO.EQ.'S' .OR. YESNO.EQ.'s') THEN
          IF (SYBLNK) THEN
              SYBMAP = .TRUE.
          ELSE
              PRINT*, '*** WARNING. Programs not linked to Sybyl libra',
     -            'ries'
              PRINT*, '***          No Sybyl contour maps will be prod',
     -            'uced'
          ENDIF
      ELSE IF (YESNO.EQ.'N' .OR. YESNO.EQ.'n') THEN
          PRINT*, '*** No map files required'
      ELSE
          PRINT*, '*** INVALID map format requested: [', YESNO, ']'
          PRINT*, '*** No map files will be written out.'
      ENDIF
CHANGE v.1.3<--

      GO TO 999

C---- Errors reading parameters      
 900  CONTINUE
CHANGE v.1.5-->
C      PRINT*, '*** Error in surface type. Should be 1-3', IPARM
      PRINT*, '*** Error in surface type. Should be 1-4', IPARM
CHANGE v.1.5<--
      GO TO 990

 902  CONTINUE
      PRINT*, '*** Unable to generate a plane if C = 0.0'
      GO TO 990

CHANGE v.1.5-->
 904  CONTINUE
      PRINT*, '*** Unable to generate ellipsoid if A, B or C = 0.0'
      GO TO 990
CHANGE v.1.5<--

 990  CONTINUE
      IFAIL = .TRUE.

 999  CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE INITS  -  Initialise parameters used in the program
C
C----------------------------------------------------------------------+--- 

      SUBROUTINE INITS

CVAX      IMPLICIT NONE

      INCLUDE 'curve.inc'

C---- Initialise variables
      RADIUS = GRDSEP
      KVALUE = - LOG (0.5) / (RADIUS * RADIUS)

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GBOUND  -   Calculate boundaries for grid box
C
C--------------------------------------------------------------------------

      SUBROUTINE GBOUND

CVAX      IMPLICIT NONE

      INCLUDE 'curve.inc'
          
      INTEGER       ARSIZE, ICOORD, LOWER, UPPER
CHANGE v.1.4-->
C      LOGICAL       FIRST
CHANGE v.1.4<--
      REAL          RESD(3)

CHANGE v.1.4-->
C      DATA  FIRST / .TRUE./
CHANGE v.1.4<--

C---- Print boundaries entered by user
      PRINT 620, 'Min coords:         ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
      PRINT 620, 'Max coords:         ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      ARSIZE = 1

C---- Calculate the array size for the grid
      DO 600, ICOORD = 1, 3
          LOWER = 2 * ICOORD - 1
          UPPER = LOWER + 1

C----     Calculate lowest grid value for this coordinate
          LIM(LOWER) = INT(VALMIN(ICOORD) / GRDSEP)
          IF (VALMIN(ICOORD).GT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) + 1
          ELSE IF (VALMIN(ICOORD).LT.0.0) THEN
              LIM(LOWER) = LIM(LOWER) - 1
          ENDIF
          IF (GAPMAP) LIM(LOWER) = LIM(LOWER) - IRANGE

C----     Calculate upper grid value for this coordinate
          LIM(UPPER) = INT(VALMAX(ICOORD) / GRDSEP)
          IF (VALMAX(ICOORD).GT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) + 1
          ELSE IF (VALMAX(ICOORD).LT.0.0) THEN
              LIM(UPPER) = LIM(UPPER) - 1
          ENDIF
          IF (GAPMAP) LIM(UPPER) = LIM(UPPER) + IRANGE
      
C----     Calculate number of grid points required for this coordinate
          NPOINT(ICOORD) = LIM(UPPER) - LIM(LOWER) + 1
          ARSIZE = ARSIZE * NPOINT(ICOORD)
      
C----     Adjust the minimum and maximum values to correspond to the
C         grid limits
          VALMIN(ICOORD) = LIM(LOWER) * GRDSEP
          VALMAX(ICOORD) = LIM(UPPER) * GRDSEP
          RESD(ICOORD) = VALMAX(ICOORD) - VALMIN(ICOORD)
600   CONTINUE

C---- Check that array is not too large
      IF (ARSIZE.GT.MAXARR) THEN
          PRINT*, '*** Array required:', ARSIZE, '   is larger',
     -            ' than that allowed:', MAXARR
          PRINT*, '     Grid points:', (NPOINT(ICOORD), ICOORD = 1, 3)
          GO TO 990
      ENDIF
      VOLBOX = RESD(1) * RESD(2) * RESD(3)
      PRINT 620, 'Adjusted min:       ',
     -    (VALMIN(ICOORD), ICOORD = 1, 3)
 620  FORMAT(1X,A,3F12.4)
      PRINT 620, 'Adjusted max:       ',
     -    (VALMAX(ICOORD), ICOORD = 1, 3)
      PRINT*
      PRINT 640, 'Grid separation:    ', GRDSEP
 640  FORMAT(1X,A,F12.4)
      PRINT*
      PRINT 660, 'Length:             ',
     -    (RESD(ICOORD), ICOORD = 1, 3), 'Volume:         ',
     -     VOLBOX
 660  FORMAT(1X,A,3F12.4,/,1X,A,F16.2)
      PRINT 680, NPOINT(1), NPOINT(2), NPOINT(3), ARSIZE
 680  FORMAT(/,1X,'Array size: ',I8,'  x',I8,'  x',I8,'  = ',I8,
     -    ' points',/) 
      GO TO 999

C---- Error conditions
CHANGE v.1.4-->
C 900  CONTINUE
C      PRINT*, '*** No atoms found to define grid boundary. Range ',
C     -    'given:', BOUNAT(1), '    to', BOUNAT(2)
C      GO TO 990
CHANGE v.1.4<--

990   CONTINUE
CHANGE v.1.4-->
C      IFAIL = 1
      IFAIL = .TRUE.
CHANGE v.1.4<--

999   CONTINUE
      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE MAKEGR  -  Form the grid of values
C
C--------------------------------------------------------------------------

CHANGE v.1.4-->
C      SUBROUTINE MAKEGR(ARRAY,IMAP)
      SUBROUTINE MAKEGR(ARRAY)
CHANGE v.1.4<--

CVAX      IMPLICIT NONE

      INCLUDE 'curve.inc'

CHANGE v.1.4-->
C      INTEGER       I, IMAP
      INTEGER       I
CHANGE v.1.4<--
      REAL          ARRAY(MAXARR)
          
C---- Initialise grid array
      DO 10, I = 1, MAXARR
          ARRAY(I) = 0.0
10    CONTINUE
      GRPTS = 0
      PRINT*
      PRINT*, 'Calculating density map ...'

C---- Loop through all the grid-points updating each one according to
C     distance from the curve
CHANGE v.1.4-->
C      CALL GRID(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
      CALL GRIDUP(ARRAY,NPOINT(1),NPOINT(2),NPOINT(3))
CHANGE v.1.4<--

      RETURN
      END

C--------------------------------------------------------------------------
C**************************************************************************
C
C  SUBROUTINE GRIDUP  -  Update the grid-points in the vicinity of the current
C                        atom using a Gaussian weighting scheme
C
C----------------------------------------------------------------------+--- 

CHANGE v.1.4-->
C      SUBROUTINE GRID(ARRAY,N1,N2,N3)
      SUBROUTINE GRIDUP(ARRAY,N1,N2,N3)
CHANGE v.1.4<--

CVAX      IMPLICIT NONE

      INCLUDE 'curve.inc'
          
      INTEGER       IX, IY, IZ, N1, N2, N3
CHANGE v.1.5-->
C      REAL          A, ADJUST, ARRAY(N1,N2,N3), B, C, CONST, D, DIST,
C     -              E, F, G, H, I, J, RAD, X, Y, Z, ZCALC
      LOGICAL       UNDEFN
      REAL          A, A2, ADJUST, ARRAY(N1,N2,N3), B, B2, C, C2, CONST,
     -              D, DIST, E, F, G, H, I, J, RAD, X, X2, Y, Y2, Z,
     -              ZCALC
CHANGE v.1.5<--

C---- Initialise variables
      A = CURVE(1)
      B = CURVE(2)
      C = CURVE(3)
      D = CURVE(4)
      E = CURVE(5)
      F = CURVE(6)
      G = CURVE(7)
      H = CURVE(8)
      I = CURVE(9)
      J = CURVE(10)
      CONST = - KVALUE
      RAD = RADIUS
CHANGE v.1.5-->
      A2 = A * A
      B2 = B * B
      C2 = C * C
CHANGE v.1.5<--

C---- Loop in y-direction
      DO 400, IY = 1, N2
          Y = VALMIN(2) + (IY - 1) * GRDSEP
CHANGE v.1.5-->
          Y2 = Y * Y
CHANGE v.1.5<--

C----     Loop in x-direction
          DO 300, IX = 1, N1
              X = VALMIN(1) + (IX - 1) * GRDSEP
CHANGE v.1.5-->
              X2 = X * X
              UNDEFN = .FALSE.
CHANGE v.1.5<--

C----         Calculate z-coordinate of this point
              IF (PLANE) THEN
                  ZCALC = (D - A * X - B * Y) / C
              ELSE IF (PARAB) THEN
                  ZCALC = A * (X * X) + B * (Y * Y)
     -                + 2.0 * C * (X * Y)
     -                + D * X + E * Y + F
              ELSE IF (CUBIC) THEN
                  ZCALC = A * (X * X) + B * (Y * Y)
     -                + 2.0 * C * (X * Y)
     -                + D * X + E * Y + F
     -                + G * (X * X * X) + H * (Y * Y * Y)
     -                + I * (X * X * Y) + J * (X * Y * Y)
CHANGE v.1.5-->
              ELSE IF (ELLIPS) THEN
                  ZCALC = C2 - C2 * (X2 / A2 + Y2 / B2)
                  IF (ZCALC.GT.0.0) THEN
                      ZCALC = SQRT(ZCALC)
                  ELSE
                      ZCALC = 0.0
                      UNDEFN = .TRUE.
                  ENDIF
CHANGE v.1.5<--
              ENDIF

C----         Loop through the points in the z-direction
              DO 200, IZ = 1, N3
                  Z = VALMIN(3) + (IZ - 1) * GRDSEP

CHANGE v.1.5-->
C----             For ellipsoid, determine whether point lies inside
C                 or outside the surface (ie within +/- ZCALC)
                  IF (ELLIPS) Z = ABS(Z)
CHANGE v.1.5<--

C----             Calculate distance of point from surface
                  DIST = Z - ZCALC

C----             If distance less than minus "width", set to high
                  IF (DIST.LE.-4.0 * RADIUS) THEN
                      ADJUST = 1.0
                  ELSE IF (DIST.GT.4.0 * RADIUS) THEN
                      ADJUST = 0.0
                  ELSE
                      ADJUST = 0.5 * EXP (CONST * DIST * DIST)
                      IF (DIST.LT.0.0) ADJUST = 1.0 - ADJUST
                  ENDIF

CHANGE v.1.5-->
C----             If z-value undefined at this point, then no adjustment
C                 to be made
                  IF (UNDEFN) ADJUST = 0.0
CHANGE v.1.5<--

C----             Update grid point
                  ARRAY(IX,IY,IZ) = ADJUST
200           CONTINUE
300       CONTINUE
400   CONTINUE

      RETURN
      END

C--------------------------------------------------------------------------
CHANGE v.1.4-->
C Subroutines WRISRF & GRHIST amended and moves to surfmaps.f
C Subroutine WRIMSK removed as not used
CHANGE v.1.4<--
CHANGE v.1.3-->
CHANGE v.1.4-->
C Subroutine INSIGH moved to surfmaps.f
CHANGE v.1.4<--
CHANGE v.1.3<--
